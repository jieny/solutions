Yis Solutions update history

<br>
<br>
Release Date: 10/22/2024
Version: 1.0.0.4
<br>
-------------------------------------------
<br>
Added Windows 11 24H2 autonomous driving solutions, packaging tutorials, video tutorials, rules, etc. * New
<br>
Added Windows Server 2025 autonomous driving solutions, rules, etc. * New
<br>
Windows 11 22H2: Obsolete ones removed * Del"
<br>
Windows 11 23H2: Update packaging tutorial and update the binding area when installing InBox Apps applications
<br>
InBox Apps: Add region tags during installation * New
<br>
InBox Apps: Allow automatic combination of dependent packages during installation * New

<br>
<br>
<br>
Release Date: 5/10/2024
Version: 1.0.0.3
<br>
-------------------------------------------
<br>
Delete the solution creation upgrade package function, create upgrade packages and merge them into backup functions

<br>
<br>
<br>
Release Date: 4/18/2024
Version: 1.0.0.2
<br>
-------------------------------------------
<br>
Fix the problem encountered when reopening the script when specifying the mount path *Fix
<br>
When obtaining the disk, when encountering the disk format REFS, you can optionally exclude *New"

<br>
<br>
<br>
Release Date: 4/5/2024
Version: 1.0.0.1
<br>
-------------------------------------------
<br>
- Added [ Yi -CT ] to create template function *New

<br>
<br>
<br>
Release Date: 3/22/2024

Version: 1.0.0.0
