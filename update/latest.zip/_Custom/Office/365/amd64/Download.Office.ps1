﻿<#
    .SYNOPSIS
    Office Download

	.DESCRIPTION
    Office Download ( ODT )

	.Author
	Yi ( https://fengyi.tel )

	.Version
	v1.0
#>

if (Test-Path "$($PSScriptRoot)\..\..\Setup.exe" -PathType Leaf) {
	Write-Host "`n   Discover the ODT tool" -ForegroundColor Green
} else {
	write-host "   - No ODT tool found" -ForegroundColor Red
	
	$Parameters = @{
		Uri              = "https://www.microsoft.com/en-us/download/confirmation.aspx?id=49117"
		UseBasicParsing  = $true
	}
	$ODTURL = ((Invoke-WebRequest @Parameters).Links | Where-Object {$_.outerHTML -match "click here to download manually"}).href
	$Parameters = @{
		Uri             = $ODTURL
		OutFile         = "$PSScriptRoot\officedeploymenttool.exe"
		UseBasicParsing = $true
		Verbose         = $true
	}
	Invoke-WebRequest @Parameters

	# Expand officedeploymenttool.exe
	Start-Process "$PSScriptRoot\officedeploymenttool.exe" -ArgumentList "/quiet /extract:`"$PSScriptRoot\officedeploymenttool`"" -Wait

	$Parameters = @{
		Path        = "$PSScriptRoot\officedeploymenttool\setup.exe"
		Destination = "$PSScriptRoot"
		Force       = $true
	}
	Move-Item @Parameters

	Start-Sleep -Seconds 1

	Remove-item -Path "$PSScriptRoot\officedeploymenttool", "$PSScriptRoot\officedeploymenttool.exe" -Recurse -Force
}

if (Test-Path "$($PSScriptRoot)\..\..\Setup.exe" -PathType Leaf) {
	Write-Host "`n   $($PSScriptRoot)\Download.x64.xml" -ForegroundColor Green
	if (Test-Path "$($PSScriptRoot)\Download.x64.xml" -PathType Leaf) {
		start-process "$($PSScriptRoot)\..\..\Setup.exe" -ArgumentList "/Download $($PSScriptRoot)\Download.x64.xml" -wait -WindowStyle Hidden
	} else {
		write-host "   - No configuration file found" -ForegroundColor Red
	}
} else {
	write-host "   - No ODT tool found" -ForegroundColor Red
}