﻿<#
    .SYNOPSIS
	 Office Download

	.DESCRIPTION
     Office Download ( ODT )

	.Author
	 Yi ( https://fengyi.tel )

	.Version
	 v1.0
#>

if (Test-Path "$($PSScriptRoot)\..\..\Setup.exe" -PathType Leaf) {
	Write-Host "`n   Discover the ODT tool" -ForegroundColor Green
	Write-Host "`n   $($PSScriptRoot)\Download.x86.xml" -ForegroundColor Green
	if (Test-Path "$($PSScriptRoot)\Download.x86.xml" -PathType Leaf) {
		start-process "$($PSScriptRoot)\..\..\Setup.exe" -ArgumentList "/Download $($PSScriptRoot)\Download.x86.xml" -wait -WindowStyle Hidden
	} else {
		write-host "   - No configuration file found" -ForegroundColor Red
	}
} else {
	write-host "   - No ODT tool found" -ForegroundColor Red
}