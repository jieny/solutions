﻿<#
	.SYNOPSIS
	 Office silent installation

	.DESCRIPTION
	 Office silent installation, automatic framework recognition

	.Author
	 Yi ( https://fengyi.tel )

	.Version
	 v1.7
#>

<#
	.Available languages
	.可用语言

	.Sorting rules: group type, regional language, short name, region name, time region
	.排序规则：分组类型、区域语言、短名称、区域名称、时间区域

	.Group type: 1. Language pack; 2. Language interface pack (LIP)
	.分组类型：1、语言包；2、语言界面包（LIP）

	.Starting from Windows 11, five new types have been added, totaling 43 types ( ca-ES, eu-ES, gl-ES, id-ID, vi-VN )
	.从 Windows 11 开始，新增五种，共计 43 种（ca-ES、eu-ES、gl-ES、id-ID、vi-VN）

	https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/available-language-packs-for-windows?view=windows-11
	https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/default-time-zones?view=windows-11
#>
$Global:AvailableLanguages = @(
	<#
           Language/region decimal ID
                    Language/region tag
                                      ISO3166            Language/region                                   Timezone                             LIP ID
	#>
	("1",  "1025",  "ar-SA",          "ar",              "Arabic - Saudi Arabia",                          "Argentina Standard Time",           "9N4S78P86PKX"),
	("1",  "1026",  "bg-BG",          "bg",              "Bulgarian (Bulgaria)",                           "FLE Standard Time",                 "9MX54588434F"),
	("1",  "2052",  "zh-CN",          "cn",              "Chinese - China",                                "China Standard Time",               "9NRMNT6GMZ70"),
	("1",  "1028",  "zh-TW",          "tw",              "Chinese - Taiwan",                               "Taipei Standard Time",              "9PCJ4DHCQ1JQ"),
	("1",  "1050",  "hr-HR",          "hr",              "Croatian (Croatia)",                             "Central European Standard Time",    "9NW01VND4LTW"),
	("1",  "1029",  "cs-CZ",          "dz",              "Czech (Czech Republic)",                         "W. Central Africa Standard Time",   "9P3WXZ1KTM7C"),
	("1",  "1030",  "da-DK",          "dk",              "Danish (Denmark)",                               "Romance Standard Time",             "9NDMT2VKSNL1"),
	("1",  "1043",  "nl-NL",          "nl",              "Dutch - Netherlands",                            "W. Europe Standard Time",           "9PF1C9NB5PRV"),
	("1",  "1033",  "en-US",          "en",              "English - United States",                        "Pacific Standard Time",             "9PDSCC711RVF"),
	("1",  "2057",  "en-GB",          "gb",              "English - Great Britain",                        "GMT Standard Time",                 "9NT52VQ39BVN"),
	("1",  "1061",  "et-EE",          "ee",              "Estonian (Estonia)",                             "FLE Standard Time",                 "9NFBHFMCR30L"),
	("1",  "1035",  "fi-FI",          "fi",              "Finnish (Finland)",                              "FLE Standard Time",                 "9MW3PQ7SD3QK"),
	("1",  "3084",  "fr-CA",          "ca",              "French - Canada",                                "Eastern Standard Time",             "9MTP2VP0VL92"),
	("1",  "1036",  "fr-FR",          "fr",              "French - France",                                "Central European Time",             "9NHMG4BJKMDG"),
	("1",  "1031",  "de-DE",          "de",              "German - Germany",                               "W. Europe Standard Time",           "9P6CT0SLW589"),
	("1",  "1032",  "el-GR",          "gr",              "Greek (Greece)",                                 "GTB Standard Time",                 "9N586B13PBLD"),
	("1",  "1037",  "he-IL",          "il",              "Hebrew (Israel)",                                "Israel Standard Time",              "9NB6ZFND5HCQ"),
	("1",  "1038",  "hu-HU",          "hu",              "Hungarian (Hungary)",                            "Central Europe Standard Time",      "9MWN3C58HL87"),
	("1",  "1040",  "it-IT",          "it",              "Italian - Italy",                                "W. Europe Standard Time",           "9P8PQWNS6VJX"),
	("1",  "1041",  "ja-JP",          "jp",              "Japanese (Japan)",                               "Tokyo Standard Time",               "9N1W692FV4S1"),
	("1",  "1042",  "ko-KR",          "kr",              "Korean (Korea)",                                 "Korea Standard Time",               "9N4TXPCVRNGF"),
	("1",  "1062",  "lv-LV",          "lv",              "Latvian (Latvia)",                               "FLE Standard Time",                 "9N5CQDPH6SQT"),
	("1",  "1063",  "lt-LT",          "lt",              "Lithuanian (Lithuania)",                         "FLE Standard Time",                 "9NWWD891H6HN"),
	("1",  "1044",  "nb-NO",          "no",              "Norwegian (Bokm?l) (Norway)",                    "W. Europe Standard Time",           "9N6J0M5DHCK0"),
	("1",  "1045",  "pl-PL",          "pl",              "Polish (Poland)",                                "Central European Standard Time",    "9NC5HW94R0LD"),
	("1",  "1046",  "pt-BR",          "br",              "Portuguese - Brazil",                            "E. South America Standard Time",    "9P8LBDM4FW35"),
	("1",  "2070",  "pt-PT",          "pt",              "Portuguese - Portugal",                          "GMT Standard Time",                 "9P7X8QJ7FL0X"),
	("1",  "1048",  "ro-RO",          "ro",              "Romanian (Romania)",                             "GTB Standard Time",                 "9MWXGPJ5PJ3H"),
	("1",  "1049",  "ru-RU",          "ru",              "Russian (Russia)",                               "Russian Standard Time",             "9NMJCX77QKPX"),
	("1",  "1051",  "sk-SK",          "sk",              "Slovak (Slovakia)",                              "Central Europe Standard Time",      "9N7LSNN099WB"),
	("1",  "1060",  "sl-SI",          "si",              "Slovenian (Slovenia)",                           "Central Europe Standard Time",      "9NV27L34J4ST"),
	("1",  "2058",  "es-MX",          "mx",              "Spanish (Mexico)",                               "Central Standard Time (Mexico)",    "9N8MCM1X3928"),
	("1",  "3082",  "es-ES",          "es-ES",           "Spanish (Castilian)",                            "Romance Standard Time",             "9NWVGWLHPB1Z"),
	("1",  "1053",  "sv-SE",          "se",              "Swedish (Sweden)",                               "W. Europe Standard Time",           "9P0HSNX08177"),
	("1",  "1054",  "th-TH",          "th",              "Thai (Thailand)",                                "SE Asia Standard Time",             "9MSTWFRL0LR4"),
	("1",  "1055",  "tr-TR",          "tr",              "Turkish (Turkey)",                               "Turkey Standard Time",              "9NL1D3T5HG9R"),
	("1",  "1058",  "uk-UA",          "ua",              "Ukrainian (Ukraine)",                            "FLE Standard Time",                 "9PPPMZRSGHR8"),
	("1",  "1027",  "ca-es",          "ca-es",           "Catalan (Spain)",                                "Romance Standard Time",             "9P6JMKJQZ9S7"),
	("1",  "1069",  "eu-es",          "eu-es",           "Basque (Spain)",                                 "Romance Standard Time",             "9NMCHQHZ37HZ"),
	("1",  "1110",  "gl-es",          "gl",              "Galician (Spain)",                               "Greenland Standard Time",           "9NXRNBRNJN9B"),
	("1",  "1057",  "id-id",          "id",              "Indonesian (Indonesia)",                         "SE Asia Standard Time",             "9P4X3N4SDK8P"),
	("1",  "1066",  "vi-vn",          "vi-vn",           "Vietnamese (Viet Nam)",                          "SE Asia Standard Time",             "9P0W68X0XZPT"),
	("1",  "9242",  "sr-latn-rs",     "sr-latn-rs",      "Serbian (Latin, Serbia)",                        "Central Europe Standard Time",      "9NBZ0SJDPPVT"),

	<#
		.Language Interface Pack (LIP)
		.语言界面包 (LIP)
	#>
	("2",  "1078",  "af-za",          "af",              "Afrikaans (South Africa)",                       "Afghanistan Standard Time",         "9PDW16B5HMXR"),
	("2",  "1118",  "am-et",          "am-et",           "Amharic (Ethiopia)",                             "E. Africa Standard Time",           "9NGL4R61W3PL"),
	("2",  "1101",  "as-in",          "as-in",           "Assamese (India)",                               "India Standard Time",               "9NTJLXMXX35J"),
	("2",  "1068",  "az-latn-az",     "az-latn-az",      "Azerbaijan",                                     "Azerbaijan Standard Time",          "9P5TFKZHQ5K8"),
	("2",  "1059",  "be-by",          "be-by",           "Belarusian (Belarus)",                           "W. Central Africa Standard Time",   "9MXPBGNNDW3L"),
	("2",  "2117",  "bn-bd",          "bn-bd",           "Bangla (Bangladesh)",                            "Bangladesh Standard Time",          "9PH7TKVXGGM8"),
	("2",  "1093",  "bn-in",          "bn-in",           "Bangla (India)",                                 "India Standard Time",               "9P1M44L7W84T"),
	("2",  "5146",  "bs-latn-ba",     "bs-latn-ba",      "Bosnian (Latin)",                                "Central European Standard Time",    "9MVFKLJ10MFL"),
	("2",  "2051",  "ca-es-valencia", "ca-es-valencia",  "Valencian",                                      "Romance Standard Time",             "9P9K3WMFSW90"),
	("2",  "1116",  "chr-cher-us",    "chr-cher-us",     "Cherokee",                                       "Central Standard Time (Mexico)",    "9MX15485N3RK"),
	("2",  "1106",  "cy-gb",          "cy",              "Welsh (United Kingdom)",                         "E. Europe Standard Time",           "9NKJ9TBML4HB"),
	("2",  "1065",  "fa-ir",          "fa",              "Farsi (Iran)",                                   "Iran Standard Time",                "9NGS7DD4QS21"),
	("2",  "1124",  "fil-ph",         "fil-ph",          "Filipino",                                       "Singapore Standard Time",           "9NWM2KGTDSSS"),
	("2",  "2108",  "ga-ie",          "ga-ie",           "Irish (Ireland)",                                "GMT Standard Time",                 "9P0L5Q848KXT"),
	("2",  "1169",  "gd-gb",          "gd-gb",           "Scottish Gaelic",                                "GMT Standard Time",                 "9P1DBPF36BF3"),
	("2",  "1095",  "gu-in",          "gu",              "Gujarati (India)",                               "West Pacific Standard Time",        "9P2HMSWDJDQ1"),
	("2",  "1128",  "ha-latn-ng",     "ha-latn-ng",      "Hausa (Latin, Nigeria)",                         "W. Central Africa Standard Time",   "9N1L95DBGRG3"),
	("2",  "1081",  "hi-in",          "hi",              "Hindi (India)",                                  "India Standard Time",               "9NZC3GRX8LD3"),
	("2",  "1067",  "hy-am",          "hy",              "Armenian (Armenia)",                             "Caucasus Standard Time",            "9NKM28TM6P67"),
	("2",  "1136",  "ig-ng",          "ig-ng",           "Igbo (Nigeria)",                                 "W. Central Africa Standard Time",   "9PG4ZFJ48JSX"),
	("2",  "1039",  "is-is",          "is",              "Icelandic (Iceland)",                            "Greenwich Standard Time",           "9NTHJR7TQXX1"),
	("2",  "1079",  "ka-ge",          "ka",              "Georgian (Georgia)",                             "Greenwich Standard Time",           "9P60JZL05WGH"),
	("2",  "1087",  "kk-kz",          "kk",              "Kazakh (Kazakhstan)",                            "Central Asia Standard Time",        "9PHV179R97LV"),
	("2",  "1107",  "km-kh",          "km-kh",           "Khmer (Cambodia)",                               "SE Asia Standard Time",             "9PGKTS4JS531"),
	("2",  "1099",  "kn-in",          "kn",              "Kannada (India)",                                "SA Western Standard Time",          "9NC6DB7N95F9"),
	("2",  "1111",  "kok-in",         "kok",             "Konkani (India)",                                "India Standard Time",               "9MV3P55CMZ6P"),
	("2",  "1170",  "ku-arab-iq",     "ku-arab-iq",      "Central Kurdish",                                "Arabic Standard Time",              "9P1C18QL3D7H"),
	("2",  "1088",  "ky-kg",          "ky",              "Kyrgyz (Kyrgyzstan)",                            "SA Pacific Standard Time",          "9P7D3JJGZM48"),
	("2",  "1134",  "lb-lu",          "lb-lu",           "Luxembourgish (Luxembourg)",                     "W. Europe Standard Time",           "9N0ST1WBZ9D9"),
	("2",  "1108",  "lo-la",          "lo-la",           "Lao (Laos)",                                     "SE Asia Standard Time",             "9N8X352G5NZV"),
	("2",  "1153",  "mi-nz",          "mi",              "Maori (New Zealand)",                            "New Zealand Standard Time",         "9P2GDFB3JPSX"),
	("2",  "1071",  "mk-mk",          "mk",              "FYRO Macedonian",                                "Central European Standard Time",    "9P1X6XB1K3RN"),
	("2",  "1100",  "ml-in",          "ml-in",           "Malayalam (India)",                              "Central European Standard Time",    "9NWDTV8FFV7L"),
	("2",  "1104",  "mn-mn",          "mn",              "Mongolian (Mongolia)",                           "Ulaanbaatar Standard Time",         "9PG1DHC4VTZW"),
	("2",  "1102",  "mr-in",          "mr",              "Marathi (India)",                                "Greenwich Standard Time",           "9MWXCKHJVR1J"),
	("2",  "1086",  "ms-my",          "ms-my",           "Malay (Malaysia)",                               "Singapore Standard Time",           "9NPXL8ZSDDQ7"),
	("2",  "1082",  "mt-mt",          "mt",              "Maltese (Malta)",                                "W. Europe Standard Time",           "9PDG96SQ6BN8"),
	("2",  "1121",  "ne-np",          "ne-np",           "Nepali (Federal Democratic Republic of Nepal)",  "Nepal Standard Time",               "9P7CHPLWDQVN"),
	("2",  "2068",  "nn-no",          "nn-no",           "Norwegian (Nynorsk) (Norway)",                   "W. Europe Standard Time",           "9PK7KM3Z06KH"),
	("2",  "1132",  "nso-za",         "nso-za",          "Sesotho sa Leboa (South Africa)",                "South Africa Standard Time",        "9NS49QLX5CDV"),
	("2",  "1096",  "or-in",          "or-in",           "Odia (India)",                                   "India Standard Time",               "9NTHCXCXSJDH"),
	("2",  "2118",  "pa-arab-pk",     "pa-arab-pk",      "Punjabi (Arabic, Pakistan)",                     "Pakistan Standard Time",            "9NJRL03WH6FM"),
	("2",  "1094",  "pa-in",          "pa",              "Punjabi (India)",                                "SA Pacific Standard Time",          "9NSNC0ZJX69B"),
	("2",  "1164",  "prs-af",         "prs-af",          "Dari",                                           "SA Pacific Standard Time",          "9P3NGC6X5ZQC"),
	("2",  "1158",  "quc-latn-gt",    "quc-latn-gt",     "K'iche' (Guatemala)",                            "Central America Standard Time",     "9P2V6MNNQZ0B"),
	("2",  "3179",  "quz-pe",         "quz-pe",          "Quechua (Peru)",                                 "SA Pacific Standard Time",          "9NHTX8NVQ04K"),
	("2",  "1159",  "rw-rw",          "rw-rw",           "Kinyarwanda",                                    "South Africa Standard Time",        "9NFW0M20H9WG"),
	("2",  "2137",  "sd-arab-pk",     "sd-arab-pk",      "Sindhi (Arabic)",                                "Pakistan Standard Time",            "9NB9JSCXW9X5"),
	("2",  "1115",  "si-lk",          "si-lk",           "Sinhala (Sri Lanka)",                            "Sri Lanka Standard Time",           "9NVF9QSLGTL0"),
	("2",  "1052",  "sq-al",          "sq",              "Albanian (Albania)",                             "Central Europe Standard Time",      "9MWLRGNMDGK7"),
	("2",  "7194",  "sr-cyrl-ba",     "sr-cyrl-ba",      "Serbian (Cyrillic, Bosnia and Herzegovina)",     "Central European Standard Time",    "9MXGN7V65C7B"),
	("2",  "10266", "sr-cyrl-rs",     "sr-cyrl-rs",      "Serbian (Cyrillic, Serbia)",                     "Central Europe Standard Time",      "9PPD6CCK9K5H"),
	("2",  "1089",  "sw-ke",          "sw-ke",           "Kiswahili (Kenya)",                              "E. Africa Standard Time",           "9NFF2M19DQ55"),
	("2",  "1097",  "ta-in",          "ta-in",           "Tamil (India)",                                  "India Standard Time",               "9PDZB1WT1B34"),
	("2",  "1098",  "te-in",          "te-in",           "Telugu (India)",                                 "India Standard Time",               "9PMQJJGF63FW"),
	("2",  "1064",  "tg-cyrl-tj",     "tg-cyrl-tj",      "Tajik (Cyrillic)",                               "West Asia Standard Time",           "9MZHLBPPT2HC"),
	("2",  "1139",  "ti-et",          "ti-et",           "Tigrinya",                                       "E. Africa Standard Time",           "9NC8C9RDNK2S"),
	("2",  "1090",  "tk-tm",          "tk-tm",           "Turkmen",                                        "West Asia Standard Time",           "9NKHQ4GL6VLT"),
	("2",  "1074",  "tn-za",          "tn-za",           "Tswana (South Africa)",                          "South Africa Standard Time",        "9NFSXM123DHT"),
	("2",  "1092",  "tt-ru",          "tt-ru",           "Tatar (Russia)",                                 "Russian Standard Time",             "9NV90Q1X1ZR2"),
	("2",  "1152",  "ug-cn",          "ug-cn",           "Uyghur",                                         "E. Africa Standard Time",           "9P52C5D7VL5S"),
	("2",  "1056",  "ur-pk",          "ur-pk",           "Urdu (Islamic Republic of Pakistan)",            "Pakistan Standard Time",            "9NDWFTFW12BQ"),
	("2",  "1091",  "uz-latn-uz",     "uz-latn-uz",      "Uzbek (Latin)",                                  "West Asia Standard Time",           "9P5P2T5P5L9S"),
	("2",  "1160",  "wo-sn",          "wo-sn",           "Wolof",                                          "Greenwich Standard Time",           "9NH3SW1CR90F"),
	("2",  "1076",  "xh-za",          "xh-za",           "Xhosa (South Africa)",                           "South Africa Standard Time",        "9NW3QWSLQD17"),
	("2",  "1130",  "yo-ng",          "yo-ng",           "Yoruba (Nigeria)",                               "W. Central Africa Standard Time",   "9NGM3VPPZS5V"),
	("2",  "1130",  "zu-za",          "zu-za",           "Zulu (South Africa)",                            "South Africa Standard Time",        "9NNRM7KT5NB0")
)

<#
	.Installation processing
	.安装处理
#>
Function Install-Process
{
	param
	(
		[string]$Version,
		[switch]$Activation,
		[switch]$Cleanup,
		[switch]$Force
	)

	$Global:UILanguage = (Get-Culture).Name
	$Global:OfficeSP = Convert-Path "$($PSScriptRoot)" -ErrorAction SilentlyContinue

	<#
		.部署前，获取已知语言并同步至配置文件

		.获取已安装的语言包
	#>
	$GetKnownLanguages = @()
	$GetAddedLanguage = @()
	$TempOfficeLanguage = @()
	Get-ChildItem "$($PSScriptRoot)\Data" -directory -ErrorAction SilentlyContinue | Foreach-Object {
		for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
			Get-ChildItem -Path $_.FullName -Filter "*$($Global:AvailableLanguages[$i][2])*" -Include *.dat -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				if (Test-Path -Path $_.FullName -PathType Leaf) {
					$GetKnownLanguages += $($Global:AvailableLanguages[$i][2])
				}
			}
		}
	}

	<#
		.Get the default language of the current operating system
		.获取当前操作系统默认语言
	#>
	Write-Host "`n   Main language: $($Global:UILanguage)"
	if (($GetKnownLanguages) -Contains $Global:UILanguage) {
		$GetAddedLanguage += $Global:UILanguage
		$TempOfficeLanguage += "			<Language ID=""$($Global:UILanguage)"" />`n"
	} else {
		if (($GetKnownLanguages) -Contains "en-US") {
			$GetAddedLanguage += "en-US"
			$TempOfficeLanguage += "			<Language ID=""en-US"" />`n"
		}
	}

	foreach ($item in $GetKnownLanguages) {
		if (($GetAddedLanguage) -notcontains $item) {
			$GetAddedLanguage += $item
			$TempOfficeLanguage += "			<Language ID=""$($item)"" />`n"
		}
	}

	$RandomGuid = [guid]::NewGuid()
	$TempGuidConfiguration = "$($env:userprofile)\AppData\Local\Temp\$($RandomGuid)"
	CheckCatalog -chkpath $TempGuidConfiguration
	Write-Host "`n   Configuration temp folder: $($TempGuidConfiguration)"

	Copy-Item -Path "$($PSScriptRoot)\Configuration\*.xml" -Destination $TempGuidConfiguration -Force -ErrorAction SilentlyContinue

	<#
		.Replace xml
		.替换 xml
	#>
	Get-ChildItem –Path "$($TempGuidConfiguration)\*.xml" | Where-Object {
		(Get-Content $_.FullName) | Foreach-Object {
			$_ -replace "--REPLACELANGUAGE--", $TempOfficeLanguage `
			   -replace "--REPLACESourcePath--", "$($Global:OfficeSP)"
		} | Set-Content -Path $_.FullName -ErrorAction SilentlyContinue
	}

	<#
		.Determine whether there is Setup.exe
		.判断是否存在 Setup.exe

		https://www.microsoft.com/en-us/download/details.aspx?id=49117
	#>
	Write-Host "`n   Sources: $($Global:OfficeSP)"

	<#
		.Convert the architecture type, configure according to the architecture settings
		.转换架构类型，按架构设置配置
	#>
	$XmlConfiguration = "Default"
	switch ($env:PROCESSOR_ARCHITECTURE) {
		"arm64" {
			if (Test-Path -Path "$($Global:OfficeSP)\Data\Arm64.cab" -PathType Leaf) {
				$XmlConfiguration = "$($TempGuidConfiguration)\$($Version).arm64.xml"
			} else {
				if (Test-Path -Path "$($Global:OfficeSP)\Data\v64.cab" -PathType Leaf) {
					$XmlConfiguration = "$($TempGuidConfiguration)\$($Version).x64.xml"
				} else {
					if (Test-Path -Path "$($Global:OfficeSP)\Data\v32.cab" -PathType Leaf) {
						$XmlConfiguration = "$($TempGuidConfiguration)\$($Version).x86.xml"
					}
				}
			}
		}
		"AMD64" {
			if (Test-Path -Path "$($Global:OfficeSP)\Data\v64.cab" -PathType Leaf) {
				$XmlConfiguration = "$($TempGuidConfiguration)\$($Version).x64.xml"
			} else {
				if (Test-Path -Path "$($Global:OfficeSP)\Data\v32.cab" -PathType Leaf) {
					$XmlConfiguration = "$($TempGuidConfiguration)\$($Version).x86.xml"
				}
			}
		}
		"x86" {
			if (Test-Path -Path "$($Global:OfficeSP)\Data\v32.cab" -PathType Leaf) {
				$XmlConfiguration = "$($TempGuidConfiguration)\$($Version).x86.xml"
			}
		}
	}

	<#
		.Determine the configuration file
		.判断配置文件
	#>
	$FlagsClean = $False
	if (Test-Path $XmlConfiguration -PathType Leaf) {
		Write-host "`n   Install...`n   Sources: $($XmlConfiguration)"
		Start-Process -FilePath "$($Global:OfficeSP)\Setup.exe" -ArgumentList "/configure $($XmlConfiguration)" -wait -WindowStyle Minimized

		Write-Host "`n   Installation status" -ForegroundColor Red
		if (Install-StatusCheck) {
			Write-Host "   - It has been installed`n" -ForegroundColor Green

			<#
				.After passing the installation status check, get whether to clear the installation package after success
				.通过安装状态检查后，成功后获取是否清除安装包
			#>
			if ($Cleanup) {
				$FlagsClean = $True
			}

			<#
				.Activation method
				.激活方式
			#>
			if ($Activation) {
				if (Test-Path "$($Global:OfficeSP)\Tools.exe" -PathType Leaf) {
					<#
						.Add to Defend rule
						.添加到 Defend 规则
					#>
					Add-MpPreference -ExclusionPath "$($Global:OfficeSP)\Tools.exe" -ErrorAction SilentlyContinue | Out-Null
					Start-Process -FilePath "$($Global:OfficeSP)\Tools.exe" -ArgumentList "*" -Wait
					Remove-MpPreference -ExclusionPath "$($Global:OfficeSP)\Tools.exe"
				}
			}
		} else {
			Write-Host "   - Not Installed`n" -ForegroundColor Red
		}
	} else {
		Write-Host "   - The installation configuration file was not found.`n" -ForegroundColor Red
		return
	}

	if ($Force) {
		$FlagsClean = $True
	}

	if ($FlagsClean) {
		$RandomTempGuid = [guid]::NewGuid()
		$test_tmp_filename = "$($Global:OfficeSP)\writetest-$($RandomTempGuid)"
		Out-File -FilePath $test_tmp_filename -Encoding utf8 -ErrorAction SilentlyContinue

		if (Test-Path $test_tmp_filename -PathType Leaf) {
			Remove-Item $test_tmp_filename -Force -ErrorAction SilentlyContinue
			RemoveTree "$($Global:OfficeSP)"

			<#
				.In order to prevent the installation package from being unable to be cleaned up, the next time you log in, execute it again
				.为了防止无法清理安装包，下次登录时，再次执行
			#>
			Write-Host "   After logging in next time, Clear Office Install Folder`n" -ForegroundColor Green
			$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
			$regKey = "Clear Office Install Folder"
			$regValue = "cmd.exe /c rd /s /q ""$($Global:OfficeSP)"""
			if (Test-Path $regPath) {
				New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
			} else {
				New-Item -Path $regPath -Force | Out-Null
				New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
			}
		} else {
			Write-Host "   - Unable to clear Office installation package directory.`n" -ForegroundColor Red
		}
	}

	<#
		.Clean up the temporary configuration directory
		.清理临时配置目录
	#>
	RemoveTree $TempGuidConfiguration

	<#
		.Rearrange the desktop icons by name
		.重新按名称排列桌面图标
	#>
	ResetDesktop
}

Function Install-StatusCheck
{
	$OfficeProduct = @(
		"Word"
		"Access"
		"Excel"
		"Lync"
		"OneDrive"
		"OneNote"
		"Outlook"
		"PowerPoint"
		"Publisher"
		"Teams"
	)

	foreach ($item in $OfficeProduct) {
		if (Test-Path -Path "HKLM:\SOFTWARE\Microsoft\Office\16.0\$($item)" -ErrorAction SilentlyContinue) {
			return $True
		}
	}

	if (Test-Path "${env:ProgramFiles}\Microsoft Office\Office16\OSPP.VBS" -PathType Leaf) {
		return $True
	}

	if (Test-Path "${env:ProgramFiles(x86)}\Microsoft Office\Office16\OSPP.VBS" -PathType Leaf) {
		return $True
	}

	# Check if Office 365 suite was installed correctly.
	$RegLocations = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
	  				  'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
					)
	foreach ($Key in (Get-ChildItem $RegLocations) ) {
		if ($Key.GetValue('DisplayName') -like '*Microsoft 365*') {
			$OfficeVersionInstalled = $Key.GetValue('DisplayName')
			return $True
		}
	}

	return $False
}

<#
	.Create a directory
	.创建目录
#>
Function CheckCatalog
{
	Param
	(
		[string]$chkpath
	)

	if (-not (Test-Path $chkpath -PathType Container)) {
		New-Item -Path $chkpath -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
		if (-not (Test-Path $chkpath -PathType Container)) {
			Write-Host "   - Create Folder Failed $($chkpath)`n" -ForegroundColor Red
			return
		}
	}
}

<#
	.Try to delete the directory
	.尝试删除目录
#>
Function RemoveTree
{
	Param
	(
		[string]$Path
	)

	Remove-Item $Path -force -Recurse -ErrorAction silentlycontinue -Confirm:$false | Out-Null

	if (Test-Path "$Path\" -ErrorAction silentlycontinue) {
		Get-ChildItem -Path $Path -File -Force -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
			Remove-Item $_.FullName -force -ErrorAction SilentlyContinue -Confirm:$false | Out-Null
		}

		Get-ChildItem -Path $Path -Directory -ErrorAction SilentlyContinue | ForEach-Object {
			RemoveTree -Path $_.FullName
		}

		if (Test-Path "$Path\" -ErrorAction silentlycontinue) {
			Remove-Item $Path -force -Recurse -ErrorAction SilentlyContinue -Confirm:$false | Out-Null
		}
	}
}

<#
	.Refresh icon cache
	.刷新图标缓存
#>
Function RefreshIconCache
{
	$code = @'
	private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
	private const int WM_SETTINGCHANGE = 0x1a;
	private const int SMTO_ABORTIFHUNG = 0x0002;

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
private static extern IntPtr SendMessageTimeout ( IntPtr hWnd, int Msg, IntPtr wParam, string lParam, uint fuFlags, uint uTimeout, IntPtr lpdwResult );

[System.Runtime.InteropServices.DllImport("Shell32.dll")] 
private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

public static void Refresh() {
	SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);
	SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);
}
'@

	Add-Type -MemberDefinition $code -Namespace MyWinAPI -Name Explorer
	[MyWinAPI.Explorer]::Refresh()
}

Function RestartExplorer
{
	Stop-Process -ProcessName explorer -force -ErrorAction SilentlyContinue
	Start-Sleep 5
	$Running = Get-Process explorer -ErrorAction SilentlyContinue
	if (-not ($Running)) {
		Start-Process "explorer.exe"
	}
}

<#
	.Rearrange the desktop icons by name
	.重新按名称排列桌面图标
#>
Function ResetDesktop
{
	$ResetDesktopReg = @(
		'HKCU:\Software\Microsoft\Windows\Shell\BagMRU'
		'HKCU:\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Microsoft\Windows\ShellNoRoam\Bags'
		'HKCU:\Software\Microsoft\Windows\ShellNoRoam\BagMRU'
		'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
		'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
	)

	foreach ($item in $ResetDesktopReg) {
		Remove-Item -Path $item -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	RestartExplorer
	RefreshIconCache
}

<#
	.Install Office version
	.安装 Office 版本

	Usage:
	用法：

	-Version
		"365"
			| O365ProPlusRetail        = Office 365 Apps for Enterprise
			| O365BusinessRetail       = Office 365 Apps for business
			| O365SmallBusPremRetail   = Office 365 Small Business Premium
			| O365HomePremRetail       = Office 365 Home

		"2021"
			| ProPlus2021Volume        = Office Professional Plus 2021 Volume


	-Activation  | After the installation is successful, try the activation method
                   安装成功后，尝试激活方式
	-Cleanup     | After the installation is successful, clear the Office installation package directory
                   安装成功后，清除 Office 安装包目录
	-Force       | Regardless of whether the installation succeeds or fails, the installation package directory is forcibly cleared
                   无论安装成功和失败时，强制清除 Office 安装包目录

#>

Install-Process -Version "ProPlus2021Volume" -Activation -Cleanup