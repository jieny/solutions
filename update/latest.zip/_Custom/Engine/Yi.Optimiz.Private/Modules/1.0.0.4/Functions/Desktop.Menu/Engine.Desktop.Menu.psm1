﻿<#
	.Personalized desktop right click
	.个性化桌面右键
#>
Function Personalise_Menu
{
	param
	(
		[switch]$Add,
		[switch]$Del,
		[switch]$Hide
	)

	Write-Host "   $($lang.DesktopMenu)" -ForegroundColor Green
	if ($Del) { Personalise_Menu_Add }
	if ($Add) {
		if ($Hide) {
			Personalise_Menu_Del -Hide
		} else {
			Personalise_Menu_Del
		}
	}
}

<#
	.Delete desktop right click
	.删除桌面右键
#>
Function Personalise_Menu_Add
{
	Write-Host "   $($lang.Delete)".PadRight(28) -NoNewline
	Remove-Item -Path "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Write-Host "   $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Add desktop right click
	.添加桌面右键
#>
Function Personalise_Menu_Del
{
	param
	(
		[switch]$Hide
	)

	$FlagsHideRight = $False
	if (Test-Path "$($PSScriptRoot)\..\..\..\..\..\Deploy\Desktop_Menu_Shift" -PathType Leaf) {
		$FlagsHideRight = $True
	}
	if ($Hide) {
		$FlagsHideRight = $True
	}

	Write-Host "   $($lang.AddTo)".PadRight(28) -NoNewline
	$IconFolder = Convert-Path -Path "$($PSScriptRoot)\..\..\..\.." -ErrorAction SilentlyContinue
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel" -Name 'Icon' -Value "$($IconFolder)\icons\MainPanel.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel" -Name "MUIVerb" -Value "$($Global:UniqueID)'s Solutions" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel\command" -Name '(default)' -Value "powershell.exe -Command ""Start-Process 'Powershell.exe' -Argument '-File ""$((Convert-Path -Path "$($PSScriptRoot)\..\..\..\..\Engine.ps1" -ErrorAction SilentlyContinue))""' -Verb RunAs""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir" -Name 'Icon' -Value "$($IconFolder)\icons\Engine.Gift.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir" -Name "MUIVerb" -Value $($lang.Location) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir\command" -Name '(default)' -Value "explorer $($Global:UniqueMainFolder)" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg" -Name 'Icon' -Value "$($IconFolder)\icons\FirstExperience.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg" -Name "MUIVerb" -Value $($lang.FirstDeployment) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg\command" -Name '(default)' -Value "powershell.exe -Command ""Start-Process 'Powershell.exe' -Argument '-File ""$((Convert-Path -Path "$($PSScriptRoot)\..\..\..\..\Engine.ps1" -ErrorAction SilentlyContinue))"" -Functions \""FirstExperience -Quit\""' -Verb RunAs""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update" -Name 'Icon' -Value "$($IconFolder)\icons\update.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update" -Name "MUIVerb" -Value $($lang.ChkUpdate) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update\command" -Name '(default)' -Value "powershell.exe -Command ""Start-Process 'Powershell.exe' -Argument '-File ""$((Convert-Path -Path "$($PSScriptRoot)\..\..\..\..\Engine.ps1" -ErrorAction SilentlyContinue))"" -Functions \""Update -Quit\""' -Verb RunAs""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About" -Name 'Icon' -Value "$($IconFolder)\icons\about.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About" -Name "MUIVerb" -Value $($lang.About) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About\command" -Name '(default)' -Value "explorer ""$($Global:AuthorURL)/go/os""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name "MUIVerb" -Value "$($Global:UniqueID)'s Solutions" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name 'Icon' -Value "$($IconFolder)\icons\Engine.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name "SeparatorAfter" -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name "Position" -Value 'Top' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	if ($FlagsHideRight) {
		New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name "Extended" -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	}
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name 'SubCommands' -Value "$($Global:UniqueID).MainPanel;$($Global:UniqueID).Dir;|;$($Global:UniqueID).Update;$($Global:UniqueID).Reg;|;$($Global:UniqueID).About;" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	Write-Host "   $($lang.Done)`n" -ForegroundColor Green
}