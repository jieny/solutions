﻿<#
	.Windows 11
#>
Function IsWin11
{
	$FlagsCheckIsWin11 = $False

	if ([System.Environment]::OSVersion.Version.Build -ge "21996") {
		$FlagsCheckIsWin11 = $True
	}

	return $FlagsCheckIsWin11
}

<#
	.Dynamic save function
	.动态保存功能
#>
Function Save_Dynamic
{
	param
	(
		$regkey,
		$name,
		$value,
		[switch]$Multi,
		[switch]$String
	)

	$Path = "HKCU:\SOFTWARE\$($Global:UniqueID)\$($regkey)"

	if (-not (Test-Path $Path)) {
		New-Item -Path $Path -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Multi) {
		New-ItemProperty -LiteralPath $Path -Name $name -Value $value -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
	}
	if ($String) {
		New-ItemProperty -LiteralPath $Path -Name $name -Value $value -PropertyType String -Force -ea SilentlyContinue | Out-Null
	}
}

<#
	.Test whether the disk is readable and writable
	.测试磁盘是否可读写
#>
Function Test_Available_Disk
{
	param
	(
		[string]$Path
	)

	try {
		New-Item -Path $Path -ItemType Directory -ErrorAction SilentlyContinue | Out-Null

		$RandomGuid = [guid]::NewGuid()
		$test_tmp_filename = "writetest-$($RandomGuid)"
		$test_filename = Join-Path -Path "$($Path)" -ChildPath "$($test_tmp_filename)" -ErrorAction SilentlyContinue

		[io.file]::OpenWrite($test_filename).close()

		if (Test-Path $test_filename -PathType Leaf)
		{
			Remove-Item $test_filename -ErrorAction SilentlyContinue
			return $true
		}
		$false
	} catch {
		return $false
	}
}

<#
	.Verify the directory and create
	.验证目录并创建
#>
Function Check_Folder
{
	Param
	(
		[string]$chkpath
	)

	if (-not (Test-Path $chkpath -PathType Container)) {
		New-Item -Path $chkpath -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
		if (-not (Test-Path $chkpath -PathType Container))
		{
			Write-Host "   $($lang.FailedCreateFolder)$($chkpath)`n" -ForegroundColor Red
			return
		}
	}
}

<#
	.Delete directory
	.删除目录
#>
Function Remove_Tree
{
	Param
	(
		[string]$Path
	)

	Remove-Item $Path -force -Recurse -ErrorAction silentlycontinue | Out-Null
	
	if (Test-Path -Path "$Path\" -ErrorAction silentlycontinue) {
		Get-ChildItem -Path $Path -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
			Remove-Item $_.FullName -force -ErrorAction SilentlyContinue
		}

		Get-ChildItem -Path $Path -Directory -ErrorAction SilentlyContinue | ForEach-Object {
			Remove_Tree -Path $_.FullName
		}

		if (Test-Path -Path "$Path\" -ErrorAction silentlycontinue) {
			Remove-Item $Path -force -ErrorAction SilentlyContinue
		}
	}
}

<#
	.验证路径是否后缀带有 \
	.Verify that the path is suffixed with \
#>
Function Join_MainFolder
{
	param
	(
		[string]$Path
	)
	if ($Path.EndsWith('\'))
	{
		return "$Path"
	} else {
		return "$Path\"
	}
}

<#
	.Unzip
	.解压缩
#>
Function Archive
{
	param
	(
		$Password,
		$filename,
		$to
	)

	$filename = Convert-Path $filename -ErrorAction SilentlyContinue
	$to = Convert-Path $to -ErrorAction SilentlyContinue

	Write-Host "   $($filename)"
	Write-host "   $($to)"
	Write-Host "   $($lang.UpdateUnpacking)".PadRight(28) -NoNewline
	if (Compressing) {
		if (([string]::IsNullOrEmpty($Password))) {
			$arguments = "x ""-r"" ""-tzip"" ""$filename"" ""-o$to"" ""-y"""
		} else {
			$arguments = "x ""-p$Password"" ""-r"" ""-tzip"" ""$filename"" ""-o$to"" ""-y"""
		}
		Start-Process $Global:Zip "$arguments" -Wait -WindowStyle Minimized
		Write-Host "$($lang.Done)`n" -ForegroundColor Green
	} else {
		Expand-Archive -LiteralPath $filename -DestinationPath $to -force
		Write-Host "$($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Get compression software
	.获取压缩软件
#>
Function Compressing
{
	if (Test-Path -Path "${env:ProgramFiles}\7-Zip\7z.exe" -PathType Leaf) {
		$Global:Zip = "${env:ProgramFiles}\7-Zip\7z.exe"
		return $true
	}

	if (Test-Path -Path "${env:ProgramFiles(x86)}\7-Zip\7z.exe" -PathType Leaf) {
		$Global:Zip = "${env:ProgramFiles(x86)}\7-Zip\7z.exe"
		return $true
	}

	if (Test-Path -Path "$(Get_Arch_Path -Path "$($PSScriptRoot)\..\..\..\..\AIO\7zPacker")\7z.exe" -PathType Leaf) {
		$Global:Zip = "$(Get_Arch_Path -Path "$($PSScriptRoot)\..\..\..\..\AIO\7zPacker")\7z.exe"
		return $true
	}
	return $false
}

<#
	.Processing: clean up packages by architecture
	.处理：按架构清理软件包
#>
Function Clear_Arch_Path
{
	param
	(
		[string]$Path
	)

	switch ($env:PROCESSOR_ARCHITECTURE) {
		"arm64" {
			if (Test-Path -Path "$Path\arm64" -PathType Container) {
				Remove_Tree -Path "$Path\AMD64"
				Remove_Tree -Path "$Path\x86"
			} else {
				if (Test-Path -Path "$Path\AMD64" -PathType Container) {
					Remove_Tree -Path "$Path\arm64"
					Remove_Tree -Path "$Path\x86"
				} else {
					if (Test-Path -Path "$Path\x86" -PathType Container) {
						Remove_Tree -Path "$Path\arm64"
						Remove_Tree -Path "$Path\AMD64"
					}
				}
			}
		}
		"AMD64" {
			if (Test-Path -Path "$Path\AMD64" -PathType Container) {
				Remove_Tree -Path "$Path\arm64"
				Remove_Tree -Path "$Path\x86"
			} else {
				if (Test-Path -Path "$Path\x86" -PathType Container) {
					Remove_Tree -Path "$Path\arm64"
					Remove_Tree -Path "$Path\AMD64"
				}
			}
		}
		"x86" {
			Remove_Tree -Path "$Path\arm64"
			Remove_Tree -Path "$Path\AMD64"
		}
	}
}

<#
	.Determine if architecture is available by path
	.按路径来判断架构是否可用
#>
Function Get_Arch_Path
{
	param
	(
		[string]$Path
	)

	switch ($env:PROCESSOR_ARCHITECTURE) {
		"arm64" {
			if (Test-Path -Path "$($Path)\arm64\$($Global:IsLang)" -PathType Container) {
				return Convert-Path -Path "$($Path)\arm64\$($Global:IsLang)" -ErrorAction SilentlyContinue
			}

			if (Test-Path -Path "$($Path)\arm64\en-US" -PathType Container) {
				return Convert-Path -Path "$($Path)\arm64\en-US" -ErrorAction SilentlyContinue
			}

			if (Test-Path -Path "$($Path)\AMD64\$($Global:IsLang)" -PathType Container) {
				return Convert-Path -Path "$($Path)\AMD64\$($Global:IsLang)" -ErrorAction SilentlyContinue
			}

			if (Test-Path -Path "$($Path)\AMD64\en-US" -PathType Container) {
				return Convert-Path -Path "$($Path)\AMD64\en-US" -ErrorAction SilentlyContinue
			}

			if (Test-Path -Path "$($Path)\x86\$($Global:IsLang)" -PathType Container) {
				return Convert-Path -Path "$($Path)\x86\$($Global:IsLang)" -ErrorAction SilentlyContinue
			}

			if (Test-Path -Path "$($Path)\x86\en-US" -PathType Container) {
				return Convert-Path -Path "$($Path)\x86\en-US" -ErrorAction SilentlyContinue
			}
		}
		"AMD64" {
			if (Test-Path -Path "$($Path)\AMD64\$($Global:IsLang)" -PathType Container) {
				return Convert-Path -Path "$($Path)\AMD64\$($Global:IsLang)" -ErrorAction SilentlyContinue
			}

			if (Test-Path -Path "$($Path)\AMD64\en-US" -PathType Container) {
				return Convert-Path -Path "$($Path)\AMD64\en-US" -ErrorAction SilentlyContinue
			}

			if (Test-Path -Path "$($Path)\x86\$($Global:IsLang)" -PathType Container) {
				return Convert-Path -Path "$($Path)\x86\$($Global:IsLang)" -ErrorAction SilentlyContinue
			}

			if (Test-Path -Path "$($Path)\x86\en-US" -PathType Container) {
				return Convert-Path -Path "$($Path)\x86\en-US" -ErrorAction SilentlyContinue
			}
		}
		"x86" {
			if (Test-Path -Path "$($Path)\x86\$($Global:IsLang)" -PathType Container) {
				return Convert-Path -Path "$($Path)\x86\$($Global:IsLang)" -ErrorAction SilentlyContinue
			}

			if (Test-Path -Path "$($Path)\x86\en-US" -PathType Container) {
				return Convert-Path -Path "$($Path)\x86\en-US" -ErrorAction SilentlyContinue
			}
		}
	}

	return $Path
}

Function TakeownFile($path) {
	takeown.exe /A /F $path | Out-Null
	$acl = Get-Acl $path

	# get administraor group
	$admins = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-544")
	$admins = $admins.Translate([System.Security.Principal.NTAccount])

	# add NT Authority\SYSTEM
	$rule = New-Object System.Security.AccessControl.FileSystemAccessRule($admins, "FullControl", "None", "None", "Allow")
	$acl.AddAccessRule($rule)

	Set-Acl -Path $path -AclObject $acl | Out-Null
}

Function TakeownFolder($path) {
	TakeownFile $path
	ForEach ($item in Get-ChildItem $path) {
		if (Test-Path $item -PathType Container) {
			TakeownFolder $item.FullName
		} else {
			TakeownFile $item.FullName
		}
	}
}

Function TakeownRegistry($key) {
    # TODO does not work for all root keys yet
    switch ($key.split('\')[0]) {
        "HKEY_CLASSES_ROOT" {
            $reg = [Microsoft.Win32.Registry]::ClassesRoot
            $key = $key.substring(18)
        }
        "HKEY_CURRENT_USER" {
            $reg = [Microsoft.Win32.Registry]::CurrentUser
            $key = $key.substring(18)
        }
        "HKEY_LOCAL_MACHINE" {
            $reg = [Microsoft.Win32.Registry]::LocalMachine
            $key = $key.substring(19)
        }
    }

    # get administraor group
    $admins = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-544")
    $admins = $admins.Translate([System.Security.Principal.NTAccount])

    # set owner
    $key = $reg.OpenSubKey($key, "ReadWriteSubTree", "TakeOwnership")
    $acl = $key.GetAccessControl()
    $acl.SetOwner($admins)
    $key.SetAccessControl($acl)

    # set FullControl
    $acl = $key.GetAccessControl()
    $rule = New-Object System.Security.AccessControl.RegistryAccessRule($admins, "FullControl", "Allow")
    $acl.SetAccessRule($rule)
    $key.SetAccessControl($acl)
}

Function ElevatePrivileges {
	param($Privilege)
	$Definition = @"
    using System;
    using System.Runtime.InteropServices;

    public class AdjPriv {
        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
            internal static extern bool AdjustTokenPrivileges(IntPtr htok, bool disall, ref TokPriv1Luid newst, int len, IntPtr prev, IntPtr rele);

        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
            internal static extern bool OpenProcessToken(IntPtr h, int acc, ref IntPtr phtok);

        [DllImport("advapi32.dll", SetLastError = true)]
            internal static extern bool LookupPrivilegeValue(string host, string name, ref long pluid);

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
            internal struct TokPriv1Luid {
                public int Count;
                public long Luid;
                public int Attr;
            }

        internal const int SE_PRIVILEGE_ENABLED = 0x00000002;
        internal const int TOKEN_QUERY = 0x00000008;
        internal const int TOKEN_ADJUST_PRIVILEGES = 0x00000020;

        public static bool EnablePrivilege(long processHandle, string privilege) {
            bool retVal;
            TokPriv1Luid tp;
            IntPtr hproc = new IntPtr(processHandle);
            IntPtr htok = IntPtr.Zero;
            retVal = OpenProcessToken(hproc, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, ref htok);
            tp.Count = 1;
            tp.Luid = 0;
            tp.Attr = SE_PRIVILEGE_ENABLED;
            retVal = LookupPrivilegeValue(null, privilege, ref tp.Luid);
            retVal = AdjustTokenPrivileges(htok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
            return retVal;
        }
    }
"@
	$ProcessHandle = (Get-Process -id $pid).Handle
	$type = Add-Type $definition -PassThru
	$type[0]::EnablePrivilege($processHandle, $Privilege)
}

Function Restart_Explorer
{
	Stop-Process -ProcessName explorer -force -ErrorAction SilentlyContinue
	Start-Sleep 5
	$Running = Get-Process explorer -ErrorAction SilentlyContinue
	if (-not ($Running)) {
		Start-Process "explorer.exe"
	}
}