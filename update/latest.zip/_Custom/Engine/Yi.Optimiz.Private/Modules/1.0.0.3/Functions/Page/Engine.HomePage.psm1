﻿<#
	.LOGO
#>
Function Logo
{
	param
	(
		$Title
	)
	Clear-Host
	$Host.UI.RawUI.WindowTitle = "$($Global:UniqueID)'s Solutions | $($Title)"
	Write-Host "`n   Author: $($Global:UniqueID) ( $($Global:AuthorURL) )

   From: $($Global:UniqueID)'s Solutions
   buildstring: $((Get-Module -Name Engine).Version.ToString()).bs_release.230429-1208`n"
}

<#
	.主界面
	.Main interface
#>
Function Mainpage
{
	Logo -Title $($lang.Mainname)
	Write-Host "   $($lang.Mainname)`n   $('-' * 80)"

	write-host "     1. $($lang.ChkUpdate)
     2. $($lang.FirstDeployment)
     3. $($lang.RestorePoint)
     4. $($lang.Delete) $($lang.Mainname)" -ForegroundColor Green

	write-host  "`n   [*] A. $($lang.Oneclick) BCDEFGHI"
	write-host  "       B. $($lang.LocationUserFolder)
       C. $($lang.DeskIcon)
       D. $($lang.Optimize) $($lang.System)
       E. $($lang.Optimize) $($lang.Service)
       F. $($lang.Instl) $($lang.Necessary)
       G. $($lang.Instl) $($lang.MostUsedSoftware)
       H. $($lang.Delete) $($lang.UninstallUWP)

   L. $($lang.SwitchLanguage)
   R. $($lang.RefreshModules)
   Q. $($lang.Exit)`n"

	$select = Read-Host "   $($lang.Choose)"
	switch ($select)
	{
		"1" {
			Update
			Modules_Refresh -Function "ToMainpage -wait 2"
		}
		"2" {
			FirstExperience
			ToMainpage -wait 2
		}
		"3" {
			Restore_Point_Create_UI
			ToMainpage -wait 2
		}
		"4" {
			Uninstall
			ToMainpage -wait 2
		}
		"a" {
			if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Engine" -Name "RestorePointPrompt" -ErrorAction SilentlyContinue) {
				$GetRestorePointPrompt = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Engine" -Name "RestorePointPrompt"
				switch ($GetRestorePointPrompt) {
					"False" { Restore_Point_Create_UI }
				}
			} else {
				Restore_Point_Create_UI
			}

			Change_Location
			Desktop
			Optimization_System_UI
			Optimization_Service_UI
			Prerequisite
			UWP_Uninstall

			$DynamicInstl = "$($PSScriptRoot)\..\..\Instl\Instl.ps1"
			if (Test-Path $DynamicInstl -PathType Leaf) {
				Start-Process powershell -ArgumentList "-File $($DynamicInstl)" -NoNewWindow -Wait
			} else {
				Write-Host "`n   $($lang.InstlNo)$DynamicInstl" -ForegroundColor Red
			}

			ToMainpage -wait 4
		}
		"b" {
			Change_Location
			ToMainpage -wait 2
		}
		"c" {
			Desktop
			ToMainpage -wait 2
		}
		"d" {
			Optimization_System_UI
			ToMainpage -wait 2
		}
		"e" {
			Optimization_Service_UI
			ToMainpage -wait 2
		}
		"f" {
			Prerequisite
			ToMainpage -wait 2
		}
		"g" {
			$DynamicInstl = "$($PSScriptRoot)\..\..\Instl\Instl.ps1"
			if (Test-Path $DynamicInstl -PathType Leaf) {
				Start-Process powershell -ArgumentList "-File $($DynamicInstl)" -NoNewWindow -Wait
			} else {
				Write-Host "`n   $($lang.InstlNo)$DynamicInstl" -ForegroundColor Red
			}

			ToMainpage -wait 2
		}
		"h" {
			UWP_Uninstall
			ToMainpage -wait 2
		}
		"l" {
			Language -Reset
			Mainpage
		}
		"r" {
			Modules_Refresh -Function "ToMainpage -wait 2"
		}
		"q" {
			Modules_Import
			$Global:Quit = $False
			exit
		}
		default { Mainpage }
	}
}

<#
	.返回到主界面
	.Return to the main interface
#>
Function ToMainpage
{
	param
	(
		[int]$wait
	)

	if ($Global:QUIT) {
		Write-Host $($lang.ToQuit -f $wait) -ForegroundColor Red
		Start-Sleep -s $wait
		Modules_Import
		$Global:Quit = $False
		exit
	} else {
		Write-Host $($lang.ToMsg -f $wait) -ForegroundColor Red
		Start-Sleep -s $wait
		Mainpage
	}
}