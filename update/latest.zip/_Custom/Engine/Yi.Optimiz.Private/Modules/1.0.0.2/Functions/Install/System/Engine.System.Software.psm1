﻿<#
	.System software user interface
	.系统软件用户界面
#>
Function System_Software_UI
{
	param
	(
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.ComesWith)
	Write-Host "   $($lang.ComesWith)`n   $('-' * 80)"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUISSUpdateClick = {
		if ($GUISSUpdate.Checked) {
			$GUISSUpdateDA.Enabled = $True
			$GUISSUpdateWelcomeExperience.Enabled = $True
			$GUISSUpdateFirstLogonAnimation.Enabled = $True
			$GUISSUpdateGP.Enabled = $True
			$GUISSUpdateDrive.Enabled = $True
			$GUISSUpdateAvailable.Enabled = $True
			$GUISSUpdateTPMUpdate.Enabled = $True
		} else {
			$GUISSUpdateDA.Enabled = $False
			$GUISSUpdateWelcomeExperience.Enabled = $False
			$GUISSUpdateFirstLogonAnimation.Enabled = $False
			$GUISSUpdateGP.Enabled = $False
			$GUISSUpdateDrive.Enabled = $False
			$GUISSUpdateAvailable.Enabled = $False
			$GUISSUpdateTPMUpdate.Enabled = $False
		}
	}
	$GUISSCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUISS.Close()
	}
	$GUISSResetClick = {
		$GUISS.Hide()
		if ($GUISSUpdate.Checked) {
			Install_Process -appname "$($lang.Enabled) $($lang.WubTips)" -status "Enabled" -act "Install" -mode "Fast" -todisk $PSScriptRoot -structure "..\..\..\..\..\AIO\Wub" -pwd "" -url "https://www.sordum.org/files/download/windows-update-blocker/Wub.zip" -urlAMD64 "" -urlarm64 "" -filename "Wub*" -param "/E" -Before "" -After ""
		}

		if ($GUISSUpdateDA.Enabled) {
			if ($GUISSUpdateDA.Checked) {
				Update_Auto_Download -Enabled
			}
		}

		if ($GUISSUpdateWelcomeExperience.Enabled) {
			if ($GUISSUpdateWelcomeExperience.Checked) {
				Welcome_Experience -Show
			}
		}

		if ($GUISSUpdateFirstLogonAnimation.Enabled) {
			if ($GUISSUpdateFirstLogonAnimation.Checked) {
				First_Logon_Animation -Disable
			}
		}

		if ($GUISSUpdateGP.Enabled) {
			if ($GUISSUpdateGP.Checked) {
				Update_Policies -Enabled
			}
		}

		if ($GUISSUpdateDrive.Enabled) {
			if ($GUISSUpdateDrive.Checked) {
				Update_Auto_Drive -Enabled
			}
		}

		if ($GUISSUpdateAvailable.Enabled) {
			if ($GUISSUpdateAvailable.Checked) {
				Update_Are_Available -Enabled
			}
		}
	
		if ($GUISSUpdateTPMUpdate.Enabled) {
			if ($GUISSUpdateTPMUpdate.Checked) {
				Win11_TPM_Update -Restore
			}
		}

		if ($GUISSFirewall.Checked) {
			Install_Process -appname "$($lang.Enabled) $($lang.FabTips)" -status "Enabled" -act "Install" -mode "Fast" -todisk $PSScriptRoot -structure "..\..\..\..\..\AIO\Fab" -pwd "" -url "https://www.sordum.org/files/download/firewall-app-blocker/fab.zip" -urlAMD64 "" -urlarm64 "" -filename "fab*" -param "/O 0" -Before "" -After ""
		}

		if ($GUISSWidgetsRemove.Checked) { Taskbar_Widgets_Remove -Restore }
		$GUISS.Close()
	}
	$GUISSOKClick = {
		$GUISS.Hide()
		if ($GUISSUpdate.Checked) {
			Install_Process -appname "$($lang.Close) $($lang.WubTips)" -status "Enabled" -act "Install" -mode "Fast" -todisk $PSScriptRoot -structure "..\..\..\..\..\AIO\Wub" -pwd "" -url "https://www.sordum.org/files/download/windows-update-blocker/Wub.zip" -urlAMD64 "" -urlarm64 "" -filename "Wub*" -param "/D /P" -Before "" -After ""
		}

		if ($GUISSUpdateDA.Enabled) {
			if ($GUISSUpdateDA.Checked) {
				Update_Auto_Download -Disable
			}
		}

		if ($GUISSUpdateWelcomeExperience.Enabled) {
			if ($GUISSUpdateWelcomeExperience.Checked) {
				Welcome_Experience -Hide
			}
		}

		if ($GUISSUpdateGP.Enabled) {
			if ($GUISSUpdateGP.Checked) {
				Update_Policies -Disable
			}
		}

		if ($GUISSUpdateDrive.Enabled) {
			if ($GUISSUpdateDrive.Checked) {
				Update_Auto_Drive -Disable
			}
		}

		if ($GUISSUpdateAvailable.Enabled) {
			if ($GUISSUpdateAvailable.Checked) {
				Update_Are_Available -Disable
			}
		}

		if ($GUISSUpdateTPMUpdate.Enabled) {
			if ($GUISSUpdateTPMUpdate.Checked) {
				Win11_TPM_Update -Disable
			}
		}

		if ($GUISSFirewall.Checked) {
			Install_Process -appname "$($lang.Close) $($lang.FabTips)" -status "Enabled" -act "Install" -mode "Fast" -todisk $PSScriptRoot -structure "..\..\..\..\..\AIO\Fab" -pwd "" -url "https://www.sordum.org/files/download/firewall-app-blocker/fab.zip" -urlAMD64 "" -urlarm64 "" -filename "fab*" -param "/O 3" -Before "" -After ""
		}

		if ($GUISSWidgetsRemove.Checked) { Taskbar_Widgets_Remove -Remove }

		if ($Global:EventQueueMode) {

		} else {
			Wait_Process_End
		}

		$GUISS.Close()
	}
	$GUISS             = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 550
		Text           = $lang.ComesWith
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUISSPanel        = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 515
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 1
		Location       = "0,0"
	}

	<#
		.Windows Update
	#>
	$GUISSUpdate       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 495
		Text           = "$($lang.Close) $($lang.WubTips)"
		ForeColor      = "#008000"
		add_Click      = $GUISSUpdateClick
		Checked        = $true
	}
	$GUISSUpdateDA     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 470
		Text           = "$($lang.Disable) $($lang.UpdateAutoDownload)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateWelcomeExperience = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 470
		Text           = "$($lang.Hide) $($lang.UpdateWelcomeExperience)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateFirstLogonAnimation = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 470
		Text           = "$($lang.Hide) $($lang.UpdateFirstLogonAnimation)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateGP     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 470
		Text           = "$($lang.Disable) $($lang.UpdatePolicies)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateDrive  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 470
		Text           = "$($lang.Disable) $($lang.UpdateAutoDrive)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateAvailable = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 470
		Text           = "$($lang.Disable) $($lang.UpdateAreAvailable)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateTPMUpdate = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 470
		Text           = "$($lang.Disable) $($lang.TPMUpdate)"
		Checked        = $true
		ForeColor      = "#008000"
		Padding        = "18,0,0,0"
	}

	$GUISSFirewall     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 495
		Text           = "$($lang.Close) $($lang.FabTips)"
		ForeColor      = "#008000"
		Padding        = "0,8,0,0"
		Checked        = $true
	}
	$GUISSWidgetsRemove = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Delete) $($lang.TaskbarWidgetsRemove)"
		ForeColor      = "#008000"
	}

	$GUISSErrorMsg     = New-Object system.Windows.Forms.Label -Property @{
		Location       = "10,530"
		Height         = 22
		Width          = 512
		Text           = ""
	}
	$GUISSReset        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,555"
		Height         = 35
		Width          = 515
		add_Click      = $GUISSResetClick
		Text           = $lang.Restore
	}
	$GUISSOK           = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,595"
		Height         = 35
		Width          = 515
		add_Click      = $GUISSOKClick
		Text           = $lang.OK
	}
	$GUISSCanel        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,635"
		Height         = 35
		Width          = 515
		add_Click      = $GUISSCanelClick
		Text           = $lang.Cancel
	}
	$GUISS.controls.AddRange((
		$GUISSPanel,
		$GUISSErrorMsg,
		$GUISSReset,
		$GUISSOK,
		$GUISSCanel
	))

	$GUISSPanel.controls.AddRange((
		$GUISSUpdate,
		$GUISSUpdateDA,
		$GUISSUpdateWelcomeExperience,
		$GUISSUpdateFirstLogonAnimation,
		$GUISSUpdateGP,
		$GUISSUpdateDrive,
		$GUISSUpdateAvailable
	))

	if (IsWin11) {
		$GUISSPanel.controls.AddRange((
			$GUISSUpdateTPMUpdate
		))
	}

	$GUISSPanel.controls.AddRange((
		$GUISSFirewall
	))

	if (IsWin11) {
		$GUISSPanel.controls.AddRange((
			$GUISSWidgetsRemove
		))
	}

	$GUISSMenuAllSelClick = {
		$GUISSPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUISSMenuAllClearClick = {
		$GUISSPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUISSMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUISSMenu.Items.Add($lang.AllSel).add_Click($GUISSMenuAllSelClick)
	$GUISSMenu.Items.Add($lang.AllClear).add_Click($GUISSMenuAllClearClick)
	$GUISSPanel.ContextMenuStrip = $GUISSMenu

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUISS.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUISS.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$GUISS.FormBorderStyle = 'Fixed3D'
	$GUISS.ShowDialog() | Out-Null
}

Enum Status
{
	Enabled
	Disable
}

Enum Mode
{
	Wait
	Fast
	Queue
}

Enum Action
{
	Install
	NoInst
	To
	Unzip
}