﻿<#
	.More features
	.更多功能
#>
Function Feature_More
{
	Clear-Host
	Logo -Title $($lang.MoreFeature)

	Write-Host "   $($lang.Menu)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	write-host "      U   $($lang.ChkUpdate)" -ForegroundColor Green

	Write-Host "      G   $($lang.Detailed_View_Rule)" -ForegroundColor Green

	Write-Host "      A   $($lang.ViewMounted)" -ForegroundColor Green

	Write-host "`n   $($lang.ViewWIMFileInfo)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	if (Test-Path "$($Global:MountTo)\sources\Boot.wim" -PathType Leaf) {
		Write-Host "      1   Boot.wim" -ForegroundColor Green
	} else {
		Write-Host "      1   Boot.wim" -ForegroundColor Red
	}

	if (Test-Path "$($Global:MountTo)\sources\Install.wim" -PathType Leaf) {
		Write-Host "      2   Install.wim" -ForegroundColor Green
	} else {
		Write-Host "      2   Install.wim" -ForegroundColor Red
	}

	if (Test-Path "$($Global:MountTo)\sources\Install.swm" -PathType Leaf) {
		Write-Host "      3   Install.swm" -ForegroundColor Green
	} else {
		Write-Host "      3   Install.swm" -ForegroundColor Red
	}

	if (Test-Path "$($Global:MountTo)\sources\install.esd" -PathType Leaf) {
		Write-Host "      4   Install.esd" -ForegroundColor Green
	} else {
		Write-Host "      4   Install.esd" -ForegroundColor Red
	}

	if (Test-Path "$($Global:MountToRouting)\Install\Install\Windows\System32\Recovery\WinRE.wim" -PathType Leaf) {
		Write-Host "      5   WinRE.wim" -ForegroundColor Green
	} else {
		Write-Host "      5   WinRE.wim" -ForegroundColor Red
	}

	Write-Host "`n   $($lang.AdvOption)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	if ($Global:Developers_Mode) {
		Write-Host "      S   $($lang.Developers_Mode)" -ForegroundColor Green
	} else {
		Write-Host "      S   $($lang.Developers_Mode)" -ForegroundColor Red
	}

	Write-Host "      B.  $($lang.UpBackup)" -ForegroundColor Green
	Write-Host "      H.  $($lang.ConvertToArchive)" -ForegroundColor Green
	Write-Host "      C.  $($lang.UpdateCreate)" -ForegroundColor Green

	Write-Host "`n   $($lang.OpenFolder)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	$SaveToLogsPath = "$($Global:LogsSaveFolder)\$($Global:LogSaveTo)"
	if (Test-Path $SaveToLogsPath -PathType Container) {
		Write-Host "      L.  $($lang.Logging)"
		Write-Host "          $($SaveToLogsPath)" -ForegroundColor Green
	} else {
		Write-Host "      L.  $($lang.Logging)" -ForegroundColor Red
	}

	Write-Host "`n      Z.  $($lang.MainImageFolder)"
	if (Test-Path $Global:MountTo -PathType Container) {
		Write-Host "          $($Global:MountTo)" -ForegroundColor Green
	} else {
		Write-Host "          $($Global:MountTo)" -ForegroundColor Red
	}

	Write-Host "`n      M.  $($lang.MountImageTo), $($lang.MainImageFolder)"
	if (Test-Path $Global:MountToRouting -PathType Container) {
		Write-Host "          $($Global:MountToRouting)" -ForegroundColor Green
	} else {
		Write-Host "          $($Global:MountToRouting)" -ForegroundColor Red
	}

	Write-Host "`n      T.  $($lang.SettingImageTempFolder)"
	if (Test-Path $Global:MountToRoutingTemp -PathType Container) {
		Write-Host "          $($Global:MountToRoutingTemp)" -ForegroundColor Green
	} else {
		Write-Host "          $($Global:MountToRoutingTemp)" -ForegroundColor Red
	}

	$select = Read-Host "`n   $($lang.Choose)"
	switch ($select)
	{
		'g' {
			Clear-Host
			Write-Host "`n   $($lang.Detailed_View_Rule)" -ForegroundColor Green
			Write-host "   $('-' * 80)"

			ForEach ($item in $Global:Image_Rule) {
				Write-Host "`n   $($lang.Event_Assign_Main) ( $($item.Main.Count) ) $($lang.EventManagerCount)" -ForegroundColor Yellow
				Write-host "   $('-' * 80)"
				Write-Host "   $($lang.Event_Group)" -ForegroundColor Yellow
				Write-Host "   $($item.Main.Group)" -ForegroundColor Green
		
				Write-Host "`n   $($lang.Event_Primary_Key)" -ForegroundColor Yellow
				Write-Host "   $($item.Main.Uid)" -ForegroundColor Green

				Write-Host "`n   $($lang.SelFile)" -ForegroundColor Yellow
				Write-Host "   $($item.Main.Path)\$($item.Main.ImageFileName).$($item.Main.Suffix)" -ForegroundColor Green

				if ($item.Expand.Count -gt 0) {
					Write-Host "`n      $($lang.Event_Assign_Expand) ( $($item.Expand.Count) ) $($lang.EventManagerCount)" -ForegroundColor Yellow
					Write-host "      $('-' * 77)"

					ForEach ($Expand in $item.Expand) {
						Write-Host "      $($lang.Event_Group)"
						Write-Host "      $($Expand.Group)`n" -ForegroundColor Green
			
						Write-Host "      $($lang.Event_Primary_Key)"
						Write-Host "      $($Expand.Uid)`n" -ForegroundColor Green
	
						Write-Host "      $($lang.SelFile)"
						Write-Host "      $($Expand.Path)\$($Expand.ImageFileName).$($Expand.Suffix)`n" -ForegroundColor Green

						Write-Host "      $($lang.Select_Path)"
						Write-Host "      $($Expand.UpdatePath)`n" -ForegroundColor Green
					}
				}

				Write-host ""
			}

			Get_Next
			ToMainpage -wait 2 -To 4
		}
		'a' {
			Clear-Host
			Write-Host "`n   $($lang.ViewMounted)" -ForegroundColor Green

			if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
				Write-Host "`n   $($lang.Command)" -ForegroundColor Green
				Write-host "   $($lang.Developers_Mode_Location)97" -ForegroundColor Green
				Write-host "   $('-' * 80)"
				write-host "   Get-WindowsImage -Mounted" -ForegroundColor Green
				Write-host "   $('-' * 80)`n"
			}
	
			Get-WindowsImage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -Mounted | ForEach-Object {
				Write-host "   $('-' * 80)"
				Write-Host "   $($lang.Select_Path)".PadRight(18) -NoNewline
				Write-Host " $($_.Path)" -ForegroundColor Green

				Write-Host "   $($lang.Image_Path)".PadRight(18) -NoNewline
				Write-Host " $($_.ImagePath)" -ForegroundColor Green

				Write-Host "   $($lang.MountedIndex)".PadRight(18) -NoNewline
				Write-Host " $($_.ImageIndex)" -ForegroundColor Green

				Write-Host "   $($lang.Mounted_Mode)".PadRight(18) -NoNewline
				Write-Host " $($_.MountMode)" -ForegroundColor Green

				Write-Host "   $($lang.Mounted_Status)".PadRight(18) -NoNewline
				Write-Host " $($_.MountStatus)" -ForegroundColor Green
				Write-host "   $('-' * 80)`n"
			}

			Get_Next
			ToMainpage -wait 2 -To 4
		}
		'b' {
			UnPack_Create
			Get_Next
			ToMainpage -wait 2
		}
		'c' {
			Update_Create_UI
			ToMainpage -wait 2
		}
		'l' {
			Write-Host "`n   $($lang.OpenFolder)" -ForegroundColor Green
			Write-host "   $('-' * 80)"

			if (Test-Path $SaveToLogsPath -PathType Container) {
				Write-Host "   $SaveToLogsPath"
				Start-Process $SaveToLogsPath
			} else {
				Write-Host "   $($lang.NoInstallImage)"
				Write-host "   $($SaveToLogsPath)" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 4
		}
		'z' {
			Write-Host "`n   $($lang.OpenFolder)" -ForegroundColor Green
			Write-host "   $('-' * 80)"

			if (Test-Path "$($Global:MountTo)" -PathType Container) {
				Write-Host "   $($Global:MountTo)"
				Start-Process $($Global:MountTo)
			} else {
				Write-Host "   $($lang.NoInstallImage)"
				Write-host "   $($Global:MountTo)" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 4
		}
		'm' {
			Write-Host "`n   $($lang.OpenFolder)" -ForegroundColor Green
			Write-host "   $('-' * 80)"

			if (Test-Path $Global:MountToRouting -PathType Container) {
				Write-Host "   $($Global:MountToRouting)"
				Start-Process $Global:MountToRouting
			} else {
				Write-Host "   $($lang.NoInstallImage)"
				Write-host "   $($Global:MountTo)" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 4
		}
		't' {
			Write-Host "`n   $($lang.OpenFolder)" -ForegroundColor Green
			Write-host "   $('-' * 80)"

			if (Test-Path $Global:MountToRoutingTemp -PathType Container) {
				Write-Host "   $($Global:MountToRoutingTemp)"
				Start-Process $Global:MountToRoutingTemp
			} else {
				Write-Host "   $($lang.NoInstallImage)"
				Write-host "   $($Global:MountTo)" -ForegroundColor Red
			}

			ToMainpage -wait 2 -To 4
		}
		'u' {
			Update
			Modules_Refresh -Function "ToMainpage -wait 2 -To 4"
		}
		's' {
			if ($Global:Developers_Mode) {
				$Global:Developers_Mode = $False
			} else {
				$Global:Developers_Mode = $True
			}
			ToMainpage -wait 2 -To 4
		}
		'h' {
			Covert_Software_Package_Unpack
			ToMainpage -wait 2
		}
		'1' {
			Image_Get_Detailed -Filename "$($Global:MountTo)\sources\Boot.wim" -View
			Get_Next

			ToMainpage -wait 2 -To 4
		}
		'2' {
			Image_Get_Detailed -Filename "$($Global:MountTo)\sources\Install.wim" -View

			Get_Next
			ToMainpage -wait 2 -To 4
		}
		'3' {
			Image_Get_Detailed -Filename "$($Global:MountTo)\sources\Install.swm" -View

			Get_Next
			ToMainpage -wait 2 -To 4
		}
		'4' {
			Image_Get_Detailed -Filename "$($Global:MountTo)\sources\Install.esd" -View

			Get_Next
			ToMainpage -wait 2 -To 4
		}
		'5' {
			Image_Get_Detailed -Filename "$($Global:MountToRouting)\Install\Install\Windows\System32\Recovery\winre.wim" -View

			Get_Next
			ToMainpage -wait 2 -To 4
		}
		default { Mainpage }
	}
}

Function Image_Get_Apps_Package
{
	param
	(
		[Switch]$View
	)

	if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
		$custom_array = @()
		try {
			Write-Host "   $($lang.Operable)" -ForegroundColor Green
			Get-AppxProvisionedPackage -Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" | ForEach-Object {
				$custom_array += [PSCustomObject]@{
					DisplayName = $_.DisplayName
					PackageName = $_.PackageName
					Version     = $_.Version
				}
			}
		} catch {
			Write-Host "   $($_)" -ForegroundColor Yellow
			Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
			return
		}

		Check_Folder -chkpath "$($Global:LogsSaveFolder)\$($Global:LogSaveTo)\Report\InBox.Apps"
		$TempSaveTo = "$($Global:LogsSaveFolder)\$($Global:LogSaveTo)\Report\InBox.Apps\$($Global:Primary_Key_Image.ImageFileName)-$(Get-Date -Format "yyyyMMddHHmmss")-$($Global:EventProcessGuid).csv"

		Write-Host "`n   $($lang.SaveTo)"
		Write-Host "   $($TempSaveTo)" -ForegroundColor Green
		$custom_array | Export-CSV -NoType -Path $TempSaveTo

@"
	`$custom_array_Export = @()
	`$multiple_output = Import-Csv "`$(`$PSScriptRoot)\$([IO.Path]::GetFileName($TempSaveTo))" | Out-GridView -Title "$($lang.GetImageUWP)" -passthru

	if (`$null -eq `$multiple_output) {
		Write-Host "   User Cancel" -ForegroundColor Red
	} else {
		ForEach (`$item in `$multiple_output) {
			`$custom_array_Export += [PSCustomObject]@{
				DisplayName = `$item.DisplayName
				PackageName = `$item.PackageName
				Version     = `$item.Version
			}
		}

		Add-Type -AssemblyName System.Windows.Forms

		`$FileBrowser = New-Object System.Windows.Forms.SaveFileDialog -Property @{ 
			Filter    = "CSV Files (*.csv)|*.csv|Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
			FileName  = "Export_Appx_`$(Get-Date -Format "yyyyMMddHHmmss")"
		}

		if (`$FileBrowser.ShowDialog() -eq "OK") {
			Write-Host "`n   Save To:"
			Write-Host "   `$(`$FileBrowser.FileName)" -ForegroundColor Green
			`$custom_array_Export | Export-CSV -NoType -Path `$FileBrowser.FileName
		} else {
			Write-Host "   User Cancel" -ForegroundColor Red
		}
	}
"@ | Out-File -FilePath "$($TempSaveTo).ps1" -Encoding UTF8 -ErrorAction SilentlyContinue

		if ($View) {
			powershell -NoLogo -NonInteractive -file "$($TempSaveTo).ps1" -wait
		}
	} else {
		Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
	}
}

Function Image_Get_Detailed
{
	param
	(
		$Filename,
		[Switch]$View
	)

	Write-Host "`n   $($lang.ViewWIMFileInfo)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	Write-host "   $($Filename)`n" -ForegroundColor Green

	if (Test-Path $Filename -PathType Leaf) {
		$custom_array = @()

		try {
			if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
				Write-Host "   $($lang.Command)" -ForegroundColor Green
				Write-host "   $($lang.Developers_Mode_Location)98" -ForegroundColor Green
				Write-host "   $('-' * 80)"
				write-host "   Get-WindowsImage -ImagePath ""$($Filename)""" -ForegroundColor Green
				Write-host "   $('-' * 80)`n"
			}
	
			Get-WindowsImage -ImagePath $Filename -ErrorAction SilentlyContinue | ForEach-Object {
				$SetCurreltIndex = $_.ImageIndex

				if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
					Write-Host "   $($lang.Command)" -ForegroundColor Green
					Write-host "   $($lang.Developers_Mode_Location)99" -ForegroundColor Green
					Write-host "   $('-' * 80)"
					write-host "   Get-WindowsImage -ImagePath ""$($Filename)"" -index ""$($SetCurreltIndex)""" -ForegroundColor Green
					Write-host "   $('-' * 80)`n"
				}
		
				Get-WindowsImage -ImagePath $Filename -index $SetCurreltIndex -ErrorAction SilentlyContinue | ForEach-Object {
					$custom_array += [PSCustomObject]@{
						ImageIndex       = $_.ImageIndex
						ImageName        = $_.ImageName
						ImageDescription = $_.ImageDescription
						ImageSize        = $_.ImageSize
						WIMBoot          = $_.WIMBoot
						Architecture     = $_.Architecture
						Hal              = $_.Hal
						Version          = $_.Version
						SPBuild          = $_.SPBuild
						SPLevel          = $_.SPLevel
						EditionId        = $_.EditionId
						InstallationType = $_.InstallationType
						ProductType      = $_.ProductType
						ProductSuite     = $_.ProductSuite
						SystemRoot       = $_.SystemRoot
						DirectoryCount   = $_.DirectoryCount
						FileCount        = $_.FileCount
						CreatedTime      = $_.CreatedTime
						ModifiedTime     = $_.ModifiedTime
						Languages        = $_.Languages
					}
				}
			}
		} catch {
			Write-Host "   $($lang.SelectFromError)" -ForegroundColor Red
			Write-Host "   $($_)" -ForegroundColor Yellow
			Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
			return
		}

		Check_Folder -chkpath "$($Global:LogsSaveFolder)\$($Global:LogSaveTo)\Report\Images"
		$TempSaveTo = "$($Global:LogsSaveFolder)\$($Global:LogSaveTo)\Report\Images\$($Global:Primary_Key_Image.ImageFileName)-$(Get-Date -Format "yyyyMMddHHmmss").csv"

		Write-Host "   $($lang.SaveTo)"
		Write-Host "   $($TempSaveTo)" -ForegroundColor Green
		$custom_array | Export-CSV -NoType -Path $TempSaveTo

@"
	`$custom_array_Export = @()
	`$multiple_output = Import-Csv "`$(`$PSScriptRoot)\$([IO.Path]::GetFileName($TempSaveTo))" | Out-GridView -Title "$($lang.ViewWIMFileInfo)$($Filename)" -passthru

	if (`$null -eq `$multiple_output) {
		Write-Host "   User Cancel" -ForegroundColor Red
	} else {
		ForEach (`$item in `$multiple_output) {
			`$custom_array_Export += [PSCustomObject]@{
				ImageIndex       = `$item.ImageIndex
				ImageName        = `$item.ImageName
				ImageDescription = `$item.ImageDescription
				ImageSize        = `$item.ImageSize
				WIMBoot          = `$item.WIMBoot
				Architecture     = `$item.Architecture
				Hal              = `$item.Hal
				Version          = `$item.Version
				SPBuild          = `$item.SPBuild
				SPLevel          = `$item.SPLevel
				EditionId        = `$item.EditionId
				InstallationType = `$item.InstallationType
				ProductType      = `$item.ProductType
				ProductSuite     = `$item.ProductSuite
				SystemRoot       = `$item.SystemRoot
				DirectoryCount   = `$item.DirectoryCount
				FileCount        = `$item.FileCount
				CreatedTime      = `$item.CreatedTime
				ModifiedTime     = `$item.ModifiedTime
				Languages        = `$item.Languages
			}
		}

		Add-Type -AssemblyName System.Windows.Forms

		`$FileBrowser = New-Object System.Windows.Forms.SaveFileDialog -Property @{ 
			Filter    = "CSV Files (*.csv)|*.csv|Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
			FileName  = "Export_Image_`$(Get-Date -Format "yyyyMMddHHmmss")"
		}

		if (`$FileBrowser.ShowDialog() -eq "OK") {
			Write-Host "`n   Save To:"
			Write-Host "   `$(`$FileBrowser.FileName)" -ForegroundColor Green
			`$custom_array_Export | Export-CSV -NoType -Path `$FileBrowser.FileName
		} else {
			Write-Host "   User Cancel" -ForegroundColor Red
		}
	}
"@ | Out-File -FilePath "$($TempSaveTo).ps1" -Encoding UTF8 -ErrorAction SilentlyContinue

		if ($View) {
			powershell -NoLogo -NonInteractive -file "$($TempSaveTo).ps1" -wait
		}
	} else {
		Write-Host "   $($lang.NoInstallImage)"
		Write-host "   $($Filename)" -ForegroundColor Red
	}
}

Function Image_Get_Components_Package
{
	param
	(
		[Switch]$View
	)

	$custom_array = @()
	if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
		try {
			Get-WindowsPackage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" | ForEach-Object {
				$custom_array += [PSCustomObject]@{
					PackageName  = $_.PackageName
					PackageState = $_.PackageState
					ReleaseType  = $_.ReleaseType
					InstallTime  = $_.InstallTime
				}
			}
			Write-Host "   $($lang.Operable)" -ForegroundColor Green
		} catch {
			Write-Host "   $($_)" -ForegroundColor Yellow
			Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
			return
		}

		Check_Folder -chkpath "$($Global:LogsSaveFolder)\$($Global:LogSaveTo)\Report\Components"
		$TempSaveTo = "$($Global:LogsSaveFolder)\$($Global:LogSaveTo)\Report\Components\$($Global:Primary_Key_Image.ImageFileName)-$(Get-Date -Format "yyyyMMddHHmmss")-$($Global:EventProcessGuid).csv"

		Write-Host "`n   $($lang.SaveTo)"
		Write-Host "   $($TempSaveTo)" -ForegroundColor Green
		$custom_array | Export-CSV -NoType -Path $TempSaveTo

@"
	`$custom_array_Export = @()
	`$multiple_output = Import-Csv "`$(`$PSScriptRoot)\$([IO.Path]::GetFileName($TempSaveTo))" | Out-GridView -Title "$($lang.GetImagePackage)" -passthru

	if (`$null -eq `$multiple_output) {
		Write-Host "   User Cancel" -ForegroundColor Red
	} else {
		ForEach (`$item in `$multiple_output) {
			`$custom_array_Export += [PSCustomObject]@{
				PackageName  = `$item.PackageName
				PackageState = `$item.PackageState
				ReleaseType  = `$item.ReleaseType
				InstallTime  = `$item.InstallTime
			}
		}

		Add-Type -AssemblyName System.Windows.Forms

		`$FileBrowser = New-Object System.Windows.Forms.SaveFileDialog -Property @{ 
			Filter    = "CSV Files (*.csv)|*.csv|Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
			FileName  = "Export_Package_`$(Get-Date -Format "yyyyMMddHHmmss")"
		}

		if (`$FileBrowser.ShowDialog() -eq "OK") {
			Write-Host "`n   Save To:"
			Write-Host "   `$(`$FileBrowser.FileName)" -ForegroundColor Green
			`$custom_array_Export | Export-CSV -NoType -Path `$FileBrowser.FileName
		} else {
			Write-Host "   User Cancel" -ForegroundColor Red
		}
	}
"@ | Out-File -FilePath "$($TempSaveTo).ps1" -Encoding UTF8 -ErrorAction SilentlyContinue

#"@ | Out-File -FilePath "$($TempSaveTo).ps1" -Encoding UTF8 -ErrorAction SilentlyContinue
#| Out-File -Encoding UTF8NoBOM

		if ($View) {
			powershell -NoLogo -NonInteractive -file "$($TempSaveTo).ps1" -wait
		}
	} else {
		Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
	}
}