﻿Function Logo
{
	param
	(
		$Title
	)

	Clear-Host
	$Host.UI.RawUI.WindowTitle = "$($Global:UniqueID)'s Solutions | $($Title)"
	Write-Host "`n   $($Global:UniqueID)'s Solutions, v$((Get-Module -Name Solutions).Version.ToString())"
	Write-host "   https://fengyi.tel/solutions`n" -ForegroundColor Yellow
}

Function Mainpage
{
	$Global:EventQueueMode = $False

	if (-not $Global:EventQueueMode) {
		Logo -Title $($lang.Menu)
		Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"

		Write-Host "   $($lang.MountImageTo)" -NoNewline
		Write-Host " $($Global:MountToRouting)" -ForegroundColor Yellow

		Write-Host "   $($lang.MainImageFolder)" -NoNewline
		Write-Host " $($Global:MountTo)" -NoNewline -ForegroundColor Yellow
		if (Test-Path "$($Global:MountTo)" -PathType Container) {
			Write-Host " $($lang.ImageLoaded)" -ForegroundColor Green
		} else {
			Write-Host " $($lang.NotMounted)" -ForegroundColor Red
			ToMainpage -wait 2
		}

		Image_Get_Mount_Status
	}

	Write-Host "`n   $($lang.Menu)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	Write-Host "      1   " -NoNewline
	Write-Host "$($lang.AddTo), " -ForegroundColor Green -NoNewline
	Write-Host "$($lang.Del), " -ForegroundColor Green -NoNewline
	Write-Host "$($lang.Update), " -ForegroundColor Green -NoNewline
	Write-Host "$($lang.Extract), " -ForegroundColor Green -NoNewline
#	Write-Host "$($lang.Wim_Rename), " -ForegroundColor Green -NoNewline
	Write-Host "$($lang.Mount), " -ForegroundColor Green -NoNewline
	Write-Host "$($lang.Reserve), " -ForegroundColor Green -NoNewline
	Write-Host "$($lang.Rebuild)" -ForegroundColor Green

	if (Image_Is_Mount) {
		Write-Host "      2   $($lang.Convert)" -ForegroundColor Red
	} else {
		Write-Host "      2   $($lang.Convert)"
	}

	Write-Host "      3   $($lang.Solution): " -NoNewline
	Write-Host "$($lang.IsCreate), " -ForegroundColor Green -NoNewline
	if ((Test-Path "$($Global:MountTo)\Autounattend.xml" -PathType Leaf) -or
		(Test-Path "$($Global:MountTo)\Sources\Unattend.xml" -PathType Leaf) -or
		(Test-Path "$($Global:MountTo)\Sources\`$OEM$" -PathType Container))
	{
		Write-host "$($lang.Del)" -ForegroundColor Green
	} else {
		Write-host "$($lang.Del)" -ForegroundColor Red
	}

	Write-Host "      4   $($lang.Language): " -NoNewline
	Write-host "$($lang.LanguageExtract), " -ForegroundColor Green -NoNewline
	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "$($lang.AddTo), " -ForegroundColor Green -NoNewline
			Write-Host "$($lang.Del), " -ForegroundColor Green -NoNewline
			Write-host "$($lang.SwitchLanguage)" -ForegroundColor Green
		} else {
			Write-Host "$($lang.AddTo), " -ForegroundColor Red -NoNewline
			Write-Host "$($lang.Del), " -ForegroundColor Red -NoNewline
			Write-host "$($lang.SwitchLanguage)" -ForegroundColor Red
		}
	} else {
		Write-Host "$($lang.AddTo), " -ForegroundColor Red -NoNewline
		Write-Host "$($lang.Del), " -ForegroundColor Red -NoNewline
		Write-host "$($lang.SwitchLanguage)" -ForegroundColor Red
	}

	if (Image_Is_Select_Install) {
		Write-Host "      5   $($lang.InboxAppsManager): " -NoNewline
		Write-Host "$($lang.AddTo), " -ForegroundColor Green -NoNewline
		Write-Host "$($lang.Del), " -ForegroundColor Green -NoNewline
		Write-Host "$($lang.Update)" -ForegroundColor Green
	} else {
		Write-Host "      5   $($lang.InboxAppsManager): " -NoNewline
		Write-Host "$($lang.AddTo), " -ForegroundColor Red -NoNewline
		Write-Host "$($lang.Del), " -ForegroundColor Red -NoNewline
		Write-Host "$($lang.Update)" -ForegroundColor Red
	}

	Write-Host "      6   $($lang.Update): " -NoNewline
	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "$($lang.AddTo), " -ForegroundColor Green -NoNewline
			Write-host "$($lang.Del)" -ForegroundColor Green
		} else {
			Write-Host "$($lang.AddTo), " -ForegroundColor Red -NoNewline
			Write-Host "$($lang.Del)" -ForegroundColor Red
		}
	} else {
		Write-Host "$($lang.AddTo), " -ForegroundColor Red -NoNewline
		Write-Host "$($lang.Del)" -ForegroundColor Red
	}

	Write-Host "      7   $($lang.Drive): " -NoNewline
	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "$($lang.AddTo), " -ForegroundColor Green -NoNewline
			Write-host "$($lang.Del)" -ForegroundColor Green
		} else {
			Write-Host "$($lang.AddTo), " -ForegroundColor Red -NoNewline
			Write-Host "$($lang.Del)" -ForegroundColor Red
		}
	} else {
		Write-Host "$($lang.AddTo), " -ForegroundColor Red -NoNewline
		Write-Host "$($lang.Del)" -ForegroundColor Red
	}

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "      8   $($lang.Editions)"
		} else {
			Write-Host "      8   $($lang.Editions)" -ForegroundColor Red
		}
	} else {
		Write-Host "      8   $($lang.Editions)" -ForegroundColor Red
	}

	Write-Host "      7   $($lang.WindowsFeature): " -NoNewline
	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "$($lang.Enable), " -ForegroundColor Green -NoNewline
			Write-Host "$($lang.Disable)" -ForegroundColor Green
		} else {
			Write-Host "$($lang.Enable), " -ForegroundColor Red -NoNewline
			Write-Host "$($lang.Disable)" -ForegroundColor Red
		}
	} else {
		Write-Host "$($lang.Enable), " -ForegroundColor Red -NoNewline
		Write-Host "$($lang.Disable)" -ForegroundColor Red
	}

	Write-Host "     10   $($lang.SpecialFunction)"

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "     11   $($lang.ImageEject)"
		} else {
			Write-Host "     11   $($lang.ImageEject)" -ForegroundColor Red
		}
	} else {
		Write-Host "     11   $($lang.ImageEject)" -ForegroundColor Red
	}

	Write-Host "     12   $($lang.UnpackISO)`n"

	Write-Host "      A.  $($lang.OnDemandPlanTask)" -ForegroundColor Green
	Write-Host "      S.  $($lang.Pri_Key_Switch)" -ForegroundColor Green
	Write-Host "      V.  $($lang.MoreFeature)"
	Write-Host "      M.  $($lang.Setting)"
	Write-Host "      L.  $($lang.SwitchLanguage)"
	Write-Host "      R.  $($lang.RefreshModules)"

	$select = Read-Host "`n    $($lang.Choose)"
	switch ($select)
	{
		'1' {
			Image_Assign_Event_Master
			ToMainpage -wait 2
		}
		'2' {
			Image_Convert
			ToMainpage -wait 2
		}
		'3' {
			Solutions_Menu
			ToMainpage -wait 2
		}
		'4' {
			Language_Menu
			ToMainpage -wait 2
		}
		'5' {
			inBox_Apps_Menu
			ToMainpage -wait 2
		}
		'6' {
			Update_Menu
			ToMainpage -wait 2
		}
		'7' {
			Drive_Menu
			ToMainpage -wait 2
		}
		'8' {
			Editions_GUI
			ToMainpage -wait 2
		}
		'9' {
			Feature_Enabled
			ToMainpage -wait 2
		}
		'10' {
			Functions_Assign
			ToMainpage -wait 2
		}
		'11' {
			Image_Eject
			ToMainpage -wait 2
		}
		'12' {
			ISO_Create
			ToMainpage -wait 2
		}
		'a' {
			Event_Assign_Task_Customize

			ToMainpage -wait 2
		}
		'i' {
			Write-Host "`n   $($lang.Event_Group)" -ForegroundColor Yellow
			Write-Host "   Install;Install;" -ForegroundColor Green

			Write-Host "`n   $($lang.Event_Primary_Key)" -ForegroundColor Yellow
			Write-Host "   Install;Install;wim;" -ForegroundColor Green

			Write-Host "`n   $($lang.Select_Path)" -ForegroundColor Yellow
			Write-Host "   $($Global:MountTo)\sources\install.wim" -ForegroundColor Green

			if (Test-Path "$($Global:MountTo)\sources\install.wim" -PathType Leaf) {
				Image_Set_Global_Primary_Key -Uid "Install;Install;wim;"
			} else {
				Write-Host "`n   $($lang.NoInstallImage)"
				Write-host "   $($Global:MountTo)\sources\install.wim" -ForegroundColor Red
			}

			ToMainpage -wait 2
		}
		'w' {
			Write-Host "`n   $($lang.Event_Group)"
			Write-Host "   Install;Install;" -ForegroundColor Green

			Write-Host "`n   $($lang.Event_Primary_Key)"
			Write-Host "   Install;WinRE;wim;" -ForegroundColor Green

			Write-Host "`n   $($lang.Select_Path)"
			Write-Host "   $($Global:MountToRouting)\Install\Install\Windows\System32\Recovery\WinRe.wim" -ForegroundColor Green

			if (Test-Path "$($Global:MountToRouting)\Install\Install\Windows\System32\Recovery\WinRe.wim" -PathType Leaf) {
				Image_Set_Global_Primary_Key -Uid "Install;WinRE;wim;"
			} else {
				Write-Host "`n   $($lang.NoInstallImage)"
				Write-host "   $($Global:MountToRouting)\Install\Install\Windows\System32\Recovery\WinRe.wim" -ForegroundColor Red
			}

			ToMainpage -wait 2
		}
		'b' {
			Write-Host "`n   $($lang.Event_Group)" -ForegroundColor Yellow
			Write-Host "   Boot;Boot;" -ForegroundColor Green

			Write-Host "`n   $($lang.Event_Primary_Key)" -ForegroundColor Yellow
			Write-Host "   Boot;Boot;wim;" -ForegroundColor Green

			Write-Host "`n   $($lang.Select_Path)" -ForegroundColor Yellow
			Write-Host "   $($Global:MountTo)\sources\boot.wim" -ForegroundColor Green

			if (Test-Path "$($Global:MountTo)\sources\boot.wim" -PathType Leaf) {
				Image_Set_Global_Primary_Key -Uid "Boot;Boot;wim;"
			} else {
				Write-Host "`n   $($lang.NoInstallImage)"
				Write-host "   $($Global:MountTo)\sources\boot.wim" -ForegroundColor Red
			}

			ToMainpage -wait 2
		}
		'm' {
			Image_Select
		}
		'l' {
			Language -Reset
			Mainpage
		}
		"r" {
			Modules_Refresh -Function "Requirements", "Mainpage"
		}
		's' {
			Image_Assign_Event_Master
			Write-Host "`n   $($lang.Pri_Key_Switch_Tips)" -ForegroundColor Green
			ToMainpage -wait 2
		}
		'v' {
			Feature_More
			ToMainpage -wait 2
		}
		't' {
			<#
				.快速测试区域
			#>
			Get_Mount_To_Temp

			<#
				.添加 ToMainpage 防止直接退出
			#>
			ToMainpage -wait 2
		}
		'q' {
			Modules_Import
			Stop-Process $PID
			exit
		}
		default { Mainpage }
	}
}

Function ToMainpage
{
	param
	(
		[int]$Wait,
		[int]$To,
		[switch]$Cancel
	)

	if ($Cancel) {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
	}

	Write-Host "   $($lang.ToMsg -f $wait)" -ForegroundColor Red
	start-process "timeout.exe" -argumentlist "/t $($wait) /nobreak" -wait -nonewwindow
	switch ($To) {
		"1" {
			Language_Menu
		}
		"2" {
			Drive_Menu
		}
		"3" {
			Update_Menu
		}
		"4" {
			Feature_More
		}
		"5" {
			inBox_Apps_Menu
		}
		"6" {
			Image_Select
		}
		"7" {
			Solutions_Menu
		}
		Default {
			Mainpage
		}
	}
}