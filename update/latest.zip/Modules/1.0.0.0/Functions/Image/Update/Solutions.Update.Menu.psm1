﻿<#
	.Update management
	.更新管理
#>
Function Update_Menu
{
	if (-not $Global:EventQueueMode) {
		Logo -Title $($lang.Update)
		Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"

		Write-Host "   $($lang.MountImageTo)" -NoNewline
		Write-Host " $($Global:MountToRouting)" -ForegroundColor Yellow

		Write-Host "   $($lang.MainImageFolder)" -NoNewline
		Write-Host " $($Global:MountTo)" -NoNewline -ForegroundColor Yellow
		if (Test-Path "$($Global:MountTo)" -PathType Container) {
			Write-Host " $($lang.ImageLoaded)" -ForegroundColor Green
		} else {
			Write-Host " $($lang.NotMounted)" -ForegroundColor Red
			ToMainpage -wait 2
		}
		Image_Get_Mount_Status

		<#
			.先决条件
		#>
		<#
			.判断是否选择 Install, Boot, WinRE
		#>
		if (-not (Image_Is_Select_IAB)) {
			Write-Host "`n   $($lang.Update)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			return
		}

		<#
			.判断挂载合法性
		#>
		if (-not (Verify_Is_Current_Same)) {
			Write-Host "`n   $($lang.Update)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
				Write-Host "   $($lang.MountedIndexError)" -ForegroundColor Red
			} else {
				Write-Host "   $($lang.NotMounted)" -ForegroundColor Red
			}
			return
		}
	}

	Write-Host "`n   $($lang.Menu)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
		Write-Host "      1   $($lang.Update): $($lang.AddTo)" -ForegroundColor Green
	} else {
		Write-Host "      1   $($lang.Update): $($lang.AddTo)" -ForegroundColor Red
	}

	if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
		Write-Host "      2   $($lang.Update): $($lang.Del)" -ForegroundColor Green
	} else {
		Write-Host "      2   $($lang.Update): $($lang.Del)" -ForegroundColor Red
	}

	Write-Host "`n   $($lang.GetImagePackage)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Green
		} else {
			Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Red
		}
	} else {
		Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Red
	}

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Green
		} else {
			Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Red
		}
	} else {
		Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Red
	}

	$select = Read-Host "`n   $($lang.Choose)"
	switch ($select)
	{
		'1' {
			Write-Host "`n    $($lang.Update): $($lang.AddTo)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
				<#
					.Assign available tasks
					.分配可用的任务
				#>
				Event_Assign -Rule "Update_Add_UI" -Run
			} else {
				Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 3
		}
		'2' {
			Write-Host "`n    $($lang.Language): $($lang.Del)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
				<#
					.Assign available tasks
					.分配可用的任务
				#>
				Event_Assign -Rule "Update_Delete_UI" -Run
			} else {
				Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 3
		}
		'p' {
			Write-Host "`n   $($lang.GetImagePackage)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"

			Write-Host "   $($lang.ExportToLogs)" -ForegroundColor Yellow

			if (Image_Is_Select_IAB) {
				Image_Get_Components_Package
				Get_Next
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 3
		}
		's' {
			Write-Host "`n   $($lang.GetImagePackage)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"

			Write-Host "   $($lang.ExportToLogs)" -ForegroundColor Yellow

			if (Image_Is_Select_IAB) {
				Image_Get_Components_Package -View
				Get_Next
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 3
		}
		default { Mainpage }
	}
}