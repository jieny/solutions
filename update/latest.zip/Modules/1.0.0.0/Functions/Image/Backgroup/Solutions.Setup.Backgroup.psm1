﻿<#
	.Select other task user interface
	.选择其它任务用户界面
#>
Function Setup_Background_UI
{
	if (-not $Global:EventQueueMode) {
		Logo -Title $($lang.Background)
		Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"

		Write-Host "   $($lang.MountImageTo)" -NoNewline
		if (Test-Path "$($Global:MountToRouting)" -PathType Container) {
			Write-Host " $($Global:MountToRouting)" -ForegroundColor Green
		} else {
			Write-Host " $($Global:MountToRouting)" -ForegroundColor Yellow
		}

		Write-Host "   $($lang.MainImageFolder)" -NoNewline
		if (Test-Path "$($Global:MountTo)" -PathType Container) {
			Write-Host " $($Global:MountTo)" -ForegroundColor Green
		} else {
			Write-Host " $($Global:MountTo)" -ForegroundColor Red
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.NoInstallImage)" -ForegroundColor Red
		}

		Image_Get_Mount_Status
	}

	Write-Host "`n   $($lang.Background)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	<#
		.事件：强行结束按需任务
	#>
	$UI_Main_Suggestion_Stop_Click = {
		$UI_Main.Hide()
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		Event_Reset_Variable
		$UI_Main.Close()
	}

	$UI_Main           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 876
		Text           = $lang.Background
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}
	$UI_Main_Background_Display = New-Object system.Windows.Forms.PictureBox -Property @{
		Height         = 363
		Width          = 400
		BorderStyle    = 0
		Padding        = 4
		SizeMode       = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
		Location       = "18,10"
	}
	$UI_Main_Background_Sources_Name = New-Object system.Windows.Forms.Label -Property @{
		Location       = "10,382"
		Height         = 22
		Width          = 405
		Text           = $lang.BackgroundTitle
	}
	$UI_Main_Background_Sources_Select = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 195
		Width          = 400
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
		Location       = "18,405"
	}
	$UI_Main_Background_Sync_To_ISO_Sources = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 430
		Text           = $lang.SettingImageToTemp
		Location       = '12,628'
	}

	<#
		.End on-demand mode
		.结束按需模式
	#>
	$UI_Main_Suggestion_Manage = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignSetting
		Location       = '570,395'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Event_Assign_Setting }
	}
	$UI_Main_Suggestion_Stop_Current = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.AssignEndCurrent -f $Global:Primary_Key_Image.Uid)"
		Location       = '570,425'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$UI_Main.Hide()
			Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
			Event_Need_Mount_Global_Variable -DevQueue "7" -Master $Global:Primary_Key_Image.Master -ImageFileName $Global:Primary_Key_Image.ImageFileName
			Event_Reset_Suggest
			$UI_Main.Close()
		}
	}
	$UI_Main_Event_Assign_Stop = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignForceEnd
		Location       = '570,455'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Suggestion_Stop_Click
	}

	<#
		.Suggested content
		.建议的内容
	#>
	$UI_Main_Suggestion_Not = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 430
		Text           = $lang.SuggestedSkip
		Location       = '570,395'
		add_Click      = {
			if ($UI_Main_Suggestion_Not.Checked) {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -name "IsSuggested" -value "True" -String
				$UI_Main_Suggestion_Setting.Enabled = $False
				$UI_Main_Suggestion_Stop.Enabled = $False
			} else {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -name "IsSuggested" -value "False" -String
				$UI_Main_Suggestion_Setting.Enabled = $True
				$UI_Main_Suggestion_Stop.Enabled = $True
			}
		}
	}
	$UI_Main_Suggestion_Setting = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignSetting
		Location       = '586,426'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Event_Assign_Setting }
	}
	$UI_Main_Suggestion_Stop = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignForceEnd
		Location       = '586,455'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Suggestion_Stop_Click
	}

	$UI_Main_Error     = New-Object system.Windows.Forms.Label -Property @{
		Location       = "570,525"
		Height         = 60
		Width          = 280
		Text           = ""
	}
	$UI_Main_OK        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "570,595"
		Height         = 36
		Width          = 280
		Text           = $lang.AddTo
		add_Click      = {
			New-Variable -Scope global -Name "Queue_Is_Change_Background_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force
			<#
				.Mark: Check the selection status
				.标记：检查选择状态
			#>
			$FlagCheckSelectStatus = $False

			$UI_Main_Background_Sources_Select.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							$FlagCheckSelectStatus = $True
							$Script:QueueChangeBackgroundSelect = $($_.Tag)
						}
					}
				}
			}

			if ($FlagCheckSelectStatus) {
				$UI_Main.Hide()
				New-Variable -Scope global -Name "Queue_Is_Change_Background_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $True -Force

				ForEach ($item in $Script:QueueChangeBackgroundSelect) {
					Write-Host "   $($item)"
				}

				if ($UI_Main_Background_Sync_To_ISO_Sources.Checked) {
					$Script:QueueChangeBackgroundSources = $True
				} else {
					$Script:QueueChangeBackgroundSources = $False
				}

				if ($UI_Main_Suggestion_Not.Checked) {
					Init_Canel_Event -All
				}
				$UI_Main.Close()
			} else {
				$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.NoChoose)"
			}
		}
	}
	$UI_Main_Canel     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "570,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$UI_Main.Hide()
			Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
			New-Variable -Scope global -Name "Queue_Is_Change_Background_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force
			$Script:QueueChangeBackgroundSources = $False
			$Script:QueueChangeBackgroundSelect = ""

			if ($UI_Main_Suggestion_Not.Checked) {
				Init_Canel_Event
			}
			$UI_Main.Close()
		}
	}
	$UI_Main.controls.AddRange((
		$UI_Main_Background_Display,
		$UI_Main_Background_Sources_Name,
		$UI_Main_Background_Sources_Select,
		$UI_Main_Background_Sync_To_ISO_Sources,
		$UI_Main_Error,
		$UI_Main_OK,
		$UI_Main_Canel
	))

	Get-ChildItem -Path "$($PSScriptRoot)\..\..\..\..\..\_Custom\Picture" -Recurse -include "*.bmp" | Where-Object {
			$CheckBox     = New-Object System.Windows.Forms.RadioButton -Property @{
				Height    = 22
				Width     = 330
				Text      = $_.BaseName
				Tag       = $_.FullName
				add_Click = {
					$UI_Main_Background_Sources_Select.Controls | ForEach-Object {
						if ($_ -is [System.Windows.Forms.RadioButton]) {
							if ($_.Enabled) {
								if ($_.Checked) {
									$UI_Main_Background_Display.image = [System.Drawing.Image]::Fromfile($($_.Tag))
								}
							}
						}
					}
				}
			}
			$UI_Main_Background_Sources_Select.controls.AddRange($CheckBox)
	}

	if ($Global:EventQueueMode) {
		$UI_Main.Text = "$($UI_Main.Text) [ $($lang.QueueMode), $($lang.Event_Primary_Key)$($Global:Primary_Key_Image.Uid) ]"
		$UI_Main.controls.AddRange((
			$UI_Main_Suggestion_Manage,
			$UI_Main_Suggestion_Stop_Current,
			$UI_Main_Event_Assign_Stop
		))
	} else {
		$UI_Main.Text = "$($UI_Main.Text) [ $($lang.Event_Primary_Key)$($Global:Primary_Key_Image.Uid) ]"
		<#
			.初始化复选框：不再建议
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
				"True" {
					$UI_Main_Suggestion_Not.Checked = $True
					$UI_Main_Suggestion_Setting.Enabled = $False
					$UI_Main_Suggestion_Stop.Enabled = $False
				}
				"False" {
					$UI_Main_Suggestion_Not.Checked = $False
					$UI_Main_Suggestion_Setting.Enabled = $True
					$UI_Main_Suggestion_Stop.Enabled = $True
				}
			}
		} else {
			$UI_Main_Suggestion_Not.Checked = $False
			$UI_Main_Suggestion_Setting.Enabled = $True
			$UI_Main_Suggestion_Stop.Enabled = $True
		}

		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
			if ((Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) -eq "True") {
				$UI_Main.controls.AddRange((
					$UI_Main_Suggestion_Not,
					$UI_Main_Suggestion_Setting,
					$UI_Main_Suggestion_Stop
				))
			}
		}
	}

	<#
		.Allow open windows to be on top
		.允许打开的窗口后置顶
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
			"True" { $UI_Main.TopMost = $True }
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$UI_Main.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$UI_Main.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$UI_Main.FormBorderStyle = 'Fixed3D'
	$UI_Main.ShowDialog() | Out-Null
}

Function Setup_Background_Process
{
	if ((Get-Variable -Scope global -Name "Queue_Is_Change_Background_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -ErrorAction SilentlyContinue).Value) {
		Get-ChildItem -Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -Recurse -include "*.bmp" | Where-Object {
			TakeownFile -path $($_.FullName)
			Copy-Item -Path $Script:QueueChangeBackgroundSelect -Destination $($_.FullName) -Force -ErrorAction SilentlyContinue
		}
	}

	if ($Script:QueueChangeBackgroundSources) {
		Get-ChildItem -Path "$($Global:MountTo)" -Recurse -include "*.bmp" | Where-Object {
			TakeownFile -path $($_.FullName)
			Copy-Item -Path $Script:QueueChangeBackgroundSelect -Destination $($_.FullName) -Force -ErrorAction SilentlyContinue
		}
	}

	Write-Host "   $($lang.Done)" -ForegroundColor Green
}