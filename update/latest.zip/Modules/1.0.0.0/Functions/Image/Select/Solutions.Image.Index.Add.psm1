﻿<#
	.Add image source user interface
	.添加映像源用户界面
#>
Function Image_Select_Add_UI
{
	Write-Host "`n   $($lang.SelectSettingImage)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$UI_Main           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 876
		Text           = $lang.Choose
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}
	$UI_Main_Menu      = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 550
		Width          = 500
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
		Dock           = 3
	}
	$UI_Main_Select_Custom_Sources = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "570,10"
		Height         = 36
		Width          = 280
		Text           = $lang.SelFile
		add_Click      = {
			$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
				Filter = "Image Files (*.WIM;*.ESD;*.SWM)|*.wim;*.esd;*.swm;|WIM Image (*.WIM)|*.wim|ESD Image (*.esd)|*.ESD|SWM Split Image (*.swm)|*.swm"
			}

			if ($FileBrowser.ShowDialog() -eq "OK") {
				$UI_Main_Menu.controls.Clear()
				$Script:TempSourcesFile = $FileBrowser.FileName

				if ($UI_Main_Duplication.checked) {
					if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
						Write-Host "`n   $($lang.Command)" -ForegroundColor Green
						Write-host "   $($lang.Developers_Mode_Location)82" -ForegroundColor Green
						Write-host "   $('-' * 80)"
						write-host "   Get-WindowsImage -ImagePath ""$($FileBrowser.FileName)""" -ForegroundColor Green
						Write-host "   $('-' * 80)`n"
					}

					Get-WindowsImage -ImagePath $FileBrowser.FileName -ErrorAction SilentlyContinue | Select-Object -Property ImageName, ImageIndex | Where-Object -FilterScript {
						($_.ImageName -notin ($Global:Primary_Key_Image.Index.ImageName))} | ForEach-Object {
							$CheckBox   = New-Object System.Windows.Forms.CheckBox -Property @{
								Height  = 40
								Width   = 450
								Text    = "$($lang.MountedName): $($_.ImageName)`n$($lang.MountedIndex): $($_.ImageIndex)"
								Tag     = $_.ImageIndex
								Checked = $True
							}
							$UI_Main_Menu.controls.AddRange($CheckBox)
					}
				} else {
					if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
						Write-Host "`n   $($lang.Command)" -ForegroundColor Green
						Write-host "   $($lang.Developers_Mode_Location)83" -ForegroundColor Green
						Write-host "   $('-' * 80)"
						write-host "   Get-WindowsImage -ImagePath ""$($FileBrowser.FileName)""" -ForegroundColor Green
						Write-host "   $('-' * 80)`n"
					}

					Get-WindowsImage -ImagePath $FileBrowser.FileName -ErrorAction SilentlyContinue | Select-Object -Property ImageName, ImageIndex | ForEach-Object {
						$CheckBox   = New-Object System.Windows.Forms.CheckBox -Property @{
							Height  = 40
							Width   = 450
							Text    = "$($lang.MountedName): $($_.ImageName)`n$($lang.MountedIndex): $($_.ImageIndex)"
							Tag     = $_.ImageIndex
							Checked = $True
						}
						$UI_Main_Menu.controls.AddRange($CheckBox)
					}
				}
			} else {
				$UI_Main_Error.Text = $($lang.UserCancel)
			}
		}
	}
	$UI_Main_Duplication = New-Object System.Windows.Forms.Checkbox -Property @{
		Height         = 25
		Width          = 280
		Text           = $lang.DeDuplication
		Location       = '572,55'
		Checked        = $True
	}
	$UI_Main_Error     = New-Object system.Windows.Forms.Label -Property @{
		Location       = "570,500"
		Height         = 55
		Width          = 280
		Text           = ""
	}
	$UI_Main_OK        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "570,595"
		Height         = 36
		Width          = 280
		Text           = $lang.AddTo
		add_Click      = {
			$UI_Main_Menu.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.CheckBox]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							$UI_Main.Hide()
							Write-Host "   $($_.Text) ( $($_.Tag) )"
							$SelectTempTag = $($_.Tag)

							if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
								Write-Host "`n   $($lang.Command)" -ForegroundColor Green
								Write-host "   $($lang.Developers_Mode_Location)85" -ForegroundColor Green
								Write-host "   $('-' * 80)"
								write-host "   Export-WindowsImage -SourceImagePath ""$($Script:TempSourcesFile)"" -SourceIndex ""$($SelectTempTag)"" -DestinationImagePath ""$($Global:Primary_Key_Image.FullPath)"" -CompressionType max -CheckIntegrity" -ForegroundColor Green
								Write-host "   $('-' * 80)`n"
							}

							Export-WindowsImage -SourceImagePath "$($Script:TempSourcesFile)" -SourceIndex "$($SelectTempTag)" -DestinationImagePath "$($Global:Primary_Key_Image.FullPath)" -CompressionType max -CheckIntegrity -ErrorAction SilentlyContinue | Out-Null
							Write-Host "   $($lang.Done)`n" -ForegroundColor Green

							$UI_Main.Close()
						}
					}
				}
			}

			$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.NoChoose)"
		}
	}
	$UI_Main_Canel     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "570,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
			$UI_Main.Close()
		}
	}
	$UI_Main.controls.AddRange((
		$UI_Main_Menu,
		$UI_Main_Select_Custom_Sources,
		$UI_Main_Duplication,
		$UI_Main_Error,
		$UI_Main_OK,
		$UI_Main_Canel
	))

	<#
		.Add right-click menu: select all, clear button
		.添加右键菜单：全选、清除按钮
	#>
	$UI_Main_Menu_Select = New-Object System.Windows.Forms.ContextMenuStrip
	$UI_Main_Menu_Select.Items.Add($lang.AllSel).add_Click({
		$UI_Main_Menu.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	})
	$UI_Main_Menu_Select.Items.Add($lang.AllClear).add_Click({
		$UI_Main_Menu.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	})
	$UI_Main_Menu.ContextMenuStrip = $UI_Main_Menu_Select

	<#
		.Allow open windows to be on top
		.允许打开的窗口后置顶
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
			"True" { $UI_Main.TopMost = $True }
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$UI_Main.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$UI_Main.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$UI_Main.FormBorderStyle = 'Fixed3D'
	$UI_Main.ShowDialog() | Out-Null
}