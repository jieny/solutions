﻿<#
   .Search image source: directory structure
   .搜索映像源：目录结构
#>
$InitImageFolderSearchStructure = "OS"

<#
	.RAMDISK initializes the volume name
	.RAMDISK 初始化卷标名
#>
$Init_RAMDISK_Volume_Label = "RAMDISK"

<#
	.Initialize selects the minimum disk size: 20GB
	.初始化选择磁盘最低大小：20GB
#>
$InitSearchDiskMinSize = 20

<#
	.Search image source: exclude directories
	.搜索映像源：排除目录
#>
$ExcludeDirectory = @(
	"Server"
	"Desktop"
	"_ISO"
	"_MSDN"
)

<#
	.Initialization: Disk source
	.初始化：磁盘来源
#>
Function Image_Init_Disk_Sources
{
	<#
		.Mark the registry location
		.标记注册表位置
	#>
	$Path = "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions"
	if (-not (Test-Path $Path)) {
		New-Item -Path $Path -Force -ErrorAction SilentlyContinue | Out-Null
	}

	<#
		.Judging Allow suggested items
		.判断 允许建议的项目 初始值
	#>
	if (-not (Get-ItemProperty -Path $Path -Name 'IsSuggested' -ErrorAction SilentlyContinue)) {
		Save_Dynamic -regkey "Solutions" -name "IsSuggested" -value "True" -String
	}

	<#
		.Judging the initial value of RAMDISK
		.判断 RAMDISK 初始值
	#>
	if (-not (Get-ItemProperty -Path $Path -Name 'RAMDisk' -ErrorAction SilentlyContinue)) {
		Save_Dynamic -regkey "Solutions" -name "RAMDisk" -value "True" -String
	}

	<#
		.Judging the initial value of RAMDISK
		.判断 RAMDISK 初始值
	#>
	if (-not (Get-ItemProperty -Path $Path -Name 'RAMDisk_Volume_Label' -ErrorAction SilentlyContinue)) {
		Save_Dynamic -regkey "Solutions" -name "RAMDisk_Volume_Label" -value $Init_RAMDISK_Volume_Label -String
	}

	<#
		.Set the validation disk tag
		.设置验证磁盘标记
	#>
	$MarkGetDiskTo = $False
	if (Get-ItemProperty -Path $Path -Name "DiskTo" -ErrorAction SilentlyContinue) {
		$GetDiskTo = Get-ItemPropertyValue -Path $Path -Name "DiskTo" -ErrorAction SilentlyContinue
		if (Test_Available_Disk -Path $GetDiskTo) {
			$MarkGetDiskTo = $True
			$Global:MainMasterFolder = $GetDiskTo
		}
	}

	if (-not ($MarkGetDiskTo)) {
		$GetCurrentDisk = (Join_MainFolder -Path (Split-Path -Path $PSScriptRoot -Qualifier))
		if (Test_Available_Disk -Path $GetCurrentDisk) {
			$MarkGetDiskTo = $True
			$Global:MainMasterFolder = Join-Path -Path $GetCurrentDisk -ChildPath $InitImageFolderSearchStructure -ErrorAction SilentlyContinue
			Save_Dynamic -regkey "Solutions" -name "DiskTo" -value $Global:MainMasterFolder -String
		}
	}

	if (-not ($MarkGetDiskTo)) {
		$drives = Get-CimInstance -Class Win32_LogicalDisk -ErrorAction SilentlyContinue | Where-Object { -not ([string]::IsNullOrEmpty($_) -or [string]::IsNullOrWhiteSpace($_))} | ForEach-Object { -not ((Join_MainFolder -Path $env:SystemDrive) -eq $_.DeviceID) } | Select-Object -ExpandProperty 'DeviceID'
		ForEach ($item in $drives) {
			if (Test_Available_Disk -Path $item) {
				Image_Set_Disk_Sources -Disk $item
				return
			}
		}

		Image_Set_Disk_Sources -Disk (Join_MainFolder -Path $env:SystemDrive)
	}
}

<#
	.Setting: Disk source
	.设置：磁盘来源
#>
Function Image_Set_Disk_Sources
{
	param
	(
		[string]$Disk
	)

	Save_Dynamic -regkey "Solutions" -name "DiskTo" -value $Disk -String
	$Global:MainMasterFolder = $Disk
}

<#
	.Select image source: menu
	.选择映像源：菜单
#>
Function Image_Select
{
	Logo -Title "$($lang.SelectSettingImage)"
	Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	Write-Host "   $($lang.Logging)" -NoNewline
	Write-Host " $($Global:LogsSaveFolder)\$($Global:LogSaveTo)" -ForegroundColor Yellow

	<#
		.Mark the registry location
		.标记注册表位置
	#>
	$Path = "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions"
	if (-not (Test-Path $Path)) {
		New-Item -Path $Path -Force -ErrorAction SilentlyContinue | Out-Null
	}

	<#
		.Initialization: Disk
		.初始化：磁盘
	#>
	Image_Init_Disk_Sources

	$GetCurrentDiskTo = Get-ItemPropertyValue -Path $Path -Name "DiskTo" -ErrorAction SilentlyContinue
	Write-Host "`n   $($lang.MountedPath)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	Write-Host "   $($GetCurrentDiskTo)" -ForegroundColor Green

	<#
		.Create an array of languages and use them for later comparison
		.创建语言数组，后期对比使用
	#>
	$Global:LanguageFull = @()
	$Global:LanguageShort = @()
	for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
		$Global:LanguageFull += $Global:AvailableLanguages[$i][2]
		$Global:LanguageShort += $Global:AvailableLanguages[$i][3]
	}

	Image_Select_UI
	if ($Global:Quit) {
		$Global:Quit = $False
	} else {
		ToMainpage -wait 2
		Mainpage
	}
}

<#
	.Select the image source user interface
	.选择映像源用户界面
#>
Function Image_Select_UI
{
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	<#
		.Event: Add directory structure
		.事件：添加目录结构
	#>

	Function RefreshNewPath
	{
		<#
			.Judgment: 1. Null value
			.判断：1. 空值
		#>
		if ([string]::IsNullOrEmpty($GUIImageSourceGroupSettingCustomizeShow.Text)) {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.NoSetLabel))"
			return $False
		}

		<#
			.Judgment: 2. The prefix cannot contain spaces
			.判断：2. 前缀不能带空格
		#>
		if ($GUIImageSourceGroupSettingCustomizeShow.Text -match '^\s') {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
			return $False
		}

		<#
			.Judgment: 3. No spaces at the end
			.判断：3. 后缀不能带空格
		#>
		if ($GUIImageSourceGroupSettingCustomizeShow.Text -match '\s$') {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
			return $False
		}

		<#
			.Judgment: 4. There can be no two spaces in between
			.判断：4. 中间不能含有二个空格
		#>
		if ($GUIImageSourceGroupSettingCustomizeShow.Text -match '\s{2,}') {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
			return $False
		}

		<#
			.Judgment: 5. Cannot contain: \\ /: *? "" <> |
			.判断：5, 不能包含：\\ / : * ? "" < > |
		#>
		if ($GUIImageSourceGroupSettingCustomizeShow.Text -match '[~#$@!%&*{}<>?/|+"]') {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorOther))"
			return $False
		}

		return $True
	}

	<#
		.选择映像来源，例如 D:\OS

		.设置界面，选择来源
	#>
	Function Image_Select_Refresh_Disk_Local
	{
		Save_Dynamic -regkey "Solutions" -name "SearchDiskMinSize" -value $GUIImageSourceGroupSettingLowSize.Text -String

		$GUIImageSourceGroupSettingDisk.controls.Clear()
		$GetDiskTo = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "DiskTo" -ErrorAction SilentlyContinue
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsFolderStructure" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsFolderStructure" -ErrorAction SilentlyContinue) {
				"True" { $GUIImageSourceGroupSettingStructure.Checked = $True }
				"False" { $GUIImageSourceGroupSettingStructure.Checked = $False }
			}
		} else {
			$GUIImageSourceGroupSettingStructure.Checked = $True
		}

		Get-CimInstance -Class Win32_LogicalDisk -ErrorAction SilentlyContinue | Where-Object { -not ([string]::IsNullOrEmpty($_) -or [string]::IsNullOrWhiteSpace($_))} | ForEach-Object {
			if (Test_Available_Disk -Path $_.DeviceID) {
				$RadioButton  = New-Object System.Windows.Forms.RadioButton -Property @{
					Height    = 35
					Width     = 380
					add_Click = $GUIImageSourceGroupSettingDiskClick
				}

				if ($GUIImageSourceGroupSettingSize.Checked) {
					if (-not (Verify_Available_Size -Disk $_.DeviceID -Size $GUIImageSourceGroupSettingLowSize.Text)) {
						$RadioButton.Enabled = $False
					}
				}

				$MarkCheckedSearchStructure = $False
				if ($GUIImageSourceGroupSettingStructure.Checked) {
					if (RefreshNewPath) {
						$MarkCheckedSearchStructure = $True
					} else {
						$MarkCheckedSearchStructure = $False
					}
				}

				if ($MarkCheckedSearchStructure) {
					$RadioButton.Text = "$(Join_MainFolder -Path $_.DeviceID)$($GUIImageSourceGroupSettingCustomizeShow.Text)"
					$RadioButton.Tag = "$(Join_MainFolder -Path $_.DeviceID)$($GUIImageSourceGroupSettingCustomizeShow.Text)"
				} else {
					$RadioButton.Text = $_.DeviceID
					$RadioButton.Tag = $_.DeviceID
				}

				if ($GetDiskTo -eq $RadioButton.Text) {
					$RadioButton.Checked = $True
				}
				$GUIImageSourceGroupSettingDisk.controls.AddRange($RadioButton)
			}
		}

		Get-CimInstance -Class Win32_NetworkConnection -ErrorAction SilentlyContinue | ForEach-Object {
			$RadioButton  = New-Object System.Windows.Forms.RadioButton -Property @{
				Height    = 35
				Width     = 365
				Text      = $_.RemoteName
				Tag       = $_.RemoteName
				add_Click = $GUIImageSourceGroupSettingDiskClick
			}

			$GUIImageSourceGroupSettingDisk.controls.AddRange($RadioButton)
		}
	}

	<#
		.响应设置界面
	#>
	Function Image_Setting_UI
	{
		<#
			.Initialize checkbox
			.初始化复选框
		#>
		$GUIImageSourceSettingTopMost.Checked = $False
		$GUIImageSourceSettingTopMostSuccess.Checked = $False
		$GUIImageSourceSettingSuggested.Checked = $False
		$GUIImageSourceSettingRAMDISK.Checked = $False
		$GUIImageSourceSetting_RAMDISK_Volume_Label.Enabled = $False
		$GUIImageSource_Setting_RAMDISK_Change.Enabled = $False
		$GUIImageSource_Setting_RAMDISK_Restore.Enabled = $False
		$GUIImageSourceSettingClearHistory.Checked = $False
		$GUIImageSourceSettingClearSaveFolder.Checked = $False
		$GUIImageSourceSettingClearAppxStage.Checked = $False
		$UI_Main_Adv_Cmd.Checked = $False
		$GUIImageSourceSettingBootSize.Checked = $False
		$GUIImageSourceSettingHistoryDism.Checked = $False

		<#
			.Search disk directory structure name
			.搜索磁盘目录结构名
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "DiskSearchStructure" -ErrorAction SilentlyContinue) {
			$GUIImageSourceGroupSettingCustomizeShow.Text = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "DiskSearchStructure" -ErrorAction SilentlyContinue
		} else {
			$GUIImageSourceGroupSettingCustomizeShow.Text = $InitImageFolderSearchStructure
		}

		<#
			.Check disk minimum size
			.检查磁盘最低大小
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsCheckLowDiskSize" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsCheckLowDiskSize" -ErrorAction SilentlyContinue) {
				"True" { $GUIImageSourceGroupSettingSize.Checked = $True }
				"False" { $GUIImageSourceGroupSettingSize.Checked = $False }
			}
		} else {
			$GUIImageSourceGroupSettingSize.Checked = $True
		}

		<#
			.显示命令行
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "ShowCommand" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "ShowCommand" -ErrorAction SilentlyContinue) {
				"True" { $UI_Main_Adv_Cmd.Checked = $True }
				"False" { $UI_Main_Adv_Cmd.Checked = $False }
			}
		}

		<#
			.Added to system variables
			.添加到系统变量
		#>
		if (Test-path -path "$($PSScriptRoot)\..\..\..\..\Router\Yi.ps1" -PathType Leaf) {
			$Current_Folder = Convert-Path -Path "$($PSScriptRoot)\..\..\..\..\Router" -ErrorAction SilentlyContinue
			$regLocation = "Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment"
			$path = (Get-ItemProperty -Path $regLocation -Name PATH).path
			$windows_path = $path -split ';'
			if (($windows_path) -Contains $Current_Folder) {
				$GUIImageSourceSettingEnv.Checked = $True
			} else {
				$GUIImageSourceSettingEnv.Checked = $False
			}
		} else {
			$GUIImageSourceSettingEnv.Enabled = $False
			$GUIImageSourceSettingEnv.Checked = $False
		}

		<#
			.Allow open windows to be on top
			.允许打开的窗口后置顶
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
				"True" { $GUIImageSourceSettingTopMost.Checked = $True }
				"False" { $GUIImageSourceSettingTopMost.Checked = $False }
			}
		} else {
			$GUIImageSourceSettingTopMost.Checked = $False
		}

		<#
			.Allow open windows to be on top
			.允许打开的窗口后置顶
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMostSuccess" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMostSuccess" -ErrorAction SilentlyContinue) {
				"True" { $GUIImageSourceSettingTopMostSuccess.Checked = $True }
				"False" { $GUIImageSourceSettingTopMostSuccess.Checked = $False }
			}
		} else {
			$GUIImageSourceSettingTopMostSuccess.Checked = $False
		}

		<#
			.Allow suggested items
			.允许建议的项目
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
				"True" {
					$GUIImageSourceSettingSuggested.Checked = $True
					$GUIImageSourceSettingSuggestedPanel.Enabled = $True
				}
				"False" {
					$GUIImageSourceSettingSuggested.Checked = $False
					$GUIImageSourceSettingSuggestedPanel.Enabled = $False
				}
			}
		} else {
			$GUIImageSourceSettingSuggested.Checked = $False
			$GUIImageSourceSettingSuggestedPanel.Enabled = $False
		}

		<#
			.Automatically select RAMDISK
			.自动选择 RAMDISK
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "RAMDisk" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "RAMDisk" -ErrorAction SilentlyContinue) {
				"True" {
					$GUIImageSourceSettingRAMDISK.Checked = $True
					$GUIImageSourceSetting_RAMDISK_Volume_Label.Enabled = $True
					$GUIImageSource_Setting_RAMDISK_Change.Enabled = $True
					$GUIImageSource_Setting_RAMDISK_Restore.Enabled = $True
					$GUIImageSourceISOCacheCustomizeName.Enabled = $False
					$GUIImageSourceISOCacheCustomize.Enabled = $False
				}
				"False" {
					$GUIImageSourceSettingRAMDISK.Checked = $False
					$GUIImageSourceSetting_RAMDISK_Volume_Label.Enabled = $False
					$GUIImageSource_Setting_RAMDISK_Change.Enabled = $False
					$GUIImageSource_Setting_RAMDISK_Restore.Enabled = $False
					$GUIImageSourceISOCacheCustomizeName.Enabled = $True
					$GUIImageSourceISOCacheCustomize.Enabled = $True
				}
			}
		} else {
			$GUIImageSourceSettingRAMDISK.Checked = $False
			$GUIImageSourceSetting_RAMDISK_Volume_Label.Enabled = $False
			$GUIImageSource_Setting_RAMDISK_Change.Enabled = $False
			$GUIImageSource_Setting_RAMDISK_Restore.Enabled = $False
		}

		<#
			.获取 RAMDISK 卷标名
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "RAMDisk_Volume_Label" -ErrorAction SilentlyContinue) {
			$GetRegRAMDISKVolumeLabel = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "RAMDisk_Volume_Label" -ErrorAction SilentlyContinue
			$GUIImageSourceSetting_RAMDISK_Volume_Label.Text = $GetRegRAMDISKVolumeLabel
			$GUIImageSourceSettingRAMDISK.Text = "$($lang.AutoSelectRAMDISK -f $GetRegRAMDISKVolumeLabel)"
		} else {
			$GUIImageSourceSettingRAMDISK.Text = "$($lang.AutoSelectRAMDISK -f $Init_RAMDISK_Volume_Label)"
			$GUIImageSourceSetting_RAMDISK_Volume_Label.Text = $Init_RAMDISK_Volume_Label
		}

		<#
			.初始化：选择，自定义磁盘缓存路径
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsDiskCache" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsDiskCache" -ErrorAction SilentlyContinue) {
				"True" {
					$GUIImageSourceISOCacheCustomizeName.Checked = $True
					$GUIImageSourceISOCacheCustomize.Enabled = $True
				}
				"False" {
					$GUIImageSourceISOCacheCustomizeName.Checked = $False
					$GUIImageSourceISOCacheCustomize.Enabled = $False
				}
			}
		} else {
			$GUIImageSourceISOCacheCustomizeName.Checked = $False
			$GUIImageSourceISOCacheCustomize.Enabled = $False
		}

		<#
			.初始化：自定义缓存路径
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "DiskCache" -ErrorAction SilentlyContinue) {
			$GUIImageSourceISOCacheCustomizePath.Text = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "DiskCache" -ErrorAction SilentlyContinue
		}

		<#
			.Clean up the logs 7 days ago
			.清理 7 天前的日志
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsLogsClear" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsLogsClear" -ErrorAction SilentlyContinue) {
				"True" { $GUIImageSourceSettingClearHistoryLog.Checked = $True }
				"False" { $GUIImageSourceSettingClearHistoryLog.Checked = $False }
			}
		} else {
			$GUIImageSourceSettingClearHistoryLog.Checked = $False
		}

		<#
			.Do not check Boot.wim file size ≥ 520MB
			.不再检查 Boot.wim 文件大小 ≥ 520MB
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "DoNotCheckBootSize" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "DoNotCheckBootSize" -ErrorAction SilentlyContinue) {
				"True" { $GUIImageSourceSettingBootSize.Checked = $True }
				"False" { $GUIImageSourceSettingBootSize.Checked = $False }
			}
		} else {
			Save_Dynamic -regkey "Solutions" -name "DoNotCheckBootSize" -value "True" -String
			$GUIImageSourceSettingBootSize.Checked = $True 
		}
		
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "SearchDiskMinSize" -ErrorAction SilentlyContinue) {
			$GUIImageSourceGroupSettingLowSize.Text = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "SearchDiskMinSize" -ErrorAction SilentlyContinue
		} else {
			Save_Dynamic -regkey "Solutions" -name "SearchDiskMinSize" -value $InitSearchDiskMinSize -String
		}

		Image_Select_Refresh_Disk_Local

		<#
			.验证目录名称，ISO 保存位置
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsCheckWrite" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsCheckWrite" -ErrorAction SilentlyContinue) {
				"True" { $GUIImageSourceISOWrite.Checked = $True }
				"False" { $GUIImageSourceISOWrite.Checked = $False }
			}
		} else {
			$GUIImageSourceISOWrite.Checked = $True
		}

		<#
			.同步新位置，ISO 保存位置
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsSearchSyncPath" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsSearchSyncPath" -ErrorAction SilentlyContinue) {
				"True" { $GUIImageSourceISOSync.Checked = $True }
				"False" { $GUIImageSourceISOSync.Checked = $False }
			}
		} else {
			$GUIImageSourceISOSync.Checked = $True
		}

		<#
			.验证目录名称，ISO 保存位置
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsCheckISOToFolderName" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsCheckISOToFolderName" -ErrorAction SilentlyContinue) {
				"True" { $GUIImageSourceISOSaveToCheckISO9660.Checked = $True }
				"False" { $GUIImageSourceISOSaveToCheckISO9660.Checked = $False }
			}
		} else {
			$GUIImageSourceISOSaveToCheckISO9660.Checked = $True
		}

		<#
			.初始化：ISO 默认保存位置
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "ISOTo" -ErrorAction SilentlyContinue) {
			$GUIImageSourceISOCustomizePath.Text = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "ISOTo" -ErrorAction SilentlyContinue
		} else {
			$GUIImageSourceISOCustomizePath.Text = $Global:MainMasterFolder
		}
	}

	<#
		.事件：更改 RAMDISK 卷标
	#>
	$GUIImageSource_Setting_RAMDISK_Change_Click = {
		<#
			.验证自定义 ISO 默认保存到目录名
		#>
		<#
			.Judgment: 1. Null value
			.判断：1. 空值
		#>
		if ([string]::IsNullOrEmpty($GUIImageSourceSetting_RAMDISK_Volume_Label.Text)) {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.NoSetLabel))"
			return
		}

		<#
			.Judgment: 2. The prefix cannot contain spaces
			.判断：2. 前缀不能带空格
		#>
		if ($GUIImageSourceSetting_RAMDISK_Volume_Label.Text -match '^\s') {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
			return
		}

		<#
			.Judgment: 3. Suffix cannot contain spaces
			.判断：3. 后缀不能带空格
		#>
		if ($GUIImageSourceSetting_RAMDISK_Volume_Label.Text -match '\s$') {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
			return
		}

		<#
			.Judgment: 4. The suffix cannot contain multiple spaces
			.判断：4. 后缀不能带多空格
		#>
		if ($GUIImageSourceSetting_RAMDISK_Volume_Label.Text -match '\s{2,}$') {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
			return
		}

		<#
			.Judgment: 5. There can be no two spaces in between
			.判断：5. 中间不能含有二个空格
		#>
		if ($GUIImageSourceSetting_RAMDISK_Volume_Label.Text -match '\s{2,}') {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
			return
		}

		<#
			.Judgment: 6. Cannot contain: \\ /: *? "" <> |
			.判断：6, 不能包含：\\ / : * ? "" < > |
		#>
		if ($GUIImageSourceSetting_RAMDISK_Volume_Label.Text -match '[~#$@!%&*{}<>?/|+"]') {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorOther))"
			return
		}
		<#
			.Judgment: 7. No more than 260 characters
			.判断：7. 不能大于 32 字符
		#>
		if ($GUIImageSourceSetting_RAMDISK_Volume_Label.Text.length -gt 32) {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISOLengthError -f "32"))"
			return
		}

		<#
			.验证自定义 ISO 默认保存到目录名，结束并保存新路径
		#>
		Save_Dynamic -regkey "Solutions" -name "RAMDisk_Volume_Label" -value $GUIImageSourceSetting_RAMDISK_Volume_Label.Text -String
		$GUIImageSourceSettingRAMDISK.Text = "$($lang.AutoSelectRAMDISK -f $GUIImageSourceSetting_RAMDISK_Volume_Label.Text)"
		$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.RAMDISK_Change) ( $($lang.Done) )"
	}

	<#
		.事件：ISO 默认保存位置，验证目录名称
	#>
	$GUIImageSourceGroupSettingDiskClick = {
		if ($GUIImageSourceISOSync.Checked) {
			$GUIImageSourceGroupSettingDisk.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							$GUIImageSourceISOCustomizePath.Text = $_.Tag
						}
					}
				}
			}
		}
	}

	Function Image_Select_Refresh_Sources_Setting
	{
		<#
			.Mark the registry location
			.标记注册表位置
		#>
		$Path = "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions"

		if ($GUIImageSourceSettingTopMost.Checked) {
			Save_Dynamic -regkey "Solutions" -name "TopMost" -value "True" -String
		} else {
			Save_Dynamic -regkey "Solutions" -name "TopMost" -value "False" -String
		}

		if ($GUIImageSourceSettingTopMostSuccess.Checked) {
			Save_Dynamic -regkey "Solutions" -name "TopMostSuccess" -value "True" -String
		} else {
			Save_Dynamic -regkey "Solutions" -name "TopMostSuccess" -value "False" -String
		}

		if ($GUIImageSourceSettingTopMost.Checked) {
			if ($GUIImageSourceSettingTopMostSuccess.Checked) {
				$UI_Main.TopMost = $True
			} else {
				$UI_Main.TopMost = $False
			}
		} else {
			if ($GUIImageSourceSettingTopMostSuccess.Checked) {
				$UI_Main.TopMost = $False
			}
		}

		if ($GUIImageSourceSettingClearHistoryLog.Checked) {
			Save_Dynamic -regkey "Solutions" -name "IsLogsClear" -value "True" -String
		} else {
			Save_Dynamic -regkey "Solutions" -name "IsLogsClear" -value "False" -String
		}

		if ($GUIImageSourceSettingBootSize.Checked) {
			Save_Dynamic -regkey "Solutions" -name "DoNotCheckBootSize" -value "True" -String
		} else {
			Save_Dynamic -regkey "Solutions" -name "DoNotCheckBootSize" -value "False" -String
		}

		<#
			.事件：允许自动选择磁盘卷标：RAMDISK
		#>
		if ($GUIImageSourceSettingRAMDISK.Checked) {
			Save_Dynamic -regkey "Solutions" -name "RAMDisk" -value "True" -String
			Save_Dynamic -regkey "Solutions" -name "IsDiskCache" -value "False" -String

			$GUIImageSourceSetting_RAMDISK_Volume_Label.Enabled = $True
			$GUIImageSource_Setting_RAMDISK_Change.Enabled = $True
			$GUIImageSource_Setting_RAMDISK_Restore.Enabled = $True
			$GUIImageSourceISOCacheCustomizeName.Enabled = $False
			$GUIImageSourceISOCacheCustomize.Enabled = $False
		} else {
			Save_Dynamic -regkey "Solutions" -name "RAMDisk" -value "False" -String
			$GUIImageSourceSetting_RAMDISK_Volume_Label.Enabled = $False
			$GUIImageSource_Setting_RAMDISK_Change.Enabled = $False
			$GUIImageSource_Setting_RAMDISK_Restore.Enabled = $False
			$GUIImageSourceISOCacheCustomizeName.Enabled = $True
			if ($GUIImageSourceISOCacheCustomizeName.Checked) {
				$GUIImageSourceISOCacheCustomize.Enabled = $True
			} else {
				$GUIImageSourceISOCacheCustomize.Enabled = $False
			}
		}

		<#
			.事件：ISO 默认保存位置，验证目录是否可读写
		#>
		if ($GUIImageSourceISOWrite.Checked) {
			Save_Dynamic -regkey "Solutions" -name "IsCheckWrite" -value "True" -String
		} else {
			Save_Dynamic -regkey "Solutions" -name "IsCheckWrite" -value "False" -String
		}

		<#
			.事件：ISO 默认保存位置，验证目录名称
		#>
		if ($GUIImageSourceISOSaveToCheckISO9660.Checked) {
			Save_Dynamic -regkey "Solutions" -name "IsCheckISOToFolderName" -value "True" -String
		} else {
			Save_Dynamic -regkey "Solutions" -name "IsCheckISOToFolderName" -value "False" -String
		}

		<#
			.完成后刷新：来源
		#>
		Image_Select_Refresh_Sources_List

		<#
			.完成后刷新：挂载状态
		#>
		Image_Select_Refresh_Mount_Disk
	}

	$GUIImageSourceGroupSettingOKClick = {
		$GUIImageSourceGroupSettingErrorMsg.Text = ""
		if ($GUIImageSourceSettingClearHistory.Checked) {
			Remove-Item -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		}

		if ($GUIImageSourceSettingClearSaveFolder.Checked) {
			Save_Dynamic -regkey "Solutions\ImageSources" -name "Sources_Other_Directory" -value "" -Multi
		}

		if ($GUIImageSourceSettingClearAppxStage.Checked) {
			Remove-Item -Path "$($env:TEMP)\appxStage-*" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
		}

		if ($UI_Main_Adv_Cmd.Checked) {
			Save_Dynamic -regkey "Solutions" -name "ShowCommand" -value "True" -String
		} else {
			Save_Dynamic -regkey "Solutions" -name "ShowCommand" -value "False" -String
		}

		if ($GUIImageSourceSettingHistoryDism.Checked) {
			Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\WIMMount\Mounted Images\*" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		}

		if ($GUIImageSourceGroupSettingSize.Checked) {
			Save_Dynamic -regkey "Solutions" -name "SearchDiskMinSize" -value $($GUIImageSourceGroupSettingLowSize.Text) -String
		}

		Image_Select_Refresh_Sources_List

		if ($GUIImageSourceISOCacheCustomizeName.Enabled) {
			if ($GUIImageSourceISOCacheCustomizeName.Checked) {
				<#
					.验证自定义 ISO 默认保存到目录名
				#>
				<#
					.Judgment: 1. Null value
					.判断：1. 空值
				#>
				if ([string]::IsNullOrEmpty($GUIImageSourceISOCacheCustomizePath.Text)) {
					$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.CacheDiskCustomize))"
					return
				}

				<#
					.Judgment: 2. The prefix cannot contain spaces
					.判断：2. 前缀不能带空格
				#>
				if ($GUIImageSourceISOCacheCustomizePath.Text -match '^\s') {
					$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
					return
				}

				<#
					.Judgment: 3. No spaces at the end
					.判断：3. 后缀不能带空格
				#>
				if ($GUIImageSourceISOCacheCustomizePath.Text -match '\s$') {
					$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
					return
				}

				<#
					.Judgment: 4. There can be no two spaces in between
					.判断：4. 中间不能含有二个空格
				#>
				if ($GUIImageSourceISOCacheCustomizePath.Text -match '\s{2,}') {
					$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
					return
				}

				<#
					.Judgment: 5. Cannot contain: \\ /: *? "" <> |
					.判断：5, 不能包含：\\ / : * ? "" < > |
				#>
				if ($GUIImageSourceISOCacheCustomizePath.Text -match '[~#$@!%&*{}<>?/|+"]') {
					$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorOther))"
					return
				}

				if (Test_Available_Disk -Path $GUIImageSourceISOCacheCustomizePath.Text) {
					Save_Dynamic -regkey "Solutions" -name "IsDiskCache" -value "True" -String
					Save_Dynamic -regkey "Solutions" -name "DiskCache" -value $GUIImageSourceISOCacheCustomizePath.Text -String
				} else {
					$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.FailedCreateFolder)"
					return
				}
			} else {
				Save_Dynamic -regkey "Solutions" -name "IsDiskCache" -value "False" -String
			}
		} else {
			Save_Dynamic -regkey "Solutions" -name "IsDiskCache" -value "False" -String
		}

		if ($GUIImageSourceISOSaveToCheckISO9660.Checked) {
			<#
				.验证自定义 ISO 默认保存到目录名
			#>
			<#
				.Judgment: 1. Null value
				.判断：1. 空值
			#>
			if ([string]::IsNullOrEmpty($GUIImageSourceISOCustomizePath.Text)) {
				$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.NoSetLabel))"
				return
			}

			<#
				.Judgment: 2. The prefix cannot contain spaces
				.判断：2. 前缀不能带空格
			#>
			if ($GUIImageSourceISOCustomizePath.Text -match '^\s') {
				$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
				return
			}

			<#
				.Judgment: 3. No spaces at the end
				.判断：3. 后缀不能带空格
			#>
			if ($GUIImageSourceISOCustomizePath.Text -match '\s$') {
				$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
				return
			}

			<#
				.Judgment: 4. There can be no two spaces in between
				.判断：4. 中间不能含有二个空格
			#>
			if ($GUIImageSourceISOCustomizePath.Text -match '\s{2,}') {
				$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorSpace))"
				return
			}

			<#
				.Judgment: 5. Cannot contain: \\ /: *? "" <> |
				.判断：5, 不能包含：\\ / : * ? "" < > |
			#>
			if ($GUIImageSourceISOCustomizePath.Text -match '[~#$@!%&*{}<>?/|+"]') {
				$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SelectFromError)$($lang.ISO9660TipsErrorOther))"
				return
			}
		}

		$MarkCheckSelectSearchDisk = $False
		$GUIImageSourceGroupSettingDisk.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Enabled) {
					if ($_.Checked) {
						$MarkCheckSelectSearchDisk = $True
						Image_Set_Disk_Sources -Disk $_.Tag
					}
				}
			}
		}

		if ($MarkCheckSelectSearchDisk) {
			Image_Select_Refresh_Sources_List
		} else {
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SearchImageSource)"
			return
		}

		if ($GUIImageSourceISOWrite.Checked) {
			if (-not (Test_Available_Disk -Path $GUIImageSourceISOCustomizePath.Text)) {
				$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.FailedCreateFolder)"
				return
			}
		}

		<#
			.验证自定义 ISO 默认保存到目录名，结束并保存新路径
		#>
		if ($GUIImageSourceGroupSettingStructure.Checked) {
			if (RefreshNewPath) {
				Save_Dynamic -regkey "Solutions" -name "DiskSearchStructure" -value $GUIImageSourceGroupSettingCustomizeShow.Text -String
			}
		}

		Save_Dynamic -regkey "Solutions" -name "ISOTo" -value $GUIImageSourceISOCustomizePath.Text -String
		$GUIImageSourceGroupSetting.visible = $False
	}

	Function Image_Select_Refresh_Sources_List
	{
		<#
			.重置：映像源显示区域
		#>
		$UI_Main_Select_Sources.controls.Clear()
		$UI_Main_Error.Text = ""
		$GUIImageSourceKernel10.Text = ""
		$UI_Main_Ok.Enabled = $False
		$GUIImageSourceMountInfo.Text = $lang.SelectImageMountStatus
		$GUIImageSourceOtherImageErrorMsg.Text = $lang.ImageSouresNoSelect
		$GUISelectNotExecuted.Enabled = $False
		$GUISelectGroupAfterFinishing.Enabled = $False

			<#
				.主键
			#>
			$UI_Primary_Key_Select.controls.Clear()
			$UI_Primary_Key_Group.Visible = $False

		<#
			.重置：重新选择语言界面
		#>
		$UI_Mask_Image_Language_Error.Text = ""
		$GUIImageSourceLanguageInfo.Text = $lang.LanguageNoSelect

		$TempSelectAraayPreRule = @()
		Get-ChildItem $Global:MainMasterFolder -Directory -Exclude ($ExcludeDirectory) -ErrorAction SilentlyContinue | ForEach-Object {
			if ((Test-Path "$($_.FullName)\sources\boot.wim" -PathType Leaf) -or
				(Test-Path "$($_.FullName)\sources\install.*" -PathType Leaf))
			{
				$TempSelectAraayPreRule += $_.FullName
			}
		}

		$UI_Main_Pre_Rule  = New-Object system.Windows.Forms.Label -Property @{
			Height         = 22
			Width          = 618
			Text           = "$($lang.RulePre) ( $($TempSelectAraayPreRule.Count) $($lang.EventManagerCount) )"
		}
		$UI_Main_Select_Sources.controls.AddRange($UI_Main_Pre_Rule)

		if ($TempSelectAraayPreRule.count -gt 0) {
			ForEach ($item in $TempSelectAraayPreRule) {
				$CheckBox     = New-Object System.Windows.Forms.RadioButton -Property @{
					Height    = 35
					Width     = 618
					Padding   = "25,0,0,0"
					Enabled   = $False
					Text      = $item
					Tag       = [IO.Path]::GetFileName($item)
					add_Click = $GUIImageSourceSelectVerClick
				}

				if ((Test-Path "$($item)\Sources\boot.wim" -PathType Leaf) -or
					(Test-Path "$($item)\Sources\install.*" -PathType Leaf))
				{
					$CheckBox.Enabled = $True
				}

				$UI_Main_Select_Sources.controls.AddRange($CheckBox)
			}
		} else {
			$UI_Main_Pre_Rule_Not_Find = New-Object system.Windows.Forms.Label -Property @{
				autoSize = 1
				Padding  = "18,0,0,0"
				margin   = "0,5,0,5"
				Text     = "$($lang.NoImagePreSource -f $Global:MainMasterFolder)"
			}
			$UI_Main_Select_Sources.controls.AddRange($UI_Main_Pre_Rule_Not_Find)
		}

		<#
			.其它位置
		#>
		if (-not (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources" -Name 'Sources_Other_Directory' -ErrorAction SilentlyContinue)) {
			Save_Dynamic -regkey "Solutions\ImageSources" -name "Sources_Other_Directory" -value "" -Multi
		}
		$GetExcludeSoftware = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources" -Name "Sources_Other_Directory" | Where-Object { -not ([string]::IsNullOrEmpty($_) -or [string]::IsNullOrWhiteSpace($_))} | Select-Object -Unique

		$TempSelectAraayOtherRule = @()
		ForEach ($item in $GetExcludeSoftware) {
			$TempSelectAraayOtherRule += $item
		}

		if ($TempSelectAraayOtherRule.count -gt 0) {
			$UI_Main_Other_Rule = New-Object system.Windows.Forms.Label -Property @{
				Height         = 22
				Width          = 618
				Margin         = "0,35,0,0"
				Text           = "$($lang.RuleOther) ( $($TempSelectAraayOtherRule.Count) $($lang.EventManagerCount) )"
			}
			$UI_Main_Select_Sources.controls.AddRange($UI_Main_Other_Rule)

			ForEach ($item in $TempSelectAraayOtherRule) {
				$CheckBox     = New-Object System.Windows.Forms.RadioButton -Property @{
					Height    = 35
					Width     = 618
					Padding   = "25,0,0,0"
					Enabled   = $False
					Text      = $item
					Tag       = [IO.Path]::GetFileName($item)
					add_Click = $GUIImageSourceSelectVerClick
				}

				if ((Test-Path "$($item)\Sources\boot.wim" -PathType Leaf) -or
					(Test-Path "$($item)\Sources\install.*" -PathType Leaf))
				{
					$CheckBox.Enabled = $True
				}

				$UI_Main_Select_Sources.controls.AddRange($CheckBox)
			}
		} else {
			$UI_Main_Other_Rule_Not_Find = New-Object system.Windows.Forms.LinkLabel -Property @{
				Height         = 35
				Width          = 618
				margin         = "0,35,0,0"
				Text           = $lang.NoImageOtherSource
				LinkColor      = "GREEN"
				ActiveLinkColor = "RED"
				LinkBehavior   = "NeverUnderline"
				add_Click      = $GUIImageSourceSelectClick
			}

			<#
				.烦，还是不显示提示未有其它路径
			#>
			$UI_Main_Select_Sources.controls.AddRange($UI_Main_Other_Rule_Not_Find)
		}
	}

	Function Image_Select_Refresh_Language
	{
		$FlagChangeLanguage = $False
		$UI_Main_Select_Sources.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Checked) {
					$FlagChangeLanguage = $true
				}
			}
		}

		if ($FlagChangeLanguage) {
			$UI_Mask_Image_Language.visible = $True
		} else {
			$UI_Main_Error.Text = $lang.SwitchLanguageError
		}
	}

	Function Image_Select_Refresh_MountTo
	{
		$FlagChangeLanguage = $False
		$UI_Main_Select_Sources.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Enabled) {
					if ($_.Checked) {
						$FlagChangeLanguage = $True
					}
				}
			}
		}

		if ($FlagChangeLanguage) {
			Image_Select_Refresh_Mount_Disk
			$UI_Mask_Image_Mount_To.visible = $True
		} else {
			$UI_Main_Error.Text = $lang.SwitchLanguageError
		}
	}

	<#
		.刷新挂载磁盘
	#>
	Function Image_Select_Refresh_Mount_Disk
	{
		if ($Global:Developers_Mode) {
			Write-Host "`n   $('-' * 80)`n   $($lang.Developers_Mode_Location)E0x006000"
		}

		$GUIImageSourceGroupMountChangeDiSKPane1.controls.Clear()
		$UI_Mask_Image_Mount_To_Tips.Text = ""
		Save_Dynamic -regkey "Solutions" -name "DiskMinSize" -value $GUIImageSourceGroupMountChangeLowSize.Text -String

		$MarkRAMDISK_Is_Check = $False
		$MarkRAMDISK_Match_Done = $False
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "RAMDisk" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "RAMDisk" -ErrorAction SilentlyContinue) {
				"True" {
					<#
						.从注册表获取卷标名
					#>
					if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "RAMDisk_Volume_Label" -ErrorAction SilentlyContinue) {
						$CustomRAMDISKLabel = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "RAMDisk_Volume_Label" -ErrorAction SilentlyContinue
					} else {
						$CustomRAMDISKLabel = $Init_RAMDISK_Volume_Label
					}

					$MarkRAMDISK_Is_Check = $True
				}
			}
		}

		Get-CimInstance -Class Win32_LogicalDisk -ErrorAction SilentlyContinue | Where-Object { -not ([string]::IsNullOrEmpty($_) -or [string]::IsNullOrWhiteSpace($_))} | ForEach-Object {
			$RootDiskMaster = (Join_MainFolder -Path $_.DeviceID)
			$RootDiskVolume = $_.VolumeName

			if (Test_Available_Disk -Path $RootDiskMaster) {
				$RadioButton  = New-Object System.Windows.Forms.RadioButton -Property @{
					Height    = 35
					Width     = 320
					Text      = "$($RootDiskVolume) ($($RootDiskMaster))"
					Tag       = $RootDiskMaster
					add_Click = { Image_Select_Refresh_Sources_Event }
				}

				if ($GUIImageSourceGroupMountChangeDiSKLowSize.Checked) {
					if (-not (Verify_Available_Size -Disk $RootDiskMaster -Size $GUIImageSourceGroupMountChangeLowSize.Text)) {
						$RadioButton.Enabled = $False
					}
				}

				if ($MarkRAMDISK_Is_Check) {
					if ($_.VolumeName -eq $CustomRAMDISKLabel) {
						$MarkRAMDISK_Match_Done = $True
						$RadioButton.Checked   = $True
						$RadioButton.ForeColor = "Green"
						$UI_Mask_Image_Mount_To_Tips.Text = "$($lang.AutoSelectRAMDISK -f $Init_RAMDISK_Volume_Label) ( $($RootDiskMaster) )"
					}
				}

				$GUIImageSourceGroupMountChangeDiSKPane1.controls.AddRange($RadioButton)
			}
		}

		if ($MarkRAMDISK_Is_Check) {
			if ($MarkRAMDISK_Match_Done) {

			} else {
				$UI_Mask_Image_Mount_To_Tips.Text = "$($lang.AutoSelectRAMDISKFailed -f $Init_RAMDISK_Volume_Label)"
			}
		}

		<#
			.初始化：自定义缓存路径
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsDiskCache" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsDiskCache" -ErrorAction SilentlyContinue) {
				"True" {
					if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\" -Name "DiskCache" -ErrorAction SilentlyContinue) {
						$GetRegeditDiskCache = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "DiskCache" -ErrorAction SilentlyContinue

						if (Test_Available_Disk -Path $GetRegeditDiskCache) {
							$RadioButton = New-Object System.Windows.Forms.RadioButton -Property @{
								Height    = 35
								Width     = 320
								Text      = $GetRegeditDiskCache
								Tag       = $GetRegeditDiskCache
								add_Click = { Image_Select_Refresh_Sources_Event }
							}

							if ($RadioButton.Tag -eq $GetRegeditDiskCache) {
								$RadioButton.Checked = $True
							}

							$GUIImageSourceGroupMountChangeDiSKPane1.controls.AddRange($RadioButton)
						}
					}
				}
			}
		}
	}

	<#
		.事件：选择挂载磁盘
	#>
	Function Image_Select_Refresh_Sources_Event
	{
		$Match_Done_And_Failed = $False

		<#
			.标记获取磁盘
		#>
		$GUIImageSourceGroupMountChangeDiSKPane1.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Enabled) {
					if ($_.Checked) {
						$Match_Done_And_Failed = $True
						$MarkNewLabelMountTo = (Join_MainFolder -Path "$($_.Tag)")
						$MarkNewLabelMountToTemp = (Join_MainFolder -Path "$($_.Tag)")
						$FullNewPath = [IO.Path]::GetFileName($GUIImageSourceGroupMountFromPath.Text)

						if ($GUIImageSourceGroupMountChangeTemp.Checked) {
							$MarkNewLabelMountTo += "Temp\"
							$MarkNewLabelMountToTemp += "Temp\"
						}

						$MarkNewLabelMountTo += "$($FullNewPath)_Mount"
						$MarkNewLabelMountToTemp += "$($FullNewPath)_Temp"

						$GUIImageSourceGroupMountToShow.Text = $MarkNewLabelMountTo

						if ($GUIImageSourceGroupMountToTemp.Checked) {
							$GUIImageSourceGroupMountToTempShow.Text = $MarkNewLabelMountToTemp
						} else {
							$GUIImageSourceGroupMountToTempShow.Text = "$($env:userprofile)\AppData\Local\Temp"
						}

						Save_Dynamic -regkey "Solutions" -name "DiskMinSize" -value $($GUIImageSourceGroupMountChangeLowSize.Text) -String
					}
				}
			}
		}

		if ($Match_Done_And_Failed) {
		} else {
			$FullNewPath = $GUIImageSourceGroupMountFromPath.Text

			if ($GUIImageSourceGroupMountChangeTemp.Checked) {
				$MarkNewLabelMountTo += "Temp\"
				$MarkNewLabelMountToTemp += "Temp\"
			}

			$MarkNewLabelMountTo += "$($FullNewPath)_Mount"
			$MarkNewLabelMountToTemp += "$($FullNewPath)_Temp"

			$GUIImageSourceGroupMountToShow.Text = $MarkNewLabelMountTo

			if ($GUIImageSourceGroupMountToTemp.Checked) {
				$GUIImageSourceGroupMountToTempShow.Text = $MarkNewLabelMountToTemp
			} else {
				$GUIImageSourceGroupMountToTempShow.Text = "$($env:userprofile)\AppData\Local\Temp"
			}
		}

		<#
			.重置打开目录
		#>
		Image_Select_Refresh_Sources
	}

	$GetDiskAvailableClick = {
		if ($GUIImageSourceGroupMountChangeDiSKLowSize.Checked) {
			$GUIImageSourceGroupMountChangeLowSize.Enabled = $True
		} else {
			$GUIImageSourceGroupMountChangeLowSize.Enabled = $False
		}

		Image_Select_Refresh_Mount_Disk
		Image_Select_Refresh_Sources_Event
	}

	$GUIImageSourceSelectClick = {
		if (-not (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources" -Name 'Sources_Other_Directory' -ErrorAction SilentlyContinue)) {
			Save_Dynamic -regkey "Solutions\ImageSources" -name "Sources_Other_Directory" -value "" -Multi
		}
		$GetExcludeSoftware = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources" -Name "Sources_Other_Directory" | Where-Object { -not ([string]::IsNullOrEmpty($_) -or [string]::IsNullOrWhiteSpace($_))} | Select-Object -Unique

		$TempSelectAraayOtherRule = @()
		ForEach ($item in $GetExcludeSoftware) {
			$TempSelectAraayOtherRule += $item
		}

		$FolderBrowser   = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{
			RootFolder   = "MyComputer"
		}

		if ($FolderBrowser.ShowDialog() -eq "OK") {
			if ($TempSelectAraayOtherRule -Contains $FolderBrowser.SelectedPath) {
				$UI_Main_Error.Text = "$($lang.Existed)"
			} else {
				$TempSelectAraayOtherRule += $FolderBrowser.SelectedPath
				Save_Dynamic -regkey "Solutions\ImageSources" -name "Sources_Other_Directory" -value $TempSelectAraayOtherRule -Multi

				Image_Select_Refresh_Sources_List
			}
		} else {
			$UI_Main_Error.Text = "$($lang.UserCanel)"
		}
	}

	Function Image_Select_Refresh_Detailed
	{
		$FlagChangeLanguage = $False
		$UI_Main_Select_Sources.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Enabled) {
					if ($_.Checked) {
						$FlagChangeLanguage = $True
					}
				}
			}
		}

		if ($FlagChangeLanguage) {
			$GUIImageSourceGroupOtherPanel.visible = $True
		} else {
			$UI_Main_Error.Text = $lang.SwitchLanguageError
		}
	}

	Function Image_Select_Refresh_Event
	{
		$GUISelectOtherSettingSaveModeErrorMsg.Text = ""
		$GUISelectNotExecuted.Enabled = $False
		$GUISelectGroupAfterFinishing.Enabled = $False
		$GUIImageSourceGroupSettingEventSelect.controls.Clear()

		Get-ChildItem -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue" -ErrorAction SilentlyContinue | ForEach-Object {
			$CheckBox     = New-Object System.Windows.Forms.RadioButton -Property @{
				Height    = 35
				Width     = 285
				Text      = Split-Path -Path $_.Name -Leaf
				add_Click = $GUIImageSourceGroupSettingEventSelectClick
			}

			$GUIImageSourceGroupSettingEventSelect.controls.AddRange($CheckBox)
		}
	}

	<#
		.事件：点击了事件
	#>
	$GUIImageSourceGroupSettingEventSelectClick = {
		$GUIImageSourceGroupSettingEventSelect.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Enabled) {
					if ($_.Checked) {
						$GUISelectNotExecuted.Enabled = $True
						$GUISelectGroupAfterFinishing.Enabled = $True

						if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue\$($_.Text)" -Name "AllowAfterFinishing" -ErrorAction SilentlyContinue) {
							switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue\$($_.Text)" -Name "AllowAfterFinishing" -ErrorAction SilentlyContinue) {
								"True" {
									$GUISelectNotExecuted.Checked = $True
									$GUISelectGroupAfterFinishing.Enabled = $True
								}
								"False" {
									$GUISelectNotExecuted.Checked = $False
									$GUISelectGroupAfterFinishing.Enabled = $False
								}
							}
						} else {
							$GUISelectNotExecuted.Checked = $False
							$GUISelectGroupAfterFinishing.Enabled = $False
						}

						if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue\$($_.Text)" -Name "AfterFinishing" -ErrorAction SilentlyContinue) {
							switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue\$($_.Text)" -Name "AfterFinishing" -ErrorAction SilentlyContinue) {
								2 { $GUISelectAfterFinishingPause.Checked = $True }
								3 { $GUISelectAfterFinishingReboot.Checked = $True }
								4 { $GUISelectAfterFinishingShutdown.Checked = $True }
							}
						} else {
							$GUISelectAfterFinishingPause.Checked = $True
						}
					}
				}
			}
		}
	}

	$GUISelectNotExecutedClick = {
		if ($GUISelectNotExecuted.Checked) {
			$GUIImageSourceGroupSettingEventSelect.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue\$($_.Text)" -name "AllowAfterFinishing" -value "True" -String
						}
					}
				}
			}
			$GUISelectGroupAfterFinishing.Enabled = $True
		} else {
			$GUIImageSourceGroupSettingEventSelect.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue\$($_.Text)" -name "AllowAfterFinishing" -value "False" -String
						}
					}
				}
			}
			$GUISelectGroupAfterFinishing.Enabled = $False
		}
	}

	<#
		.Event: canceled
		.事件：取消
	#>
	$GUIImageSourceSelectVerClick = {
		$GUIImageSourceOtherImageErrorMsg.Text = ""
		$UI_Main_Error.Text = ""
		$GUISelectOtherSettingSaveModeErrorMsg.Text = ""
		$UI_Mask_Image_Language_Error.Text = ""
		$GUIImageSourceGroupSettingEventClear.Enabled = $True
		$GUISelectOtherSettingSaveModeClear.Enabled = $True

		<#
			.清除选择主键
		#>
		$UI_Primary_Key_Select.controls.Clear()

		<#
			.禁用确定按钮
		#>
		$UI_Main_Ok.Enabled = $True

		$UI_Main_Select_Sources.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Checked) {
					$Global:MountTo = $($_.Text)
					$Global:MainImage = $($_.Tag)

					$GUIImageSourceGroupMountFromPath.Text = $($_.Text)

					<#
						从注册表获取是否临时目录与挂载到位置相同
					#>
					if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "TempFolderSync" -ErrorAction SilentlyContinue) {
						switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "TempFolderSync" -ErrorAction SilentlyContinue) {
							"True" { $GUIImageSourceGroupMountToTemp.Checked = $True }
							"False" { $GUIImageSourceGroupMountToTemp.Checked = $False }
						}
					} else {
						$GUIImageSourceGroupMountToTemp.Checked = $True
					}

					<#
						从注册表获取是否使用临时目录
					#>
					if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "UseTempFolder" -ErrorAction SilentlyContinue) {
						switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "UseTempFolder" -ErrorAction SilentlyContinue) {
							"True" { $GUIImageSourceGroupMountChangeTemp.Checked = $True }
							"False" { $GUIImageSourceGroupMountChangeTemp.Checked = $False }
						}
					} else {
						$GUIImageSourceGroupMountChangeTemp.Checked = $False
					}

					<#
						从注册表获取挂载目录
					#>
					if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "MountToRouting" -ErrorAction SilentlyContinue) {
						$GetDiskMinSize = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "MountToRouting"
						$GUIImageSourceGroupMountToShow.Text = $GetDiskMinSize
					} else {
						$GUIImageSourceGroupMountToShow.Text = "$($Global:MountTo)_Mount"
					}

					<#
						从注册表获取挂载临时目录
					#>
					if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "MountToRoutingTemp" -ErrorAction SilentlyContinue) {
						$GetDiskMinSize = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "MountToRoutingTemp"
						$GUIImageSourceGroupMountToTempShow.Text = $GetDiskMinSize
					} else {
						$GUIImageSourceGroupMountToTempShow.Text = "$($env:userprofile)\AppData\Local\Temp"
					}

					<#
						从注册表获取保存的映像默认语言
					#>
					ISO_Verify_Sources_Language

					<#
						判断内核
					#>
					ISO_Verify_Kernel

					<#
						判断架构
					#>
					ISO_Verify_Arch
			
					<#
						.判断安装类型
					#>
					ISO_Verify_Install_Type

					<#
						.Get the matched or saved tag name
						.获取匹配到，或已保存的标签名
					#>
					if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\ISO" -Name "Label" -ErrorAction SilentlyContinue) {
						$GetSaveLabelSelect = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\ISO" -Name "Label" -ErrorAction SilentlyContinue
						$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.ImageCodename) ( $($GetSaveLabelSelect), $($lang.SaveMode) )"
					} else {
						$MarkCodename = $False
						ForEach ($item in $Global:OSCodename) {
							if ($Global:MainImage -like "*$($item)*") {
								$MarkCodename = $True
								Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\ISO" -name "Label" -value $item -String
								$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.ImageCodename) ( $($item), $($lang.MatchMode) )"
								break
							}
						}
			
						if (-not $MarkCodename) {
							$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.ImageCodename) ( $($lang.ImageCodenameNo) )"
						}
					}

					<#
						.从注册表获取完成后事件：
						2：暂停；3：重启计算机；4：关闭计算机
					#>
					[int]$MarkInitLanguage = 0
					Get-ChildItem -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue" -ErrorAction SilentlyContinue | ForEach-Object {
						$MarkInitLanguage++
					}
					Image_Select_Refresh_Event
			
					if ($MarkInitLanguage -ge "1") {
						$GUIImageSourceOtherImageErrorMsg.Text += ", $($lang.EventManager) ( $($MarkInitLanguage) $($lang.EventManagerCount) )"
					} else {
						$GUIImageSourceOtherImageErrorMsg.Text += ", $($lang.EventManager) ( $($lang.EventManagerNo) )"
					}
			
					$UI_Main_Select_Sources.Controls | ForEach-Object {
						if ($_ -is [System.Windows.Forms.RadioButton]) {
							if ($_.Enabled) {
								if ($_.Checked) {
									if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($_.Tag)" -Name "language" -ErrorAction SilentlyContinue) {
										$GUIImageSourceOtherImageErrorMsg.Text += ", $($lang.SaveModeTipsClear)"
									}
								}
							}
						}
					}

					<#
						.从注册表获取完成后事件：
						2：暂停；3：重启计算机；4：关闭计算机
					#>
					$GUISelectNotExecuted.Checked = $False
					$GUISelectGroupAfterFinishing.Enabled = $False
					$GUISelectAfterFinishingPause.Checked
					$GUISelectAfterFinishingReboot.Checked
					$GUISelectAfterFinishingShutdown.Checked

					Image_Select_Refresh_Mount_Disk
					Image_Select_Refresh_Sources_Event

					$Global:MountToRouting = $GUIImageSourceGroupMountToShow.Text
					$Global:MountToRoutingTemp = $GUIImageSourceGroupMountToTempShow.Text

					$Script:Mark_Is_Legal_Sources_init = $False

					<#
						.刷新全局规则
					#>
					Image_Refresh_Init_GLobal_Rule

					<#
						.Tag: match from the current operating system mounted list
						.标记：从当前操作系统已挂载列表匹配
					#>
					ForEach ($item in $Global:Image_Rule) {
						Image_Select_New_Sources -Master $item.Main.ImageFileName -ImageName $item.Main.ImageFileName -ImageFile $item.Main.AbsolutePath -ImageUid $item.Main.Uid

						if ($item.Expand.Count -gt 0) {
							ForEach ($Expand in $item.Expand) {
							 	Image_Select_New_Sources -Master $item.Main.ImageFileName -ImageName $Expand.ImageFileName -ImageFile $Expand.AbsolutePath -ImageUid $Expand.Uid -Expand
							}
						}
					}

					<#
						.刷新挂载状态
					#>
					if ($Script:Mark_Is_Legal_Sources_init) {
						Image_Select_Refresh_Sources_Event
						$GUIImageSourceGroupMountChangePanel.Enabled = $False
						$GUIImageSourceGroupMountToTemp.Enabled = $False
						$UI_Mask_Image_Mount_To_Reset.Enabled = $False
						$GUIImageSourceGroupSettingEventClear.Enabled = $False
						$GUISelectOtherSettingSaveModeClear.Enabled = $False
						$GUIImageSourceMountInfo.Text = "$($lang.Mounted), $($lang.Detailed_View)"
						$UI_Mask_Image_Mount_To_Error.Text = "$($lang.Mounted), $($lang.Inoperable)"
					} else  {
						Image_Select_Refresh_Sources_Event
						$GUIImageSourceGroupMountChangePanel.Enabled = $True
						$GUIImageSourceGroupMountToTemp.Enabled = $True
						$UI_Mask_Image_Mount_To_Reset.Enabled = $True
						$GUIImageSourceGroupSettingEventClear = $True
						$GUISelectOtherSettingSaveModeClear.Enabled = $True
						$GUIImageSourceMountInfo.Text = "$($lang.NotMountedSpecify)"
						$UI_Mask_Image_Mount_To_Error.Text = "$($lang.NotMountedSpecify)"
					}
				}
			}
		}
	}

	Function Image_Select_New_Sources
	{
		param
		(
			$Master,
			$ImageName,
			$ImageFile,
			$ImageUid,
			[switch]$Expand
		)

		<#
			.判断 ISO 主要来源是否存在文件
		#>
		if (Test-Path $ImageFile -PathType leaf -ErrorAction SilentlyContinue) {
			$UI_Primary_Key_Group.Visible = $True

			$GUIImageSelectInstall = New-Object System.Windows.Forms.RadioButton -Property @{
				Height             = 30
				Width              = 245
				Text               = $ImageName
				Tag                = $ImageUid
			}

			if ($Global:Primary_Key_Image.Uid -eq "$($Master);$($ImageName);") {
				$GUIImageSelectInstall.Checked = $True
			}

			$GUIImageSelectInstallTips = New-Object System.Windows.Forms.Label -Property @{
				AutoSize           = 1
				Padding            = "15,0,0,0"
				Text               = ""
			}

			$GUIImageSelectInstall_Wrap = New-Object System.Windows.Forms.Label -Property @{
				Height             = 15
				Width              = 245
			}
			$UI_Primary_Key_Select.controls.AddRange((
				$GUIImageSelectInstall,
				$GUIImageSelectInstallTips,
				$GUIImageSelectInstall_Wrap
			))
			
			if ($Expand) {
				$GUIImageSelectInstall.Padding = "20,0,0,0"
				$GUIImageSelectInstallTips.Padding = "36,0,0,0"
			}

			<#
				.Get all mounted images from the current system that match the current one
				.从当前系统里获取所有已挂载镜像与当前匹配
			#>
			$MarkErrorMounted = $False
			try {
				<#
					.标记是否捕捉到事件
				#>
				Get-WindowsImage -Mounted -ErrorAction SilentlyContinue | ForEach-Object {
					<#
						.判断文件路径与当前是否一致
					#>
					if ($_.ImagePath -eq $ImageFile) {
						$MarkErrorMounted = $True
						$Script:Mark_Is_Legal_Sources_init = $True

						<#
							.不合法和损坏
						#>
						if ($_.MountStatus -eq "Invalid") {
							$GUIImageSelectInstall.ForeColor = "Red"
							$GUIImageSelectInstallTips.Text = $lang.MountedIndexError
						}

						if ($_.MountStatus -eq "Ok") {
							$GUIImageSelectInstall.ForeColor = "Green"
							$GUIImageSelectInstallTips.Text = $lang.MountedIndexSuccess
						}
					}
				}

				if ($MarkErrorMounted) {
					$GUIImageSelectInstallTips.Text = $lang.MountedIndexError
				} else {
					if (Test-Path "$($Global:MountToRouting)\$($Master)\$($ImageName)" -PathType Container -ErrorAction SilentlyContinue) {
						$GUIImageSelectInstallTips.Text = $lang.MountedIndexError
					} else {
						$GUIImageSelectInstallTips.Text = $lang.NotMounted
					}
				}
			} catch {
				$GUIImageSelectInstallTips.Text = $lang.MountedIndexError
			}
		}
	}

	<#
		.重置打开目录
	#>
	Function Image_Select_Refresh_Sources
	{
		<#
			.映像源
		#>
		if (Test-Path $GUIImageSourceGroupMountFromPath.Text -PathType Container) {
			$GUIImageSourceGroupMountFromOpenFolder.Enabled = $True
			$GUIImageSourceGroupMountFromPaste.Enabled = $True
		} else {
			$GUIImageSourceGroupMountFromOpenFolder.Enabled = $False
			$GUIImageSourceGroupMountFromPaste.Enabled = $False
		}

		<#
			.挂载到
		#>
		if (Test-Path $GUIImageSourceGroupMountToShow.Text -PathType Container) {
			$GUIImageSourceGroupMountToOpenFolder.Enabled = $True
			$GUIImageSourceGroupMountToPaste.Enabled = $True
		} else {
			$GUIImageSourceGroupMountToOpenFolder.Enabled = $False
			$GUIImageSourceGroupMountToPaste.Enabled = $False
		}

		<#
			.临时目录
		#>
		if (Test-Path $GUIImageSourceGroupMountToTempShow.Text -PathType Container) {
			$GUIImageSourceGroupMountToTempOpenFolder.Enabled = $True
			$GUIImageSourceGroupMountToTempPaste.Enabled = $True
		} else {
			$GUIImageSourceGroupMountToTempOpenFolder.Enabled = $False
			$GUIImageSourceGroupMountToTempPaste.Enabled = $False
		}
	}

	<#
		.Event: Ok
		.事件：确认
	#>
	$UI_Main_Ok_Click = {
		$UI_Main_Select_Sources.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				#region 已选择
				if ($_.Checked) {
					$UI_Main.Hide()
					$Global:MountTo = $($_.Text)
					$Global:MainImage = $($_.Tag)

					Write-Host "`n   $($lang.SelectPriKey)" -ForegroundColor Yellow
					$UI_Primary_Key_Select.Controls | ForEach-Object {
						if ($_ -is [System.Windows.Forms.RadioButton]) {
							if ($_.Enabled) {
								if ($_.Checked) {
									Image_Set_Global_Primary_Key -Uid $_.Tag
								}
							}
						}
					}

					if ([string]::IsNullOrEmpty($Global:Primary_Key_Image.ImageFileName)) {
						Write-Host "   $($lang.NoChoose)" -ForegroundColor Red
					} else {
						Write-Host "   $($Global:Primary_Key_Image.ImageFileName)" -ForegroundColor Yellow
					}

					$Global:MountToRouting = $GUIImageSourceGroupMountToShow.Text
					Write-Host "`n   $($lang.MountImageTo), $($lang.MainImageFolder)"
					Write-Host "   $($Global:MountToRouting)" -ForegroundColor Yellow

					<#
						.刷新全局规则
					#>
					Image_Refresh_Init_GLobal_Rule

					Write-Host "`n   $($lang.MainImageFolder)"
					Write-Host "   $($Global:MountTo)" -ForegroundColor Yellow
					Image_Get_Mount_Status

					$Global:MountToRoutingTemp = $GUIImageSourceGroupMountToTempShow.Text
					Write-Host "`n   $($lang.SettingImageTempFolder)"
					Write-Host "   $($Global:MountToRoutingTemp)" -ForegroundColor Yellow

					Save_Dynamic -regkey "Solutions\ImageSources\$($_.Tag)" -name "language" -value $Global:MainImageLang -String
					Write-Host "`n   $($lang.Language)"
					Write-Host "   $($Global:MainImageLang)" -ForegroundColor Green

					Write-Host "`n   $($lang.Kernel)"
					$Global:Kernel = $GUIImageSourceKernel10.Text

					Write-Host "   $($Global:Kernel)" -ForegroundColor Green
					Save_Dynamic -regkey "Solutions\ImageSources\$($_.Tag)" -name "Kernel" -value $Global:Kernel -String

					Write-Host "`n   $($lang.ImageLevel)"
					if ($GUISelectTypeDesktop.Checked) {
						$Global:ImageType = "Desktop"
						Write-Host "   $($GUISelectTypeDesktop.Text)" -ForegroundColor Green
					}
					if ($GUISelectTypeServer.Checked) {
						$Global:ImageType  = "Server"
						Write-Host "   $($GUISelectTypeServer.Text)" -ForegroundColor Green
					}
					Save_Dynamic -regkey "Solutions\ImageSources\$($_.Tag)" -name "ImageType" -value $Global:ImageType -String

					if ($GUIImageSourceArchitectureARM64.Checked) { $Global:Architecture = "arm64" }
					if ($GUIImageSourceArchitectureAMD64.Checked)   { $Global:Architecture  = "AMD64" }
					if ($GUIImageSourceArchitectureX86.Checked)   { $Global:Architecture  = "x86" }
					Save_Dynamic -regkey "Solutions\ImageSources\$($_.Tag)" -name "Architecture" -value $Global:Architecture -String

					Write-Host "`n   $($lang.Architecture)"
					Write-Host "   $($Global:Architecture)" -ForegroundColor Green

					Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)" -name "MountToRouting" -value $Global:MountToRouting -String
					Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)" -name "MountToRoutingTemp" -value $Global:MountToRoutingTemp -String

					Event_Reset_Variable
					$UI_Main.Close()
				}
				#endregion 已选择
			}
		}
		$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.NoSelectImageSource))"
	}
	$UI_Main           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 1006
		Text           = $lang.SelectSettingImage
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}

	<#
		.动态显示映像来源：磁盘
	#>
	$UI_Main_Select_Sources = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 490
		Width          = 650
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Location       = '0,0'
		Padding        = "15,15,0,0"
	}

	<#
		.组：设置界面
	#>
	$GUIImageSourceGroupSetting = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 678
		Width          = 1006
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '0,0'
		Visible        = 0
	}

	$GUIImageSourceSettingGroupAll = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 675
		Width          = 500
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "0,10,0,0"
		Location       = '20,0'
	}
	$GUIImageSourceSettingAdv = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 475
		Margin         = "0,10,0,0"
		Text           = $lang.AdvOption
	}

	<#
		.事件：添加到系统变量
	#>
	$GUIImageSourceSettingEnv = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 475
		Padding        = "16,0,0,0"
		Text           = $lang.AddEnv
		add_Click      = {
			$Current_Folder = Convert-Path -Path "$($PSScriptRoot)\..\..\..\..\Router" -ErrorAction SilentlyContinue
			$regLocation = "Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment"
			$path = (Get-ItemProperty -Path $regLocation -Name PATH).path
	
			if ($This.Checked) {
				<#
					.添加模式
				#>
				$windows_path = $path -split ';'
				if (($windows_path) -Contains $Current_Folder) {
				} else {
					$path = "$($path);$($Current_Folder)"
					Set-ItemProperty -Path $regLocation -Name PATH -Value $path
					$Env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
				}
			} else {
				<#
					.删除模式
				#>
				$path = ($path.Split(';') | Where-Object { $_ -ne $Current_Folder }) -join ';'
				Set-ItemProperty -Path $regLocation -Name PATH -Value $path
				$Env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
			}
		}
	}
	$GUIImageSourceSettingEnvTips = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		Margin         = "36,0,0,10"
		Text           = $lang.AddEnvTips
	}

	$GUIImageSourceSettingTopMost = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 475
		Padding        = "16,0,0,0"
		Text           = $lang.AllowTopMost
		add_Click      = { Image_Select_Refresh_Sources_Setting }
	}
	$GUIImageSourceSettingTopMostSuccess = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 475
		Padding        = "36,0,0,0"
		Margin         = "0,0,0,12"
		Text           = $lang.AllowTopMostSuccess
		add_Click      = { Image_Select_Refresh_Sources_Setting }
	}
	$GUIImageSourceSettingClearHistory = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 475
		Padding        = "16,0,0,0"
		Text           = $lang.History
	}
	$GUIImageSourceSettingClearHistoryLog = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 475
		Padding        = "16,0,0,0"
		Text           = $lang.HistoryLog
		add_Click      = { Image_Select_Refresh_Sources_Setting }
	}
	$GUIImageSourceSettingClearSaveFolder = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 475
		Padding        = "16,0,0,0"
		Text           = $lang.HistorySaveFolder
	}
	$GUIImageSourceSettingClearAppxStage = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 475
		Padding        = "16,0,0,0"
		Text           = $lang.HistoryClearappxStage
	}
	$UI_Main_Adv_Cmd   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 475
		Padding        = "16,0,0,0"
		Text           = $lang.ShowCommand
	}
	$GUIImageSourceSettingBootSize = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 475
		Padding        = "16,0,0,0"
		Text           = $lang.DoNotCheckBoot
		add_Click      = { Image_Select_Refresh_Sources_Setting }
	}
	$GUIImageSourceSettingHistoryDism = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 475
		Padding        = "16,0,0,0"
		Text           = $lang.HistoryClearDismSave
	}

	<#
		.磁盘缓存
	#>
	$GUIImageSourceISOCache = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 470
		Margin         = "0,22,0,0"
		Text           = $lang.CacheDisk
	}
	$GUIImageSourceSettingRAMDISK = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 460
		Margin         = "16,0,0,0"
		Text           = "$($lang.AutoSelectRAMDISK -f "Initial")"
		add_Click      = { Image_Select_Refresh_Sources_Setting }
	}
	$GUIImageSourceSetting_RAMDISK_Volume_Label = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 35
		Width          = 255
		Margin         = "30,5,0,20"
		Text           = ""
	}
	$GUIImageSource_Setting_RAMDISK_Change = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 475
		Padding        = "28,0,0,0"
		Text           = $lang.RAMDISK_Change
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $GUIImageSource_Setting_RAMDISK_Change_Click
	}

	<#
		.事件：恢复初始化 RAMDISK 卷标
	#>
	$GUIImageSource_Setting_RAMDISK_Restore = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 475
		Padding        = "30,0,0,0"
		margin         = "0,0,0,10"
		Text           = "$($lang.RAMDISK_Restore -f $Init_RAMDISK_Volume_Label)"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Save_Dynamic -regkey "Solutions" -name "RAMDisk_Volume_Label" -value $Init_RAMDISK_Volume_Label -String
			$GUIImageSourceSettingRAMDISK.Text = "$($lang.AutoSelectRAMDISK -f $Init_RAMDISK_Volume_Label)"
			$GUIImageSourceSetting_RAMDISK_Volume_Label.Text = $Init_RAMDISK_Volume_Label
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.RAMDISK_Restore -f $Init_RAMDISK_Volume_Label)"
		}
	}

	<#
		.事件：自定义缓存路径
	#>
	$GUIImageSourceISOCacheCustomizeName = New-Object system.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 460
		Margin         = "16,0,0,0"
		Text           = $lang.CacheDiskCustomize
		add_Click      = {
			if ($GUIImageSourceISOCacheCustomizeName.Checked) {
				$GUIImageSourceISOCacheCustomize.Enabled = $True
			} else {
				Save_Dynamic -regkey "Solutions" -name "IsDiskCache" -value "False" -String
				$GUIImageSourceISOCacheCustomize.Enabled = $False
			}
		}
	}
	$GUIImageSourceISOCacheCustomize = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		AutoSize       = 1
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "0,0,8,0"
	}
	$GUIImageSourceISOCacheCustomizePath = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 414
		Margin         = "30,5,0,20"
		Text           = ""
	}

	<#
		.事件：自定义缓存路径，选择目录
	#>
	$GUIImageSourceISOCacheCustomizePathSelect = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 455
		Padding        = "26,0,0,0"
		Text           = $lang.SelectFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$GUIImageSourceGroupSettingErrorMsg.Text = ""
			$FolderBrowser   = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{
				RootFolder   = "MyComputer"
			}

			if ($FolderBrowser.ShowDialog() -eq "OK") {
				if (Test_Available_Disk -Path $FolderBrowser.SelectedPath) {
					$GUIImageSourceISOCacheCustomizePath.Text = $FolderBrowser.SelectedPath
				} else {
					$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.FailedCreateFolder)"
				}
			} else {
				$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.UserCanel)"
			}
		}
	}

	<#
		.事件：磁盘缓存，打开目录
	#>
	$GUIImageSourceISOCacheCustomizePathOpen = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 455
		Padding        = "26,0,0,0"
		Text           = $lang.OpenFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($GUIImageSourceISOCacheCustomizePath.Text)) {
				if (Test-Path $GUIImageSourceISOCacheCustomizePath.Text -PathType Container) {
					Start-Process $GUIImageSourceISOCacheCustomizePath.Text
				}
			}
		}
	}

	<#
		.事件：磁盘缓存，复制路径
	#>
	$GUIImageSourceISOCacheCustomizePathPaste = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 455
		Padding        = "26,0,0,0"
		Text           = $lang.Paste
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($GUIImageSourceISOCacheCustomizePath.Text)) {
				Set-Clipboard -Value $GUIImageSourceISOCacheCustomizePath.Text
			}
		}
	}

	<#
		.ISO：保存位置
	#>
	$GUIImageSourceISOSaveTo = New-Object system.Windows.Forms.Label -Property @{
		Height         = 28
		Width          = 470
		Margin         = "0,22,0,0"
		Text           = $lang.SaveTo
	}
	$GUIImageSourceISOCustomizePath = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 430
		Margin         = "18,0,0,20"
		Text           = ""
	}

	<#
		.事件：ISO 默认保存位置，选择目录
	#>
	$GUIImageSourceISOCustomizePathSelect = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 475
		Padding        = "14,0,0,0"
		Text           = $lang.SelectFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$GUIImageSourceGroupSettingErrorMsg.Text = ""
			$FolderBrowser   = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{
				RootFolder   = "MyComputer"
			}

			if ($FolderBrowser.ShowDialog() -eq "OK") {
				if (Test_Available_Disk -Path $FolderBrowser.SelectedPath) {
					$GUIImageSourceISOCustomizePath.Text = $FolderBrowser.SelectedPath
					Save_Dynamic -regkey "Solutions" -name "ISOTo" -value $FolderBrowser.SelectedPath -String
				} else {
					$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.FailedCreateFolder)"
				}
			} else {
				$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.UserCanel)"
			}
		}
	}

	<#
		.事件：ISO 默认保存位置，打开目录
	#>
	$GUIImageSourceISOCustomizePathOpen = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 475
		Padding        = "14,0,0,0"
		Text           = $lang.OpenFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($GUIImageSourceISOCustomizePath.Text)) {
				if (Test-Path $GUIImageSourceISOCustomizePath.Text -PathType Container) {
					Start-Process $GUIImageSourceISOCustomizePath.Text
				}
			}
		}
	}

	<#
		.事件：ISO 默认保存位置，复制路径
	#>
	$GUIImageSourceISOCustomizePathPaste = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 475
		Padding        = "14,0,0,0"
		Text           = $lang.Paste
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($GUIImageSourceISOCustomizePath.Text)) {
				Set-Clipboard -Value $GUIImageSourceISOCustomizePath.Text
			}
		}
	}

	<#
		.事件：恢复为映像源搜索盘同一位置
	#>
	$GUIImageSourceISOCustomizePathRestore = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 475
		Padding        = "14,0,0,0"
		Text           = $lang.ISOSaveSame
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$GUIImageSourceGroupSettingDisk.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							$GUIImageSourceISOCustomizePath.Text = $_.Tag
						}
					}
				}
			}

			Save_Dynamic -regkey "Solutions" -name "ISOTo" -value $Global:MainMasterFolder -String
		}
	}

	<#
		.事件：ISO 默认保存位置，同步新位置
	#>
	$GUIImageSourceISOSync = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 450
		Margin         = "22,15,0,0"
		Text           = $lang.ISOSaveSync
		add_Click      = {
			if ($This.Checked) {
				Save_Dynamic -regkey "Solutions" -name "IsSearchSyncPath" -value "True" -String

				$GUIImageSourceGroupSettingDisk.Controls | ForEach-Object {
					if ($_ -is [System.Windows.Forms.RadioButton]) {
						if ($_.Enabled) {
							if ($_.Checked) {
								$GUIImageSourceISOCustomizePath.Text = $_.Tag
							}
						}
					}
				}
			} else {
				Save_Dynamic -regkey "Solutions" -name "IsSearchSyncPath" -value "False" -String
			}
		}
	}
	$GUIImageSourceISOWrite = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 450
		Margin         = "22,0,0,0"
		Text           = $lang.ISOFolderWrite
		add_Click      = { Image_Select_Refresh_Sources_Setting }
	}
	$GUIImageSourceISOSaveToCheckISO9660 = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 450
		Margin         = "22,0,0,0"
		Text           = $lang.ISO9660
		add_Click      = { Image_Select_Refresh_Sources_Setting }
	}
	$GUIImageSourceISOSaveToCheckISO9660Tips = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		Margin         = "36,0,25,0"
		Text           = $lang.ISO9660Tips
	}

	<#
		.建议的项目
	#>
	$GUIImageSourceSettingSuggested = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 470
		Margin         = "0,35,0,8"
		Text           = $lang.SuggestedAllow
		add_Click      = {
			if ($GUIImageSourceSettingSuggested.Checked) {
				Save_Dynamic -regkey "Solutions" -name "IsSuggested" -value "True" -String
				$GUIImageSourceSettingSuggestedPanel.Enabled = $True
			} else {
				Save_Dynamic -regkey "Solutions" -name "IsSuggested" -value "False" -String
				$GUIImageSourceSettingSuggestedPanel.Enabled = $False
			}
		}
	}
	$GUIImageSourceSettingSuggestedPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		AutoSize       = 1
		autoSizeMode   = 1
		autoScroll     = $True
	}

	<#
		.生成解决方案
	#>
	$GUIImageSourceSettingSuggestedSoltions = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "12,0,0,0"
		Text           = $lang.CopyFileToImage
		Tag            = "Solutions_Create_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}

	<#
		.组，语言
	#>
	$GUIImageSourceSettingSuggestedLang = New-Object system.Windows.Forms.Label -Property @{
		Height         = 35
		Width          = 450
		Padding        = "16,0,0,0"
		margin         = "0,15,0,0"
		Text           = $lang.Language
	}
	$GUIImageSourceSettingSuggestedLangAdd = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = "$($lang.Language): $($lang.AddTo)"
		Tag            = "Language_Add_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}
	$GUIImageSourceSettingSuggestedLangDel = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = "$($lang.Language): $($lang.Del)"
		Tag            = "Language_Delete_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}
	$GUIImageSourceSettingSuggestedLangChange = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = $lang.SwitchLanguage
		Tag            = "Language_Change_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}
	$GUIImageSourceSettingSuggestedLangClean = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = $lang.OnlyLangCleanup
		Tag            = "Language_Cleanup_Components_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}

	<#
		.组，UWP 应用
	#>
	$GUIImageSourceSettingSuggestedUWP = New-Object System.Windows.Forms.Label -Property @{
		Height         = 35
		Width          = 450
		Text           = $lang.InboxAppsManager
		Padding        = "16,0,0,0"
		margin         = "0,6,0,0"
	}
	$GUIImageSourceSettingSuggestedUWPOne = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = $lang.StepOne
		Tag            = "InBox_Apps_Mark_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}
	$GUIImageSourceSettingSuggestedUWPTwo = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = "$($lang.StepTwo)$($lang.InboxAppsAdd)"
		Tag            = "InBox_Apps_Add_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}
	$GUIImageSourceSettingSuggestedUWPThere = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = $lang.StepThree
		Tag            = "InBox_Apps_Refresh_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}
	$GUIImageSourceSettingSuggestedUWPDelete = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = $lang.InboxAppsMatchDel
		Tag            = "InBox_Apps_Match_Delete_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}

	<#
		.组，更新
	#>
	$GUIImageSourceSettingSuggestedUpdate = New-Object system.Windows.Forms.Label -Property @{
		Height         = 35
		Width          = 450
		Padding        = "16,0,0,0"
		margin         = "0,15,0,0"
		Text           = $lang.Update
	}
	$GUIImageSourceSettingSuggestedUpdateAdd = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = "$($lang.Update): $($lang.AddTo)"
		Tag            = "Update_Add_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}
	$GUIImageSourceSettingSuggestedUpdateDel = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = "$($lang.Update): $($lang.Del)"
		Tag            = "Update_Delete_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}

	<#
		.组，驱动
	#>
	$GUIImageSourceSettingSuggestedDrive = New-Object system.Windows.Forms.Label -Property @{
		Height         = 35
		Width          = 450
		Padding        = "16,0,0,0"
		margin         = "0,15,0,0"
		Text           = $lang.Drive
	}
	$GUIImageSourceSettingSuggestedDriveAdd = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = "$($lang.Drive): $($lang.AddTo)"
		Tag            = "Drive_Add_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}
	$GUIImageSourceSettingSuggestedDriveDel = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = "$($lang.Drive): $($lang.Del)"
		Tag            = "Drive_Delete_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}

	<#
		.组，无挂载时可用事件
	#>
	$GUIImageSourceSettingSuggestedNeedMount = New-Object system.Windows.Forms.Label -Property @{
		Height         = 35
		Width          = 450
		margin         = "16,25,0,0"
		Text           = $lang.AssignNoMount
	}
	$GUIImageSourceSettingSuggestedConvert = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = $lang.Convert
		Tag            = "Image_Convert_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}
	$GUIImageSourceSettingSuggestedISO = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 445
		Padding        = "26,0,0,0"
		Text           = $lang.UnpackISO
		Tag            = "ISO_Create_UI"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Event_Assign -Rule $This.Tag
			Event_Assign_Setting -Setting -RuleName $This.Tag
		}
	}

	<#
		.重置所有建议
	#>
	$GUIImageSourceSettingSuggestedReset = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 30
		Width          = 445
		Padding        = "14,0,0,0"
		margin         = "0,20,0,20"
		Text           = $lang.SuggestedReset
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			Remove-Item -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\Suggested" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
			$GUIImageSourceGroupSettingErrorMsg.Text = "$($lang.SuggestedReset), $($lang.Done)"
		}
	}

	<#
		.设置搜索映像来源
	#>
	$GUIImageSourceGroupSettingDiskTips = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 425
		Text           = $lang.SearchImageSource
		Location       = '560,15'
	}
	$GUIImageSourceGroupSettingPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 495
		Width          = 425
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $False
		Padding        = 0
		Location       = '560,45'
	}
	$GUIImageSourceGroupSettingStructure = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 300
		Padding        = "14,0,0,0"
		Text           = $lang.ISOStructure
		add_Click      = {
			if ($GUIImageSourceGroupSettingStructure.Checked) {
				Save_Dynamic -regkey "Solutions" -name "IsFolderStructure" -value "True" -String
			} else {
				Save_Dynamic -regkey "Solutions" -name "IsFolderStructure" -value "False" -String
			}

			Image_Select_Refresh_Disk_Local
		}
	}
	$GUIImageSourceGroupSettingCustomizeShow = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 350
		margin         = "34,5,0,0"
		Text           = ""
		BackColor      = "#FFFFFF"
		add_Click      = { Image_Select_Refresh_Disk_Local }
	}
	$GUIImageSourceGroupSettingCustomizeTips = New-Object System.Windows.Forms.Label -Property @{
		AutoSize       = 1
		Text           = $lang.ISO9660Tips
		margin        = "34,15,20,20"
	}

	<#
		.自动选择可用磁盘时
	#>
	$GUIImageSourceGroupSettingSelectDISK = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 410
		Text           = $lang.SelectAutoAvailable
	}

	<#
		.Event: Check the minimum free disk space
		.事件：检查最低可用磁盘剩余空间
	#>
	$GUIImageSourceGroupSettingSize = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 380
		Padding        = "14,0,0,0"
		Text           = $lang.SelectCheckAvailable
		Checked        = $True
		add_Click      = {
			if ($This.Checked) {
				$GUIImageSourceGroupSettingLowSize.Enabled = $True
				Save_Dynamic -regkey "Solutions" -name "IsCheckLowDiskSize" -value "True" -String
				$GUIImageSourceGroupSettingLowSize
			} else {
				$GUIImageSourceGroupSettingLowSize.Enabled = $False
				Save_Dynamic -regkey "Solutions" -name "IsCheckLowDiskSize" -value "True" -String
			}

			Image_Select_Refresh_Disk_Local
		}
	}
	$GUIImageSourceGroupSettingSizeChange = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 60
		Width          = 380
	}
	$GUIImageSourceGroupSettingLowSize = New-Object System.Windows.Forms.NumericUpDown -Property @{
		Height         = 22
		Width          = 60
		Location       = "34,2"
		Value          = 1
		Minimum        = 1
		Maximum        = 999999
		TextAlign      = 1
		add_Click      = { Image_Select_Refresh_Disk_Local }
	}
	$GUIImageSourceGroupSettingLowUnit = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 80
		Text           = "GB"
		Location       = "106,6"
	}

	$GUIImageSourceGroupSettingDiskSelect = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 300
		Text           = $lang.ChangeInstallDisk
		Location       = '606,235'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Image_Select_Refresh_Disk_Local }
	}
	$GUIImageSourceGroupSettingDisk = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 160
		Width          = 415
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
		Location       = '606,260'
	}

	$GUIImageSourceGroupSettingErrorMsg = New-Object system.Windows.Forms.Label -Property @{
		Location       = "560,565"
		Height         = 22
		Width          = 420
		Text           = ""
	}
	$GUIImageSourceGroupSettingOK = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,595"
		Height         = 36
		Width          = 280
		add_Click      = $GUIImageSourceGroupSettingOKClick
		Text           = $lang.OK
	}
	$GUIImageSourceGroupSettingCanel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$GUIImageSourceGroupSettingErrorMsg.Text = ""
			$GUIImageSourceGroupSetting.visible = $False
		}
	}

	<#
		.组：更改 ISO 挂载的映像主语言
	#>
	$UI_Mask_Image_Language = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 678
		Width          = 1006
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '0,0'
		Visible        = 0
	}
	$UI_Mask_Image_Language_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 340
		Location       = '15,15'
		Text           = $lang.AvailableLanguages
	}
	$UI_Mask_Image_Language_Select = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 630
		Width          = 340
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
		Location       = '15,45'
	}
	$UI_Mask_Image_Language_Tips = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 260
		Width          = 500
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $False
		Padding        = "8,0,8,0"
		Location       = "400,20"
	}
	$UI_Mask_Image_Language_Tips_Name = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		Text           = $lang.SwitchLanguageTips
	}
	$UI_Mask_Image_Language_Unlock = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 300
		Text           = $lang.SwitchLanguageHide
		Location       = '88,8'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$UI_Mask_Image_Language_Select.controls.Clear()
			for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
				$CheckBox   = New-Object System.Windows.Forms.RadioButton -Property @{
					Height  = 45
					Width   = 310
					Text    = "$($Global:AvailableLanguages[$i][4])`n$($Global:AvailableLanguages[$i][2])"
					Tag     = "$($Global:AvailableLanguages[$i][2])"
				}

				$UI_Mask_Image_Language_Select.controls.AddRange($CheckBox)
			}
		}
	}
	$UI_Mask_Image_Language_Error = New-Object system.Windows.Forms.Label -Property @{
		Location       = "235,645"
		Height         = 22
		Width          = 450
		Text           = ""
	}
	$UI_Mask_Image_Language_OK = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,595"
		Height         = 36
		Width          = 280
		Text           = $lang.OK
		add_Click      = {
			$UI_Mask_Image_Language_Select.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Checked) {
						$FlagTag = $_.Tag

						if ($Global:LanguageFull -Contains $FlagTag) {
							for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
								if ($Global:AvailableLanguages[$i][2] -eq $FlagTag) {
									$Global:MainImageLang = $Global:AvailableLanguages[$i][2]
									$Global:MainImageLangShort = $Global:AvailableLanguages[$i][3]
									$Global:MainImageLangName = $Global:AvailableLanguages[$i][4]

									$GUIImageSourceLanguageInfo.Text = "$($Global:MainImageLangName), $($lang.LanguageCode) ( $($Global:MainImageLang) ), $($lang.LanguageShort) ( $($Global:MainImageLangShort) )"
									$UI_Mask_Image_Language.visible = $False
									break
								}
							}
						}
					} else {
						$UI_Mask_Image_Language_Error.Text = $lang.NoChoose
					}
				}
			}
		}
	}
	$UI_Mask_Image_Language_Canel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$UI_Mask_Image_Language.visible = $False
		}
	}

	<#
		.挂载到更改
	#>
	$UI_Mask_Image_Mount_To = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 678
		Width          = 1006
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '0,0'
		Visible        = 0
	}
	$UI_Mask_Image_Mount_ToGroupAll = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 625
		Width          = 480
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Location       = '5,0'
		Padding        = "16,15,0,0"
	}
	$GUIImageSourceGroupMountFrom = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 430
		Text           = $lang.SelectSettingImage
	}
	$GUIImageSourceGroupMountFromPath = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		margin         = "20,8,0,12"
		ForeColor      = "Green"
		Text           = ""
	}

	<#
		.事件：映像源，打开目录
	#>
	$GUIImageSourceGroupMountFromOpenFolder = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 430
		Padding        = "16,0,0,0"
		Text           = $lang.OpenFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		Enabled        = $False
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($GUIImageSourceGroupMountFromPath.Text)) {
				if (Test-Path $GUIImageSourceGroupMountFromPath.Text -PathType Container) {
					Start-Process $GUIImageSourceGroupMountFromPath.Text
				}
			}
		}
	}

	<#
		.事件：映像源，复制路径
	#>
	$GUIImageSourceGroupMountFromPaste = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 430
		Padding        = "16,0,0,0"
		Text           = $lang.Paste
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		Enabled        = $False
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($GUIImageSourceGroupMountFromPath.Text)) {
				Set-Clipboard -Value $GUIImageSourceGroupMountFromPath.Text
			}
		}
	}

	<#
		.挂载到
	#>
	$GUIImageSourceGroupMountTo = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 430
		margin         = "0,22,0,0"
		Text           = "$($lang.MountImageTo)  $($lang.MainImageFolder)"
	}
	$GUIImageSourceGroupMountToShow = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		margin         = "20,8,0,12"
		ForeColor      = "Green"
		Text           = ""
	}

	<#
		.事件：挂载到，打开目录
	#>
	$GUIImageSourceGroupMountToOpenFolder = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 430
		Padding        = "16,0,0,0"
		Text           = $lang.OpenFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		Enabled        = $False
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($GUIImageSourceGroupMountToShow.Text)) {
				if (Test-Path $GUIImageSourceGroupMountToShow.Text -PathType Container) {
					Start-Process $GUIImageSourceGroupMountToShow.Text
				}
			}
		}
	}

	<#
		.事件：挂载到，复制路径
	#>
	$GUIImageSourceGroupMountToPaste = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 430
		Padding        = "16,0,0,0"
		Text           = $lang.Paste
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		Enabled        = $False
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($GUIImageSourceGroupMountToShow.Text)) {
				Set-Clipboard -Value $GUIImageSourceGroupMountToShow.Text
			}
		}
	}

	<#
		.Event: The temporary directory is the same as mounted to the location
		.事件：临时目录与挂载到位置相同
	#>
	$GUIImageSourceGroupMountToTemp = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 430
		Text           = $lang.SettingImageToTemp
		Location       = '15,125'
		margin         = "0,22,0,0"
		Checked        = $True
		add_Click      = {
			$GUIImageSourceGroupMountToShow.Text = "$($Global:MountTo)_Mount"

			if ($This.Checked) {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)" -name "TempFolderSync" -value "True" -String
				$GUIImageSourceGroupMountToTempShow.Text = "$($Global:MountTo)_Temp"
			} else {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)" -name "TempFolderSync" -value "False" -String
				$GUIImageSourceGroupMountToTempShow.Text = "$($env:userprofile)\AppData\Local\Temp"
			}

			Image_Select_Refresh_Sources_Event
		}
	}
	$GUIImageSourceGroupMountToTempShow = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		margin         = "20,8,0,12"
		ForeColor      = "Green"
		Text           = ""
	}

	<#
		.事件：临时目录，打开目录
	#>
	$GUIImageSourceGroupMountToTempOpenFolder = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 430
		Padding        = "16,0,0,0"
		Text           = $lang.OpenFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		Enabled        = $False
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($GUIImageSourceGroupMountToTempShow.Text)) {
				if (Test-Path $GUIImageSourceGroupMountToTempShow.Text -PathType Container) {
					Start-Process $GUIImageSourceGroupMountToTempShow.Text
				}
			}
		}
	}

	<#
		.事件：临时目录，复制路径
	#>
	$GUIImageSourceGroupMountToTempPaste = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 430
		Padding        = "16,0,0,0"
		Text           = $lang.Paste
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		Enabled        = $False
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($GUIImageSourceGroupMountToTempShow.Text)) {
				Set-Clipboard -Value $GUIImageSourceGroupMountToTempShow.Text
			}
		}
	}
	$GUIImageSourceGroupMountChangeTipsErrorMsg = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		margin         = "15,30,0,0"
		Text           = $lang.SettingImageNewPathTips
	}

	<#
		.更改映像源挂载位置
	#>
	$GUIImageSourceGroupMountChangePanel = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 550
		Width          = 440
		autoSizeMode   = 1
		Location       = '540,10'
	}
	$GUIImageSourceGroupMountChangeTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 400
		Text           = $lang.SettingImage
		Location       = '10,5'
	}

	<#
		.Event: Use Temp directory
		.事件：使用 Temp 目录
	#>
	$GUIImageSourceGroupMountChangeTemp = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 400
		Text           = $lang.SettingImagePathTemp
		Location       = '26,35'
		add_Click      = {
			if ($This.Checked) {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)" -name "UseTempFolder" -value "True" -String
			} else {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)" -name "UseTempFolder" -value "False" -String
			}

			Image_Select_Refresh_Sources_Event
		}
	}
	$GUIImageSourceGroupMountChangeDiSKLowSize = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 400
		Text           = $lang.SettingImageLow
		Location       = '26,70'
		Checked        = $True
		add_Click      = $GetDiskAvailableClick
	}
	$GUIImageSourceGroupMountChangeLowSize = New-Object System.Windows.Forms.NumericUpDown -Property @{
		Height         = 22
		Width          = 60
		Location       = "45,105"
		Value          = 1
		Minimum        = 1
		Maximum        = 999999
		TextAlign      = 1
		add_Click      = $GetDiskAvailableClick
	}
	$GUIImageSourceGroupMountChangeLowUnit = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 80
		Text           = "GB"
		Location       = "112,108"
	}
	$GUIImageSourceGroupMountChangeDiSKTitle = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 400
		Text           = $lang.SettingImageNewPath
		Location       = '24,155'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $GUIImageSourceSelectVerClick
	}
	$GUIImageSourceGroupMountChangeDiSKPane1 = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 320
		Width          = 400
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "16,0,8,0"
		Location       = '24,180'
	}
	$UI_Mask_Image_Mount_To_Tips = New-Object system.Windows.Forms.Label -Property @{
		Location       = "24,518"
		Height         = 22
		Width          = 400
		Text           = ""
	}

	<#
		.Event: Restore the default mount location
		.事件：恢复默认挂载位置
	#>
	$UI_Mask_Image_Mount_To_Reset = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,595"
		Height         = 36
		Width          = 280
		Text           = $lang.SettingImageRestore
		add_Click      = {
			$GUIImageSourceGroupMountToShow.Text = "$($Global:MountTo)_Mount"

			if ($GUIImageSourceGroupMountToTemp.Checked) {
				$GUIImageSourceGroupMountToTempShow.Text = "$($Global:MountTo)_Temp"
			} else {
				$GUIImageSourceGroupMountToTempShow.Text = "$($env:userprofile)\AppData\Local\Temp"
			}

			Image_Select_Refresh_Mount_Disk
		}
	}
	$UI_Mask_Image_Mount_To_Error = New-Object system.Windows.Forms.Label -Property @{
		Location       = "15,645"
		Height         = 22
		Width          = 600
		Text           = ""
	}
	$UI_Mask_Image_Mount_To_Canel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$UI_Mask_Image_Mount_To.visible = $False
		}
	}

	<#
		.显示挂载到：选择动态显示
	#>
	$GUIImageSourceGroupMount = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 28
		Width          = 640
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '10,527'
	}
	$GUIImageSourceMountTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 70
		Text           = $lang.MountImageTo
		Location       = '0,8'
		RightToLeft    = 1
	}
	$GUIImageSourceMountInfo = New-Object System.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 548
		Text           = $lang.SelectImageMountStatus
		Location       = '88,8'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Image_Select_Refresh_MountTo }
	}

	<#
		显示其它信息：语言
	#>
	$GUIImageSourceGroupLang = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 28
		Width          = 640
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '10,555'
	}
	$GUIImageSourceLangTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 70
		Text           = $lang.Language
		Location       = '0,8'
		RightToLeft    = 1
	}
	$GUIImageSourceLanguageInfo = New-Object System.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 548
		Text           = $lang.LanguageNoSelect
		Location       = '88,8'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Image_Select_Refresh_Language }
	}

	<#
		显示其它信息：详细
	#>
	$GUIImageSourceGroupOther = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 60
		Width          = 640
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '10,583'
	}
	$GUIImageSourceOtherTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 70
		Text           = $lang.Detailed
		Location       = '0,8'
		RightToLeft    = 1
	}
	$GUIImageSourceOtherImageErrorMsg = New-Object System.Windows.Forms.LinkLabel -Property @{
		Height         = 48
		Width          = 548
		Text           = $lang.ImageSouresNoSelect
		Location       = '88,8'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Image_Select_Refresh_Detailed }
	}

	<#
		显示其它信息：面板
	#>
	$GUIImageSourceGroupOtherPanel = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 678
		Width          = 1006
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '0,0'
		Visible        = 0
	}

	<#
		.事件管理
	#>
	$GUIImageSourceGroupSettingEvent = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 400
		Text           = $lang.EventManager
		Location       = '15,15'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Image_Select_Refresh_Event }
	}
	$GUIImageSourceGroupSettingEventSelect = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 440
		Width          = 320
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
		Location       = '15,40'
	}

	$GUISelectNotExecuted = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 320
		Text           = $lang.AfterFinishingNotExecuted
		Location       = '15,525'
		add_Click      = $GUISelectNotExecutedClick
		Enabled        = $False
	}
	$GUISelectGroupAfterFinishing = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 110
		Width          = 305
		autoSizeMode   = 1
		Padding        = 14
		Location       = '31,550'
		Enabled        = $False
	}
	$GUISelectAfterFinishingPause = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 35
		Width          = 300
		Text           = $lang.AfterFinishingPause
		Location       = '0,0'
		add_Click      = {
			$GUIImageSourceGroupSettingEventSelect.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue\$($_.Text)" -name "AfterFinishing" -value "2" -String
						}
					}
				}
			}
		}
	}
	$GUISelectAfterFinishingReboot = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 35
		Width          = 300
		Text           = $lang.AfterFinishingReboot
		Location       = '0,35'
		add_Click      =  {
			$GUIImageSourceGroupSettingEventSelect.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue\$($_.Text)" -name "AfterFinishing" -value "3" -String
						}
					}
				}
			}
		}
	}
	$GUISelectAfterFinishingShutdown = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 35
		Width          = 300
		Text           = $lang.AfterFinishingShutdown
		Location       = '0,70'
		add_Click      = {
			$GUIImageSourceGroupSettingEventSelect.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue\$($_.Text)" -name "AfterFinishing" -value "4" -String
						}
					}
				}
			}
		}
	}

	$GUIImageSourceGroupOtherPanel_Menu = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 600
		Width          = 585
		Location       = '390,5'
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "15,15,8,0"
	}
	$GUIImageSourceKernelTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 510
		Text           = $lang.Kernel
		Location       = '5,6'
	}
	$GUIImageSourceKernel10 = New-Object system.Windows.Forms.ComboBox -Property @{
		Height         = 30
		Width          = 300
		margin         = "30,0,0,35"
		Text           = ""
		DropDownStyle  = "DropDownList"
	}

	$GUISelectGroupArchitecture = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		autoSize       = 1
		BorderStyle    = 0
		autoSizeMode   = 1
		margin         = "0,0,0,20"
		autoScroll     = $False
	}
	$GUIImageSourceArchitectureTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 510
		Text           = $lang.Architecture
	}
	$GUIImageSourceArchitectureARM64 = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 35
		Width          = 510
		Padding        = "25,0,0,0"
		Text           = "arm64"
	}
	$GUIImageSourceArchitectureAMD64 = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 35
		Width          = 510
		Padding        = "25,0,0,0"
		Text           = "x64"
	}
	$GUIImageSourceArchitectureX86 = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 35
		Width          = 510
		Padding        = "25,0,0,0"
		Text           = "x86"
		Checked        = $True
	}

	$GUIImageSourceGroupType = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		autoSize       = 1
		BorderStyle    = 0
		autoSizeMode   = 1
		margin         = "0,0,0,35"
		autoScroll     = $False
	}
	$GUISelectTypeTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 510
		Text           = $lang.ImageLevel
	}
	$GUISelectTypeDesktop = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 35
		Width          = 510
		Padding        = "25,0,0,0"
		Text           = $lang.LevelDesktop
		Checked        = $True
	}
	$GUISelectTypeServer = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 35
		Width          = 510
		Padding        = "25,0,0,0"
		Text           = $lang.LevelServer
	}

	<#
		.可选功能
	#>
	$GUIImageSourceGroupSettingAdv = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 505
		Text           = $lang.AdvOption
	}

	<#
		.清除所有事件
	#>
	$GUIImageSourceGroupSettingEventClear = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 510
		Padding        = "25,0,0,0"
		Text           = $lang.EventManagerClear
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$GUISelectOtherSettingSaveModeErrorMsg.Text = ""
			$GUIImageSourceGroupSettingEventSelect.controls.Clear()
			Remove-Item -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\Queue" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null

			$GUISelectNotExecuted.Enabled = $False
			$GUISelectGroupAfterFinishing.Enabled = $False
			$GUISelectOtherSettingSaveModeErrorMsg.Text = "$($lang.EventManagerClear), $($lang.Done)"
		}
	}

	<#
		.清除所选
	#>
	$GUISelectOtherSettingSaveModeClear = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 510
		Padding        = "25,0,0,0"
		Text           = $lang.SaveModeClear
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$UI_Main_Select_Sources.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							Remove-Item -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($_.Tag)" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
						}
					}
				}
			}

			$GUIImageSourceGroupOtherPanel.visible = $False
			Image_Select_Refresh_Sources_List
		}
	}

	$GUISelectOtherSettingSaveModeErrorMsg = New-Object system.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 510
		Text           = ""
		Location       = "390,580"
	}
	$GUIImageSourceGroupOtherCanel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$GUIImageSourceGroupOtherPanel.visible = $False
		}
	}

	<#
		.主界面
	#>
	<#
		.设置按钮
	#>
	$GUIImageSourceSetting = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,10"
		Height         = 36
		Width          = 280
		Text           = $lang.Setting
		add_Click      = {
			Image_Setting_UI
			$GUIImageSourceGroupSetting.visible = $True
		}
	}

	<#
		.更换语言
	#>
	$GUIImageSourceLanguage = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,50"
		Height         = 36
		Width          = 280
		Text           = $lang.Language
		add_Click      = {
			$UI_Main.Hide()
			Language -Reset

			if (-not ($Global:Quit)) {
				Image_Select
			}
			$UI_Main.Close()
		}
	}

	<#
		.刷新
	#>
	$GUISelectRefresh = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,90"
		Height         = 36
		Width          = 280
		add_Click      = { Image_Select_Refresh_Sources_List }
		Text           = $lang.Refresh
	}

	<#
		.检查更新
	#>
	$GUISelectUpdate   = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,130"
		Height         = 36
		Width          = 280
		add_Click      = {
			$UI_Main.Hide()
			Update
			$UI_Main.Close()

			Modules_Refresh -Function "ToMainpage -wait 2 -To 6"
		 }
		Text           = $lang.ChkUpdate
	}

	<#
		.生成解决方案
	#>
	$GUICreateSolutions = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,170"
		Height         = 36
		Width          = 280
		add_Click      = {
			$UI_Main.Hide()
			$Global:QUIT = $True
			Solutions -Current

			$UI_Main.Close()
		}
		Text           = $lang.CopyFileToImage
	}

	<#
		.主键项
	#>
	$UI_Primary_Key_Group = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 370
		Width          = 280
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $False
		Location       = "698,190"
		Visible        = 0
	}
	$UI_Primary_Key_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 270
		Text           = $lang.Event_Primary_Key
	}
	$UI_Primary_Key_Select = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		AutoSize       = 1
		autoSizeMode   = 1
		autoScroll     = $False
		Padding        = "14,0,0,0"
	}

	$UI_Main_Error     = New-Object system.Windows.Forms.Label -Property @{
		Location       = "15,648"
		Height         = 22
		Width          = 635
		Text           = ""
		BorderStyle    = 0
	}
	$UI_Main_Ok        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,595"
		Height         = 36
		Width          = 280
		add_Click      = $UI_Main_Ok_Click
		Text           = $lang.OK
		Enabled        = $False
	}
	$UI_Main_Canel     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "698,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
			$Global:QUIT = $True
			$UI_Main.Close()
		}
	}
	$UI_Main.controls.AddRange((
		<#
			.蒙板：设置界面
		#>
		$GUIImageSourceGroupSetting,

		<#
			.蒙板：更改挂载到
		#>
		$UI_Mask_Image_Mount_To,

		<#
			.蒙板：更改 ISO 挂载的映像主语言
		#>
		$UI_Mask_Image_Language,

		<#
			.蒙板：其它信息
		#>
		$GUIImageSourceGroupOtherPanel,

		<#
			.挂载到
		#>
		$GUIImageSourceGroupMount,

		<#
			.主界面：选择 ISO 来源
		#>
		$UI_Main_Select_Sources,

		<#
			.蒙板：更改匹配的映像源语言
		#>
		$GUIImageSourceGroupLang,
		$GUIImageSourceGroupOther,

		<#
			.按钮：设置
		#>
		$GUIImageSourceSetting,

		<#
			.按钮：切换语言
		#>
		$GUIImageSourceLanguage,

		<#
			.按钮：刷新
		#>
		$GUISelectRefresh,

		<#
			.按钮：检查更新
		#>
		$GUISelectUpdate,

		<#
			.按钮：语言
		#>
		$GUICreateSolutions,

		<#
			.动态显示 ISO 目录下的 Install, Boot
		#>
		$UI_Primary_Key_Group,

		$UI_Main_Error,
		$UI_Main_Ok,
		$UI_Main_Canel
	))
	$UI_Primary_Key_Group.controls.AddRange((
		$UI_Primary_Key_Name,
		$UI_Primary_Key_Select
	))
	$GUIImageSourceGroupSetting.controls.AddRange((
		$GUIImageSourceGroupSettingDiskTips,
		$GUIImageSourceGroupSettingPanel,
		$GUIImageSourceSettingGroupAll,
		$GUIImageSourceGroupSettingErrorMsg,
		$GUIImageSourceGroupSettingOK,
		$GUIImageSourceGroupSettingCanel
	))
	$GUIImageSourceGroupSettingPanel.controls.AddRange((
		$GUIImageSourceGroupSettingStructure,
		$GUIImageSourceGroupSettingCustomizeShow,
		$GUIImageSourceGroupSettingCustomizeTips,
		$GUIImageSourceGroupSettingSelectDISK,
		$GUIImageSourceGroupSettingSize,
		$GUIImageSourceGroupSettingSizeChange,
		$GUIImageSourceGroupSettingDiskSelect,
		$GUIImageSourceGroupSettingDisk
	))
	$GUIImageSourceGroupSettingSizeChange.controls.AddRange((
		$GUIImageSourceGroupSettingLowSize,
		$GUIImageSourceGroupSettingLowUnit
	))
	$GUIImageSourceSettingGroupAll.controls.AddRange((
		$GUIImageSourceSettingAdv,
		$GUIImageSourceSettingEnv,
		$GUIImageSourceSettingEnvTips,
		$GUIImageSourceSettingTopMost,
		$GUIImageSourceSettingTopMostSuccess,
		$GUIImageSourceSettingClearHistory,
		$GUIImageSourceSettingClearHistoryLog,
		$GUIImageSourceSettingClearSaveFolder,
		$GUIImageSourceSettingClearAppxStage,
		$UI_Main_Adv_Cmd,
		$GUIImageSourceSettingBootSize,
		$GUIImageSourceSettingHistoryDism,
		$GUIImageSourceISOCache,
		$GUIImageSourceSettingRAMDISK,
		$GUIImageSourceSetting_RAMDISK_Volume_Label,
		$GUIImageSource_Setting_RAMDISK_Change,
		$GUIImageSource_Setting_RAMDISK_Restore,
		$GUIImageSourceISOCacheCustomizeName,
		$GUIImageSourceISOCacheCustomize,
		$GUIImageSourceISOSaveTo,
		$GUIImageSourceISOCustomizePath,
		$GUIImageSourceISOCustomizePathSelect,
		$GUIImageSourceISOCustomizePathOpen,
		$GUIImageSourceISOCustomizePathPaste,
		$GUIImageSourceISOCustomizePathRestore,
		$GUIImageSourceISOSync,
		$GUIImageSourceISOWrite,
		$GUIImageSourceISOSaveToCheckISO9660,
		$GUIImageSourceISOSaveToCheckISO9660Tips,
		$GUIImageSourceSettingSuggested,
		$GUIImageSourceSettingSuggestedPanel
	))
	
	$GUIImageSourceSettingSuggestedPanel.controls.AddRange((
		$GUIImageSourceSettingSuggestedSoltions,

		$GUIImageSourceSettingSuggestedLang,
		$GUIImageSourceSettingSuggestedLangAdd,
		$GUIImageSourceSettingSuggestedLangDel,
		$GUIImageSourceSettingSuggestedLangChange,
		$GUIImageSourceSettingSuggestedLangClean,

		$GUIImageSourceSettingSuggestedUWP,
		$GUIImageSourceSettingSuggestedUWPOne,
		$GUIImageSourceSettingSuggestedUWPTwo,
		$GUIImageSourceSettingSuggestedUWPThere,
		$GUIImageSourceSettingSuggestedUWPDelete,

		$GUIImageSourceSettingSuggestedUpdate,
		$GUIImageSourceSettingSuggestedUpdateAdd,
		$GUIImageSourceSettingSuggestedUpdateDel,

		$GUIImageSourceSettingSuggestedDrive,
		$GUIImageSourceSettingSuggestedDriveAdd,
		$GUIImageSourceSettingSuggestedDriveDel,

		$GUIImageSourceSettingSuggestedNeedMount,
		$GUIImageSourceSettingSuggestedConvert,
		$GUIImageSourceSettingSuggestedISO,

		$GUIImageSourceSettingSuggestedReset
	))

	$GUIImageSourceISOCacheCustomize.controls.AddRange((
		$GUIImageSourceISOCacheCustomizePath,
		$GUIImageSourceISOCacheCustomizePathSelect,
		$GUIImageSourceISOCacheCustomizePathOpen,
		$GUIImageSourceISOCacheCustomizePathPaste
	))

	$GUIImageSourceGroupOtherPanel.controls.AddRange((
		$GUIImageSourceGroupOtherPanel_Menu,
		$GUIImageSourceKernelTitle,
		$GUIImageSourceGroupSettingEvent,
		$GUIImageSourceGroupSettingEventSelect,
		$GUISelectNotExecuted,
		$GUISelectGroupAfterFinishing,
		$GUISelectOtherSettingSaveModeErrorMsg,
		$GUIImageSourceGroupOtherCanel
	))
	$GUIImageSourceGroupOtherPanel_Menu.controls.AddRange((
		$GUIImageSourceKernelTitle,
		$GUIImageSourceKernel10,
		$GUISelectGroupArchitecture,
		$GUIImageSourceGroupType,
		$GUIImageSourceGroupSettingAdv,
		$GUIImageSourceGroupSettingEventClear,
		$GUISelectOtherSettingSaveModeClear
	))
	$GUIImageSourceGroupMount.controls.AddRange((
		$GUIImageSourceMountTitle,
		$GUIImageSourceMountInfo
	))
	$GUIImageSourceGroupLang.controls.AddRange((
		$GUIImageSourceLangTitle,
		$GUIImageSourceLanguageInfo
	))
	$GUIImageSourceGroupOther.controls.AddRange((
		$GUIImageSourceOtherTitle,
		$GUIImageSourceOtherImageErrorMsg
	))
	$UI_Mask_Image_Mount_To.controls.AddRange((
		$UI_Mask_Image_Mount_ToGroupAll,
		$GUIImageSourceGroupMountChangePanel,
		$UI_Mask_Image_Mount_To_Error,
		$UI_Mask_Image_Mount_To_Reset,
		$UI_Mask_Image_Mount_To_Canel
	))
	$UI_Mask_Image_Mount_ToGroupAll.controls.AddRange((
		$GUIImageSourceGroupMountFrom,
		$GUIImageSourceGroupMountFromPath,
		$GUIImageSourceGroupMountFromOpenFolder,
		$GUIImageSourceGroupMountFromPaste,
		$GUIImageSourceGroupMountTo,
		$GUIImageSourceGroupMountToShow,
		$GUIImageSourceGroupMountToOpenFolder,
		$GUIImageSourceGroupMountToPaste,
		$GUIImageSourceGroupMountToTemp,
		$GUIImageSourceGroupMountToTempShow,
		$GUIImageSourceGroupMountToTempOpenFolder,
		$GUIImageSourceGroupMountToTempPaste,
		$GUIImageSourceGroupMountChangeTipsErrorMsg
	))
	$GUIImageSourceGroupMountChangePanel.controls.AddRange((
		$GUIImageSourceGroupMountChangeTitle,
		$GUIImageSourceGroupMountChangeTemp,
		$GUIImageSourceGroupMountChangeDiSKLowSize,
		$GUIImageSourceGroupMountChangeLowSize,
		$GUIImageSourceGroupMountChangeLowUnit,
		$GUIImageSourceGroupMountChangeDiSKTitle,
		$GUIImageSourceGroupMountChangeDiSKPane1,
		$UI_Mask_Image_Mount_To_Tips
	))
	$UI_Mask_Image_Language.controls.AddRange((
		$UI_Mask_Image_Language_Name,
		$UI_Mask_Image_Language_Select,
		$UI_Mask_Image_Language_Tips,
		$UI_Mask_Image_Language_Error,
		$UI_Mask_Image_Language_OK,
		$UI_Mask_Image_Language_Canel
	))
	$UI_Mask_Image_Language_Tips.controls.AddRange((
		$UI_Mask_Image_Language_Tips_Name,
		$UI_Mask_Image_Language_Unlock
	))
	$GUISelectGroupArchitecture.controls.AddRange((
		$GUIImageSourceArchitectureTitle,
		$GUIImageSourceArchitectureARM64,
		$GUIImageSourceArchitectureAMD64,
		$GUIImageSourceArchitectureX86
	))
	$GUIImageSourceGroupType.controls.AddRange((
		$GUISelectTypeTitle,
		$GUISelectTypeDesktop,
		$GUISelectTypeServer
	))
	$GUISelectGroupAfterFinishing.controls.AddRange((
		$GUISelectAfterFinishingPause,
		$GUISelectAfterFinishingReboot,
		$GUISelectAfterFinishingShutdown
	))

	Get-ChildItem -Path "$($PSScriptRoot)\..\..\..\..\..\_Custom\Unattend" -directory -ErrorAction SilentlyContinue | ForEach-Object {
		$GUIImageSourceKernel10.Items.Add($_.BaseName) | Out-Null
	}

	<#
		.初始化设置界面
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "SearchDiskMinSize" -ErrorAction SilentlyContinue) {
		$GUIImageSourceGroupSettingLowSize.Text = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "SearchDiskMinSize" -ErrorAction SilentlyContinue
	} else {
		Save_Dynamic -regkey "Solutions" -name "SearchDiskMinSize" -value $InitSearchDiskMinSize -String
	}

	Image_Setting_UI

	<#
		.初始化设置语言界面
	#>
	Image_Select_Refresh_Sources_List

	for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
		if ($Global:AvailableLanguages[$i][0] -eq "1") {
			$CheckBox   = New-Object System.Windows.Forms.RadioButton -Property @{
				Height  = 40
				Width   = 310
				Text    = "$($Global:AvailableLanguages[$i][4])`n$($Global:AvailableLanguages[$i][2])"
				Tag     = $Global:AvailableLanguages[$i][2]
			}

			$UI_Mask_Image_Language_Select.controls.AddRange($CheckBox)
		}
	}

	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "DiskMinSize" -ErrorAction SilentlyContinue) {
		$GUIImageSourceGroupMountChangeLowSize.Text = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "DiskMinSize" -ErrorAction SilentlyContinue
	} else {
		Save_Dynamic -regkey "Solutions" -name "DiskMinSize" -value $InitSearchDiskMinSize -String
		$GUIImageSourceGroupMountChangeLowSize.Text = $InitSearchDiskMinSize
	}
	Image_Select_Refresh_Mount_Disk

	<#
		.Allow open windows to be on top
		.允许打开的窗口后置顶
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
			"True" { $UI_Main.TopMost = $True }
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$UI_Main.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		'de-DE' {
			$GUIImageSourceISOSync.Height = "35"
		}
		Default {
			$UI_Main.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$UI_Main.FormBorderStyle = 'Fixed3D'
	$UI_Main.ShowDialog() | Out-Null
}

<#
	判断内核
#>
Function ISO_Verify_Kernel
{
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "Kernel" -ErrorAction SilentlyContinue) {
		$TempSelectAraayKernelRegedit = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "Kernel"
		$GUIImageSourceKernel10.Text = $TempSelectAraayKernelRegedit
		$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Kernel) ( $($TempSelectAraayKernelRegedit), $($lang.SaveMode) ), "
		return
	}
	
	$TempSelectAraayKernel = @()
	Get-ChildItem -Path "$($PSScriptRoot)\..\..\..\..\..\_Custom\Unattend" -directory -ErrorAction SilentlyContinue | ForEach-Object {
		$TempSelectAraayKernel += $_.BaseName
	}
	
	if ($TempSelectAraayKernel.Count -gt 0) {
		ForEach ($item in $TempSelectAraayKernel) {
			$SearchNT10 = @(
				"*_$($item)_*"
				"*$($item)_*"
			)

			ForEach ($NewItem in $SearchNT10) {
				if ($Global:MainImage -like $NewItem) {
					$GUISelectTypeDesktop.Checked = $True

					$GUIImageSourceKernel10.Text = $item
					$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Kernel) ( $($item), $($lang.MatchMode) ), "
					return
				}
			}
		}

		$GUISelectTypeDesktop.Checked = $True
		$TempSelectAraayKernelRegedit = $TempSelectAraayKernel | Get-Random
		$GUIImageSourceKernel10.Text = $TempSelectAraayKernelRegedit
		$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Kernel) ( $($TempSelectAraayKernelRegedit), $($lang.RandomSelect) ), "
	}


	$GUIImageSourceKernel10.Text = $TempSelectAraayKernel | Get-Random
	$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Kernel) ( $($lang.Inoperable) ), "
}

<#
	判断架构
#>
Function ISO_Verify_Arch
{
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "Architecture" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "Architecture" -ErrorAction SilentlyContinue) {
			"arm64" {
				$GUIImageSourceArchitectureARM64.Checked = $True
				$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Architecture) ( Arm64, $($lang.SaveMode) ), "
			}
			"AMD64" {
				$GUIImageSourceArchitectureAMD64.Checked = $True
				$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Architecture) ( x64, $($lang.SaveMode) ), "
			}
			"x86" {
				$GUIImageSourceArchitectureX86.Checked = $True
				$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Architecture) ( x86, $($lang.SaveMode) ), "
			}
		}
	} else {
		$SearchArchitectureARM64 = @(
			"*_arm_*"
			"*_arm64_*"
			"*_64arm_*"
		)
		$SearchArchitectureAMD64 = @(
			"*x64*"
			"*x64FRE*"
		)
		$SearchArchitecturex86 = @(
			"*x86*"
			"*x86FRE*"
		)

		ForEach ($item in $SearchArchitectureARM64) {
			if ($Global:MainImage -like $item) {
				$GUIImageSourceArchitectureARM64.Checked = $True
				$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Architecture) ( Arm64, $($lang.MatchMode) ), " 
				return
			}
		}

		ForEach ($item in $SearchArchitectureAMD64) {
			if ($Global:MainImage -like $item) {
				$GUIImageSourceArchitectureAMD64.Checked = $True
				$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Architecture) ( x64, $($lang.MatchMode) ), "
				return
			}
		}

		ForEach ($item in $SearchArchitecturex86) {
			if ($Global:MainImage -like $item) {
				$GUIImageSourceArchitectureX86.Checked = $True
				$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Architecture) ( x86, $($lang.MatchMode) ), "
				return
			}
		}

		$GUIImageSourceArchitectureAMD64.Checked = $True
		$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.Architecture) ( x64, $($lang.RandomSelect) ), "
	}
}

<#
	.判断安装类型
#>
Function ISO_Verify_Install_Type
{
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "ImageType" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "ImageType" -ErrorAction SilentlyContinue) {
			"Desktop" {
				$GUISelectTypeDesktop.Checked = $True
				$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.ImageLevel) ( $($lang.LevelDesktop), $($lang.SaveMode) ), "
			}
			"Server"  {
				$GUISelectTypeServer.Checked  = $True
				$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.ImageLevel) ( $($lang.LevelServer), $($lang.SaveMode) ), "
			}
		}
	} else {
		$SearchDesktop = @(
			"*_consumer_*"
			"*_business_*"
			"*_desktop_*"
			"*_client_*"
		)
		$SearchServer = @(
			"*Server*"
			"vNext"
		)

		ForEach ($item in $SearchDesktop) {
			if ($Global:MainImage -like $item) {
				$GUISelectTypeDesktop.Checked = $True
				$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.ImageLevel) ( $($lang.LevelDesktop), $($lang.MatchMode) ), "
				return
			}
		}

		ForEach ($item in $SearchServer) {
			if ($Global:MainImage -like $item) {
				$GUISelectTypeServer.Checked = $True
				$GUIImageSourceArchitectureAMD64.Checked = $True
				$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.ImageLevel) ( $($lang.LevelServer), $($lang.MatchMode) ), "
				return
			}
		}

		$GUISelectTypeDesktop.Checked = $True
		$GUIImageSourceOtherImageErrorMsg.Text += "$($lang.ImageLevel) ( $($lang.LevelDesktop), $($lang.RandomSelect) ), "
	}
}

Function ISO_Verify_Sources_Language
{
	<#
		.重置：重新选择语言界面
	#>
	$UI_Mask_Image_Language_Select.Controls | ForEach-Object {
		if ($Global:MainImageLang -eq $_.Tag) {
			$_.Checked = $True
		} else {
			$_.Checked = $False
		}
	}

	<#
		从注册表获取保存的映像默认语言
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "language" -ErrorAction SilentlyContinue) {
		$GetRegeditlanguage = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)" -Name "language" -ErrorAction SilentlyContinue
		if ($($Global:LanguageFull) -Contains $GetRegeditlanguage) {
			for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
				if ($Global:AvailableLanguages[$i][2] -eq $GetRegeditlanguage) {
					$Global:MainImageLang      = $Global:AvailableLanguages[$i][2]
					$Global:MainImageLangShort = $Global:AvailableLanguages[$i][3]
					$Global:MainImageLangName  = $Global:AvailableLanguages[$i][4]
					$GUIImageSourceLanguageInfo.Text = "$($Global:MainImageLangName), $($lang.LanguageCode) ( $($Global:MainImageLang) ), $($lang.LanguageShort) ( $($Global:MainImageLangShort) ), $($lang.SaveMode)"
					
					return
				}
			}
		}
	}

	<#
		继续判断语言：判断 mul_ 开头，多语标签设置为默认英文
	#>
	if ($Global:MainImage -like "*mul_*") {
		$DefaultLanguage = "en-us"
		for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
			if ($Global:AvailableLanguages[$i][2] -eq $DefaultLanguage) {
				$UI_Main_Error.Text = $lang.LanguageMatchError
				$Global:MainImageLang = $Global:AvailableLanguages[$i][2]
				$Global:MainImageLangShort = $Global:AvailableLanguages[$i][3]
				$Global:MainImageLangName = $Global:AvailableLanguages[$i][4]
				$GUIImageSourceLanguageInfo.Text = "$($Global:MainImageLangName), $($lang.LanguageCode) ( $($Global:MainImageLang) ), $($lang.LanguageShort) ( $($Global:MainImageLangShort) ), $($lang.MatchMode)"

				return
			}
		}
	}

	<#
		继续判断语言：按国家语言标记，例如：en-US, zh-CN
	#>
	ForEach ($item in $Global:LanguageFull) {
		if ($Global:MainImage -like "*$($item)*") {
			for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
				if ($Global:AvailableLanguages[$i][2] -eq $item) {
					$Global:MainImageLang      = $Global:AvailableLanguages[$i][2]
					$Global:MainImageLangShort = $Global:AvailableLanguages[$i][3]
					$Global:MainImageLangName  = $Global:AvailableLanguages[$i][4]
					$GUIImageSourceLanguageInfo.Text = "$($Global:MainImageLangName), $($lang.LanguageCode) ( $($Global:MainImageLang) ), $($lang.LanguageShort) ( $($Global:MainImageLangShort) ), $($lang.MatchMode)"

					return
				}
			}
		}
	}

	<#
		继续判断语言：短名称，例如 en, cn 开头的
	#>
	ForEach ($item in $Global:LanguageShort) {
		if ($Global:MainImage -like "$($item)_*") {
			for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
				if ($Global:AvailableLanguages[$i][3] -eq $item) {
					$Global:MainImageLang      = $Global:AvailableLanguages[$i][2]
					$Global:MainImageLangShort = $Global:AvailableLanguages[$i][3]
					$Global:MainImageLangName  = $Global:AvailableLanguages[$i][4]
					$GUIImageSourceLanguageInfo.Text = "$($Global:MainImageLangName), $($lang.LanguageCode) ( $($Global:MainImageLang) ), $($lang.LanguageShort) ( $($Global:MainImageLangShort) ), $($lang.MatchMode)"
					return
				}
			}
		}
	}

	<#
		条件：
			1、从注册表里获取保存的失败；
			2、判断短名称失败；
			3、按国家语言判断失败。
			设置为主语：en-US。
	#>
	for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
		if ($Global:AvailableLanguages[$i][2] -eq "en-us") {
			$UI_Main_Error.Text = $lang.LanguageMatchError
			$Global:MainImageLang = $Global:AvailableLanguages[$i][2]
			$Global:MainImageLangShort = $Global:AvailableLanguages[$i][3]
			$Global:MainImageLangName = $Global:AvailableLanguages[$i][4]
			$GUIImageSourceLanguageInfo.Text = "$($Global:MainImageLangName), $($lang.LanguageCode) ( $($Global:MainImageLang) ), $($lang.LanguageShort) ( $($Global:MainImageLangShort) ), $($lang.MatchMode)"
			return
		}
	}
}

<#
	.初始化主要项，扩展项文件
#>
Function Image_Refresh_Init_GLobal_Rule
{
	<#
		.搜索映像文件类型
	#>
	$Global:Image_Rule = @(
		@{
			Main = @(
				@{
					Group         = "Boot;Boot;"
					Uid           = "Boot;Boot;"
					ImageFileName = "Boot"
					AbsolutePath  = "$($Global:MountTo)\sources\Boot.wim"
				}
			)
			Expand = @()
		}
		@{
			Main = @(
				@{
					Group         = "Install;Install;"
					Uid           = "Install;Install;"
					ImageFileName = "Install"
					AbsolutePath  = "$($Global:MountTo)\sources\install.wim"
				}
			)
			Expand = @(
				@{
					Group         = "Install;Install;"
					Uid           = "Install;WinRE;"
					ImageFileName = "WinRe"
					AbsolutePath  = "$($Global:MountToRouting)\Install\Install\Windows\System32\Recovery\WinRe.wim"
					UpdatePath    = "\Windows\System32\Recovery\WinRe.wim"
				}
			)
		}
	)
}