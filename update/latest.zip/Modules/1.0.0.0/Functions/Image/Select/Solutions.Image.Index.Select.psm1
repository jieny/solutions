﻿<#
	.Select the image source index number user interface
	.选择映像源索引号用户界面
#>
Function Image_Select_Index_UI
{
	param
	(
		$Uid
	)

	Write-Host "`n   $($lang.SelectSettingImage)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	<#
		.事件：查看详细内容
	#>
	Function Wimlib_Image_Edit_Index_Detial
	{
		param
		(
			$Index
		)

		<#
			.清除所有旧的信息
		#>
		$UI_Main_Mask_Rule_Wim_Image_Index.Text = $lang.MountedIndexSelect
		$UI_Main_Mask_Rule_Wim_Image_Index.Tag = ""
		$UI_Main_Mask_Rule_Wim_Image_Name_Edit.Text = ""
		$UI_Main_Mask_Rule_Wim_Image_Description_Edit.Text = ""
		$UI_Main_Mask_Rule_Wim_Display_Name_Edit.Text = ""
		$UI_Main_Mask_Rule_Wim_Display_Description_Edit.Text = ""
		$UI_Main_Mask_Rule_Wim_Edition_Edit.Text = ""
		$UI_Main_Mask_Rule_Wim_Architecture.Text = $lang.Architecture
		$UI_Main_Mask_Rule_Wim_Created.Text = $lang.Wim_Created
		$UI_Main_Mask_Rule_Wim_Expander_Space.Text = $lang.Wim_Expander_Space
		$UI_Main_Mask_Rule_Wim_System_Version.Text = ""

		ForEach ($item in $Global:Primary_Key_Image.Index) {
			if ($item.ImageIndex -eq $index) {
				<#
					.索引号
				#>
				$UI_Main_Mask_Rule_Wim_Image_Index.Text = "$($lang.MountedIndexSelect): $($item.ImageIndex)"
				$UI_Main_Mask_Rule_Wim_Image_Index.Tag = $item.ImageIndex

				<#
					.映像名称
				#>
				$UI_Main_Mask_Rule_Wim_Image_Name_Edit.Text = $item.ImageName

				<#
					.映像说明
				#>
				$UI_Main_Mask_Rule_Wim_Image_Description_Edit.Text = $item.ImageDescription

				<#
					.显示名称
				#>
				$UI_Main_Mask_Rule_Wim_Display_Name_Edit.Text = $item.DISPLAYNAME

				<#
					.显示说明
				#>
				$UI_Main_Mask_Rule_Wim_Display_Description_Edit.Text = $item.DISPLAYDESCRIPTION

				<#
					.映像标志
				#>
				$UI_Main_Mask_Rule_Wim_Edition_Edit.Text = $item.EditionId

				<#
					.架构
				#>
				switch ($item.Architecture) {
					0 {
						$New_Architecture = "x86"
					}
					9 {
						$New_Architecture = "x64"
					}
					Default 
					{
						$New_Architecture = "arm64"
					}
				}
				$UI_Main_Mask_Rule_Wim_Architecture.Text = "$($lang.Architecture): $($New_Architecture)"

				<#
					.创建日期
				#>
				$UI_Main_Mask_Rule_Wim_Created.Text = "$($lang.Wim_Created): $($item.CreatedTime)"

				<#
					.展开空间
				#>
				$UI_Main_Mask_Rule_Wim_Expander_Space.Text = "$($lang.Wim_Expander_Space): $($item.ImageSize)"

				<#
					.系统版本
				#>
				$UI_Main_Mask_Rule_Wim_System_Version.Text = "$($lang.EditionsTips -f $($item.Version))"
			}
		}

		$UI_Main_Mask_Rule_Detailed.Visible = $True
	}

	<#
		.刷新
	#>
	Function Wimlib_Image_Refresh_Details_Rule
	{
		param
		(
			[switch]$Refresh
		)

		if ($Refresh) {
			Image_Set_Global_Primary_Key -Uid $Global:Primary_Key_Image.Uid -Detailed -DevCode "25"
		}
		$UI_Main_Menu.controls.clear()

		ForEach ($item in $Global:Primary_Key_Image.Index) {
			$CheckBox   = New-Object System.Windows.Forms.RadioButton -Property @{
				Height  = 40
				Width   = 528
				Text    = "$($lang.MountedName): $($item.ImageName)`n$($lang.MountedIndex): $($item.ImageIndex)"
				Tag     = $item.ImageIndex
			}

			$UI_Main_Rule_Details_View = New-Object system.Windows.Forms.LinkLabel -Property @{
				Height         = 30
				Width          = 515
				Padding        = "0,0,0,0"
				Margin         = "18,5,0,25"
				Text           = $lang.Detailed_View
				Tag            = $item.ImageIndex
				LinkColor      = "GREEN"
				ActiveLinkColor = "RED"
				LinkBehavior   = "NeverUnderline"
				add_Click      = {
					Wimlib_Image_Edit_Index_Detial -Index $this.Tag
				}
			}

			$UI_Main_Menu.controls.AddRange((
				$CheckBox,
				$UI_Main_Rule_Details_View
			))
		}

		<#
			.非 install.wim 时，禁用其它功能，和显示解锁按钮
		#>
		switch ($Global:Primary_Key_Image.Uid) {
			"boot;boot;wim;" {
				$UI_Main_Image_Add.Enabled = $False           # 添加
				$UI_Main_Image_Del.Enabled = $False           # 删除
				$UI_Main_Rebuild_All.Enabled = $False         # 重建
				$UI_Main_Tips.Visible = $True
			}
			"install;install;esd;" {
				$UI_Main_OK.Visible = $False
				$UI_Main_Image_Add.Enabled = $False           # 添加
				$UI_Main_Image_Del.Enabled = $True            # 删除
				$UI_Main_Rebuild_All.Enabled = $False         # 重建
			}
			"install;install;swm;" {
				$UI_Main_OK.Visible = $False
				$UI_Main_Image_Add.Enabled = $False           # 添加
				$UI_Main_Image_Del.Enabled = $True            # 删除
				$UI_Main_Rebuild_All.Enabled = $False         # 重建
			}
		}

		<#
			.判断是否有扩展项，有则启用：提取、更新 WIM 内的文件
		#>
		ForEach ($item in $Global:Image_Rule) {
			if ($item.Main.Suffix -eq "wim") {
				if ($item.Main.Uid -eq $Global:Primary_Key_Image.Uid) {
					if ($item.Expand.Count -gt 0) {
						$UI_Main_Image_WIM_Update.Enabled = $True
					}
				}

				if ($item.Expand.Count -gt 0) {
					if ($item.Expand.Uid -eq $Global:Primary_Key_Image.Uid) {
						if ($item.Expand.Expand.Count -gt 0) {
							$UI_Main_Image_WIM_Update.Enabled = $True
						}
					}
				}
			}
		}
	}

	$UI_Main           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 928
		Text           = $lang.Choose
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}
	$UI_Main_Menu      = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		Height         = 675
		Width          = 555
		autoSizeMode   = 1
		Location       = '20,0'
		Padding        = "0,15,0,0"
		autoScroll     = $True
	}


	<#
		.Mask: Displays the rule details
		.蒙板：显示规则详细信息
	#>
	$UI_Main_Mask_Rule_Detailed = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 678
		Width          = 1006
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '0,0'
		Visible        = 0
	}
	$UI_Main_Mask_Rule_Detailed_Results = New-Object System.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		Height         = 675
		Width          = 555
		autoSizeMode   = 1
		Location       = '20,0'
		Padding        = "0,15,0,0"
		autoScroll     = $True
	}

	<#
		.显示详细信息，控件
	#>
	<#
		.索引号
	#>
	$UI_Main_Mask_Rule_Wim_Image_Index = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 530
		margin         = "2,0,0,10"
		Text           = $lang.MountedIndexSelect
		Tag            = ""
	}

	<#
		.映像名称
	#>
	$UI_Main_Mask_Rule_Wim_Image_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		Text           = $lang.Wim_Image_Name
	}
	$UI_Main_Mask_Rule_Wim_Image_Name_Edit = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 480
		Text           = ""
		margin         = "22,0,0,30"
	}

	<#
		.映像说明
	#>
	$UI_Main_Mask_Rule_Wim_Image_Description = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		Text           = $lang.Wim_Image_Description
	}
	$UI_Main_Mask_Rule_Wim_Image_Description_Edit = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 480
		Text           = ""
		margin         = "22,0,0,30"
	}

	<#
		.显示名称
	#>
	$UI_Main_Mask_Rule_Wim_Display_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		Text           = $lang.Wim_Display_Name
	}
	$UI_Main_Mask_Rule_Wim_Display_Name_Edit = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 480
		Text           = ""
		margin         = "22,0,0,30"
	}

	<#
		.显示说明
	#>
	$UI_Main_Mask_Rule_Wim_Display_Description = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		Text           = $lang.Wim_Display_Description
	}
	$UI_Main_Mask_Rule_Wim_Display_Description_Edit = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 480
		Text           = ""
		margin         = "22,0,0,30"
	}

	<#
		.映像标志
	#>
	$UI_Main_Mask_Rule_Wim_Edition = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		Text           = $lang.Wim_Edition
	}
	$UI_Main_Mask_Rule_Wim_Edition_Edit = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 480
		Text           = ""
		margin         = "22,0,0,30"
	}

	<#
		.架构
	#>
	$UI_Main_Mask_Rule_Wim_Architecture = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		margin         = "2,12,0,12"
		Text           = $lang.Architecture
	}

	<#
		.创建日期
	#>
	$UI_Main_Mask_Rule_Wim_Created = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 530
		margin         = "2,0,0,12"
		Text           = $lang.Wim_Created
	}

	<#
		.展开空间
	#>
	$UI_Main_Mask_Rule_Wim_Expander_Space = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 530
		margin         = "2,0,0,12"
		Text           = $lang.Wim_Expander_Space
	}

	<#
		.系统版本
	#>
	$UI_Main_Mask_Rule_Wim_System_Version = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 530
		margin         = "2,0,0,12"
		Text           = $lang.EditionsTips
	}

	$UI_Main_Mask_Rule_Detailed_Ok = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,595"
		Height         = 36
		Width          = 280
		Text           = $lang.Wim_Rename
		add_Click      = {
			$UI_Main_Mask_Rule_Detailed.Visible = $False
			$wimlib = "$(Get_Arch_Path -Path "$($PSScriptRoot)\..\..\..\..\AIO\wimlib")\wimlib-imagex.exe"
			if (Test-Path $wimlib -PathType Leaf) {
				$Arguments = "info ""$($Global:Primary_Key_Image.FullPath)"" $($UI_Main_Mask_Rule_Wim_Image_Index.Tag) --image-property NAME=""$($UI_Main_Mask_Rule_Wim_Image_Name_Edit.Text)"" --image-property DESCRIPTION=""$($UI_Main_Mask_Rule_Wim_Image_Description_Edit.Text)"" --image-property DISPLAYNAME=""$($UI_Main_Mask_Rule_Wim_Display_Name_Edit.Text)"" --image-property DISPLAYDESCRIPTION=""$($UI_Main_Mask_Rule_Wim_Display_Description_Edit.Text)"" --image-property FLAGS=""$($UI_Main_Mask_Rule_Wim_Edition_Edit.Text)"""

				Start-Process -FilePath $wimlib -ArgumentList $Arguments -wait -nonewwindow
			}

			Wimlib_Image_Refresh_Details_Rule -Refresh
		}
	}
	$UI_Main_Mask_Rule_Detailed_Canel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$UI_Main_Mask_Rule_Detailed.Visible = $False
		}
	}

	<#
		.添加
	#>
	$UI_Main_Image_Add = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,10"
		Height         = 36
		Width          = 280
		Text           = $lang.AddTo
		add_Click      = {
			$UI_Main.Hide()
			Image_Select_Add_UI
			$UI_Main.Close()
		}
	}

	<#
		.删除
	#>
	$UI_Main_Image_Del = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,50"
		Height         = 36
		Width          = 280
		add_Click      = {
			$UI_Main.Hide()
			Image_Select_Del_UI
			$UI_Main.Close()
		}
		Text           = $lang.Del
	}

	<#
		.导出
	#>
	$UI_Main_Export_Image = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,90"
		Height         = 36
		Width          = 280
		add_Click      = {
			$UI_Main.Hide()
			Image_Select_Export_UI
			$UI_Main.Close()
		}
		Text           = $lang.Export_Image
	}

	<#
		.重建
	#>
	$UI_Main_Rebuild_All = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,130"
		Height         = 36
		Width          = 280
		add_Click      = {
			$UI_Main.Hide()
			Rebuild_Image_File -Filename $Global:Primary_Key_Image.FullPath
			$UI_Main.Close()
		}
		Text           = $lang.RebuildAll
	}

	<#
		.修改映像信息
	#>
	$UI_Main_Image_WIM_Update = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,170"
		Height         = 36
		Width          = 280
		Text           = $lang.Wim_Rule_Update
		Enabled        = $False
		add_Click      = {
			$UI_Main.Hide()
			Wimlib_Extract_And_Update
			$UI_Main.Close()
		}
	}

	<#
		.不可操作时，可选按钮：解锁
	#>
	$UI_Main_Tips      = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 200
		Width          = 280
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $False
		Padding        = "8,0,8,0"
		Location       = "620,220"
		visible        = 0
	}
	$UI_Main_Tips_Show = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		Text           = $lang.SolutionsToError
	}
	$UI_Main_Unlock    = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 300
		Text           = $lang.UnlockBoot
		Location       = '88,8'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$UI_Main_Tips.Visible = $False

			$UI_Main_Image_Add.Enabled = $True
			$UI_Main_Export_Image.Enabled = $True
			$UI_Main_Image_Del.Enabled = $True
			$UI_Main_Image_WIM_Update.Enabled = $True
		}
	}

	$UI_Main_Error     = New-Object system.Windows.Forms.Label -Property @{
		Location       = "620,570"
		Height         = 22
		Width          = 300
		Text           = ""
	}
	$UI_Main_OK        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,595"
		Height         = 36
		Width          = 280
		Text           = $lang.Mount
		add_Click      = {
			$UI_Main_Menu.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Enabled) {
						if ($_.Checked) {
							$UI_Main.Hide()

							ForEach ($item in $Global:Primary_Key_Image.Index) {
								if ($item.ImageIndex -eq $_.Tag) {
									Write-Host "   $($lang.MountedName): " -NoNewline
									Write-Host "$($item.ImageName)" -ForegroundColor Yellow

									Write-Host "   $($lang.MountedIndex): " -NoNewline
									Write-Host "$($item.ImageIndex)" -ForegroundColor Yellow

									if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
										if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
											Write-Host "`n   $($lang.Command)" -ForegroundColor Green
											Write-host "   $($lang.Developers_Mode_Location)90" -ForegroundColor Green
											Write-host "   $('-' * 80)"
											write-host "   Repair-WindowsImage -Path ""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"" -RestoreHealth" -ForegroundColor Green
											Write-host "   $('-' * 80)`n"
										}

										Repair-WindowsImage -Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -RestoreHealth -ErrorAction SilentlyContinue | Out-Null
										dism /cleanup-wim | Out-Null
										Clear-WindowsCorruptMountPoint -LogPath "$($Global:SaveToDism)" -ErrorAction SilentlyContinue | Out-Null
										Remove_Tree "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"
									}

									Check_Folder -chkpath "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"

									if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
										Write-Host "`n   $($lang.Command)" -ForegroundColor Green
										Write-host "   $($lang.Developers_Mode_Location)91" -ForegroundColor Green
										Write-host "   $('-' * 80)"
										write-host "   Mount-WindowsImage -ImagePath ""$($Global:Primary_Key_Image.FullPath)"" -Index ""$($_.Tag)"" -Path ""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)""" -ForegroundColor Green
										Write-host "   $('-' * 80)`n"
									}

									Mount-WindowsImage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -ImagePath "$($Global:Primary_Key_Image.FullPath)" -Index "$($_.Tag)" -Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"
								}
							}

							Write-Host "   $($lang.Done)" -ForegroundColor Green

							$UI_Main.Close()
						}
					}
				}
			}

			$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.NoChoose)"
		}
	}
	$UI_Main_Canel     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
			$UI_Main.Close()
		}
	}
	$UI_Main.controls.AddRange((
		$UI_Main_Mask_Rule_Detailed,
		$UI_Main_Menu,
		$UI_Main_Tips,
		$UI_Main_Image_Add,
		$UI_Main_Image_Del,
		$UI_Main_Image_WIM_Update,
		$UI_Main_Rebuild_All,
		$UI_Main_Export_Image,
		$UI_Main_Error,
		$UI_Main_OK,
		$UI_Main_Canel
	))
	$UI_Main_Tips.controls.AddRange((
		$UI_Main_Tips_Show,
		$UI_Main_Unlock
	))
	$UI_Main_Mask_Rule_Detailed.controls.AddRange((
		$UI_Main_Mask_Rule_Detailed_Results,
		$UI_Main_Mask_Rule_Detailed_Ok,
		$UI_Main_Mask_Rule_Detailed_Canel
	))
	$UI_Main_Mask_Rule_Detailed_Results.controls.AddRange((
		$UI_Main_Mask_Rule_Wim_Image_Index,
		$UI_Main_Mask_Rule_Wim_Image_Name,
		$UI_Main_Mask_Rule_Wim_Image_Name_Edit,
		$UI_Main_Mask_Rule_Wim_Image_Description,
		$UI_Main_Mask_Rule_Wim_Image_Description_Edit,
		$UI_Main_Mask_Rule_Wim_Display_Name,
		$UI_Main_Mask_Rule_Wim_Display_Name_Edit,
		$UI_Main_Mask_Rule_Wim_Display_Description,
		$UI_Main_Mask_Rule_Wim_Display_Description_Edit,
		$UI_Main_Mask_Rule_Wim_Edition,
		$UI_Main_Mask_Rule_Wim_Edition_Edit,
		$UI_Main_Mask_Rule_Wim_Architecture,
		$UI_Main_Mask_Rule_Wim_Created,
		$UI_Main_Mask_Rule_Wim_Expander_Space,
		$UI_Main_Mask_Rule_Wim_System_Version
	))

	Wimlib_Image_Refresh_Details_Rule

	if (Verify_Is_Current_Same) {
		$UI_Main_Image_Add.Enabled = $False
		$UI_Main_Image_Del.Enabled = $False
		$UI_Main_Export_Image.Enabled = $False
		$UI_Main_Rebuild_All.Enabled = $False
	}

	if ($Global:EventQueueMode) {
		$UI_Main.Text = "$($UI_Main.Text) [ $($lang.QueueMode), $($lang.Event_Primary_Key)$($Global:Primary_Key_Image.Uid) ]"
	} else {
		$UI_Main.Text = "$($UI_Main.Text) [ $($lang.Event_Primary_Key)$($Global:Primary_Key_Image.Uid) ]"
	}

	<#
		.Allow open windows to be on top
		.允许打开的窗口后置顶
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
			"True" { $UI_Main.TopMost = $True }
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$UI_Main.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$UI_Main.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$UI_Main.FormBorderStyle = 'Fixed3D'
	$UI_Main.ShowDialog() | Out-Null
}

<#
	.选择索引号，多
#>
Function Image_Select_Mul_UI
{
	param
	(
		$ImageFileName
	)

	Write-Host "`n   $($lang.Chosen) $($lang.SelectSettingImage)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	<#
		.事件：强行结束按需任务
	#>
	$UI_Main_Suggestion_Stop_Click = {
		$UI_Main.Hide()
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		Event_Reset_Variable
		$UI_Main.Close()
	}

	$UI_Main           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 876
		Text           = $lang.Choose
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}
	$UI_Main_Menu      = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 580
		Width          = 500
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "15,8,0,0"
		Dock           = 3
	}

	<#
		.Note
		.注意
	#>
	$UI_Main_Tips   = New-Object System.Windows.Forms.RichTextBox -Property @{
		Height         = 220
		Width          = 270
		BorderStyle    = 0
		Location       = "575,10"
		Text           = $lang.SelectTips
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}

	<#
		.End on-demand mode
		.结束按需模式
	#>
	$UI_Main_Suggestion_Stop_Current = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.AssignEndCurrent -f "$($Global:Primary_Key_Image.Master);$($Global:Primary_Key_Image.ImageFileName)")"
		Location       = '570,395'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$UI_Main.Hide()
			Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
			Event_Need_Mount_Global_Variable -DevQueue "24" -Master $Global:Primary_Key_Image.Master -ImageFileName $Global:Primary_Key_Image.ImageFileName
			Event_Reset_Suggest
			$UI_Main.Close()
		}
	}
	$UI_Main_Event_Assign_Stop = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignForceEnd
		Location       = '570,425'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Suggestion_Stop_Click
	}

	<#
		.Suggested content
		.建议的内容
	#>
	$UI_Main_Suggestion_Not = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 430
		Text           = $lang.SuggestedSkip
		Location       = '570,395'
		add_Click      = {
			if ($UI_Main_Suggestion_Not.Checked) {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -name "IsSuggested" -value "True" -String
				$UI_Main_Suggestion_Setting.Enabled = $False
				$UI_Main_Suggestion_Stop.Enabled = $False
			} else {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -name "IsSuggested" -value "False" -String
				$UI_Main_Suggestion_Setting.Enabled = $True
				$UI_Main_Suggestion_Stop.Enabled = $True
			}
		}
	}
	$UI_Main_Suggestion_Setting = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignSetting
		Location       = '586,426'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Event_Assign_Setting }
	}
	$UI_Main_Suggestion_Stop = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignForceEnd
		Location       = '586,455'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Suggestion_Stop_Click
	}

	$UI_Main_Error     = New-Object system.Windows.Forms.Label -Property @{
		Location       = "570,525"
		Height         = 22
		Width          = 280
		Text           = ""
	}
	$UI_Main_OK        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "570,595"
		Height         = 36
		Width          = 280
		Text           = $lang.OK
		add_Click      = {
			<#
				.Reset selected
				.重置已选择
			#>
			$TempQueueProcessImageSelectPending = @()
			$MarkSelectIndexin = @()

	 		<#
	 		    .Mark: Check the selection status
	 		    .标记：检查选择状态
	 		#>

			$UI_Main_Menu.Controls | ForEach-Object {
				if ($_.Enabled) {
					if ($_.Checked) {
						$MarkSelectIndexin += $_.Tag
					}
				}
			}

			if ($MarkSelectIndexin.Count -gt 0) {
				$UI_Main.Hide()

				ForEach ($item in $MarkSelectIndexin) {
					$WildCardMatches = ForEach ($WildCard in (Get-Variable -Scope global -Name "Queue_Process_Image_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -ErrorAction SilentlyContinue).Value) {
						if ($item -eq $WildCard.Index) {
							$TempQueueProcessImageSelectPending += @{
								Name   = "$($WildCard.Name)"
								Index  = "$($WildCard.Index)"
							}
						}
					}
				}
				New-Variable -Scope global -Name "Queue_Process_Image_Select_Pending_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $TempQueueProcessImageSelectPending -Force

				ForEach ($item in $TempQueueProcessImageSelectPending) {
					Write-Host "   $($lang.MountedName): " -NoNewline
					Write-Host "$($item.Name)" -ForegroundColor Yellow

					Write-Host "   $($lang.MountedIndex): " -NoNewline
					Write-Host "$($item.Index)`n" -ForegroundColor Yellow
				}

				if ($UI_Main_Suggestion_Not.Checked) {
					Init_Canel_Event -All
				}
				$UI_Main.Close()
			} else {
				$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.NoChoose)"
			}
		}
	}
	$UI_Main_Canel     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "570,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
			New-Variable -Scope global -Name "Queue_Process_Image_Select_Pending_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value @() -Force

			if ($UI_Main_Suggestion_Not.Checked) {
				Init_Canel_Event
			}
			$UI_Main.Close()
		}
	}
	$UI_Main.controls.AddRange((
		$UI_Main_Menu,
		$UI_Main_Tips,
		$UI_Main_Error,
		$UI_Main_OK,
		$UI_Main_Canel
	))

	$TempQueueProcessImageSelect = @()
	if (Test-Path $ImageFileName -PathType Leaf) {
		if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
			Write-Host "`n   $($lang.Command)" -ForegroundColor Green
			Write-host "   $($lang.Developers_Mode_Location)92" -ForegroundColor Green
			Write-host "   $('-' * 80)"
			write-host "   Get-WindowsImage -ImagePath ""$($ImageFileName)""" -ForegroundColor Green
			Write-host "   $('-' * 80)`n"
		}

		Get-WindowsImage -ImagePath $ImageFileName -ErrorAction SilentlyContinue | ForEach-Object {
			$TempQueueProcessImageSelect += @{
				Name   = "$($_.ImageName)"
				Index  = "$($_.ImageIndex)"
			}

			$CheckBox   = New-Object System.Windows.Forms.CheckBox -Property @{
				Height  = 40
				Width   = 450
				margin  = "0,0,0,18"
				Text    = "$($lang.MountedName): $($_.ImageName)`n$($lang.MountedIndex): $($_.ImageIndex)"
				Tag     = $_.ImageIndex
				Checked = $True
			}

			if ($Queue) {
				$CheckBox.Checked = $True
			}
			$UI_Main_Menu.controls.AddRange($CheckBox)
		}
	}
	New-Variable -Scope global -Name "Queue_Process_Image_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $TempQueueProcessImageSelect -Force

	<#
		.Add right-click menu: select all, clear button
		.添加右键菜单：全选、清除按钮
	#>
	$UI_Main_Menu_Select = New-Object System.Windows.Forms.ContextMenuStrip
	$UI_Main_Menu_Select.Items.Add($lang.AllSel).add_Click({
		$UI_Main_Menu.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	})
	$UI_Main_Menu_Select.Items.Add($lang.AllClear).add_Click({
		$UI_Main_Menu.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	})
	$UI_Main_Menu.ContextMenuStrip = $UI_Main_Menu_Select

	if ($Global:EventQueueMode) {
		$UI_Main.Text = "$($UI_Main.Text) [ $($lang.QueueMode), $($lang.Event_Primary_Key)$($Global:Primary_Key_Image.Uid) ]"
		$UI_Main.controls.AddRange((
			$UI_Main_Suggestion_Stop_Current,
			$UI_Main_Event_Assign_Stop
		))
	} else {
		$UI_Main.Text = "$($UI_Main.Text) [ $($lang.Event_Primary_Key)$($Global:Primary_Key_Image.Uid) ]"

		<#
			.初始化复选框：不再建议
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
				"True" {
					$UI_Main_Suggestion_Not.Checked = $True
					$UI_Main_Suggestion_Setting.Enabled = $False
					$UI_Main_Suggestion_Stop.Enabled = $False
				}
				"False" {
					$UI_Main_Suggestion_Not.Checked = $False
					$UI_Main_Suggestion_Setting.Enabled = $True
					$UI_Main_Suggestion_Stop.Enabled = $True
				}
			}
		} else {
			$UI_Main_Suggestion_Not.Checked = $False
			$UI_Main_Suggestion_Setting.Enabled = $True
			$UI_Main_Suggestion_Stop.Enabled = $True
		}

		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
			if ((Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) -eq "True") {
				$UI_Main.controls.AddRange((
					$UI_Main_Suggestion_Not,
					$UI_Main_Suggestion_Setting,
					$UI_Main_Suggestion_Stop
				))
			}
		}
	}

	<#
		.Allow open windows to be on top
		.允许打开的窗口后置顶
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
			"True" { $UI_Main.TopMost = $True }
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$UI_Main.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$UI_Main.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$UI_Main.FormBorderStyle = 'Fixed3D'
	$UI_Main.ShowDialog() | Out-Null
}