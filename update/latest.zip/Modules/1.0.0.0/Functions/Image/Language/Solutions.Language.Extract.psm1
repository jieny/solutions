﻿<#
	.Extract Language Add
	.提取语言添加
#>
Function Language_Extract_UI
{
	param
	(
		[switch]$Add,
		[switch]$Del
	)

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	Function Language_Extract_Add_Refresh
	{
		param
		(
			$Mode,
			$NewUid,
			$NewLanguage,
			$SaveTo
		)

		<#
			.在主界面，显示查看历史记录
		#>
		$UI_Main_Extract_View.Visible = $True

		<#
			.刷新打开目录、粘贴事件
		#>
		Language_Add_Refresh_Folder_Sources

		<#
			.判断是否跳过添加英文语言包
		#>
		if ($UI_Main_Extract_Rule_Exclude_EN_US.Enabled) {
			if ($UI_Main_Extract_Rule_Exclude_EN_US.Checked) {
				if ($NewLanguage -eq "en-US") {
					return
				}
			}
		}

		<#
			.转换变量
		#>
		$NewArch  = $($Global:Architecture)
		$NewArchC = $($Global:Architecture).Replace("AMD64", "x64")
		switch -regex ($NewLanguage) {
			"ar-AE|ar-BH|ar-DJ|ar-DZ|ar-EG|ar-ER|ar-IL|ar-IQ|ar-JO|ar-KM|ar-KW|ar-LB|ar-LY|ar-MA|ar-MR|ar-OM|ar-PS|ar-QA|ar-SA|ar-SD|ar-SO|ar-SS|ar-SY|ar-TD|ar-TN|ar-YE|arz-Arab|ckb-Arab|fa-AF|fa-IR|glk-Arab|ha-Arab|ks-Arab|ks-Arab-IN|ku-Arab|ku-Arab-IQ|mzn-Arab|pa-Arab|pa-Arab-PK|pnb-Arab|prs-AF|prs-Arab|ps-AF|sd-Arab|sd-Arab-PK|tk-Arab|ug-Arab|ug-CN|ur-IN|ur-PK|uz-Arab|uz-Arab-AF" {
				$NewDiyLanguage = "Arab"
			}
			"as-IN|bn-BD|bn-IN|bpy-Beng" {
				$NewDiyLanguage = "Beng"
			}
			"da-dk|iu-Cans|iu-Cans-CA" {
				$NewDiyLanguage = "Cans"
			}
			"chr-Cher-US|chr-Cher" {
				$NewDiyLanguage = "Cher"
			}
			"bh-Deva|brx-Deva|brx-IN|hi-IN|ks-Deva|mr-IN|ne-IN|ne-NP|new-Deva|pi-Deva|sa-Deva|sa-IN" {
				$NewDiyLanguage = "Deva"
			}
			"am-ET|byn-ER|byn-Ethi|ti-ER|ti-ET|tig-ER|tig-Ethi|ve-Ethi|wal-ET|wal-Ethi" {
				$NewDiyLanguage = "Ethi"
			}
			"gu-IN" {
				$NewDiyLanguage = "Gujr"
			}
			"pa-Guru|pa-IN" {
				$NewDiyLanguage = "Guru"
			}
			"cmn-Hans|gan-Hans|hak-Hans|wuu-Hans|yue-Hans|zh-CN|zh-gan-Hans|zh-hak-Hans|zh-Hans|zh-SG|zh-wuu-Hans|zh-yue-Hans" {
				$NewDiyLanguage = "Hans"
			}
			"cmn-Hant|hak-Hant|lzh-Hant|zh-hak-Hant|zh-Hant|zh-HK|zh-lzh-Hant|zh-MO|zh-TW|zh-yue-Hant" {
				$NewDiyLanguage = "Hant"
			}
			"he-IL|yi" {
				$NewDiyLanguage = "Hebr"
			}
			"ja-JP" {
				$NewDiyLanguage = "Jpan"
			}
			"km-KH" {
				$NewDiyLanguage = "Khmr"
			}
			"kn-IN" {
				$NewDiyLanguage = "Knda"
			}
			"ko-KR" {
				$NewDiyLanguage = "Kore"
			}
			"de-de|lo-LA" {
				$NewDiyLanguage = "Laoo"
			}
			"ml-IN" {
				$NewDiyLanguage = "Mlym"
			}
			"or-IN" {
				$NewDiyLanguage = "Orya"
			}
			"si-LK" {
				$NewDiyLanguage = "Sinh"
			}
			"tr-tr|arc-Syrc|syr-SY|syr-Syrc" {
				$NewDiyLanguage = "Syrc"
			}
			"ta-IN|ta-LK|ta-MY|ta-SG" {
				$NewDiyLanguage = "Taml"
			}
			"te-IN" {
				$NewDiyLanguage = "Telu"
			}
			"th-TH" {
				$NewDiyLanguage = "Thai"
			}
			default {
				$NewDiyLanguage = "skip_$($NewLanguage)_"
			}
		}

		$InBox_Apps_Rule_Select_Single = @()

		<#
			.从预规则里获取
		#>
		ForEach ($item in $Global:Pre_Config_Rules) {
			if ($Script:LanguageSearchRuleSelected -eq $item.GUID) {
				$InBox_Apps_Rule_Select_Single = $item
				break
			}
		}

		<#
			.从单条规则里获取
		#>
		ForEach ($item in $Global:Preconfigured_Rule_Language) {
			if ($Script:LanguageSearchRuleSelected -eq $item.GUID) {
				$InBox_Apps_Rule_Select_Single = $item
				break
			}
		}

		<#
			.从用户自定义规则里获取
		#>
		if (Is_Find_Modules -Name "Solutions.Custom.Extension") {
			if ($Global:Custom_Rule_Language.count -gt 0) {
				ForEach ($item in $Global:Custom_Rule_Language) {
					if ($Script:LanguageSearchRuleSelected -eq $item.GUID) {
						$InBox_Apps_Rule_Select_Single = $item
						break
					}
				}
			}
		}

		ForEach ($item in $InBox_Apps_Rule_Select_Single.Language.Rule) {
			if (($NewUid) -Contains $item.Group) {
				if ($item.Rule.Count -gt 0) {
					$UI_Main_Extract_Rule_Have_Result.Text += "$($lang.Event_Primary_Key)$($item.Group)`n$('-' * 80)`n"
					$UI_Main_Extract_Rule_Need_Result.Text += "$($lang.Event_Primary_Key)$($item.Group)`n$('-' * 80)`n"
					$UI_Main_Extract_Rule_Not_Result.Text  += "$($lang.Event_Primary_Key)$($item.Group)`n$('-' * 80)`n"

					for ($i=0; $i -lt $item.Rule.Count; $i++) {

						$WimLib_SplieNew_Rule_path = $item.Group -split ';'

						$MarkSearchTempFileResult = $False

						$SearchNewFileName  = "$($item.Rule[$i][0])".Replace("{ARCH}", $NewArch).Replace("{ARCHC}", $NewArchC).Replace("{Lang}", $NewLanguage).Replace("{DiyLang}", $NewDiyLanguage)
						$SearchNewStructure = "$($item.Rule[$i][1])".Replace("{ARCH}", $NewArch).Replace("{ARCHC}", $NewArchC).Replace("{Lang}", $NewLanguage).Replace("{DiyLang}", $NewDiyLanguage)
						$LocalLanguageFiles = "$($UI_Main_Extract_Rule_To_Result.Text)\$($WimLib_SplieNew_Rule_path[0])\$($WimLib_SplieNew_Rule_path[1])\$($SaveTo)\$($NewLanguage)\$($SearchNewFileName)"
						$UI_Main_Extract_Rule_Need_Result.Text += "$($SearchNewFileName)`n"

						if (Test-Path $LocalLanguageFiles -PathType Leaf) {
							$MarkSearchTempFileResult = $True
							$UI_Main_Extract_Rule_Have_Result.Text += "$($LocalLanguageFiles)`n"
						} else {
							Get-CimInstance -Class Win32_LogicalDisk -ErrorAction SilentlyContinue | Where-Object { -not ([string]::IsNullOrEmpty($_) -or [string]::IsNullOrWhiteSpace($_))} | ForEach-Object {
								$TempFileFullName = "$($SearchNewStructure)\$($SearchNewFileName)"
								$SearchTempFile = Join-Path -Path $_.DeviceID -ChildPath $TempFileFullName -ErrorAction SilentlyContinue

								if (Test-Path $SearchTempFile -PathType Leaf) {
									$MarkSearchTempFileResult = $True
									$UI_Main_Extract_Rule_Have_Result.Text += "$($SearchTempFile)`n"

									if ($Mode -eq "Import") {
										$CopyImportLication = "$($UI_Main_Extract_Rule_To_Result.Text)\$($WimLib_SplieNew_Rule_path[0])\$($WimLib_SplieNew_Rule_path[1])\$($SaveTo)\$($NewLanguage)"
										Check_Folder -chkpath $CopyImportLication
										Copy-Item -Path $SearchTempFile -Destination $CopyImportLication -Recurse -Force -ErrorAction SilentlyContinue

										if ($UI_Main_Extract_Delete_Duplicate.Checked) {
											Language_Extract_Add_Duplication -NewPath $CopyImportLication
										}
									}

									Language_Add_Refresh_Folder_Sources
									return
								}
							}
						}

						if (-not ($MarkSearchTempFileResult)) {
							$UI_Main_Extract_Rule_Not_Result.Text += "$($SearchNewFileName)`n"
						}
					}
					
					$UI_Main_Extract_Rule_Have_Result.Text += "`n`n"
					$UI_Main_Extract_Rule_Need_Result.Text += "`n`n"
					$UI_Main_Extract_Rule_Not_Result.Text  += "`n`n"
					#end for
				}
			}
		}
	}

	Function Language_Extract_Add_View
	{
		param
		(
			$Mode
		)

		<#
			.重置结果
		#>
		$UI_Main_Error.Text = ""
		$UI_Main_Extract_Rule_Key_Result.Text = ""
		$UI_Main_Extract_Rule_Need_Result.Text = ""
		$UI_Main_Extract_Rule_Have_Result.Text = ""
		$UI_Main_Extract_Rule_Not_Result.Text = ""

		$MarkCheckedRuleNaming = $False
		$FlagCheckSelectLanguage = $False
		$MarkCheckRules = $False
		$MarkCheckSelectAddDel = $False
		$MarkCheckSelectAddDelDefault = ""

		$TempSelectLXPsLanguage = @()
		$Wait_Select_Key = @()

		<#
			.检查是否选择规则命名
		#>
		$UI_Main_Extract_Rule_Select_Sourcest.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Checked) {
					$MarkCheckedRuleNaming = $True
					$Script:LanguageSearchRuleSelected = $_.Tag
					Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -name "SelectGUID" -value $_.Tag -String
				}
			}
		}

		if ($MarkCheckedRuleNaming) {
		} else {
			$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.NoChoose) ( $($lang.RulePre) )"
			return
		}

		<#
			.检查是否选择语言
		#>
		$UI_Main_Available_Languages_Select.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					if ($_.Checked) {
						$FlagCheckSelectLanguage = $True
						$TempSelectLXPsLanguage += $_.Tag
					}
				}
			}
		}

		if ($FlagCheckSelectLanguage) {
			Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -name "Add_List" -value $TempSelectLXPsLanguage -Multi
		} else {
			$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.NoChoose) ( $($lang.AvailableLanguages) )"
			return
		}

		<#
			.检查是否选择添加、删除
		#>
		$UI_Main_Extract_Save_To_Select.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Enabled) {
					if ($_.Checked) {
						$MarkCheckSelectAddDel = $True
						$MarkCheckSelectAddDelDefault = $_.Tag
					}
				}
			}
		}

		if ($MarkCheckSelectAddDel) {
			
		} else {
			$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.NoChoose) ( $($lang.SaveTo) )"
			return
		}


		<#
			.检查是否选择主键
		#>
		$UI_Main_Extract_Select_WIM.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Checked) {
					$Wait_Select_Key += $_.Tag
					$UI_Main_Extract_Rule_Key_Result.Text += "$($_.Tag)`n"
				}
			}
		}

		if ($Wait_Select_Key.Count -gt 0) {
			$UI_Main_View_Return.Visible = $True
			
			Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -name "Add_List" -value $TempSelectLXPsLanguage -Multi

			switch ($Mode) {
				"Search" {
					ForEach ($item in $TempSelectLXPsLanguage) {
						Language_Extract_Add_Refresh -NewLanguage $item -Mode "Search" -NewUid $Wait_Select_Key -SaveTo $MarkCheckSelectAddDelDefault
					}
				}
				"Import" {
					ForEach ($item in $TempSelectLXPsLanguage) {
						Language_Extract_Add_Refresh -NewLanguage $item -Mode "Import" -NewUid $Wait_Select_Key -SaveTo $MarkCheckSelectAddDelDefault
					}
				}
			}
		} else {
			$UI_Main_Error.Text = $lang.LanguageExtractRuleNoSel
		}
	}

	Function Language_Extract_Add_Duplication
	{
		param
		(
			$NewPath
		)

		$duplicates = Get-ChildItem $NewPath -File -Recurse -ErrorAction SilentlyContinue | Get-FileHash | Group-Object -Property Hash | Where-Object Count -GT 1

		if ($duplicates.count -lt 1) {
			$UI_Main_Error.Text = $lang.NoWork
			return
		} else {
			$result = ForEach ($d in $duplicates)  {
				$d.Group | Select-Object -Property Path, Hash
			}

			if ($d.count -gt 0) {
				ForEach ($item in $result) {
					Move-Item $item.Path -Destination $NewPath -Force -ErrorAction SilentlyContinue | Out-Null
				}

				$UI_Main_Error.Text = "$($lang.Del) ( $($d.Count) $($lang.EventManagerCount) )"
			} else {
				$UI_Main_Error.Text = $lang.NoWork
			}
		}
	}

	Function Language_Add_Refresh_Folder_Sources
	{
		<#
			.计算公式：
				四舍五入为整数
					(初始化字符长度 * 初始化字符长度）
				/ 控件高度
		#>

		<#
			.初始化字符长度
		#>
		[int]$InitCharacterLength = 70

		<#
			.初始化控件高度
		#>
		[int]$InitControlHeight = 40

		$InitLength = $item.Length
		if ($InitLength -lt $InitCharacterLength) { $InitLength = $InitCharacterLength }

		$UI_Main_Extract_Rule_To_Result.Height = $([math]::Ceiling($InitLength / $InitCharacterLength) * $InitControlHeight)

		if (Test-Path $UI_Main_Extract_Rule_To_Result.Text -PathType Container) {
			$UI_Main_Extract_Rule_To_Open_Folder.Enabled = $True
			$UI_Main_Extract_Rule_To_Paste.Enabled = $True
		} else {
			$UI_Main_Extract_Rule_To_Open_Folder.Enabled = $False
			$UI_Main_Extract_Rule_To_Paste.Enabled = $False
		}
	}

	<#
		.事件：查看规则命名，详细内容
	#>
	Function Language_Add_Rule_Details_View
	{
		param
		(
			$GUID
		)

		$InBox_Apps_Rule_Select_Single = @()

		<#
			.从预规则里获取
		#>
		ForEach ($item in $Global:Pre_Config_Rules) {
			if ($GUID -eq $item.GUID) {
				$InBox_Apps_Rule_Select_Single = $item
				break
			}
		}

		<#
			.从预规则里获取
		#>
		ForEach ($item in $Global:Preconfigured_Rule_Language) {
			if ($GUID -eq $item.GUID) {
				$InBox_Apps_Rule_Select_Single = $item
				break
			}
		}

		<#
			.从用户自定义规则里获取
		#>
		if (Is_Find_Modules -Name "Solutions.Custom.Extension") {
			if ($Global:Custom_Rule_Language.count -gt 0) {
				ForEach ($item in $Global:Custom_Rule_Language) {
					if ($GUID -eq $item.GUID) {
						$InBox_Apps_Rule_Select_Single = $item
						break
					}
				}
			}
		}

		if ($InBox_Apps_Rule_Select_Single.count -gt 0) {
			$UI_Main_View_Detailed.Visible = $True
			$UI_Main_View_Detailed_Show.Text = ""

			$UI_Main_View_Detailed_Show.Text += "$($lang.RuleAuthon)`n"
			$UI_Main_View_Detailed_Show.Text += "   $($InBox_Apps_Rule_Select_Single.Author)"

			$UI_Main_View_Detailed_Show.Text += "`n`n$($lang.RuleGUID)`n"
			$UI_Main_View_Detailed_Show.Text += "     $($InBox_Apps_Rule_Select_Single.GUID)"

			$UI_Main_View_Detailed_Show.Text += "`n`n$($lang.RuleName)`n"
			$UI_Main_View_Detailed_Show.Text += "     $($InBox_Apps_Rule_Select_Single.Name)"

			$UI_Main_View_Detailed_Show.Text += "`n`nISO`n"
			ForEach ($item in $InBox_Apps_Rule_Select_Single.ISO) {
				$UI_Main_View_Detailed_Show.Text += "     $($item)`n"
			}

			$UI_Main_View_Detailed_Show.Text += "`n`n$($lang.RuleDescription)`n"
			$UI_Main_View_Detailed_Show.Text += "     $($InBox_Apps_Rule_Select_Single.Description)"

			$UI_Main_View_Detailed_Show.Text += "`n`n$($lang.RuleISO)`n"
			ForEach ($item in $InBox_Apps_Rule_Select_Single.Language.ISO) {
				$UI_Main_View_Detailed_Show.Text += "     $($item)`n"
			}

			$UI_Main_View_Detailed_Show.Text += "`n`n$($lang.Language)`n"
			if ($InBox_Apps_Rule_Select_Single.Language.Rule.Count -gt 0) {
				ForEach ($PrintExpandRule in $InBox_Apps_Rule_Select_Single.Language.Rule) {
					$Temp_Add_Not_Mounted_New = $PrintExpandRule.Rule | Where-Object { -not ([string]::IsNullOrEmpty($_) -or [string]::IsNullOrWhiteSpace($_))} | Select-Object -Unique

					$UI_Main_View_Detailed_Show.Text += "     $($lang.Event_Primary_Key)$($PrintExpandRule.Group)`n     $('-' * 80)`n"

					if ($Temp_Add_Not_Mounted_New.Count -gt 0) {
						$UI_Main_View_Detailed_Show.Text += "`n           $($lang.MatchMode) ( $($Temp_Add_Not_Mounted_New.Count) $($lang.EventManagerCount) )`n           $('-' * 76)`n"
						ForEach ($item in $Temp_Add_Not_Mounted_New) {
							$UI_Main_View_Detailed_Show.Text += "           $($item[0])`n"
						}
					} else {
						$UI_Main_View_Detailed_Show.Text += "     $($lang.NoWork)`n"
					}

					$UI_Main_View_Detailed_Show.Text += "`n"
				}
			} else {
				$UI_Main_View_Detailed_Show.Text += "$($lang.NoWork)"
			}
		} else {
			$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.Detailed_View)"
		}
	}
	
	<#
		.事件，隐藏显示规则详细
	#>
	$UI_Main_View_Detailed_Canel_Click = {
		$UI_Main_View_Detailed.Visible = $False
	}

	<#
		.事件：打开目录
	#>
	$UI_Main_Extract_Rule_To_Open_FolderClick = {
		if (-not [string]::IsNullOrEmpty($UI_Main_Extract_Rule_To_Result.Text)) {
			if (Test-Path $UI_Main_Extract_Rule_To_Result.Text -PathType Container) {
				Start-Process $UI_Main_Extract_Rule_To_Result.Text
			}
		} 
	}

	<#
		.事件：复制
	#>
	$UI_Main_Extract_Rule_To_PasteClick = {
		if (-not [string]::IsNullOrEmpty($UI_Main_Extract_Rule_To_Result.Text)) {
			Set-Clipboard -Value $UI_Main_Extract_Rule_To_Result.Text
		}
	}

	<#
		.事件：解锁已隐藏语言
	#>
	$UI_Main_Available_Languages_Unlock_Click = {
		$UI_Main_Available_Languages_Select.controls.Clear()
		if (-not (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -Name 'Add_List' -ErrorAction SilentlyContinue)) {
			$DeployinboxGetSources = $False
			$DeployinboxGetSourcesOnly = @()

			for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
				if (Test-Path "$($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])" -PathType Container) {
					if((Get-ChildItem "$($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])" -Recurse -ErrorAction SilentlyContinue | Measure-Object).Count -gt 0) {
						$DeployinboxGetSources = $True
						$DeployinboxGetSourcesOnly += $($Global:AvailableLanguages[$i][2])
					}
				}
			}

			if ($DeployinboxGetSources) {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -name "Add_List" -value $DeployinboxGetSourcesOnly -Multi
			} else {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -name "Add_List" -value "" -Multi
			}
		}
		$GetSelectLXPsLanguage = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -Name "Add_List"

		$SelectLXPsLanguage = @()
		ForEach ($item in $GetSelectLXPsLanguage) {
			$SelectLXPsLanguage += $item
		}

		for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
			$CheckBox   = New-Object System.Windows.Forms.CheckBox -Property @{
				Height  = 28
				Width   = 485
				Text    = "$($Global:AvailableLanguages[$i][2].PadRight(45)) $($Global:AvailableLanguages[$i][4])"
				Tag     = $($Global:AvailableLanguages[$i][2])
			}

			if ($SelectLXPsLanguage -eq $Global:AvailableLanguages[$i][2]) {
				$CheckBox.Checked = $True
			} else {
				$CheckBox.Checked = $False
			}

			$UI_Main_Available_Languages_Select.controls.AddRange($CheckBox)
		}
	}

	<#
		.Event: canceled
		.事件：取消
	#>
	$UI_Main_Canel_Click = {
		$UI_Main.Close()
	}
	$UI_Main           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 928
		Text           = "$($lang.Language): $($lang.LanguageExtract)"
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}


	<#
		.Mask: Displays the rule details
		.蒙板：显示提取结果
	#>
	$UI_Main_View_Return = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 678
		Width          = 1006
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '0,0'
		Visible        = 0
	}
	$UI_Main_View_Return_Menu = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		Height         = 675
		Width          = 555
		autoSizeMode   = 1
		Location       = '20,0'
		Padding        = "0,20,0,0"
		autoScroll     = $True
	}
	
	<#
		.Search Key
		.匹配主键
	#>
	$UI_Main_Extract_Rule_Key_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		Text           = $lang.Pri_Key_Switch
	}
	$UI_Main_Extract_Rule_Key_Result = New-Object system.Windows.Forms.Label -Property @{
		autosize       = 1
		margin         = "20,0,0,0"
		Text           = ""
	}

	<#
		提取到标签
	#>
	$UI_Main_Extract_Rule_To_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		margin         = "0,35,0,0"
		Text           = $lang.LanguageExtractTo
	}
	$UI_Main_Extract_Rule_To_Result = New-Object system.Windows.Forms.Label -Property @{
		autosize       = 1
		Width          = 510
		margin         = "20,5,0,10"
		ForeColor      = "Green"
		Text           = "$($Global:MountTo)_Custom\Language"
	}
	$UI_Main_Extract_Rule_To_Open_Folder = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 30
		Width          = 530
		Padding        = "18,0,0,0"
		Text           = $lang.OpenFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Extract_Rule_To_Open_FolderClick
		Enabled        = $False
	}
	$UI_Main_Extract_Rule_To_Paste = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 30
		Width          = 530
		Padding        = "18,0,0,0"
		Text           = $lang.Paste
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Extract_Rule_To_PasteClick
		Enabled        = $False
	}

	<#
		.Search condition
		.匹配适用于所需的必备包
	#>
	$UI_Main_Extract_Rule_Need_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		margin         = "0,35,0,0"
		Text           = $lang.LanguageExtractCondition
	}
	$UI_Main_Extract_Rule_Need_Result = New-Object System.Windows.Forms.RichTextBox -Property @{
		Height         = 160
		Width          = 510
		margin         = "20,0,0,0"
		BorderStyle    = 0
		Text           = $lang.LanguageExtractConditionTips
	}

	<#
		.搜索结果
	#>
	$UI_Main_Extract_Rule_Have_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		margin         = "0,35,0,0"
		Text           = $lang.LanguageExtractSearchResult
	}
	$UI_Main_Extract_Rule_Have_Result = New-Object System.Windows.Forms.RichTextBox -Property @{
		Height         = 160
		Width          = 510
		margin         = "20,0,0,0"
		BorderStyle    = 0
		Text           = $lang.LanguageExtractSearchResultTips
	}

	<#
		.未找到结果
	#>
	$UI_Main_Extract_Rule_Not_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 530
		margin         = "0,35,0,0"
		Text           = $lang.LanguageExtractSearchResultNO
	}
	$UI_Main_Extract_Rule_Not_Result = New-Object System.Windows.Forms.RichTextBox -Property @{
		Height         = 160
		Width          = 510
		margin         = "20,0,0,0"
		BorderStyle    = 0
		Text           = ""
	}

	$UI_Main_View_Return_Wrap = New-Object system.Windows.Forms.Label -Property @{
		Height         = 35
		Width          = 530
	}

	<#
		.Note
		.注意
	#>
	$UI_Main_View_Return_Tips = New-Object System.Windows.Forms.RichTextBox -Property @{
		Height         = 500
		Width          = 275
		BorderStyle    = 0
		Location       = "620,20"
		Text           = $lang.Extract_Tips
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}

	$UI_Main_View_Return_Canel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$UI_Main_View_Return.Visible = $False
		}
	}

	<#
		.Mask: Displays the rule details
		.蒙板：显示规则详细信息
	#>
	$UI_Main_View_Detailed = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 678
		Width          = 1006
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '0,0'
		Visible        = 0
	}
	$UI_Main_View_Detailed_Show = New-Object System.Windows.Forms.RichTextBox -Property @{
		Height         = 600
		Width          = 880
		BorderStyle    = 0
		Location       = "15,15"
		Text           = ""
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}

	$UI_Main_View_Detailed_Canel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,635"
		Height         = 36
		Width          = 280
		add_Click      = $UI_Main_View_Detailed_Canel_Click
		Text           = $lang.Cancel
	}

	$UI_Main_Menu      = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		Height         = 675
		Width          = 555
		autoSizeMode   = 1
		Location       = '20,0'
		Padding        = "0,20,0,0"
		autoScroll     = $True
	}

	<#
		.选择规则
	#>
	$UI_Main_Extract_Rule_Name = New-Object system.Windows.Forms.Label -Property @{
		Location       = "10,10"
		Height         = 28
		Width          = 530
		Text           = $lang.LanguageExtractRuleFilter
	}
	$UI_Main_Extract_Pre_Rule = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 460
		Text           = $lang.RulePre
	}
	$UI_Main_Extract_Other_Rule = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 460
		Margin         = "0,15,0,0"
		Text           = $lang.RuleOther
	}
	$UI_Main_Extract_Customize_Rule = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 460
		Margin         = "0,15,0,0"
		Text           = $lang.RuleCustomize
	}
	$UI_Main_Extract_Customize_Rule_Tips_Not = New-Object system.Windows.Forms.Label -Property @{
		autosize       = 1
		Padding        = "18,0,0,0"
		Text           = $lang.RuleCustomizeNot
	}
	$UI_Main_Extract_Customize_Rule_Tips = New-Object system.Windows.Forms.Label -Property @{
		autosize       = 1
		Padding        = "18,0,0,0"
		Text           = $lang.RuleCustomizeTips
	}
	$UI_Main_Extract_Rule_Select_Sourcest = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		autosize       = 1
		BorderStyle    = 0
		autoSizeMode   = 1
		autoScroll     = $true
		Padding        = "16,0,0,0"
		margin         = "0,0,0,40"
	}

	<#
		.选择主键
	#>
	$UI_Main_Extract_Select_WIM_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 530
		Text           = $lang.LanguageExtractRule
	}
	$UI_Main_Extract_Select_WIM = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		autosize       = 1
		BorderStyle    = 0
		autoSizeMode   = 1
		Padding        = "18,0,0,0"
		autoScroll     = $False
		margin         = "0,0,0,40"
	}

	<#
		.选择保存到
	#>
	$UI_Main_Extract_Save_To_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 530
		Text           = $lang.SaveTo
	}
	$UI_Main_Extract_Save_To_Select = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		autosize       = 1
		BorderStyle    = 0
		autoSizeMode   = 1
		Padding        = "18,0,0,0"
		autoScroll     = $False
		margin         = "0,0,0,40"
	}
	$UI_Main_Extract_Save_To_Add = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 35
		Width          = 500
		Text           = $lang.AddTo
		Tag            = "Add"
	}
	$UI_Main_Extract_Save_To_Del = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 35
		Width          = 500
		Text           = $lang.Del
		Tag            = "Del"
	}

	<#
		.选择语言
	#>
	$UI_Main_Available_Languages_Name = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 300
		Text           = $lang.AvailableLanguages
	}
	$UI_Main_Available_Languages_Select = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 400
		Width          = 525
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "15,0,8,0"
	}
	$UI_Main_Available_Languages_Unlock = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 30
		Width          = 500
		Padding        = "16,10,10,0"
		Text           = $lang.SwitchLanguageHide
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Available_Languages_Unlock_Click
	}

	<#
		.提取规则
	#>
	$UI_Main_Extract_Rule_ADV = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 530
		margin         = "0,35,0,0"
		Text           = $lang.AdvOption
	}
	$UI_Main_Extract_Rule_Exclude_EN_US = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 530
		Padding        = "18,0,0,0"
		Text           = $lang.LEPSkipAddEnglish
		Checked        = $True
		Enabled	       = $True
	}
	$UI_Main_Extract_Rule_Exclude_EN_US_Tips = New-Object system.Windows.Forms.Label -Property @{
		autosize       = 1
		Padding        = "33,0,0,0"
		Text           = $lang.LEPSkipAddEnglishTips
	}
	$UI_Main_Menu_Wrap = New-Object system.Windows.Forms.Label -Property @{
		Height         = 45
		Width          = 530
	}

	$UI_Main_Extract_Search = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Height         = 36
		Width          = 280
		Location       = "620,10"
		add_Click      = { Language_Extract_Add_View -Mode "Search" }
		Text           = $lang.LanguageExtractSearch
	}
	$UI_Main_Extract_Import = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Height         = 36
		Width          = 280
		Location       = "620,50"
		add_Click      = { Language_Extract_Add_View -Mode "Import" }
		Text           = $lang.LanguageExtractAddTo
	}
	$UI_Main_Extract_Delete_Duplicate = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 280
		Location       = "622,105"
		Text           = $lang.ImportCleanDuplicate
		Checked        = $True
	}
	
	<#
		.查看历史记录
	#>
	$UI_Main_Extract_View = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 30
		Width          = 500
		Location       = "620,140"
		Text           = $lang.SwitchLanguageHide
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		Visible        = $False
		add_Click      = {
			$UI_Main_View_Return.Visible = $True
		}
	}

	$UI_Main_Error     = New-Object system.Windows.Forms.Label -Property @{
		Height         = 36
		Width          = 280
		Location       = "620,595"
		Text           = ""
	}
	$UI_Main_Canel     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Height         = 36
		Width          = 280
		Location       = "620,635"
		add_Click      = $UI_Main_Canel_Click
		Text           = $lang.Cancel
	}
	$UI_Main.controls.AddRange((
		$UI_Main_View_Return,
		$UI_Main_View_Detailed,
		$UI_Main_Menu,
		$UI_Main_Extract_Search,
		$UI_Main_Extract_Import,
		$UI_Main_Extract_Delete_Duplicate,
		$UI_Main_Extract_View,
		$UI_Main_Error,
		$UI_Main_Canel
	))
	$UI_Main_View_Detailed.controls.AddRange((
		$UI_Main_View_Detailed_Show,
		$UI_Main_View_Detailed_Canel
	))
	$UI_Main_Menu.controls.AddRange((
		<#
			.选择规则
		#>
		$UI_Main_Extract_Rule_Name,
		$UI_Main_Extract_Rule_Select_Sourcest,

		<#
			.选择适用于 install.wim 或 boot.wim
		#>
		$UI_Main_Extract_Select_WIM_Name,
		$UI_Main_Extract_Select_WIM,

		<#
			.选择保存到
		#>
		$UI_Main_Extract_Save_To_Name,
		$UI_Main_Extract_Save_To_Select,

		<#
			.选择语言
		#>
		$UI_Main_Available_Languages_Name,
		$UI_Main_Available_Languages_Select,
		$UI_Main_Available_Languages_Unlock,

		<#
			.其它选项
		#>
		$UI_Main_Extract_Rule_ADV,
		$UI_Main_Extract_Rule_Exclude_EN_US,
		$UI_Main_Extract_Rule_Exclude_EN_US_Tips,
		$UI_Main_Menu_Wrap
	))

	$UI_Main_Extract_Save_To_Select.controls.AddRange((
		$UI_Main_Extract_Save_To_Add,
		$UI_Main_Extract_Save_To_Del
	))

	if ($Add) {
		$UI_Main_Extract_Save_To_Add.Checked = $True
	}

	if ($Del) {
		$UI_Main_Extract_Save_To_Del.Checked = $True
	}

	$UI_Main_View_Return.controls.AddRange((
		$UI_Main_View_Return_Menu,
		$UI_Main_View_Return_Tips,
		$UI_Main_View_Return_Canel
	))
	$UI_Main_View_Return_Menu.controls.AddRange((
		<#
			.Select key
			.已选择主键
		#>
		$UI_Main_Extract_Rule_Key_Name,
		$UI_Main_Extract_Rule_Key_Result,

		<#
			.提取到
		#>
		$UI_Main_Extract_Rule_To_Name,
		$UI_Main_Extract_Rule_To_Result,
		$UI_Main_Extract_Rule_To_Open_Folder,
		$UI_Main_Extract_Rule_To_Paste,

		<#
			.Search condition
			.匹配适用于所需的必备包
		#>
		$UI_Main_Extract_Rule_Need_Name,
		$UI_Main_Extract_Rule_Need_Result,

		<#
			.搜索结果
		#>
		$UI_Main_Extract_Rule_Have_Name,
		$UI_Main_Extract_Rule_Have_Result,

		<#
			.未找到结果
		#>
		$UI_Main_Extract_Rule_Not_Name,
		$UI_Main_Extract_Rule_Not_Result,
		$UI_Main_View_Return_Wrap
	))

	<#
		.获取语言列表并初始化选择
	#>
	if (-not (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -Name 'Add_List' -ErrorAction SilentlyContinue)) {
		$DeployinboxGetSources = $False
		$DeployinboxGetSourcesOnly = @()

		for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
			if (Test-Path "$($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])" -PathType Container) {
				if((Get-ChildItem "$($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])" -Recurse -ErrorAction SilentlyContinue | Measure-Object).Count -gt 0) {
					$DeployinboxGetSources = $True
					$DeployinboxGetSourcesOnly += $($Global:AvailableLanguages[$i][2])
				}
			}
		}

		if ($DeployinboxGetSources) {
			Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -name "Add_List" -value $DeployinboxGetSourcesOnly -Multi
		} else {
			Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -name "Add_List" -value "" -Multi
		}
	}
	$GetSelectLXPsLanguage = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -Name "Add_List"

	$SelectLXPsLanguage = @()
	ForEach ($item in $GetSelectLXPsLanguage) {
		$SelectLXPsLanguage += $item
	}

	for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
		if ($Global:AvailableLanguages[$i][0] -eq "1") {
			$CheckBox   = New-Object System.Windows.Forms.CheckBox -Property @{
				Height  = 35
				Width   = 485
				Text    = "$($Global:AvailableLanguages[$i][2].PadRight(45)) $($Global:AvailableLanguages[$i][4])"
				Tag     = $($Global:AvailableLanguages[$i][2])
			}

			if ($SelectLXPsLanguage -eq $Global:AvailableLanguages[$i][2]) {
				$CheckBox.Checked = $True
			} else {
				$CheckBox.Checked = $False
			}

			$UI_Main_Available_Languages_Select.controls.AddRange($CheckBox)
		}
	}

	<#
		.选择全局唯一规则 GUID
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -Name "SelectGUID" -ErrorAction SilentlyContinue) {
		$GetDefaultSelectLabel = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Language" -Name "SelectGUID" 	-ErrorAction SilentlyContinue
	} else {
		$GetDefaultSelectLabel = ""
	}

	<#
		.添加规则：预置规则
	#>
	$UI_Main_Extract_Rule_Select_Sourcest.controls.AddRange($UI_Main_Extract_Pre_Rule)
	ForEach ($item in $Global:Pre_Config_Rules) {
		$CheckBox     = New-Object System.Windows.Forms.RadioButton -Property @{
			Height    = 28
			Width     = 460
			Padding   = "18,0,0,0"
			Text      = $item.Name
			Tag       = $item.GUID
		}

		$UI_Main_Rule_Details_View = New-Object system.Windows.Forms.LinkLabel -Property @{
			Height         = 28
			Width          = 460
			Padding        = "36,0,0,0"
			Margin         = "0,0,0,5"
			Text           = $lang.Detailed_View
			Tag            = $item.GUID
			LinkColor      = "GREEN"
			ActiveLinkColor = "RED"
			LinkBehavior   = "NeverUnderline"
			add_Click      = ({
				Language_Add_Rule_Details_View -GUID $this.Tag
			})
		}
	
		if ($GetDefaultSelectLabel -eq $item.GUID) {
			$CheckBox.Checked = $True
		}

		$UI_Main_Extract_Rule_Select_Sourcest.controls.AddRange((
			$CheckBox,
			$UI_Main_Rule_Details_View
		))
	}

	<#
		.添加规则：预置规则
	#>
	$UI_Main_Extract_Rule_Select_Sourcest.controls.AddRange($UI_Main_Extract_Other_Rule)
	ForEach ($item in $Global:Preconfigured_Rule_Language) {
		$CheckBox     = New-Object System.Windows.Forms.RadioButton -Property @{
			Height    = 28
			Width     = 460
			Padding   = "18,0,0,0"
			Text      = $item.Name
			Tag       = $item.GUID
		}

		$UI_Main_Rule_Details_View = New-Object system.Windows.Forms.LinkLabel -Property @{
			Height         = 28
			Width          = 460
			Padding        = "36,0,0,0"
			Margin         = "0,0,0,5"
			Text           = $lang.Detailed_View
			Tag            = $item.GUID
			LinkColor      = "GREEN"
			ActiveLinkColor = "RED"
			LinkBehavior   = "NeverUnderline"
			add_Click      = ({
				Language_Add_Rule_Details_View -GUID $this.Tag
			})
		}

		if ($GetDefaultSelectLabel -eq $item.GUID) {
			$CheckBox.Checked = $True
		}

		$UI_Main_Extract_Rule_Select_Sourcest.controls.AddRange((
			$CheckBox,
			$UI_Main_Rule_Details_View
		))
	}

	<#
		.添加规则，自定义
	#>
	$UI_Main_Extract_Rule_Select_Sourcest.controls.AddRange($UI_Main_Extract_Customize_Rule)
	if (Is_Find_Modules -Name "Solutions.Custom.Extension") {
		if ($Global:Custom_Rule_Language.count -gt 0) {
			ForEach ($item in $Global:Custom_Rule_Language) {
				$CheckBox     = New-Object System.Windows.Forms.RadioButton -Property @{
					Height    = 28
					Width     = 460
					Padding   = "18,0,0,0"
					Text      = $item.Name
					Tag       = $item.GUID
				}

				if ($GetDefaultSelectLabel -eq $item.GUID) {
					$CheckBox.Checked = $True
				}

				$UI_Main_Rule_Details_View = New-Object system.Windows.Forms.LinkLabel -Property @{
					Height         = 28
					Width          = 460
					Padding        = "36,0,0,0"
					Margin         = "0,0,0,5"
					Text           = $lang.Detailed_View
					Tag            = $item.GUID
					LinkColor      = "GREEN"
					ActiveLinkColor = "RED"
					LinkBehavior   = "NeverUnderline"
					add_Click      = ({
						Language_Add_Rule_Details_View -GUID $this.Tag
					})
				}

				$UI_Main_Extract_Rule_Select_Sourcest.controls.AddRange((
					$CheckBox,
					$UI_Main_Rule_Details_View
				))
			}
		} else {
			$UI_Main_Extract_Rule_Select_Sourcest.controls.AddRange($UI_Main_Extract_Customize_Rule_Tips)
		}
	} else {
		$UI_Main_Extract_Rule_Select_Sourcest.controls.AddRange($UI_Main_Extract_Customize_Rule_Tips_Not)
	}

	<#
		.当前默认是英文，启用跳过添加 en-US
	#>
	if ($Global:MainImageLang -eq "en-US") {
		$UI_Main_Extract_Rule_Exclude_EN_US.Checked = $True
	} else {
		$UI_Main_Extract_Rule_Exclude_EN_US.Checked = $False
	}

	ForEach ($item in $Global:Image_Rule) {
		if ($item.Main.Suffix -eq "wim") {
			$New_Main      = New-Object System.Windows.Forms.CheckBox -Property @{
				Height     = 30
				Width      = 435
				Text       = $item.Main.ImageFileName
				Tag        = "$($item.Main.ImageFileName);$($item.Main.ImageFileName);"
				add_Click  = $OKArchitectureX86Click
			}

			if ($Global:Primary_Key_Image.Uid -eq $item.Main.Uid) {
				$New_Main.Checked = $True
			}

			$UI_Main_Extract_Select_WIM.Controls.AddRange($New_Main)

			if ($item.Expand.Count -gt 0) {
				ForEach ($itemExpandNew in $item.Expand) {
					$Temp_Main_Save_Expand_Name = New-Object System.Windows.Forms.CheckBox -Property @{
						Height     = 35
						Width      = 435
						Padding    = "20,0,0,0"
						Text       = $itemExpandNew.ImageFileName
						Tag        = "$($item.Main.ImageFileName);$($itemExpandNew.ImageFileName);"
					}

					if ($Global:Primary_Key_Image.Uid -eq $itemExpandNew.Uid) {
						$Temp_Main_Save_Expand_Name.Checked = $True
					}

					$UI_Main_Extract_Select_WIM.Controls.AddRange($Temp_Main_Save_Expand_Name)
				}
			}
		}
	}

	Language_Add_Refresh_Folder_Sources

	<#
		.Add right-click menu: select all, clear button, Select Key
		.添加右键菜单：全选、清除按钮，选择主键
	#>
	$UI_Main_WIM_Menu_Select = New-Object System.Windows.Forms.ContextMenuStrip
	$UI_Main_WIM_Menu_Select.Items.Add($lang.AllSel).add_Click({
		$UI_Main_Extract_Select_WIM.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	})
	$UI_Main_WIM_Menu_Select.Items.Add($lang.AllClear).add_Click({
		$UI_Main_Extract_Select_WIM.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	})
	$UI_Main_Extract_Select_WIM.ContextMenuStrip = $UI_Main_WIM_Menu_Select

	<#
		.Add right-click menu: select all, clear button
		.添加右键菜单：全选、清除按钮
	#>
	$UI_Main_Menu_Select = New-Object System.Windows.Forms.ContextMenuStrip
	$UI_Main_Menu_Select.Items.Add($lang.AllSel).add_Click({
		$UI_Main_Available_Languages_Select.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	})
	$UI_Main_Menu_Select.Items.Add($lang.AllClear).add_Click({
		$UI_Main_Available_Languages_Select.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	})
	$UI_Main_Available_Languages_Select.ContextMenuStrip = $UI_Main_Menu_Select

	if ($Global:EventQueueMode) {
		$UI_Main.Text = "$($UI_Main.Text) [ $($lang.QueueMode), $($lang.Event_Primary_Key)$($Global:Primary_Key_Image.Uid) ]"
	}

	<#
		.Allow open windows to be on top
		.允许打开的窗口后置顶
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
			"True" { $UI_Main.TopMost = $True }
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$UI_Main.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$UI_Main.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$UI_Main.FormBorderStyle = 'Fixed3D'
	$UI_Main.ShowDialog() | Out-Null
}