﻿<#
	.Menu: Language
	.菜单：语言
#>
Function Language_Menu
{
	if (-not $Global:EventQueueMode) {
		Logo -Title $($lang.Language)
		Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"

		Write-Host "   $($lang.MountImageTo)" -NoNewline
		if (Test-Path "$($Global:MountToRouting)" -PathType Container) {
			Write-Host " $($Global:MountToRouting)" -ForegroundColor Green
		} else {
			Write-Host " $($Global:MountToRouting)" -ForegroundColor Yellow
		}

		Write-Host "   $($lang.MainImageFolder)" -NoNewline
		if (Test-Path "$($Global:MountTo)" -PathType Container) {
			Write-Host " $($Global:MountTo)" -ForegroundColor Green
		} else {
			Write-Host " $($Global:MountTo)" -ForegroundColor Red
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.NoInstallImage)" -ForegroundColor Red

			ToWait -wait 2
			Language_Menu
		}

		Image_Get_Mount_Status
	}

	Write-Host "`n   $($lang.Language)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	Write-Host "      E   $($lang.LanguageExtract)" -ForegroundColor Green

	if (Verify_Is_Current_Same) {
		Write-Host "      1   $($lang.AddTo)" -ForegroundColor Green
	} else {
		Write-Host "      1   $($lang.AddTo)" -ForegroundColor Red
	}
	if (Verify_Is_Current_Same) {
		Write-Host "      2   $($lang.Del)" -ForegroundColor Green
	} else {
		Write-Host "      2   $($lang.Del)" -ForegroundColor Red
	}

	if (Verify_Is_Current_Same) {
		Write-Host "      3   $($lang.SwitchLanguage)" -ForegroundColor Green
	} else {
		Write-Host "      3   $($lang.SwitchLanguage)" -ForegroundColor Red
	}
	Write-Host ""

	if (Verify_Is_Current_Same) {
		Write-Host "      C   $($lang.OnlyLangCleanup)" -ForegroundColor Green
	} else {
		Write-Host "      C   $($lang.OnlyLangCleanup)" -ForegroundColor Red
	}

	if (Verify_Is_Current_Same) {
		if (Image_Is_Select_Boot) {
			Write-Host "      R   $($lang.LangIni)" -ForegroundColor Green
		} else {
			Write-Host "      R   $($lang.LangIni)" -ForegroundColor Red
		}
	} else {
		Write-Host "      R   $($lang.LangIni)" -ForegroundColor Red
	}

	if (Verify_Is_Current_Same) {
		Write-Host "      V   $($lang.ViewLanguage)" -ForegroundColor Green
	} else {
		Write-Host "      V   $($lang.ViewLanguage)" -ForegroundColor Red
	}

	Write-Host "`n   $($lang.GetImagePackage)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Green
		} else {
			Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Red
		}
	} else {
		Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Red
	}

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Green
		} else {
			Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Red
		}
	} else {
		Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Red
	}

	switch (Read-Host "`n   $($lang.Choose)")
	{
		'e' {
			Language_Extract_UI
			ToWait -wait 2
			Language_Menu
		}
		'1' {
			Write-Host "`n   $($lang.Language): $($lang.AddTo)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Image_Is_Select_IAB) {
				if (Verify_Is_Current_Same) {
					<#
						.Assign available tasks
						.分配可用的任务
					#>
					Event_Assign -Rule "Language_Add_UI" -Run
				} else {
					Write-Host "   $($lang.NotMounted)" -ForegroundColor Red
				}
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			
			ToWait -wait 2
			Language_Menu
		}
		'2' {
			Write-Host "`n   $($lang.Language): $($lang.Del)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Image_Is_Select_IAB) {
				if (Verify_Is_Current_Same) {
					<#
						.Assign available tasks
						.分配可用的任务
					#>
					Event_Assign -Rule "Language_Delete_UI" -Run
				} else {
					Write-Host "   $($lang.NotMounted)" -ForegroundColor Red
				}
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			
			ToWait -wait 2
			Language_Menu
		}
		'3' {
			Write-Host "`n   $($lang.SwitchLanguage)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Image_Is_Select_IAB) {
				if (Verify_Is_Current_Same) {
					<#
						.Assign available tasks
						.分配可用的任务
					#>
					Event_Assign -Rule "Language_Change_UI" -Run
				} else {
					Write-Host "   $($lang.NotMounted)" -ForegroundColor Red
				}
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			
			ToWait -wait 2
			Language_Menu
		}
		'c' {
			Write-Host "`n   $($lang.OnlyLangCleanup)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Verify_Is_Current_Same) {
				<#
					.Assign available tasks
					.分配可用的任务
				#>
				Event_Assign -Rule "Language_Cleanup_Components_UI" -Run
			} else {
				Write-Host "   $($lang.NotMounted)" -ForegroundColor Red
			}
			
			ToWait -wait 2
			Language_Menu
		}
		'r' {
			Write-Host "`n   $($lang.LangIni)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Verify_Is_Current_Same) {
				if (Image_Is_Select_Boot) {
					Language_Refresh_Ini
				} else {
					Write-Host "   $($lang.BootProcess -f "boot")" -ForegroundColor Red
				}
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			
			ToWait -wait 2
			Language_Menu
		}
		"v" {
			Write-Host "`n   $($lang.ViewLanguage)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Image_Is_Select_IAB) {
				if (Verify_Is_Current_Same) {
					if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
						Write-Host "`n   $($lang.Command)" -ForegroundColor Green
						Write-host "   $($lang.Developers_Mode_Location)65" -ForegroundColor Green
						Write-host "   $('-' * 80)"
						write-host "   Dism.exe /Image:""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"" /Get-Intl" -ForegroundColor Green
						Write-host "   $('-' * 80)`n"
					}
			
					start-process "Dism.exe" -ArgumentList "/Image:""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"" /Get-Intl" -wait -nonewwindow
					Get_Next
				} else {
					Write-Host "   $($lang.NotMounted)" -ForegroundColor Red
				}
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			
			ToWait -wait 2
			Language_Menu
		}
		'p' {
			Write-Host "`n   $($lang.GetImagePackage)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.ExportToLogs)" -ForegroundColor Yellow

			if (Image_Is_Select_IAB) {
				Image_Get_Components_Package
				Get_Next
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			
			ToWait -wait 2
			Language_Menu
		}
		's' {
			Write-Host "`n   $($lang.GetImagePackage)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.ExportToLogs)" -ForegroundColor Yellow

			if (Image_Is_Select_IAB) {
				Image_Get_Components_Package -View
				Get_Next
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			
			ToWait -wait 2
			Language_Menu
		}
		default {
			Mainpage
		}
	}
}

<#
	.同步语言包到安装程序
#>
Function Language_Sync_To_ISO_Process
{
	if (-not $Global:EventQueueMode) {
		$Host.UI.RawUI.WindowTitle = $lang.BootSyncToISO
	}

	for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
		if (Test-Path -Path "$($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])" -PathType Container) {
			TakeownFolder -path "$($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])"
			Write-Host "   $($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])"
			Write-Host "   $($lang.Del)".PadRight(28) -NoNewline
			Remove_Tree -Path "$($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])"
			Write-Host "   $($lang.Done)`n" -ForegroundColor Green
		}

		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\sources\$($Global:AvailableLanguages[$i][2])" -PathType Container) {
			Write-Host "   $($lang.Paste)"
			Write-Host "   > $($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\sources\$($Global:AvailableLanguages[$i][2])"
			Write-Host "   + $($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])"

			Copy-Item -Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\sources\$($Global:AvailableLanguages[$i][2])" -Destination "$($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])" -Recurse -Force -ErrorAction SilentlyContinue
			
			Write-Host "   $($lang.Done)`n" -ForegroundColor Green
		}
	}
}

<#
	.生成同步语言列表
#>
Function Language_Refresh_Ini
{
	if (-not $Global:EventQueueMode) {
		$Host.UI.RawUI.WindowTitle = $lang.LangIni
	}

	if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
		Write-Host "`n   $($lang.Command)" -ForegroundColor Green
		Write-host "   $($lang.Developers_Mode_Location)66" -ForegroundColor Green
		Write-host "   $('-' * 80)"
		write-host "   dism /image:""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"" /gen-langini /distribution:""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)""" -ForegroundColor Green
		Write-host "   $('-' * 80)`n"
	}

	dism /image:"""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)""" /gen-langini /distribution:"""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"""

	if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
		Write-Host "`n   $($lang.Command)" -ForegroundColor Green
		Write-host "   $($lang.Developers_Mode_Location)67" -ForegroundColor Green
		Write-host "   $('-' * 80)"
		write-host "   dism /image:""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"" /gen-langini /distribution:""$($Global:MountTo)""" -ForegroundColor Green
		Write-host "   $('-' * 80)`n"
	}

	dism /image:"""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)""" /gen-langini /distribution:"""$($Global:MountTo)"""
}