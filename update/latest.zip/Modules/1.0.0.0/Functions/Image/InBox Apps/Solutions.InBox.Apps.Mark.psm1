﻿<#
	.Mark: Language Experience Pack ( LXPs )
	.标记：本地语言体验包 ( LXPs )
#>
Function InBox_Apps_Mark_UI
{
	if (-not $Global:EventQueueMode) {
		Logo -Title $($lang.StepOne)
		Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"

		Write-Host "   $($lang.MountImageTo)" -NoNewline
		Write-Host " $($Global:MountToRouting)" -ForegroundColor Yellow

		Write-Host "   $($lang.MainImageFolder)" -NoNewline
		Write-Host " $($Global:MountTo)" -NoNewline -ForegroundColor Yellow
		if (Test-Path "$($Global:MountTo)" -PathType Container) {
			Write-Host " $($lang.ImageLoaded)" -ForegroundColor Green
		} else {
			Write-Host " $($lang.NotMounted)" -ForegroundColor Red
			ToMainpage -wait 2
		}
		Image_Get_Mount_Status
	}

	Write-Host "`n   $($lang.StepOne)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	$Script:InBox_Apps_Select_Add_Sources = ""

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	<#
		.事件：强行结束按需任务
	#>
	$UI_Main_Suggestion_Stop_Click = {
		$UI_Main.Hide()
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		Event_Reset_Variable
		$UI_Main.Close()
	}

	Function LXPs_Refresh_Sources_To_Status
	{
		$UI_Main_Mask_Report_Error.Text = ""
		$RandomGuid = [guid]::NewGuid()
		$InitalReportSources = $UI_Main_Mask_Report_Sources_Path.Text
		$DesktopOldpath = [Environment]::GetFolderPath("Desktop")

		if (Test-Path -Path "$($InitalReportSources)" -PathType Container) {
			if (Test_Available_Disk -Path $InitalReportSources) {
				$UI_Main_Mask_Report_Sources_Open_Folder.Enabled = $True
				$UI_Main_Mask_Report_Sources_Paste.Enabled = $True
				$UI_Main_Mask_Report_Save_To.Text = "$($InitalReportSources)\Report.$($RandomGuid).csv"
			} else {
				$UI_Main_Mask_Report_Sources_Open_Folder.Enabled = $False
				$UI_Main_Mask_Report_Sources_Paste.Enabled = $False
				$UI_Main_Mask_Report_Save_To.Text = "$($DesktopOldpath)\Report.$($RandomGuid).csv"
			}
		} else {
			$UI_Main_Mask_Report_Sources_Open_Folder.Enabled = $False
			$UI_Main_Mask_Report_Sources_Paste.Enabled = $False
			$UI_Main_Mask_Report_Save_To.Text = "$($DesktopOldpath)\Report.$($RandomGuid).csv"
		}
	}

	$UI_Main           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 928
		Text           = "$($lang.StepOne)"
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}
	
	$UI_Main_Menu      = New-Object System.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		Height         = 620
		Width          = 555
		autoSizeMode   = 1
		Location       = '20,0'
		Padding        = "0,15,0,0"
		autoScroll     = $True
	}
	$UI_Main_Other_Rule = New-Object system.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 500
		Text           = $lang.RuleOther
	}
	$UI_Main_Select_LXPs = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 310
		Width          = 500
		Padding        = "16,0,0,0"
		margin         = "0,0,0,30"
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
	}

	<#
		.显示提示蒙层
	#>
	$UI_Main_Mask_Tips = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 760
		Width          = 928
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '0,0'
		Visible        = 0
	}
	$UI_Main_Mask_Tips_Results = New-Object System.Windows.Forms.RichTextBox -Property @{
		Height         = 555
		Width          = 885
		BorderStyle    = 0
		Location       = "15,15"
		Text           = $lang.RemoveAllUWPTips
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}
	$UI_Main_Mask_Tips_Global_Do_Not = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "20,607"
		Height         = 25
		Width          = 440
		Text           = $lang.LXPsAddDelTipsGlobal
		add_Click      = {
			if ($UI_Main_Mask_Tips_Global_Do_Not.Checked) {
				Save_Dynamic -regkey "Solutions" -name "TipsWarningUWPGlobal" -value "True" -String
				$UI_Main_Mask_Tips_Do_Not.Enabled = $False
			} else {
				Save_Dynamic -regkey "Solutions" -name "TipsWarningUWPGlobal" -value "False" -String
				$UI_Main_Mask_Tips_Do_Not.Enabled = $True
			}
	}
	}
	$UI_Main_Mask_Tips_Do_Not = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "20,635"
		Height         = 25
		Width          = 440
		Text           = $lang.LXPsAddDelTips
		add_Click      = {
			if ($UI_Main_Mask_Tips_Do_Not.Checked) {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\InBox" -name "TipsWarningUWP" -value "True" -String
			} else {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\InBox" -name "TipsWarningUWP" -value "False" -String
			}
		}
	}
	$UI_Main_Mask_Tips_Canel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$UI_Main_Mask_Tips.Visible = 0
		}
	}

	$UI_Main_Is_Install_LXPs = New-Object System.Windows.Forms.Checkbox -Property @{
		Height         = 25
		Width          = 500
		Text           = $lang.ForceRemovaAllUWP
		add_Click      = {
			if ($UI_Main_Is_Install_LXPs.Checked) {
				$UI_Main_Select_LXPs.Enabled = $False
				$UI_Main_Select_Folder.Enabled = $False
			} else {
				$UI_Main_Select_LXPs.Enabled = $True
				$UI_Main_Select_Folder.Enabled = $True
			}
		}
	}
	$UI_Main_Skip_English = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 500
		Text           = $lang.LEPSkipAddEnglish
		Checked        = $True
	}
	$UI_Main_Skip_English_Tips = New-Object system.Windows.Forms.Label -Property @{
		autosize       = 1
		Padding        = "18,0,8,0"
		Margin         = "0,0,0,25"
		Text           = $lang.LEPSkipAddEnglishTips
	}

	<#
		.安装前的方式
	#>
	$UI_Main_InBox_Apps_Install_Type = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 500
		Text           = $lang.LEPBrandNew
	}
	$UI_Main_InBox_Apps_Clear = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 500
		Padding        = "18,0,0,0"
		Text           = $lang.InboxAppsClear
		Checked        = $True
	}
	$UI_Main_InBox_Apps_Clear_Rule = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 500
		Padding        = "35,0,0,0"
		Text           = $lang.ExcludeItem
		Checked        = $True
	}
	$UI_Main_InBox_Apps_Clear_Rule_View = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 25
		Width          = 500
		Padding        = "54,0,0,0"
		Text           = $lang.Exclude_View
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$UI_Main_View_Detailed.Visible = $True
			$UI_Main_View_Detailed_Show.Text = ""

			$UI_Main_View_Detailed_Show.Text += "   $($lang.ExcludeItem)`n"
			$custom_array = @()
			ForEach ($item in $Global:ExcludeUWPDeletedItems) {
				$UI_Main_View_Detailed_Show.Text += "       $($item)`n"
			}
		}
	}

	$UI_Main_Tips_New  = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 470
		Text           = $lang.LXPsAddDelTipsView
		Location       = "31,640"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$UI_Main_Mask_Tips.Visible = 1
		}
	}

	<#
		.Mask: Displays the rule details
		.蒙板：显示规则详细信息
	#>
	$UI_Main_View_Detailed = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 678
		Width          = 1006
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '0,0'
		Visible        = 0
	}
	$UI_Main_View_Detailed_Show = New-Object System.Windows.Forms.RichTextBox -Property @{
		Height         = 600
		Width          = 880
		BorderStyle    = 0
		Location       = "15,15"
		Text           = ""
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}
	$UI_Main_View_Detailed_Canel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$UI_Main_View_Detailed.Visible = $False
		}
	}

	<#
		.End on-demand mode
		.结束按需模式
	#>
	$UI_Main_Suggestion_Manage = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignSetting
		Location       = '620,395'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Event_Assign_Setting }
	}
	$UI_Main_Suggestion_Stop_Current = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.AssignEndCurrent -f "$($Global:Primary_Key_Image.Master);$($Global:Primary_Key_Image.ImageFileName)")"
		Location       = '620,425'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$UI_Main.Hide()
			Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
			Event_Need_Mount_Global_Variable -DevQueue "15" -Master $Global:Primary_Key_Image.Master -ImageFileName $Global:Primary_Key_Image.ImageFileName
			Event_Reset_Suggest
			$UI_Main.Close()
		}
	}
	$UI_Main_Event_Assign_Stop = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignForceEnd
		Location       = '620,455'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Suggestion_Stop_Click
	}

	<#
		.Suggested content
		.建议的内容
	#>
	$UI_Main_Suggestion_Not = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 430
		Text           = $lang.SuggestedSkip
		Location       = '620,395'
		add_Click      = {
			if ($UI_Main_Suggestion_Not.Checked) {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -name "IsSuggested" -value "True" -String
				$UI_Main_Suggestion_Setting.Enabled = $False
				$UI_Main_Suggestion_Stop.Enabled = $False
			} else {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -name "IsSuggested" -value "False" -String
				$UI_Main_Suggestion_Setting.Enabled = $True
				$UI_Main_Suggestion_Stop.Enabled = $True
			}
		}
	}
	$UI_Main_Suggestion_Setting = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignSetting
		Location       = '636,426'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Event_Assign_Setting }
	}
	$UI_Main_Suggestion_Stop = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 280
		Text           = $lang.AssignForceEnd
		Location       = '636,455'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Suggestion_Stop_Click
	}

	<#
		.Displays the report mask
		.显示报告蒙层
	#>
	$UI_Main_Mask_Report = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 760
		Width          = 1025
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '0,0'
		Visible        = 0
	}
	$UI_Main_Mask_Report_Menu = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 665
		Width          = 530
		Padding        = "8,0,8,0"
		Location       = "15,10"
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
	}
	$UI_Main_Mask_Report_Sources_Name = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 480
		Text           = $lang.AdvAppsDetailed
	}
	$UI_Main_Mask_Report_Sources_Name_Tips = New-Object system.Windows.Forms.Label -Property @{
		autoSize       = 1
		Padding        = "16,0,0,0"
		margin         = "0,0,0,20"
		Text           = $lang.AdvAppsDetailedTips
	}

	$UI_Main_Mask_Report_Sources_Path_Name = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 480
		Text           = $lang.ProcessSources
	}
	$UI_Main_Mask_Report_Sources_Path = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 22
		Width          = 450
		margin         = "18,5,0,15"
		Text           = ""
		ReadOnly       = $True
	}
	$UI_Main_Mask_Report_Sources_Select_Folder = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 480
		Padding        = "16,0,0,0"
		Text           = $lang.SelectFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$RandomGuid = [guid]::NewGuid()
			$DesktopOldpath = [Environment]::GetFolderPath("Desktop")
			$UI_Main_Mask_Report_Error.Text = ""
	
			$FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{
				RootFolder = "MyComputer"
			}
	
			if ($FolderBrowser.ShowDialog() -eq "OK") {
				$InitalReportSources = (Join_MainFolder -Path $FolderBrowser.SelectedPath)
				$UI_Main_Mask_Report_Sources_Path.Text = $InitalReportSources
				
				if (Test-Path -Path "$($InitalReportSources)" -PathType Container) {
					if (Test_Available_Disk -Path $InitalReportSources) {
						$UI_Main_Mask_Report_Save_To.Text = "$($InitalReportSources)Report.$($RandomGuid).csv"
					} else {
						$UI_Main_Mask_Report_Save_To.Text = "$($DesktopOldpath)\Report.$($RandomGuid).csv"
					}
	
					LXPs_Refresh_Sources_To_Status
				} else {
					$UI_Main_Mask_Report_Save_To.Text = "$($DesktopOldpath)\Report.$($RandomGuid).csv"
				}
			} else {
				$UI_Main_Mask_Report_Error.Text = "$($lang.UserCancel)"
			}
		}
	}
	$UI_Main_Mask_Report_Sources_Open_Folder = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 480
		Padding        = "16,0,0,0"
		Text           = $lang.OpenFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($UI_Main_Mask_Report_Sources_Path.Text)) {
				if (Test-Path $UI_Main_Mask_Report_Sources_Path.Text -PathType Container) {
					Start-Process $UI_Main_Mask_Report_Sources_Path.Text
				}
			}
		}
	}
	$UI_Main_Mask_Report_Sources_Paste = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 480
		Padding        = "16,0,0,0"
		Text           = $lang.Paste
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($UI_Main_Mask_Report_Sources_Path.Text)) {
				Set-Clipboard -Value $UI_Main_Mask_Report_Sources_Path.Text
			}
		}
	}

	<#
		.The report is saved to
		.报告保存到
	#>
	$UI_Main_Mask_Report_Save_To_Name = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 480
		margin         = "0,30,0,0"
		Text           = $lang.SaveTo
	}
	$UI_Main_Mask_Report_Save_To = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 22
		Width          = 450
		margin         = "20,5,0,15"
		Text           = ""
		ReadOnly       = $True
	}
	$UI_Main_Mask_Report_Select_Folder = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 480
		Padding        = "16,0,0,0"
		Text           = $lang.SelectFolder
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$RandomGuid = [guid]::NewGuid()

			$FileBrowser = New-Object System.Windows.Forms.SaveFileDialog -Property @{ 
				FileName = "Report.$($RandomGuid).csv"
				Filter   = "Export CSV Files (*.CSV;)|*.csv;"
			}

			if ($FileBrowser.ShowDialog() -eq "OK") {
				$UI_Main_Mask_Report_Save_To.Text = $FileBrowser.FileName
			} else {
				$UI_Main_Mask_Report_Error.Text = $($lang.UserCancel)
			}
		}
	}
	$UI_Main_Mask_Report_Paste = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 35
		Width          = 480
		Padding        = "16,0,0,0"
		Text           = $lang.Paste
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			if (-not [string]::IsNullOrEmpty($UI_Main_Mask_Report_Save_To.Text)) {
				Set-Clipboard -Value $UI_Main_Mask_Report_Save_To.Text
			}
		}
	}
	$UI_Main_Mask_Report_Error = New-Object system.Windows.Forms.Label -Property @{
		Location       = "620,565"
		Height         = 22
		Width          = 280
		Text           = ""
	}
	$UI_Main_Mask_Report_OK = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,595"
		Height         = 36
		Width          = 280
		Text           = $lang.OK
		add_Click      = {
			$MarkVerifyWrite = $False
			$InitalReportSources = $UI_Main_Mask_Report_Sources_Path.Text
			if (-not [string]::IsNullOrEmpty($InitalReportSources)) {
				if (Test-Path -Path "$($InitalReportSources)" -PathType Container) {
					$MarkVerifyWrite = $True
				}
			}

			if ($MarkVerifyWrite) {
				LXPs_Save_Report_Process -Path $UI_Main_Mask_Report_Sources_Path.Text -SaveTo $UI_Main_Mask_Report_Save_To.Text
				$UI_Main_Mask_Report.Visible = $False
			} else {
				$UI_Main_Mask_Report_Error.Text = $($lang.Inoperable)
			}
		}
	}
	$UI_Main_Mask_Report_Canel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$UI_Main_Mask_Report.visible = $False
		}
	}

	$UI_Main_Select_Folder = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,10"
		Height         = 36
		Width          = 280
		Text           = $lang.SelectFolder
		add_Click      = {
			if (-not (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\InBox" -Name "$(Get_GPS_Location)_SelectLXPsLanguage" -ErrorAction SilentlyContinue)) {
				$DeployinboxGetSources = $False
				$DeployinboxGetSourcesOnly = @()

				for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
					if (Test-Path "$($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])" -PathType Container) {
						if((Get-ChildItem "$($Global:MountTo)\sources\$($Global:AvailableLanguages[$i][2])" -Recurse -ErrorAction SilentlyContinue | Measure-Object).Count -gt 0) {
							$DeployinboxGetSources = $True
							$DeployinboxGetSourcesOnly += $($Global:AvailableLanguages[$i][2])
						}
					}
				}

				if ($DeployinboxGetSources) {
					Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\InBox" -name "$(Get_GPS_Location)_SelectLXPsLanguage" -value $DeployinboxGetSourcesOnly -Multi
				} else {
					Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\InBox" -name "$(Get_GPS_Location)_SelectLXPsLanguage" -value "" -Multi
				}
			}
			$GetSelectLXPsLanguage = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\InBox" -Name "$(Get_GPS_Location)_SelectLXPsLanguage"

			$SelectLXPsLanguage = @()
			ForEach ($item in $GetSelectLXPsLanguage) {
				$SelectLXPsLanguage += $item
			}

			<#
				.Initial browse directory
				.初始浏览目录
			#>
			$FolderBrowser   = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{
				RootFolder   = "MyComputer"
			}

			<#
				.Browse catalog: confirm
				.浏览目录：确认
			#>
			if ($FolderBrowser.ShowDialog() -eq "OK") {
				<#
					.Clear display area
					.清除显示区域
				#>
				$UI_Main_Select_LXPs.controls.Clear()

				$Script:InBox_Apps_Select_Add_Sources = $FolderBrowser.SelectedPath

				<#
					.Search whether the selected directory has: LanguageExperiencePack.*.appx
					.搜索已选择的目录是否有：LanguageExperiencePack.*.appx
				#>
				if (Test-Path "$($FolderBrowser.SelectedPath)\LocalExperiencePack" -PathType Container) {
					Get-ChildItem "$($FolderBrowser.SelectedPath)\LocalExperiencePack" -directory -ErrorAction SilentlyContinue | ForEach-Object {
						if (Test-Path "$($_.FullName)\LanguageExperiencePack.*.appx" -PathType Leaf) {
							$CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
								Height = 35
								Width  = 465
								Text   = $_.BaseName
								Tag    = $_.FullName
							}

							if ($SelectLXPsLanguage -eq $_.BaseName) {
								$CheckBox.Checked = $True
							} else {
								$CheckBox.Checked = $False
							}

							$UI_Main_Select_LXPs.controls.AddRange($CheckBox)
						}
					}
				} else {
					Get-ChildItem "$($FolderBrowser.SelectedPath)" -directory -ErrorAction SilentlyContinue | ForEach-Object {
						if (Test-Path "$($_.FullName)\LanguageExperiencePack.*.appx" -PathType Leaf) {
							$CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
								Height = 35
								Width  = 465
								Text   = $_.BaseName
								Tag    = $_.FullName
							}

							if ($SelectLXPsLanguage -eq $_.BaseName) {
								$CheckBox.Checked = $True
							} else {
								$CheckBox.Checked = $False
							}

							$UI_Main_Select_LXPs.controls.AddRange($CheckBox)
						}
					}
				}
			} else {
				$UI_Main_Error.Text = "$($lang.UserCanel)"
			}
		}
	}
	$UI_Main_Report    = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,50"
		Height         = 36
		Width          = 280
		Text           = $lang.AdvAppsDetailed
		add_Click      = {
			$UI_Main_Mask_Report_Error.Text = ""
			$InitalReportSources = $UI_Main_Save_To.Text

			$RandomGuid = [guid]::NewGuid()
			$UI_Main_Mask_Report_Error.Text = ""

			<#
				.Determine whether the save to is empty, if not, randomly generate a new save path
				.判断保存到是否为空，如果不为空则随机生成新的保存路径
			#>
			if ([string]::IsNullOrEmpty($InitalReportSources)) {
				$UI_Main_Mask_Report_Save_To.Text = "$($Global:MainMasterFolder)\$($Global:ImageType)\_Custom\InBox_Apps\Report.$($RandomGuid).csv"
				$UI_Main_Mask_Report_Sources_Path.Text = "$($Global:MainMasterFolder)\$($Global:ImageType)\_Custom\InBox_Apps"
			} else {
				<#
					.获取是否有添加源
				#>
				$UI_Main_Mask_Report_Sources_Path.Text = $Script:InBox_Apps_Select_Add_Sources
			}

			LXPs_Refresh_Sources_To_Status
			$UI_Main_Mask_Report.visible = $True
		}
	}
	$UI_Main_Error     = New-Object system.Windows.Forms.Label -Property @{
		Location       = '620,525'
		Height         = 60
		Width          = 280
		Text           = ""
	}
	$UI_Main_OK        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,595"
		Height         = 36
		Width          = 280
		Text           = $lang.Ok
		add_Click      = {
			<#
				.Reset selected
				.重置已选择
			#>
			New-Variable -Scope global -Name "Queue_Is_LXPs_Add_Step_One_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force
			New-Variable -Scope global -Name "Queue_Is_LXPs_Add_Step_One_Custom_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value @() -Force
			$Temp_Select_Experience_Pack_Queue = @()

			<#
				.Mark: Check the selection status
				.标记：检查选择状态
			#>
			$FlagCheckSelectStatus = $False

			if ($UI_Main_Is_Install_LXPs.Checked) {
				$FlagCheckSelectStatus = $True
			} else {
				$UI_Main_Select_LXPs.Controls | ForEach-Object {
					if ($_ -is [System.Windows.Forms.CheckBox]) {
						if ($_.Enabled) {
							if ($_.Checked) {
								$FlagCheckSelectStatus = $True
								$Temp_Select_Experience_Pack_Queue += @{
									Language = "$($_.Text)"
									Path     = "$($_.Tag)"
								}
							}
						}
					}
				}
			}

			<#
				.Verification mark: check selection status
				.验证标记：检查选择状态
			#>
			if ($FlagCheckSelectStatus) {
				$UI_Main.Hide()
				New-Variable -Scope global -Name "Queue_Is_LXPs_Add_Step_One_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $True -Force
				New-Variable -Scope global -Name "Queue_Is_LXPs_Add_Step_One_Custom_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $Temp_Select_Experience_Pack_Queue -Force

				<#
					.仅打印已选择的语言：短标签：例如 en-US
				#>
				$Temp_Save_Lxps_Queue_Print = @()
				ForEach ($item in $Temp_Select_Experience_Pack_Queue) {
					$Temp_Save_Lxps_Queue_Print += $item.Language
					Write-Host "   $($item.Language)".PadRight(20) -NoNewline
					Write-Host " $($item.Path)" -ForegroundColor Green
				}
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\InBox" -name "$(Get_GPS_Location)_SelectLXPsLanguage" -value $Temp_Save_Lxps_Queue_Print -Multi

				New-Variable -Scope global -Name "Queue_Is_InBox_Apps_Clear_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force
				New-Variable -Scope global -Name "Queue_Is_InBox_Apps_Clear_Allow_Rule_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force

				<#
					.Automatically search for missing packages from all disks
					.自动从所有磁盘搜索缺少的软件包
				#>
				Write-Host "`n   $($lang.InboxAppsClear)"
				if ($UI_Main_InBox_Apps_Clear.Checked) {
					Write-Host "   $($lang.Operable)" -ForegroundColor Green
					New-Variable -Scope global -Name "Queue_Is_InBox_Apps_Clear_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $True -Force

					Write-Host "`n   $($lang.ExcludeItem)" -ForegroundColor Yellow
					if ($UI_Main_InBox_Apps_Clear_Rule.Checked) {
						Write-Host "   $($lang.Operable)" -ForegroundColor Green
						New-Variable -Scope global -Name "Queue_Is_InBox_Apps_Clear_Allow_Rule_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $True -Force
					} else {
						Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
					}
				} else {
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
				}

				if ($UI_Main_Skip_English.Checked) {
					$Script:QueueExperiencePackNoEnglish = $True
				} else {
					$Script:QueueExperiencePackNoEnglish = $False
				}

				if ($UI_Main_Suggestion_Not.Checked) {
					Init_Canel_Event -All
				}
				$UI_Main.Close()
			} else {
				$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.NoChoose)"
			}
		}
	}
	$UI_Main_Canel     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "620,635"
		Height         = 36
		Width          = 280
		Text           = $lang.Cancel
		add_Click      = {
			$UI_Main.Hide()
			Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
			New-Variable -Scope global -Name "Queue_Is_LXPs_Add_Step_One_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force
			New-Variable -Scope global -Name "Queue_Is_InBox_Apps_Clear_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force
			New-Variable -Scope global -Name "Queue_Is_InBox_Apps_Clear_Allow_Rule_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force
			New-Variable -Scope global -Name "Queue_Is_LXPs_Add_Step_One_Custom_Select_$($item.Main.ImageFileName)" -Value @() -Force

			if ($UI_Main_Suggestion_Not.Checked) {
				Init_Canel_Event
			}
			$UI_Main.Close()
		}
	}
	$UI_Main.controls.AddRange((
		$UI_Main_View_Detailed,
		$UI_Main_Mask_Report,
		$UI_Main_Mask_Tips,
		$UI_Main_Menu,
		$UI_Main_Tips_New,
		$UI_Main_Select_Folder,
		$UI_Main_Report,
		$UI_Main_Error,
		$UI_Main_OK,
		$UI_Main_Canel
	))
	$UI_Main_View_Detailed.controls.AddRange((
		$UI_Main_View_Detailed_Show,
		$UI_Main_View_Detailed_Canel
	))
	$UI_Main_Mask_Tips.controls.AddRange((
		$UI_Main_Mask_Tips_Results,
		$UI_Main_Mask_Tips_Global_Do_Not,
		$UI_Main_Mask_Tips_Do_Not,
		$UI_Main_Mask_Tips_Canel
	))
	$UI_Main_Menu.controls.AddRange((
		$UI_Main_Other_Rule,	
		$UI_Main_Select_LXPs,
		$UI_Main_Is_Install_LXPs,
		$UI_Main_Skip_English,
		$UI_Main_Skip_English_Tips,
		$UI_Main_InBox_Apps_Install_Type,
		$UI_Main_InBox_Apps_Clear,
		$UI_Main_InBox_Apps_Clear_Rule,
		$UI_Main_InBox_Apps_Clear_Rule_View
	))
	<#
		.Mask, report
		.蒙板，报告
	#>
	$UI_Main_Mask_Report.controls.AddRange((
		$UI_Main_Mask_Report_Menu,
		$UI_Main_Mask_Report_Error,
		$UI_Main_Mask_Report_OK,
		$UI_Main_Mask_Report_Canel
	))
	$UI_Main_Mask_Report_Menu.controls.AddRange((
		$UI_Main_Mask_Report_Sources_Name,
		$UI_Main_Mask_Report_Sources_Name_Tips,
		$UI_Main_Mask_Report_Sources_Path_Name,
		$UI_Main_Mask_Report_Sources_Path,
		$UI_Main_Mask_Report_Sources_Select_Folder,
		$UI_Main_Mask_Report_Sources_Open_Folder,
		$UI_Main_Mask_Report_Sources_Paste,
		$UI_Main_Mask_Report_Save_To_Name,
		$UI_Main_Mask_Report_Save_To,
		$UI_Main_Mask_Report_Select_Folder,
		$UI_Main_Mask_Report_Paste
	))

	<#
		.遇到 映像源 类型为服务器级别时，不勾选：安装前强行删除已安装的所有预应用程序 ( UWP )
	#>
	if (($Global:ImageType) -eq "Server") {
		$UI_Main_InBox_Apps_Clear.Checked = $False
	}

	<#
		.提示
	#>
	$MarkShowNewTips = $False
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TipsWarningUWPGlobal" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TipsWarningUWPGlobal" -ErrorAction SilentlyContinue) {
			"True" {
				$MarkShowNewTips = $True
				$UI_Main_Mask_Tips_Global_Do_Not.Checked = $True
				$UI_Main_Mask_Tips_Do_Not.Enabled = $False
			}
			"False" {
				$UI_Main_Mask_Tips_Global_Do_Not.Checked = $False
				$UI_Main_Mask_Tips_Do_Not.Enabled = $True
			}
		}
	}
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\InBox" -Name "TipsWarningUWP" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Deploy\InBox" -Name "TipsWarningUWP" -ErrorAction SilentlyContinue) {
			"True" {
				$MarkShowNewTips = $True
				$UI_Main_Mask_Tips_Do_Not.Checked = $True
			}
			"False" {
				$UI_Main_Mask_Tips_Do_Not.Checked = $False
			}
		}
	}
	if ($MarkShowNewTips) {
		$UI_Main_Mask_Tips.Visible = 0
	} else {
		$UI_Main_Mask_Tips.Visible = 1
	}

	<#
		.Add right-click menu: select all, clear button
		.添加右键菜单：全选、清除按钮
	#>
	$GUILXPsSelectMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUILXPsSelectMenu.Items.Add($lang.AllSel).add_Click({
		$UI_Main_Select_LXPs.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { 
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	})
	$GUILXPsSelectMenu.Items.Add($lang.AllClear).add_Click({
		$UI_Main_Select_LXPs.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	})
	$UI_Main_Select_LXPs.ContextMenuStrip = $GUILXPsSelectMenu

	if ($Global:EventQueueMode) {
		$UI_Main.Text = "$($UI_Main.Text) [ $($lang.QueueMode), $($lang.Event_Primary_Key)$($Global:Primary_Key_Image.Uid) ]"
		$UI_Main.controls.AddRange((
			$UI_Main_Suggestion_Manage,
			$UI_Main_Suggestion_Stop_Current,
			$UI_Main_Event_Assign_Stop
		))
	} else {
		$UI_Main.Text = "$($UI_Main.Text) [ $($lang.Event_Primary_Key)$($Global:Primary_Key_Image.Uid) ]"

		<#
			.初始化复选框：不再建议
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
				"True" {
					$UI_Main_Suggestion_Not.Checked = $True
					$UI_Main_Suggestion_Setting.Enabled = $False
					$UI_Main_Suggestion_Stop.Enabled = $False
				}
				"False" {
					$UI_Main_Suggestion_Not.Checked = $False
					$UI_Main_Suggestion_Setting.Enabled = $True
					$UI_Main_Suggestion_Stop.Enabled = $True
				}
			}
		} else {
			$UI_Main_Suggestion_Not.Checked = $False
			$UI_Main_Suggestion_Setting.Enabled = $True
			$UI_Main_Suggestion_Stop.Enabled = $True
		}

		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
			if ((Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) -eq "True") {
				$UI_Main.controls.AddRange((
					$UI_Main_Suggestion_Not,
					$UI_Main_Suggestion_Setting,
					$UI_Main_Suggestion_Stop
				))
			}
		}
	}

	<#
		.Allow open windows to be on top
		.允许打开的窗口后置顶
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
			"True" { $UI_Main.TopMost = $True }
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$UI_Main.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		'de-DE' {
			$UI_Main_Is_Install_LXPs.Height = "35"
		}
		Default {
			$UI_Main.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$UI_Main.FormBorderStyle = 'Fixed3D'
	$UI_Main.ShowDialog() | Out-Null
}

<#
	.Clear all pre-installed applications in the image package
	.清除映像包里的所有预安装应用
#>
Function InBox_Apps_LIPs_Clean_Process
{
	<#
		.初始化，获取预安装 UWP 应用
	#>
	$InitlUWPPrePakcage = @()
	$InitlUWPPrePakcageExclude = @()
	$InitlUWPPrePakcageDelete = @()

	<#
		.判断挂载目录是否存在
	#>
	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			<#
				.从设置里判断是否允许排除规则
			#>
			if ((Get-Variable -Scope global -Name "Queue_Is_InBox_Apps_Clear_Allow_Rule_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -ErrorAction SilentlyContinue).Value) {
				ForEach ($item in $Global:ExcludeUWPDeletedItems) {
					$InitlUWPPrePakcageDelete += $item
				}
			}

			<#
				.输出当前所有排除规则
			#>
			Write-Host "`n   $($lang.ExcludeItem)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if ($InitlUWPPrePakcageDelete.count -gt 0) {
				ForEach ($item in $InitlUWPPrePakcageDelete) {
					Write-Host "   $($item)" -ForegroundColor Green
				}
			} else {
				Write-Host "   $($lang.NoWork)" -ForegroundColor Red
			}

			<#
				.获取所有已安装的 UWP 应用，并输出到数组
			#>
			Write-Host "`n   $($lang.GetImageUWP)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			try {
				Get-AppXProvisionedPackage -path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -ErrorAction SilentlyContinue | ForEach-Object {
					$InitlUWPPrePakcage += $_.PackageName
					Write-Host "   $($_.PackageName)" -ForegroundColor Green
				}
			} catch {
				Write-Host "   $($lang.SelectFromError)" -ForegroundColor Red
				Write-Host "   $($_)" -ForegroundColor Yellow
				Write-Host "   $($lang.GetImageUWP), $($lang.Inoperable)" -ForegroundColor Red
				return
			}

			<#
				.从排除规则获取需要排除的项目
			#>
			if ($InitlUWPPrePakcage.count -gt 0) {
				ForEach ($Item in $InitlUWPPrePakcage) {
					$WildCardMatches = ForEach ($WildCard in $InitlUWPPrePakcageDelete) {
						if ($item -like $WildCard) {
							$InitlUWPPrePakcageExclude += $item
						}
					}
				}

				Write-Host "`n   $($lang.ExcludeItem) ( $($InitlUWPPrePakcageExclude.count) ) $($lang.EventManagerCount)" -ForegroundColor Yellow
				Write-host "   $('-' * 80)"
				if ($InitlUWPPrePakcageExclude.count -gt 0) {
					ForEach ($item in $InitlUWPPrePakcageExclude) {
						Write-Host "   $($item)" -ForegroundColor Green
					}
				} else {
					Write-Host "   $($lang.NoWork)" -ForegroundColor Red
				}

				Write-Host "`n   $($lang.LXPsWaitRemove)" -ForegroundColor Green
				Write-host "   $('-' * 80)"
				ForEach ($item in $InitlUWPPrePakcage) {
					if (($InitlUWPPrePakcageExclude) -notContains $item) {
						if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
							Write-Host "`n   $($lang.Command)" -ForegroundColor Green
							Write-host "   $($lang.Developers_Mode_Location)57" -ForegroundColor Green
							Write-host "   $('-' * 80)"
							write-host "   Remove-AppxProvisionedPackage -Path ""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"" -PackageName ""$($item)""`n" -ForegroundColor Green
							Write-host "   $('-' * 80)`n"
						}
			
						Write-Host "   $($item)" -ForegroundColor Red
						Write-Host "   $($lang.Del)".PadRight(28) -NoNewline
						try {
							Remove-AppxProvisionedPackage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PackageName "$($item)" -ErrorAction SilentlyContinue | Out-Null
							Write-Host "   $($lang.Done)`n" -ForegroundColor Green
						} catch {
							Write-Host "`n   $($lang.SelectFromError)" -ForegroundColor Red
							Write-Host "   $($_)" -ForegroundColor Yellow
							Write-Host "   $($lang.RemoveFolderFailed)`n" -ForegroundColor Red
						}
					}
				}
			} else {
				Write-Host "   $($lang.NoWork)" -ForegroundColor Red
			}
		} else {
			Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
		}
	} else {
		Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
	}
}

Function InBox_Apps_LIPs_Add_Mark_Process
{
	if (-not $Global:EventQueueMode) {
		$Host.UI.RawUI.WindowTitle = "$($lang.StepOne)"
	}

	$Temp_Select_Queue_LXPs_Add_Custom_Select = (Get-Variable -Scope global -Name "Queue_Is_LXPs_Add_Step_One_Custom_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -ErrorAction SilentlyContinue).Value
	if ($Temp_Select_Queue_LXPs_Add_Custom_Select.count -gt 0) {
		Write-Host "   $($lang.AddSources)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"
		ForEach ($item in $Temp_Select_Queue_LXPs_Add_Custom_Select) {
			Write-Host "   $($item.Language)".PadRight(20) -NoNewline
			Write-Host "$($item.Path)" -ForegroundColor Green
		}

		Write-Host "`n   $($lang.AddQueue)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"
		ForEach ($item in $Temp_Select_Queue_LXPs_Add_Custom_Select) {
			Write-Host "   $($item.Path)"
			if ($Script:QueueExperiencePackNoEnglish) {
				$shortname = [IO.Path]::GetFileName($($item.Path))
				if ($shortname -eq "en-US") {
					Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
				} else {
					InBox_Apps_Add_Mark_Process -Path $($item.Path)
				}
			} else {
				InBox_Apps_Add_Mark_Process -Path $($item.Path)
			}
		}
	} else {
		Write-Host "   $($lang.NoWork)" -ForegroundColor Red
	}
}

<#
	.Add local language experience packs (LXPs)
	.开始添加本地语言体验包 ( LXPs )
#>
Function InBox_Apps_Add_Mark_Process
{
	param
	(
		[string]$Path
	)

	if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
		Write-Host "`n   $($lang.Command)" -ForegroundColor Green
		Write-host "   $($lang.Developers_Mode_Location)58" -ForegroundColor Green
		Write-host "   $('-' * 80)"
		write-host "   Get-ChildItem ""$($Path)\LanguageExperiencePack.*.appx""" -ForegroundColor Green
		Write-host "   $('-' * 80)`n"
	}

	Get-ChildItem "$($Path)\LanguageExperiencePack.*.appx" -ErrorAction SilentlyContinue | ForEach-Object {
		Write-Host "   $($_.FullName)" -ForegroundColor Green

		if (Test-Path "$($Path)\License.xml" -PathType Leaf) {
			if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
				Write-Host "`n   $($lang.Command)" -ForegroundColor Green
				Write-host "   $($lang.Developers_Mode_Location)59" -ForegroundColor Green
				Write-host "   $('-' * 80)"
				write-host "   Add-AppxProvisionedPackage -Path ""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"" -PackagePath ""$($_.FullName)"" -LicensePath ""$($Path)\License.xml""" -ForegroundColor Green
				Write-host "   $('-' * 80)`n"
			}

			Write-Host "   $($Path)\License.xml" -ForegroundColor Yellow
			Write-Host "   $($lang.License)".PadRight(28) -NoNewline
			Add-AppxProvisionedPackage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PackagePath "$($_.FullName)" -LicensePath "$($Path)\License.xml" -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   $($lang.Done)`n" -ForegroundColor Green
		} else {
			if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
				Write-Host "`n   $($lang.Command)" -ForegroundColor Green
				Write-host "   $($lang.Developers_Mode_Location)60" -ForegroundColor Green
				Write-host "   $('-' * 80)"
				write-host "   Add-AppxProvisionedPackage -Path ""$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)"" -PackagePath ""$($_.FullName)"" -SkipLicense" -ForegroundColor Green
				Write-host "   $('-' * 80)`n"
			}

			Write-Host "   $($lang.NoLicense)".PadRight(28) -NoNewline
			Add-AppxProvisionedPackage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PackagePath "$($_.FullName)" -SkipLicense -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   $($lang.Done)`n" -ForegroundColor Green
		}
	}
}

Function LXPs_Save_Report_Process
{
	param
	(
		$Path,
		$SaveTo
	)

	if (Test-Path -Path "$($Path)\LocalExperiencePack" -PathType Container) {
		$FolderDirect = (Join_MainFolder -Path "$($Path)\LocalExperiencePack")
	} else {
		$FolderDirect = (Join_MainFolder -Path $Path)
	}

	Write-Host "`n   $($lang.AdvAppsDetailed)"
	$QueueSelectLXPsReport = @()
	$RandomGuid = [guid]::NewGuid()
	$ISOTestFolderMain = "$($env:userprofile)\AppData\Local\Temp\$($RandomGuid)"
	Check_Folder -chkpath $ISOTestFolderMain

	for ($i=0; $i -lt $Global:AvailableLanguages.Count; $i++) {
		$TempNewFileFolderPath = "$($ISOTestFolderMain)\$($Global:AvailableLanguages[$i][2])"
		$TempNewFileFullPath = "$($FolderDirect)$($Global:AvailableLanguages[$i][2])\LanguageExperiencePack.$($Global:AvailableLanguages[$i][2]).Neutral.appx"

		if (Test-Path -Path $TempNewFileFullPath -PathType Leaf) {
			Check_Folder -chkpath $TempNewFileFolderPath

			Add-Type -AssemblyName System.IO.Compression.FileSystem
			$zipFile = [IO.Compression.ZipFile]::OpenRead($TempNewFileFullPath)
			$zipFile.Entries | where { $_.Name -like 'AppxManifest.xml' } | ForEach {
				[System.IO.Compression.ZipFileExtensions]::ExtractToFile($_, "$($TempNewFileFolderPath)\$($_.Name)", $true)
			}
			$zipFile.Dispose()

			if (Test-Path -Path "$($TempNewFileFolderPath)\AppxManifest.xml" -PathType Leaf) {
				[xml]$xml = Get-Content -Path "$($TempNewFileFolderPath)\AppxManifest.xml"

				$QueueSelectLXPsReport += [PSCustomObject]@{
					FileName           = "LanguageExperiencePack.$($Global:AvailableLanguages[$i][2]).Neutral.appx"
					MatchLanguage      = "$($Global:AvailableLanguages[$i][2])"
					LXPsDisplayName    = $Xml.Package.Properties.DisplayName
					LXPsLanguage       = $Xml.Package.Resources.Resource.Language
					LXPsVersion        = $Xml.Package.Identity.Version
					TargetDeviceFamily = $Xml.Package.Dependencies.TargetDeviceFamily.Name
					MinVersion         = $Xml.Package.Dependencies.TargetDeviceFamily.MinVersion
					MaxVersionTested   = $Xml.Package.Dependencies.TargetDeviceFamily.MaxVersionTested
				}
			}
		} else {
			$QueueSelectLXPsReport += [PSCustomObject]@{
				FileName           = "LanguageExperiencePack.$($Global:AvailableLanguages[$i][2]).Neutral.appx"
				MatchLanguage      = "$($Global:AvailableLanguages[$i][2])"
				LXPsDisplayName    = ""
				LXPsLanguage       = ""
				LXPsVersion        = ""
				TargetDeviceFamily = ""
				MinVersion         = ""
				MaxVersionTested   = ""
			}
		}
	}

	$QueueSelectLXPsReport | Export-CSV -NoTypeInformation -Path "$($SaveTo)" -Encoding UTF8

	Remove_Tree $ISOTestFolderMain
}