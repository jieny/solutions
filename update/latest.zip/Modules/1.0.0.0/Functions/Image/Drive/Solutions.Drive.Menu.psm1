﻿<#
	.Drive management
	.驱动管理
#>
Function Drive_Menu
{
	if (-not $Global:EventQueueMode) {
		Logo -Title $($lang.Drive)
		Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"

		Write-Host "   $($lang.MountImageTo)" -NoNewline
		Write-Host " $($Global:MountToRouting)" -ForegroundColor Yellow

		Write-Host "   $($lang.MainImageFolder)" -NoNewline
		Write-Host " $($Global:MountTo)" -NoNewline -ForegroundColor Yellow
		if (Test-Path "$($Global:MountTo)" -PathType Container) {
			Write-Host " $($lang.ImageLoaded)" -ForegroundColor Green
		} else {
			Write-Host " $($lang.NotMounted)" -ForegroundColor Red
			ToMainpage -wait 2
		}
		Image_Get_Mount_Status
	}

	Write-Host "`n   $($lang.Menu)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "      1   $($lang.Drive): $($lang.AddTo)" -ForegroundColor Green
		} else {
			Write-Host "      1   $($lang.Drive): $($lang.AddTo)" -ForegroundColor Red
		}
	} else {
		Write-Host "      1   $($lang.Drive): $($lang.AddTo)" -ForegroundColor Red
	}

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "      2   $($lang.Drive): $($lang.Del)" -ForegroundColor Green
		} else {
			Write-Host "      2   $($lang.Drive): $($lang.Del)" -ForegroundColor Red
		}
	} else {
		Write-Host "      2   $($lang.Drive): $($lang.Del)" -ForegroundColor Red
	}

	Write-Host "`n   $($lang.ViewDrive)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Green
		} else {
			Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Red
		}
	} else {
		Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Red
	}

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
			Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Green
		} else {
			Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Red
		}
	} else {
		Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Red
	}

	$select = Read-Host "`n   $($lang.Choose)"
	switch ($select)
	{
		'1' {
			if (Image_Is_Select_IAB) {
				if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
					Event_Assign -Rule "Drive_Add_UI" -Run
				} else {
					Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
				}
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 2
		}
		'2' {
			if (Image_Is_Select_IAB) {
				if (Test-Path "$($Global:MountToRouting)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)" -PathType Container) {
					Event_Assign -Rule "Drive_Delete_UI" -Run
				} else {
					Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
				}
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 2
		}
		'p' {
			Write-Host "`n   $($lang.ViewDrive)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"

			Write-Host "   $($lang.ExportToLogs)" -ForegroundColor Yellow
			if (Image_Is_Select_IAB) {
				Image_Get_Installed_Drive
				Get_Next
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 2
		}
		's' {
			Write-Host "`n   $($lang.ViewDrive)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"

			Write-Host "   $($lang.ExportToLogs)" -ForegroundColor Yellow
			if (Image_Is_Select_IAB) {
				Image_Get_Installed_Drive -View
				Get_Next
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}
			ToMainpage -wait 2 -To 2
		}
		default { Mainpage }
	}
}