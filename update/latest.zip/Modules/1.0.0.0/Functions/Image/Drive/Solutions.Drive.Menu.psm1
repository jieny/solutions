﻿<#
	.Drive management
	.驱动管理
#>
Function Drive_Menu
{
	if (-not $Global:EventQueueMode) {
		Logo -Title $($lang.Drive)
		Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"

		Write-Host "   $($lang.MountImageTo)" -NoNewline
		if (Test-Path "$($Global:Mount_To_Route)" -PathType Container) {
			Write-Host " $($Global:Mount_To_Route)" -ForegroundColor Green
		} else {
			Write-Host " $($Global:Mount_To_Route)" -ForegroundColor Yellow
		}

		Write-Host "   $($lang.MainImageFolder)" -NoNewline
		if (Test-Path "$($Global:Image_source)" -PathType Container) {
			Write-Host " $($Global:Image_source)" -ForegroundColor Green
		} else {
			Write-Host " $($Global:Image_source)" -ForegroundColor Red
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.NoInstallImage)" -ForegroundColor Red

			ToWait -wait 2
			Drive_Menu
		}

		Image_Get_Mount_Status
	}

	Write-Host "`n   $($lang.Drive)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
			Write-Host "      1   $($lang.AddTo)" -ForegroundColor Green
		} else {
			Write-Host "      1   $($lang.AddTo)" -ForegroundColor Red
		}
	} else {
		Write-Host "      1   $($lang.AddTo)" -ForegroundColor Red
	}

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
			Write-Host "      2   $($lang.Del)" -ForegroundColor Green
		} else {
			Write-Host "      2   $($lang.Del)" -ForegroundColor Red
		}
	} else {
		Write-Host "      2   $($lang.Del)" -ForegroundColor Red
	}

	Write-Host "`n   $($lang.ViewDrive)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
			Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Green
		} else {
			Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Red
		}
	} else {
		Write-Host "      P   $($lang.ExportToLogs)" -ForegroundColor Red
	}

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
			Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Green
		} else {
			Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Red
		}
	} else {
		Write-Host "      S   $($lang.ExportShow)" -ForegroundColor Red
	}

	switch (Read-Host "`n   $($lang.Choose)")
	{
		'1' {
			if (Image_Is_Select_IAB) {
				if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
					Event_Assign -Rule "Drive_Add_UI" -Run
				} else {
					Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
				}
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}

			ToWait -wait 2
			Drive_Menu
		}
		'2' {
			if (Image_Is_Select_IAB) {
				if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
					Event_Assign -Rule "Drive_Delete_UI" -Run
				} else {
					Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
				}
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}

			ToWait -wait 2
			Drive_Menu
		}
		'p' {
			Write-Host "`n   $($lang.ViewDrive)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.ExportToLogs)" -ForegroundColor Yellow

			if (Image_Is_Select_IAB) {
				Image_Get_Installed_Drive
				Get_Next
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}

			ToWait -wait 2
			Drive_Menu
		}
		's' {
			Write-Host "`n   $($lang.ViewDrive)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"

			Write-Host "   $($lang.ExportToLogs)" -ForegroundColor Yellow
			if (Image_Is_Select_IAB) {
				Image_Get_Installed_Drive -View
				Get_Next
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}

			ToWait -wait 2
			Drive_Menu
		}
		default { Mainpage }
	}
}