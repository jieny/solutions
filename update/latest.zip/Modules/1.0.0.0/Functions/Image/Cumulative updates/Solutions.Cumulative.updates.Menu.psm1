﻿<#
	.Update management
	.更新管理
#>
Function Update_Menu
{
	if (-not $Global:EventQueueMode) {
		Logo -Title $($lang.CUpdate)
		Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"

		Write-Host "   $($lang.MountImageTo) " -NoNewline
		if (Test-Path $Global:Mount_To_Route -PathType Container) {
			Write-Host $Global:Mount_To_Route -ForegroundColor Green
		} else {
			Write-Host $Global:Mount_To_Route -ForegroundColor Yellow
		}

		Write-Host "   $($lang.MainImageFolder) " -NoNewline
		if (Test-Path $Global:Image_source -PathType Container) {
			Write-Host $Global:Image_source -ForegroundColor Green
		} else {
			Write-Host $Global:Image_source -ForegroundColor Red
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.NoInstallImage)" -ForegroundColor Red

			ToWait -wait 2
			Update_Menu
		}

		Image_Get_Mount_Status
	}

	Write-Host "`n   $($lang.CUpdate)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
		Write-Host "      1   " -NoNewline -ForegroundColor Yellow
		Write-host $lang.AddTo -ForegroundColor Green
	} else {
		Write-Host "      1   " -NoNewline -ForegroundColor Yellow
		Write-host $lang.AddTo -ForegroundColor Red
	}

	if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
		Write-Host "      2   " -NoNewline -ForegroundColor Yellow
		Write-host $lang.Del -ForegroundColor Green
	} else {
		Write-Host "      2   " -NoNewline -ForegroundColor Yellow
		Write-host $lang.Del -ForegroundColor Red
	}

	Write-Host "`n   $($lang.MoreFeature)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
		Write-Host "      3   " -NoNewline -ForegroundColor Yellow
		Write-host $lang.CuringUpdate -ForegroundColor Green
	} else {
		Write-Host "      3   " -NoNewline -ForegroundColor Yellow
		Write-host $lang.CuringUpdate -ForegroundColor Red
	}
	Write-host "          $('-' * 73)"

	if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
		Write-Host "          31   " -NoNewline -ForegroundColor Yellow
		Write-host $lang.Superseded -ForegroundColor Green
	} else {
		Write-Host "          31   " -NoNewline -ForegroundColor Yellow
		Write-host $lang.Superseded -ForegroundColor Red
	}

	if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
		Write-Host "          32   " -NoNewline -ForegroundColor Yellow
		Write-host "$($lang.Superseded), $($lang.ExcludeItem)" -ForegroundColor Green
	} else {
		Write-Host "          32   " -NoNewline -ForegroundColor Yellow
		Write-host "$($lang.Superseded), $($lang.ExcludeItem)" -ForegroundColor Red
	}

	Write-Host "`n   $($lang.GetImagePackage)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
			Write-Host "      P   " -NoNewline -ForegroundColor Yellow
			Write-host $lang.ExportToLogs -ForegroundColor Green
		} else {
			Write-Host "      P   " -NoNewline -ForegroundColor Yellow
			Write-host $lang.ExportToLogs -ForegroundColor Red
		}
	} else {
		Write-Host "      P   " -NoNewline -ForegroundColor Yellow
		Write-host $lang.ExportToLogs -ForegroundColor Red
	}

	if (Image_Is_Select_IAB) {
		if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
			Write-Host "      S   " -NoNewline -ForegroundColor Yellow
			Write-host $lang.ExportShow -ForegroundColor Green
		} else {
			Write-Host "      S   " -NoNewline -ForegroundColor Yellow
			Write-host $lang.ExportShow -ForegroundColor Red
		}
	} else {
		Write-Host "      S   " -NoNewline -ForegroundColor Yellow
		Write-host $lang.ExportShow -ForegroundColor Red
	}

	switch (Read-Host "`n   $($lang.Choose)")
	{
		'1' {
			Write-Host "`n   $($lang.Update): $($lang.AddTo)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
				<#
					.Assign available tasks
					.分配可用的任务
				#>
				Event_Assign -Rule "Update_Add_UI" -Run
			} else {
				Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
			}

			ToWait -wait 2
			Update_Menu
		}
		'2' {
			Write-Host "`n   $($lang.Update): $($lang.Del)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
				<#
					.Assign available tasks
					.分配可用的任务
				#>
				Event_Assign -Rule "Update_Delete_UI" -Run
			} else {
				Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
			}

			ToWait -wait 2
			Update_Menu
		}
		'3' {
			Write-Host "`n   $($lang.CuringUpdate)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
				New-Variable -Scope global -Name "Queue_Is_Update_Curing_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $True -Force
				Event_Process_Task_Need_Mount
				New-Variable -Scope global -Name "Queue_Is_Update_Curing_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force

				Get_Next
			} else {
				Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
			}

			ToWait -wait 2
			Update_Menu
		}
		'31' {
			Write-Host "`n   $($lang.Superseded)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
				New-Variable -Scope global -Name "Queue_Superseded_Clean_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $True -Force
				Image_Clear_Superseded
				New-Variable -Scope global -Name "Queue_Superseded_Clean_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force

				Get_Next
			} else {
				Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
			}

			ToWait -wait 2
			Update_Menu

		}
		'32' {
			Write-Host "`n   $($lang.Superseded)" -ForegroundColor Yellow
			Write-Host "`n   $($lang.Superseded)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if (Test-Path "$($Global:Mount_To_Route)\$($Global:Primary_Key_Image.Master)\$($Global:Primary_Key_Image.ImageFileName)\Mount" -PathType Container) {
				New-Variable -Scope global -Name "Queue_Superseded_Clean_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $True -Force
				New-Variable -Scope global -Name "Queue_Superseded_Clean_Allow_Rule_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $True -Force
				Image_Clear_Superseded
				New-Variable -Scope global -Name "Queue_Superseded_Clean_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force
				New-Variable -Scope global -Name "Queue_Superseded_Clean_Allow_Rule_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force

				Get_Next
			} else {
				Write-Host "   $($lang.NotMounted)`n" -ForegroundColor Red
			}

			ToWait -wait 2
			Update_Menu

		}
		'p' {
			Write-Host "`n   $($lang.GetImagePackage)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.ExportToLogs)" -ForegroundColor Yellow

			if (Image_Is_Select_IAB) {
				Image_Get_Components_Package
				Get_Next
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}

			ToWait -wait 2
			Update_Menu
		}
		's' {
			Write-Host "`n   $($lang.GetImagePackage)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.ExportToLogs)" -ForegroundColor Yellow

			if (Image_Is_Select_IAB) {
				Image_Get_Components_Package -View
				Get_Next
			} else {
				Write-Host "   $($lang.IABSelectNo)" -ForegroundColor Red
			}

			ToWait -wait 2
			Update_Menu
		}
		default {
			Mainpage
		}
	}
}