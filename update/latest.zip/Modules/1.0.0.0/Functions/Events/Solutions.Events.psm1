﻿<#
	.Assign available event preconfigurations
	.分配可用事件预配置
#>
Function Event_Assign
{
	param
	(
		[switch]$Run,
		$Rule
	)

	$Temp_Set_Need_Mounted_Primary = @(
		@{
			Uid         = "Current"
			IsMounted   = @{
				Primary = "Solutions_Create_UI"
				Expand  = @()
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Solutions_Create_UI"
			IsMounted   = @{
				Primary = "Solutions_Create_UI"
				Expand  = @()
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @(
					"ISO_Create_UI"
				)
			}
			IsEvent = @(
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Update_Add_UI"
			IsMounted   = @{
				Primary = "Update_Add_UI"
				Expand  = @(
					"Update_Delete_UI"
				)
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Update_Delete_UI"
			IsMounted   = @{
				Primary = "Update_Delete_UI"
				Expand  = @(
					"Update_Add_UI"
				)
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Language_Cleanup_Components_UI"
			IsMounted   = @{
				Primary = "Language_Cleanup_Components_UI"
				Expand  = @(
					"Language_Add_UI"
					"Language_Delete_UI"
					"Language_Change_UI"
				)
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Language_Add_UI"
			IsMounted   = @{
				Primary = "Language_Add_UI"
				Expand  = @(
					"Language_Delete_UI"
					"Language_Change_UI"
					"Language_Cleanup_Components_UI"
				)
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Language_Delete_UI"
			IsMounted   = @{
				Primary = "Language_Delete_UI"
				Expand  = @(
					"Language_Add_UI"
					"Language_Change_UI"
					"Language_Cleanup_Components_UI"
				)
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Language_Change_UI"
			IsMounted   = @{
				Primary = "Language_Change_UI"
				Expand  = @(
					"Language_Add_UI"
					"Language_Delete_UI"
					"Language_Cleanup_Components_UI"
				)
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Drive_Add_UI"
			IsMounted   = @{
				Primary = "Drive_Add_UI"
				Expand  = @(
					"Drive_Delete_UI"
				)
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Drive_Delete_UI"
			IsMounted   = @{
				Primary = "Drive_Delete_UI"
				Expand  = @(
					"Drive_Add_UI"
				)
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Feature_Enabled_UI"
			IsMounted   = @{
				Primary = "Feature_Enabled_UI"
				Expand  = @()
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "InBox_Apps_Mark_UI"
			IsMounted   = @{
				Primary = "InBox_Apps_Mark_UI"
				Expand  = @(
					"InBox_Apps_Add_UI"
					"InBox_Apps_Refresh_UI"
				)
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "InBox_Apps_Add_UI"
			IsMounted   = @{
				Primary = "InBox_Apps_Add_UI"
				Expand  = @(
					"InBox_Apps_Refresh_UI"
				)
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "InBox_Apps_Refresh_UI"
			IsMounted   = @{
				Primary = "InBox_Apps_Refresh_UI"
				Expand  = @()
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Image_Eject_UI"
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "InBox_Apps_Match_Delete_UI"
			IsMounted   = @{
				Primary = "InBox_Apps_Match_Delete_UI"
				Expand  = @()
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Functions"
			IsMounted   = @{
				Primary = "Functions_Assign_UI"
				Expand  = @()
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Eject"
			IsMounted   = @{
				Primary = "Image_Eject_UI"
				Expand  = @()
			}
			NotMonuted  = @{
				Primary = ""
				Expand  = @()
			}
			IsEvent = @(
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "Image_Convert_UI"
			IsMounted   = @{
				Primary = ""
				Expand  = @()
			}
			NotMonuted  = @{
				Primary = "Image_Convert_UI"
				Expand  = @(
					"ISO_Create_UI"
				)
			}
			IsEvent = @(
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
		@{
			Uid         = "ISO_Create_UI"
			IsMounted   = @{
				Primary = ""
				Expand  = @()
			}
			NotMonuted  = @{
				Primary = "ISO_Create_UI"
				Expand  = @()
			}
			IsEvent = @(
				"Event_Completion_Setting_UI"
				"Event_Completion_Start_Setting_UI"
			)
		}
	)

	ForEach ($item in $Temp_Set_Need_Mounted_Primary) {
		if ($item.Uid -eq $Rule) {
			Event_Assign_Task_Queue_Add -Uid $Rule -IsMountedPrimary $item.IsMounted.Primary -IsMountedExpand $item.IsMounted.Expand -NotMonutedPrimary $item.NotMonuted.Primary -NotMonutedExpand $item.NotMonuted.Expand -IsEvent $item.IsEvent
		}
	}

	if ($Run) {
		Event_Assign_Task
	}
}

<#
	.Event assignment add
	.事件分配添加
#>
Function Event_Assign_Task_Queue_Add
{
	param
	(
		$Uid,

		<#
			.需要挂载项
		#>
		$IsMountedPrimary,
		$IsMountedExpand,

		<#
			.无需挂载项
		#>
		$NotMonutedPrimary,
		$NotMonutedExpand,

		<#
			.有事件触发时
		#>

		$IsEvent
	)

	<#
		.分配到全局唯一识别
	#>
	$Global:EventProcessGuid = [guid]::NewGuid()
	$Global:Event_Guid = $Uid

	<#
		.分配已运行过的 UI
	#>
	New-Variable -Scope global -Name "Queue_Assign_Has_Been_Run_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value @() -Force

	# ------------------------------11111111111111111111111---------------------------
	<#
		.分配 1 ：需要挂载项
	#>
		<#
			.主要项
		#>
		New-Variable -Scope global -Name "Queue_Is_Mounted_Primary_Assign_Task_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $IsMountedPrimary -Force

		<#
			.扩展项
		#>
		if ([string]::IsNullOrWhitespace($IsMountedExpand)) {
			New-Variable -Scope global -Name "Queue_Is_Mounted_Expand_Assign_Task_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value @() -Force
			New-Variable -Scope global -Name "Queue_Is_Mounted_Expand_Assign_Task_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value @() -Force
		} else {
			New-Variable -Scope global -Name "Queue_Is_Mounted_Expand_Assign_Task_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $IsMountedExpand -Force

			if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\Suggested\$($Uid)" -Name "IsMountedExpand_Select" -ErrorAction SilentlyContinue) {
				$SchemeVerSingle = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\Suggested\$($Uid)" -Name "IsMountedExpand_Select" -ErrorAction SilentlyContinue
				New-Variable -Scope global -Name "Queue_Is_Mounted_Expand_Assign_Task_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $SchemeVerSingle -Force
			} else {
				Save_Dynamic -regkey "Solutions\Suggested\$($Uid)" -name "IsMountedExpand_Select" -value $IsMountedExpand -Multi
				New-Variable -Scope global -Name "Queue_Is_Mounted_Expand_Assign_Task_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $IsMountedExpand -Force
			}
		}


	# ------------------------------222222222222222222222222---------------------------
	<#
		.分配 2 ：无需要挂载项
	#>
		<#
			.主要项
		#>
		if ([string]::IsNullOrWhitespace($NotMonutedPrimary)) {
			$Global:Queue_Assign_Not_Monuted_Primary = @()
		} else {
			$Global:Queue_Assign_Not_Monuted_Primary = $NotMonutedPrimary
		}

		<#
			.扩展项，分配全部
		#>
		if ([string]::IsNullOrWhitespace($NotMonutedExpand)) {
			$Global:Queue_Assign_Not_Monuted_Expand = @()
			$Global:Queue_Assign_Not_Monuted_Expand_Select = @()
		} else {
			$Global:Queue_Assign_Not_Monuted_Expand = $NotMonutedExpand

			if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\Suggested\$($Uid)" -Name "NotMonutedExpand_Select" -ErrorAction SilentlyContinue) {
				$SchemeVerSingle = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\Suggested\$($Uid)" -Name "NotMonutedExpand_Select" -ErrorAction SilentlyContinue

				$Global:Queue_Assign_Not_Monuted_Expand_Select = $SchemeVerSingle | Where-Object { -not ([string]::IsNullOrEmpty($_) -or [string]::IsNullOrWhiteSpace($_))}
			} else {
				Save_Dynamic -regkey "Solutions\Suggested\$($Uid)" -name "NotMonutedExpand_Select" -value $NotMonutedExpand -Multi
				$Global:Queue_Assign_Not_Monuted_Expand_Select = $NotMonutedExpand
			}
		}


	# ------------------------------33333333333333333333333---------------------------
	<#
		.分配 3：分配有事件时
	#>
	if ([string]::IsNullOrWhitespace($IsEvent)) {
		$Global:Queue_Assign_Available = @()
	} else {
		$Global:Queue_Assign_Available = $IsEvent
	}

	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\Suggested\$($Uid)" -Name "IsEvent_Select" -ErrorAction SilentlyContinue) {
		$SchemeVerSingle = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\Suggested\$($Uid)" -Name "IsEvent_Select" -ErrorAction SilentlyContinue
		$Global:Queue_Assign_Available_Select = $SchemeVerSingle | Where-Object { -not ([string]::IsNullOrEmpty($_) -or [string]::IsNullOrWhiteSpace($_))}
	} else {
		Save_Dynamic -regkey "Solutions\Suggested\$($Uid)" -name "IsEvent_Select" -value $IsEvent -Multi

		if ([string]::IsNullOrWhitespace($IsEvent)) {
			$Global:Queue_Assign_Available_Select = @()
		} else {
			$Global:Queue_Assign_Available_Select = $IsEvent
		}
	}
	
	<#
		.不再建议项
	#>
	if ((Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) -eq "True") {
		if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Uid)" -Name "IsSuggested" -ErrorAction SilentlyContinue) -eq "False") {
			New-Variable -Scope global -Name "Queue_Is_Mounted_Expand_Assign_Task_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value @() -Force
			$Global:Queue_Assign_Not_Monuted_Expand_Select = @()
		}
	}
}

<#
	.Event assignment add
	.事件分配添加，自定义
#>
Function Event_Assign_Task_Queue_Add_New
{
	param
	(
		$Uid,

		<#
			.需要挂载项
		#>
		$IsMountedPrimary,
		$IsMountedExpand,

		<#
			.无需挂载项
		#>
		$NotMonutedPrimary,
		$NotMonutedExpand,

		<#
			.有事件触发时
		#>

		$IsEvent
	)

	<#
		.分配到全局唯一识别
	#>
	$Global:EventProcessGuid = [guid]::NewGuid()
	$Global:Event_Guid = $Uid

	<#
		.分配已运行过的 UI
	#>
	New-Variable -Scope global -Name "Queue_Assign_Has_Been_Run_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value @() -Force

	# ------------------------------11111111111111111111111---------------------------
	<#
		.分配 1 ：需要挂载项
	#>
		<#
			.主要项。
		#>
		New-Variable -Scope global -Name "Queue_Is_Mounted_Primary_Assign_Task_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value @() -Force

		<#
			扩展项
		#>
		New-Variable -Scope global -Name "Queue_Is_Mounted_Expand_Assign_Task_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $IsMountedExpand -Force
		New-Variable -Scope global -Name "Queue_Is_Mounted_Expand_Assign_Task_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $IsMountedExpand -Force
}

Function Event_Track
{
	param
	(
		[switch]$Reset,
		[switch]$Add,
		[switch]$Del
	)

	if ($Reset) {
		$Global:EventProcessGuid = [guid]::NewGuid()
	}

	if ($Global:EventQueueMode) {
		$EventMaps = "Queue"
	} else {
		$EventMaps = "Assign"
	}

	if ($Add) {
		Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\$($EventMaps)\$($Global:EventProcessGuid)" -name "GUID" -value $Global:EventProcessGuid -String
		Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\$($EventMaps)\$($Global:EventProcessGuid)" -name "Time" -value "$(Get-Date -Format "yyyy/MM/dd HH:mm:ss")" -String
	}

	if ($Del) {
		Remove-Item "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\$($EventMaps)\$($Global:EventProcessGuid)" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
	}
}

<#
	.One-click production, on-demand planning
	.一键制作，按需计划
#>
Function Event_Assign_Task
{
	<#
		.生成唯一事件：GUID
	#>
	
	Event_Track -Reset -Add
	Event_Processing_Requires_Mounting

	<#
		.Events: Handling disallowed items
		.事件：分配无需挂载的项
	#>
	Event_Assign_Not_Allowed_UI

	if (Event_Assign_Task_Verify -Mount -Eject -All) {
		<#
			.Events: Handling Allowed Items
			.事件：有可用的事件时
		#>
		Event_Process_Available_UI

		if ($Global:QueueWaitTime) {
			Event_Completion_Start_Process
		}

		<#
			.如果等待时间完成后，优先处理生成解决方案，仅生成到 挂载主目录 下
		#>
		Solutions_Quick_Copy_Process

		<#
			.Handle operations that need to be mounted after install.wim or boot.wim
			.处理需要挂载 install.wim 或 boot.wim 后的操作
		#>
		Event_Process_Task_Need_Mount
	}

	if ($Global:Primary_Key_Image.Count -gt 0) {
		<#
			.处理扩展项任务，更新映像内的文件
		#>
		Write-host "`n   $($lang.Event_Allow_Update_Rule)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"
		Image_Get_Mount_Status -Silent

		if ((Get-Variable -Scope global -Name "Mark_Is_Mount_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)").Value) {
			Write-host "   $($lang.Mounted)" -ForegroundColor Green
		} else {
			Write-host "   $($lang.NotMounted)" -ForegroundColor Red

			ForEach ($item in $Global:Image_Rule) {
				if ($item.Main.Suffix -eq "wim") {
					if ($item.Main.Uid -eq $Global:Primary_Key_Image.Uid) {
						if ($item.Expand.Count -gt 0) {
							ForEach ($itemExpandNew in $item.Expand) {
								Write-host "`n   $($lang.Unique_Name)"
								Write-host "   $($item.Main.ImageFileName);$($itemExpandNew.ImageFileName);" -ForegroundColor Green

								Image_Queue_Wimlib_Process_Wim_Main -NewUid $itemExpandNew.Uid -NewMaster $item.Main.ImageFileName -NewImageFileName $itemExpandNew.ImageFileName -MasterFile "$($item.Main.Path)\$($item.Main.ImageFileName).$($item.Main.Suffix)" 

								New-Variable -Scope global -Name "Queue_Is_Update_Rule_Expand_Rule_$($item.Main.ImageFileName)_$($itemExpandNew.ImageFileName)" -Value @() -Force
							}
						}
					}
				}
			}

			<#
				.完成所有后，重建
			#>
			Write-Host "`n   $($lang.Rebuilding)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			if ((Get-Variable -Scope global -Name "Queue_Rebuild_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -ErrorAction SilentlyContinue).Value) {
				Write-Host "   $($lang.Operable)" -ForegroundColor Green

				Rebuild_Image_File -Filename $Global:Primary_Key_Image.FullPath
				New-Variable -Scope global -Name "Queue_Rebuild_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value $False -Force
			} else {
				Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
			}
		}
	}
	
	<#
		.Handle events that don't require the image source to be mounted
		.处理不需要挂载映像源的事件
	#>
	Event_Process_Task_Sustainable

	<#
		.After event processing is complete
		.事件处理完成后
	#>
	Event_Completion_Process

	Event_Reset_Variable -Silent
}

Function Init_Canel_Event
{
	param
	(
		[switch]$All
	)

	New-Variable -Scope global -Name "Queue_Is_Mounted_Expand_Assign_Task_Select_$($Global:Primary_Key_Image.Master)_$($Global:Primary_Key_Image.ImageFileName)" -Value @() -Force
	$Global:Queue_Assign_Not_Monuted_Expand_Select = @()
	$Global:Queue_Assign_Available_Select = @()

	if ($All) {
		<#
			.未设置有任务时，初始化默认出厂值
		#>
		<#
			.初始化：等待时间
		#>
		$Global:QueueWaitTime = $False

		if ($Global:EventQueueMode) {
			$EventMaps = "Queue"
		} else {
			$EventMaps = "Assign"
		}

		<#
			.初始化：完成后事件
		#>
		$Global:IsFinish = $True

		Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\$($EventMaps)\$($Global:EventProcessGuid)" -name "AllowAfterFinishing" -value "True" -String
		Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Deploy\Event\$($EventMaps)\$($Global:EventProcessGuid)" -name "AfterFinishing" -value "2" -String
	}
}