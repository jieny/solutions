﻿<#
	.Requirements
	.先决条件
#>
Function Requirements
{
	# Elevating priviledges for this process
	do {} until ( ElevatePrivileges SeTakeOwnershipPrivilege )

	Clear-Host
	$Host.UI.RawUI.WindowTitle = "$((Get-Module -Name Solutions).Author)'s Solutions | Prerequisites"
	Write-Host "`n   Prerequisites" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	Write-Host -NoNewline "   Checking PS version 5.1 and above".PadRight(75)
	if ($PSVersionTable.PSVersion.major -ge "5") {
		Write-Host -ForegroundColor Green "OK".PadLeft(8)
	} else {
		Write-Host -ForegroundColor Red " Failed".PadLeft(8)
	}

	Write-Host -NoNewline "   Checking Windows version > 10.0.16299.0".PadRight(75)
	$OSVer = [System.Environment]::OSVersion.Version;
	if (($OSVer.Major -eq 10 -and $OSVer.Minor -eq 0 -and $OSVer.Build -ge 16299)) {
		Write-Host -ForegroundColor Green "OK".PadLeft(8)
	} else {
		Write-Host -ForegroundColor Red "Failed".PadLeft(8)
	}

	Write-Host -NoNewline "   Checking Must be elevated to higher authority".PadRight(75)
	if (([System.Security.Principal.WindowsIdentity]::GetCurrent()).groups -match "S-1-5-32-544") {
		Write-Host -ForegroundColor Green "OK".PadLeft(8)
	} else {
		Write-Host -ForegroundColor Red "Failed".PadLeft(8)
		Write-Host "`n   It will automatically exit after 6 seconds." -ForegroundColor Red
		start-process "timeout.exe" -argumentlist "/t 6 /nobreak" -wait -nonewwindow
		Modules_Import
		Stop-Process $PID
		exit
	}

	<#
		模块名称
		模块最低版本
	#>
	$ExpansionModule = @(
		@{
			Name    = "Solutions.Custom.Extension"
			Version = "1.0.0.0"
		}
	)

	Write-Host "`n   Expansion module" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"
	ForEach	 ($item in $ExpansionModule) {
		Write-Host -NoNewline "   $($item.name)".PadRight(75) -ForegroundColor Green

		$MarkFindModule = $False
		$MarkFindModuleVersion = ""

		Get-Module -Name $item.Name | ForEach-Object {
			if ($item.Name -eq $_.Name) {
				$MarkFindModule = $True
				$MarkFindModuleVersion = $_.Version
			}
		}

		if ($MarkFindModule) {
			Write-Host -ForegroundColor Green "Find".PadLeft(8)

			Write-Host "     Minimum version: $($item.Version), Current version: $($MarkFindModuleVersion)"
			Write-Host -NoNewline "     Meet the criteria".PadRight(75) -ForegroundColor Green

			if ($item.Version -eq $MarkFindModuleVersion) {
				Write-Host -ForegroundColor Green "OK".PadLeft(8)
			} else {
				Write-Host -ForegroundColor Red "Failed".PadLeft(8)

				Write-Host "`n   The version is wrong, please refer to Solutions.Custom.Extension.psm1.Example,`n   re-upgrade $($item.Name).psm1 and try again." -ForegroundColor Red
				start-process "timeout.exe" -argumentlist "/t 6 /nobreak" -wait -nonewwindow
				Modules_Import
				Stop-Process $PID
				exit
			}

			Write-Host ""
		} else {
			Write-Host -ForegroundColor Red "No".PadLeft(8)
		}
	}

	Write-Host "`n   Congratulations, passing the prerequisites.`n   About to go to the next step." -ForegroundColor Green
	Start-Sleep -s 2
}