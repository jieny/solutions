﻿<#
	.Exclusions when removing all UWP apps
	.删除所有 UWP 应用时排除项
#>
$Global:ExcludeUWPDeletedItems = @(
	"*Advertising.Xaml*"
	"*DesktopAppInstaller*"
	"*Native.Framework*1.7*"
	"*Native.Framework*2.2*"
	"*Native.Runtime*1.7*"
	"*Native.Runtime*2.2*"
	"*Services.Store.Engagement*"
	"*SecHealthUI*"
	"*UI.Xaml*2.0*"
	"*UI.Xaml*2.1*"
	"*UI.Xaml*2.3*"
	"*UI.Xaml*2.4*"
	"*UI.Xaml*2.7*"
	"*UI.Xaml*2.8*"
	"*VCLibs*"
)

<#
	.预配置规则

	 Group       = 名称
	 GUID        = 规则唯一标识符
	 Description = 描述

	* InBox Apps
	 	ISO      = 规则命名通过验证 ISO 文件。
		SN       = S 版、SN 版
		Edition  = Windows 操作系统版本识别

		N        = N 版
		Edition  = Windows 操作系统版本识别
		Exclude  = 遇到 N 版时，排除的应用规则

		Rule     = 规则
				   安装包类型，唯一识别名，模糊查找名，依赖

	* Language
		ISO      = 规则命名通过验证 ISO 文件。
		Rule     = Boot
				 = Install

	.替换机制
		{Lang}     = 语言标记
		{ARCH}     = 架构：原始 amd64
		{ARCHC}    = 架构：转换后的结果：x64
		{ARCHTag}  = 架构：缩写
		{Specific} = 特定包转换，了解：
		             https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/features-on-demand-language-fod?view=windows-11#other-region-specific-requirements

	.排序：内核、系统类型、boot 或 Install、所需文件、文件路径
#>
$Global:Pre_Config_Rules = @(
	#region Windows 11 23H2
	@{
		GUID        = "b277acfd-fb10-4fca-bff2-3a3395fab95b"
		Author      = "Yi"
		Copyright   = "FengYi, Inc. All rights reserved."
		Name        = "Windows 11 23H2"
		ISO         = @(
			"X23-59465_22631.2428.231001-0608.23H2_NI_RELEASE_SVC_REFRESH_CLOUDEDITION_amd64fre_en-us.iso"
			"X23-59466_22631.2428.231001-0608.23H2_NI_RELEASE_SVC_REFRESH_CLOUDEDITION_arm64fre_en-us.iso"
			"X23-59435_22631.2428.231001-0608.23H2_NI_RELEASE_SVC_REFRESH_CLIENT_CONSUMER_x64FRE_en-us.iso"
			"X23-59469_22631.2428.231001-0608.23H2_NI_RELEASE_SVC_REFRESH_CLIENTENTERPRISE_OEM_x64FRE_en-us.iso"
		)
		Description = ""
		InboxApps   = @{
			ISO = @(
				"X23-59424_22621.2501.231009-1937.ni_release_svc_prod3_amd64fre_InboxApps.iso"
			)
			SN = @{
				Edition = @(
					"EnterpriseS"
					"EnterpriseSN"
					"IoTEnterpriseS"
				)
			}
			Edition = @(
				#region CloudEdition
				@{
					Name = @(
						"CloudEdition"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.UI.Xaml.2.8"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.VP9VideoExtensions"
						"Clipchamp.Clipchamp"
						"Microsoft.BingNews"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.GetHelp"
						"Microsoft.Getstarted"
						"Microsoft.HEIFImageExtension"
						"Microsoft.HEVCVideoExtension"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.MinecraftEducationEdition"
						"Microsoft.Paint"
						"Microsoft.RawImageExtension"
						"Microsoft.ScreenSketch"
						"Microsoft.SecHealthUI"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.WebMediaExtensions"
						"Microsoft.WebpImageExtension"
						"Microsoft.Whiteboard"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsCalculator"
						"Microsoft.WindowsCamera"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsSoundRecorder"
						"Microsoft.Xbox.TCUI"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.ZuneMusic"
						"Microsoft.ZuneVideo"
						"MicrosoftCorporationII.QuickAssist"
					)
				}
				#endregion

				#region CloudEditionN
				@{
					Name = @(
						"CloudEditionN"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.UI.Xaml.2.8"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.XboxSpeechToTextOverlay"
						"Clipchamp.Clipchamp"
						"Microsoft.BingNews"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.GetHelp"
						"Microsoft.Getstarted"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.MinecraftEducationEdition"
						"Microsoft.Paint"
						"Microsoft.ScreenSketch"
						"Microsoft.SecHealthUI"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Whiteboard"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsCalculator"
						"Microsoft.WindowsCamera"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.WindowsNotepad"
						"Microsoft.XboxIdentityProvider"
						"MicrosoftCorporationII.QuickAssist"
					)
				}
				#endregion

				#region Core, CoreN, CoreSingleLanguage
				@{
					Name = @(
						"Core"
						"CoreN"
						"CoreSingleLanguage"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.UI.Xaml.2.8"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.HEIFImageExtension"
						"Microsoft.HEVCVideoExtension"
						"Microsoft.SecHealthUI"
						"Microsoft.VP9VideoExtensions"
						"Microsoft.WebpImageExtension"
						"Microsoft.WindowsStore"
						"Microsoft.GamingApp"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.Paint"
						"Microsoft.PowerAutomateDesktop"
						"Microsoft.ScreenSketch"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsTerminal"
						"Clipchamp.Clipchamp"
						"Microsoft.MicrosoftSolitaireCollection"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.ZuneMusic"
						"Microsoft.BingNews"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.WindowsCamera"
						"Microsoft.Getstarted"
						"Microsoft.Cortana"
						"Microsoft.GetHelp"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.People"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.WebMediaExtensions"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsCalculator"
						"Microsoft.windowscommunicationsapps"
						"Microsoft.WindowsSoundRecorder"
						"Microsoft.Xbox.TCUI"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxGamingOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.YourPhone"
						"Microsoft.ZuneVideo"
						"MicrosoftCorporationII.QuickAssist"
						"MicrosoftWindows.Client.WebExperience"
						"Microsoft.RawImageExtension"
						"MicrosoftCorporationII.MicrosoftFamily"
					)
				}
				#endregion

				#region ServerStandardCore, ServerStandard, ServerDatacenter
				@{
					Name = @(
						"Education"
						"Professional"
						"ProfessionalEducation"
						"ProfessionalWorkstation"
						"Enterprise"
						"IoTEnterprise"
						"ServerRdsh"

#						"ServerStandardCore"
						"ServerStandard"
#						"ServerDataCenterCore"
						"ServerDatacenter"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.UI.Xaml.2.8"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.HEIFImageExtension"
						"Microsoft.HEVCVideoExtension"
						"Microsoft.SecHealthUI"
						"Microsoft.VP9VideoExtensions"
						"Microsoft.WebpImageExtension"
						"Microsoft.WindowsStore"
						"Microsoft.GamingApp"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.Paint"
						"Microsoft.PowerAutomateDesktop"
						"Microsoft.ScreenSketch"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsTerminal"
						"Clipchamp.Clipchamp"
						"Microsoft.MicrosoftSolitaireCollection"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.ZuneMusic"
						"Microsoft.BingNews"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.WindowsCamera"
						"Microsoft.Getstarted"
						"Microsoft.Cortana"
						"Microsoft.GetHelp"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.People"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.WebMediaExtensions"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsCalculator"
						"Microsoft.windowscommunicationsapps"
						"Microsoft.WindowsSoundRecorder"
						"Microsoft.Xbox.TCUI"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxGamingOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.YourPhone"
						"Microsoft.ZuneVideo"
						"MicrosoftCorporationII.QuickAssist"
						"MicrosoftWindows.Client.WebExperience"
						"Microsoft.RawImageExtension"
					)
				}
				#endregion

				#region N
				@{
					Name = @(
						"EnterpriseN"
						"EnterpriseGN"
						"EnterpriseSN"
						"ProfessionalN"
						"EducationN"
						"ProfessionalWorkstationN"
						"ProfessionalEducationN"
						"CloudN"
						"CloudEN"
						"CloudEditionLN"
						"StarterN"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.UI.Xaml.2.8"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.SecHealthUI"
						"Microsoft.WindowsStore"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.Paint"
						"Microsoft.PowerAutomateDesktop"
						"Microsoft.ScreenSketch"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsTerminal"
						"Clipchamp.Clipchamp"
						"Microsoft.MicrosoftSolitaireCollection"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.BingNews"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.WindowsCamera"
						"Microsoft.Getstarted"
						"Microsoft.Cortana"
						"Microsoft.GetHelp"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.People"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsCalculator"
						"Microsoft.windowscommunicationsapps"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.YourPhone"
						"MicrosoftCorporationII.QuickAssist"
						"MicrosoftWindows.Client.WebExperience"
					)
				}
				#endregion
			)
			Rule = @(
				@{ Name = "Microsoft.UI.Xaml.2.3";                  Match = "UI.Xaml*{ARCHC}*2.3";             License = "UI.Xaml*{ARCHC}*2.3";             Dependencies = @(); }
				@{ Name = "Microsoft.UI.Xaml.2.4";                  Match = "UI.Xaml*{ARCHTag}*2.4";             License = "UI.Xaml*{ARCHTag}*2.4";             Dependencies = @(); }
				@{ Name = "Microsoft.UI.Xaml.2.7";                  Match = "UI.Xaml*{ARCHTag}*2.7";             License = "UI.Xaml*{ARCHTag}*2.7";             Dependencies = @(); }
				@{ Name = "Microsoft.UI.Xaml.2.8";                  Match = "UI.Xaml*{ARCHTag}*2.8";             License = "UI.Xaml*{ARCHTag}*2.8";             Dependencies = @(); }
				@{ Name = "Microsoft.NET.Native.Framework.2.2";     Match = "Native.Framework*{ARCHTag}*2.2";    License = "Native.Framework*{ARCHTag}*2.2";    Dependencies = @(); }
				@{ Name = "Microsoft.NET.Native.Runtime.2.2";       Match = "Native.Runtime*{ARCHTag}*2.2";      License = "Native.Runtime*{ARCHTag}*2.2";      Dependencies = @(); }
				@{ Name = "Microsoft.VCLibs.140.00";                Match = "VCLibs*{ARCHTag}";                  License = "VCLibs*{ARCHTag}";                  Dependencies = @(); }
				@{ Name = "Microsoft.VCLibs.140.00.UWPDesktop";     Match = "VCLibs*{ARCHTag}*Desktop";          License = "VCLibs*{ARCHTag}*Desktop";          Dependencies = @(); }
				@{ Name = "Microsoft.Services.Store.Engagement";    Match = "Services.Store.Engagement*{ARCHC}"; License = "Services.Store.Engagement*{ARCHC}"; Dependencies = @(); }
				@{ Name = "Microsoft.HEIFImageExtension";           Match = "HEIFImageExtension";                License = "HEIFImageExtension*";               Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.HEVCVideoExtension";           Match = "HEVCVideoExtension*{ARCHC}";        License = "HEVCVideoExtension*{ARCHC}*xml";    Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.SecHealthUI";                  Match = "SecHealthUI*{ARCHC}";               License = "SecHealthUI*{ARCHC}";               Dependencies = @("Microsoft.UI.Xaml.2.4", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.VP9VideoExtensions";           Match = "VP9VideoExtensions*{ARCHC}";        License = "VP9VideoExtensions*{ARCHC}";        Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WebpImageExtension";           Match = "WebpImageExtension*{ARCHC}";        License = "WebpImageExtension*{ARCHC}";        Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsStore";                 Match = "WindowsStore";                      License = "WindowsStore";                      Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.GamingApp";                    Match = "GamingApp";                         License = "GamingApp";                         Dependencies = @("Microsoft.UI.Xaml.2.3", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.MicrosoftStickyNotes";         Match = "MicrosoftStickyNotes";              License = "MicrosoftStickyNotes";              Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Paint";                        Match = "Paint";                             License = "Paint";                             Dependencies = @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop", "Microsoft.UI.Xaml.2.7"); }
				@{ Name = "Microsoft.PowerAutomateDesktop";         Match = "PowerAutomateDesktop";              License = "PowerAutomateDesktop";              Dependencies = @("Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.ScreenSketch";                 Match = "ScreenSketch";                      License = "ScreenSketch";                      Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsNotepad";               Match = "WindowsNotepad";                    License = "WindowsNotepad";                    Dependencies = @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop", "Microsoft.UI.Xaml.2.7"); }
				@{ Name = "Microsoft.WindowsTerminal";              Match = "WindowsTerminal";                   License = "WindowsTerminal";                   Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Clipchamp.Clipchamp";                    Match = "Clipchamp.Clipchamp";               License = "Clipchamp.Clipchamp";               Dependencies = @(); }
				@{ Name = "Microsoft.MicrosoftSolitaireCollection"; Match = "MicrosoftSolitaireCollection";      License = "MicrosoftSolitaireCollection";      Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsAlarms";                Match = "WindowsAlarms";                     License = "WindowsAlarms";                     Dependencies = @("Microsoft.UI.Xaml.2.8", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.WindowsFeedbackHub";           Match = "WindowsFeedbackHub";                License = "WindowsFeedbackHub";                Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsMaps";                  Match = "WindowsMaps";                       License = "WindowsMaps";                       Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.ZuneMusic";                    Match = "ZuneMusic";                         License = "ZuneMusic";                         Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "MicrosoftCorporationII.MicrosoftFamily"; Match = "MicrosoftFamily";                   License = "MicrosoftFamily";                   Dependencies = @("Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.BingNews";                     Match = "BingNews";                          License = "BingNews";                          Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.BingWeather";                  Match = "BingWeather";                       License = "BingWeather";                       Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.DesktopAppInstaller";          Match = "DesktopAppInstaller";               License = "DesktopAppInstaller";               Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.WindowsCamera";                Match = "WindowsCamera";                     License = "WindowsCamera";                     Dependencies = @("Microsoft.UI.Xaml.2.8", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Getstarted";                   Match = "Getstarted";                        License = "Getstarted";                        Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Cortana";                      Match = "Cortana";                           License = "Cortana";                           Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.GetHelp";                      Match = "GetHelp";                           License = "GetHelp";                           Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.MicrosoftOfficeHub";           Match = "MicrosoftOfficeHub";                License = "MicrosoftOfficeHub";                Dependencies = @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.People";                       Match = "People";                            License = "People";                            Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.StorePurchaseApp";             Match = "StorePurchaseApp";                  License = "StorePurchaseApp";                  Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Todos";                        Match = "Todos";                             License = "Todos";                             Dependencies = @("Microsoft.UI.Xaml.2.8", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop", "Microsoft.Services.Store.Engagement"); }
				@{ Name = "Microsoft.WebMediaExtensions";           Match = "WebMediaExtensions";                License = "WebMediaExtensions";                Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Windows.Photos";               Match = "Windows.Photos";                    License = "Windows.Photos";                    Dependencies = @("Microsoft.UI.Xaml.2.4", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsCalculator";            Match = "WindowsCalculator";                 License = "WindowsCalculator";                 Dependencies = @("Microsoft.UI.Xaml.2.8", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.windowscommunicationsapps";    Match = "WindowsCommunicationsApps";         License = "WindowsCommunicationsApps";         Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsSoundRecorder";         Match = "WindowsSoundRecorder";              License = "WindowsSoundRecorder";              Dependencies = @("Microsoft.UI.Xaml.2.3", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Xbox.TCUI";                    Match = "Xbox.TCUI";                         License = "Xbox.TCUI";                         Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.XboxGameOverlay";              Match = "XboxGameOverlay";                   License = "XboxGameOverlay";                   Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.XboxGamingOverlay";            Match = "XboxGamingOverlay";                 License = "XboxGamingOverlay";                 Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.XboxIdentityProvider";         Match = "XboxIdentityProvider";              License = "XboxIdentityProvider";              Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.XboxSpeechToTextOverlay";      Match = "XboxSpeechToTextOverlay";           License = "XboxSpeechToTextOverlay";           Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.YourPhone";                    Match = "YourPhone";                         License = "YourPhone";                         Dependencies = @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.ZuneVideo";                    Match = "ZuneVideo";                         License = "ZuneVideo";                         Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00"); }
				@{ Name = "MicrosoftCorporationII.QuickAssist";     Match = "QuickAssist";                       License = "QuickAssist";                       Dependencies = @("Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "MicrosoftWindows.Client.WebExperience";  Match = "WebExperience";                     License = "WebExperience";                     Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.MinecraftEducationEdition";    Match = "MinecraftEducationEdition";         License = "MinecraftEducationEdition";         Dependencies = @("Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.Whiteboard";                   Match = "Whiteboard";                        License = "Whiteboard";                        Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.RawImageExtension";            Match = "RawImageExtension";                 License = "RawImageExtension";                 Dependencies = @(); }
			)
		}
		Language = @{
			ISO = @(
				"https://software-static.download.prss.microsoft.com/dbazure/988969d5-f34g-4e03-ac9d-1f9786c66749/22621.1.220506-1250.ni_release_amd64fre_CLIENT_LOF_PACKAGES_OEM.iso"
			)
			Rule = @(
				@{
					Group = "Boot;Boot;"
					Rule = @(
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"; }
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "lp.cab";                           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "WinPE-Setup_{Lang}.cab";           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "WINPE-SETUP-CLIENT_{Lang}.CAB";    Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-securestartup_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-atbroker_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiocore_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiodrivers_{Lang}.cab";    Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-enhancedstorage_{Lang}.cab"; Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-narrator_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-scripting_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-speech-tts_{Lang}.cab";      Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srh_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srt_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wds-tools_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wmi_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
					)
				}
				@{
					Group = "Install;Install;"
					Rule = @(
						@{ Match = "Microsoft-Windows-LanguageFeatures-Fonts-{DiyLang}-Package~31bf3856ad364e35~{ARCH}~~.cab";     Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-Client-Language-Pack_{ARCHC}_{Lang}.cab";                                    Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-Basic-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";        Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-Handwriting-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";  Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-OCR-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";          Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-Speech-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";       Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-TextToSpeech-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab"; Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-InternetExplorer-Optional-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";      Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-Notepad-System-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";             Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-Notepad-System-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";              Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-MediaPlayer-Package-{ARCH}-{Lang}.cab";                                      Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-MediaPlayer-Package-wow64-{Lang}.cab";                                       Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-PowerShell-ISE-FOD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";             Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-PowerShell-ISE-FOD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";              Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-Printing-PMCPPC-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";            Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-StepsRecorder-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";                  Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-StepsRecorder-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                   Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-WMIC-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";                       Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-WMIC-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                        Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";                    Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                     Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                     Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-InternationalFeatures-{Specific}-Package~31bf3856ad364e35~{ARCH}~~.cab";     Structure = "LanguagesAndOptionalFeatures"; }
					)
				}
				@{
					Group = "Install;WinRE;"
					Rule = @(
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"; }
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "lp.cab";                           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-securestartup_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-atbroker_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiocore_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiodrivers_{Lang}.cab";    Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-enhancedstorage_{Lang}.cab"; Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-narrator_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-scripting_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-speech-tts_{Lang}.cab";      Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srh_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srt_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wds-tools_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wmi_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-appxdeployment_{Lang}.cab";  Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-appxpackaging_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-storagewmi_{Lang}.cab";      Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wifi_{Lang}.cab";            Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-windowsupdate_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-rejuv_{Lang}.cab";           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-opcservices_{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-hta_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
					)
				}
			)
		}
	}
	#endregion

	#region Windows 11 22H2
	@{
		GUID        = "ec9e0561-3496-4b1a-8b29-03e60e549adf"
		Author      = "Yi"
		Copyright   = "FengYi, Inc. All rights reserved."
		Name        = "Windows 11 22H2"
		ISO         = @(
			"en-us_windows_11_business_editions_version_22h2_x64_dvd_17a08ce3.iso"
			"en-us_windows_11_consumer_editions_version_22h2_x64_dvd_e630fafd.iso"
			"en-us_windows_11_iot_enterprise_version_22h2_x64_dvd_eb39bf70.iso"
			"en-us_windows_11_iot_enterprise_version_22h2_arm64_dvd_f09f5d29.iso"
		)
		Description = ""
		InboxApps   = @{
			ISO = @(
				"https://software-static.download.prss.microsoft.com/dbazure/888969d5-f34g-4e03-ac9d-1f9786c66749/22621.1778.230511-2102.ni_release_svc_prod3_amd64fre_InboxApps.iso"
				"https://software-static.download.prss.microsoft.com/dbazure/988969d5-f34g-4e03-ac9d-1f9786c66749/22621.1.220506-1250.ni_release_amd64fre_InboxApps.iso"
			)
			SN = @{
				Edition = @(
					"EnterpriseS"
					"EnterpriseSN"
					"IoTEnterpriseS"
				)
			}
			Edition = @(
				#region CloudEdition
				@{
					Name = @(
						"CloudEdition"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.VP9VideoExtensions"
						"Clipchamp.Clipchamp"
						"Microsoft.BingNews"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.GetHelp"
						"Microsoft.Getstarted"
						"Microsoft.HEIFImageExtension"
						"Microsoft.HEVCVideoExtension"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.MinecraftEducationEdition"
						"Microsoft.Paint"
						"Microsoft.RawImageExtension"
						"Microsoft.ScreenSketch"
						"Microsoft.SecHealthUI"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.WebMediaExtensions"
						"Microsoft.WebpImageExtension"
						"Microsoft.Whiteboard"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsCalculator"
						"Microsoft.WindowsCamera"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsSoundRecorder"
						"Microsoft.Xbox.TCUI"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.ZuneMusic"
						"Microsoft.ZuneVideo"
						"MicrosoftCorporationII.QuickAssist"
					)
				}
				#endregion

				#region CloudEditionN
				@{
					Name = @(
						"CloudEditionN"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.XboxSpeechToTextOverlay"
						"Clipchamp.Clipchamp"
						"Microsoft.BingNews"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.GetHelp"
						"Microsoft.Getstarted"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.MinecraftEducationEdition"
						"Microsoft.Paint"
						"Microsoft.ScreenSketch"
						"Microsoft.SecHealthUI"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Whiteboard"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsCalculator"
						"Microsoft.WindowsCamera"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.WindowsNotepad"
						"Microsoft.XboxIdentityProvider"
						"MicrosoftCorporationII.QuickAssist"
					)
				}
				#endregion

				@{
					Name = @(
						"Core"
						"CoreN"
						"CoreSingleLanguage"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.HEIFImageExtension"
						"Microsoft.HEVCVideoExtension"
						"Microsoft.SecHealthUI"
						"Microsoft.VP9VideoExtensions"
						"Microsoft.WebpImageExtension"
						"Microsoft.WindowsStore"
						"Microsoft.GamingApp"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.Paint"
						"Microsoft.PowerAutomateDesktop"
						"Microsoft.ScreenSketch"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsTerminal"
						"Clipchamp.Clipchamp"
						"Microsoft.MicrosoftSolitaireCollection"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.ZuneMusic"
						"Microsoft.BingNews"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.WindowsCamera"
						"Microsoft.Getstarted"
						"Microsoft.Cortana"
						"Microsoft.GetHelp"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.People"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.WebMediaExtensions"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsCalculator"
						"Microsoft.windowscommunicationsapps"
						"Microsoft.WindowsSoundRecorder"
						"Microsoft.Xbox.TCUI"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxGamingOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.YourPhone"
						"Microsoft.ZuneVideo"
						"MicrosoftCorporationII.QuickAssist"
						"MicrosoftWindows.Client.WebExperience"
						"Microsoft.RawImageExtension"
						"MicrosoftCorporationII.MicrosoftFamily"
					)
				}
				@{
					Name = @(
						"Education"
						"Professional"
						"ProfessionalEducation"
						"ProfessionalWorkstation"
						"Enterprise"
						"IoTEnterprise"
						"ServerRdsh"

#						"ServerStandardCore"
						"ServerStandard"
#						"ServerDataCenterCore"
						"ServerDatacenter"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.HEIFImageExtension"
						"Microsoft.HEVCVideoExtension"
						"Microsoft.SecHealthUI"
						"Microsoft.VP9VideoExtensions"
						"Microsoft.WebpImageExtension"
						"Microsoft.WindowsStore"
						"Microsoft.GamingApp"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.Paint"
						"Microsoft.PowerAutomateDesktop"
						"Microsoft.ScreenSketch"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsTerminal"
						"Clipchamp.Clipchamp"
						"Microsoft.MicrosoftSolitaireCollection"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.ZuneMusic"
						"Microsoft.BingNews"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.WindowsCamera"
						"Microsoft.Getstarted"
						"Microsoft.Cortana"
						"Microsoft.GetHelp"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.People"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.WebMediaExtensions"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsCalculator"
						"Microsoft.windowscommunicationsapps"
						"Microsoft.WindowsSoundRecorder"
						"Microsoft.Xbox.TCUI"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxGamingOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.YourPhone"
						"Microsoft.ZuneVideo"
						"MicrosoftCorporationII.QuickAssist"
						"MicrosoftWindows.Client.WebExperience"
						"Microsoft.RawImageExtension"
					)
				}
				@{
					Name = @(
						"EnterpriseN"
						"EnterpriseGN"
						"EnterpriseSN"
						"ProfessionalN"
						"EducationN"
						"ProfessionalWorkstationN"
						"ProfessionalEducationN"
						"CloudN"
						"CloudEN"
						"CloudEditionLN"
						"StarterN"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.SecHealthUI"
						"Microsoft.WindowsStore"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.Paint"
						"Microsoft.PowerAutomateDesktop"
						"Microsoft.ScreenSketch"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsTerminal"
						"Clipchamp.Clipchamp"
						"Microsoft.MicrosoftSolitaireCollection"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.BingNews"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.WindowsCamera"
						"Microsoft.Getstarted"
						"Microsoft.Cortana"
						"Microsoft.GetHelp"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.People"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsCalculator"
						"Microsoft.windowscommunicationsapps"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.YourPhone"
						"MicrosoftCorporationII.QuickAssist"
						"MicrosoftWindows.Client.WebExperience"
					)
				}
			)
			Rule = @(
				@{ Name = "Microsoft.UI.Xaml.2.3";                  Match = "UI.Xaml*{ARCHTag}*2.3";          License = "UI.Xaml*{ARCHTag}*2.3";          Dependencies = @(); }
				@{ Name = "Microsoft.UI.Xaml.2.4";                  Match = "UI.Xaml*{ARCHTag}*2.4";          License = "UI.Xaml*{ARCHTag}*2.4";          Dependencies = @(); }
				@{ Name = "Microsoft.UI.Xaml.2.7";                  Match = "UI.Xaml*{ARCHTag}*2.7";          License = "UI.Xaml*{ARCHTag}*2.7";          Dependencies = @(); }
				@{ Name = "Microsoft.NET.Native.Framework.2.2";     Match = "Native.Framework*{ARCHTag}*2.2"; License = "Native.Framework*{ARCHTag}*2.2"; Dependencies = @(); }
				@{ Name = "Microsoft.NET.Native.Runtime.2.2";       Match = "Native.Runtime*{ARCHTag}*2.2";   License = "Native.Runtime*{ARCHTag}*2.2";   Dependencies = @(); }
				@{ Name = "Microsoft.VCLibs.140.00";                Match = "VCLibs*{ARCHTag}";               License = "VCLibs*{ARCHTag}";               Dependencies = @(); }
				@{ Name = "Microsoft.VCLibs.140.00.UWPDesktop";     Match = "VCLibs*{ARCHTag}*Desktop";       License = "VCLibs*{ARCHTag}*Desktop";       Dependencies = @(); }
				@{ Name = "Microsoft.HEIFImageExtension";           Match = "HEIFImageExtension";             License = "HEIFImageExtension*";            Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.HEVCVideoExtension";           Match = "HEVCVideoExtension*{ARCHC}";     License = "HEVCVideoExtension*{ARCHC}*xml"; Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.SecHealthUI";                  Match = "SecHealthUI*{ARCHC}";            License = "SecHealthUI*{ARCHC}";            Dependencies = @("Microsoft.UI.Xaml.2.4", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.VP9VideoExtensions";           Match = "VP9VideoExtensions*{ARCHC}";     License = "VP9VideoExtensions*{ARCHC}";     Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WebpImageExtension";           Match = "WebpImageExtension*{ARCHC}";     License = "WebpImageExtension*{ARCHC}";     Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsStore";                 Match = "WindowsStore";                   License = "WindowsStore";                   Dependencies = @("Microsoft.UI.Xaml.2.3", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.GamingApp";                    Match = "GamingApp";                      License = "GamingApp";                      Dependencies = @("Microsoft.UI.Xaml.2.3", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.MicrosoftStickyNotes";         Match = "Microsoft.Sticky.Notes";         License = "MicrosoftStickyNotes";           Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Paint";                        Match = "Paint";                          License = "Paint";                          Dependencies = @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop", "Microsoft.UI.Xaml.2.7"); }
				@{ Name = "Microsoft.PowerAutomateDesktop";         Match = "PowerAutomateDesktop";           License = "PowerAutomateDesktop";           Dependencies = @("Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.ScreenSketch";                 Match = "ScreenSketch";                   License = "ScreenSketch";                   Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsNotepad";               Match = "WindowsNotepad";                 License = "WindowsNotepad";                 Dependencies = @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop", "Microsoft.UI.Xaml.2.7"); }
				@{ Name = "Microsoft.WindowsTerminal";              Match = "WindowsTerminal";                License = "WindowsTerminal";                Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Clipchamp.Clipchamp";                    Match = "Clipchamp.Clipchamp";            License = "Clipchamp.Clipchamp";            Dependencies = @(); }
				@{ Name = "Microsoft.MicrosoftSolitaireCollection"; Match = "MicrosoftSolitaireCollection";   License = "MicrosoftSolitaireCollection";   Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsAlarms";                Match = "WindowsAlarms";                  License = "WindowsAlarms";                  Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsFeedbackHub";           Match = "WindowsFeedbackHub";             License = "WindowsFeedbackHub";             Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsMaps";                  Match = "WindowsMaps";                    License = "WindowsMaps";                    Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.ZuneMusic";                    Match = "ZuneMusic";                      License = "ZuneMusic";                      Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00"); }
				@{ Name = "MicrosoftCorporationII.MicrosoftFamily"; Match = "MicrosoftFamily";                License = "MicrosoftFamily";                Dependencies = @(); }
				@{ Name = "Microsoft.BingNews";                     Match = "BingNews";                       License = "BingNews";                       Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.BingWeather";                  Match = "BingWeather";                    License = "BingWeather";                    Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.DesktopAppInstaller";          Match = "DesktopAppInstaller";            License = "DesktopAppInstaller";            Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.WindowsCamera";                Match = "WindowsCamera";                  License = "WindowsCamera";                  Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Getstarted";                   Match = "Getstarted";                     License = "Getstarted";                     Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Cortana";                      Match = "Cortana";                        License = "Cortana";                        Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.GetHelp";                      Match = "GetHelp";                        License = "GetHelp";                        Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.MicrosoftOfficeHub";           Match = "MicrosoftOfficeHub";             License = "MicrosoftOfficeHub";             Dependencies = @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.People";                       Match = "People";                         License = "People";                         Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.StorePurchaseApp";             Match = "StorePurchaseApp";               License = "StorePurchaseApp";               Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Todos";                        Match = "Todos";                          License = "Todos";                          Dependencies = @("Microsoft.UI.Xaml.2.4", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WebMediaExtensions";           Match = "WebMediaExtensions";             License = "WebMediaExtensions";             Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Windows.Photos";               Match = "Windows.Photos";                 License = "Windows.Photos";                 Dependencies = @("Microsoft.UI.Xaml.2.4", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsCalculator";            Match = "WindowsCalculator";              License = "WindowsCalculator";              Dependencies = @("Microsoft.UI.Xaml.2.4", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.windowscommunicationsapps";    Match = "WindowsCommunicationsApps";      License = "WindowsCommunicationsApps";      Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.WindowsSoundRecorder";         Match = "WindowsSoundRecorder";           License = "WindowsSoundRecorder";           Dependencies = @("Microsoft.UI.Xaml.2.3", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.Xbox.TCUI";                    Match = "Xbox.TCUI";                      License = "Xbox.TCUI";                      Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.XboxGameOverlay";              Match = "XboxGameOverlay";                License = "XboxGameOverlay";                Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.XboxGamingOverlay";            Match = "XboxGamingOverlay";              License = "XboxGamingOverlay";              Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.XboxIdentityProvider";         Match = "XboxIdentityProvider";           License = "XboxIdentityProvider";           Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.XboxSpeechToTextOverlay";      Match = "XboxSpeechToTextOverlay";        License = "XboxSpeechToTextOverlay";        Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.YourPhone";                    Match = "YourPhone";                      License = "YourPhone";                      Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.ZuneVideo";                    Match = "ZuneVideo";                      License = "ZuneVideo";                      Dependencies = @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00"); }
				@{ Name = "MicrosoftCorporationII.QuickAssist";     Match = "QuickAssist";                    License = "QuickAssist";                    Dependencies = @(); }
				@{ Name = "MicrosoftWindows.Client.WebExperience";  Match = "WebExperience";                  License = "WebExperience";                  Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.MinecraftEducationEdition";    Match = "MinecraftEducationEdition";      License = "MinecraftEducationEdition";      Dependencies = @("Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.Whiteboard";                   Match = "Whiteboard";                     License = "Whiteboard";                     Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.RawImageExtension";            Match = "RawImageExtension";              License = "RawImageExtension";              Dependencies = @(); }
			)
		}
		Language = @{
			ISO = @(
				"https://software-static.download.prss.microsoft.com/dbazure/988969d5-f34g-4e03-ac9d-1f9786c66749/22621.1.220506-1250.ni_release_amd64fre_CLIENT_LOF_PACKAGES_OEM.iso"
				"https://software-download.microsoft.com/download/sg/22000.1.210604-1628.co_release_amd64fre_CLIENT_LOF_PACKAGES_OEM.iso"
			)
			Rule = @(
				@{
					Group = "Boot;Boot;"
					Rule = @(
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"; }
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "lp.cab";                           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "WinPE-Setup_{Lang}.cab";           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "WINPE-SETUP-CLIENT_{Lang}.CAB";    Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-securestartup_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-atbroker_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiocore_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiodrivers_{Lang}.cab";    Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-enhancedstorage_{Lang}.cab"; Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-narrator_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-scripting_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-speech-tts_{Lang}.cab";      Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srh_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srt_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wds-tools_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wmi_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
					)
				}
				@{
					Group = "Install;Install;"
					Rule = @(
						@{ Match = "Microsoft-Windows-LanguageFeatures-Fonts-{DiyLang}-Package~31bf3856ad364e35~{ARCH}~~.cab";     Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-Client-Language-Pack_{ARCHC}_{Lang}.cab";                                    Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-Basic-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";        Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-Handwriting-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";  Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-OCR-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";          Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-Speech-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";       Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-TextToSpeech-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab"; Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-InternetExplorer-Optional-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";      Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-Notepad-System-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";             Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-Notepad-System-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";              Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-MediaPlayer-Package-{ARCH}-{Lang}.cab";                                      Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-MediaPlayer-Package-wow64-{Lang}.cab";                                       Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-PowerShell-ISE-FOD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";             Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-PowerShell-ISE-FOD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";              Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-Printing-PMCPPC-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";            Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-StepsRecorder-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";                  Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-StepsRecorder-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                   Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-WMIC-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";                       Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-WMIC-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                        Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";                    Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                     Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                     Structure = "LanguagesAndOptionalFeatures"; }
						@{ Match = "Microsoft-Windows-InternationalFeatures-{Specific}-Package~31bf3856ad364e35~{ARCH}~~.cab";     Structure = "LanguagesAndOptionalFeatures"; }
					)
				}
				@{
					Group = "Install;WinRE;"
					Rule = @(
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"; }
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "lp.cab";                           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-securestartup_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-atbroker_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiocore_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiodrivers_{Lang}.cab";    Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-enhancedstorage_{Lang}.cab"; Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-narrator_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-scripting_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-speech-tts_{Lang}.cab";      Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srh_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srt_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wds-tools_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wmi_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-appxdeployment_{Lang}.cab";  Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-appxpackaging_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-storagewmi_{Lang}.cab";      Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wifi_{Lang}.cab";            Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-windowsupdate_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-rejuv_{Lang}.cab";           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-opcservices_{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-hta_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
					)
				}
			)
		}
	}
	#endregion

	#region Windows 10
	@{
		GUID        = "d33b848d-ef73-470b-ba0e-8b7f21536ccd"
		Author      = "Yi"
		Copyright   = "FengYi, Inc. All rights reserved."
		Name        = "Windows 10"
		ISO         = @(
			"en-us_windows_10_business_editions_version_22h2_x64_dvd_8cf17b79.iso"
			"en-us_windows_10_business_editions_version_22h2_x86_dvd_186a68c3.iso"
			"en-us_windows_10_consumer_editions_version_22h2_x64_dvd_8da72ab3.iso"
			"en-us_windows_10_consumer_editions_version_22h2_x86_dvd_90883feb.iso"
			"en-us_windows_10_iot_enterprise_version_22h2_arm64_dvd_39566b6b.iso"
			"en-us_windows_10_iot_enterprise_version_22h2_x64_dvd_51cc370f.iso"

			"en-us_windows_10_enterprise_ltsc_2021_x64_dvd_d289cf96.iso"
			"en-us_windows_10_enterprise_ltsc_2021_x86_dvd_9f4aa95f.iso"
			"en-us_windows_10_iot_enterprise_ltsc_2021_x64_dvd_257ad90f.iso"
			"en_windows_10_business_editions_version_21h1_x64_dvd_ec5a76c1.iso"
			"en_windows_10_business_editions_version_21h1_x86_dvd_1495793c.iso"
			"en_windows_10_consumer_editions_version_21h1_x64_dvd_540c0dd4.iso"
			"en_windows_10_consumer_editions_version_21h1_x86_dvd_68cee121.iso"
			
			"en_windows_10_business_editions_version_20h2_x64_dvd_4788fb7c.iso"
			"en_windows_10_business_editions_version_20h2_x86_dvd_fae4084e.iso"
			"en_windows_10_consumer_editions_version_20h2_x64_dvd_ab0e3e0a.iso"
			"en_windows_10_consumer_editions_version_20h2_x86_dvd_ea9a9e3f.iso"
			"en_windows_10_iot_enterprise_version_20h2_arm64_dvd_fe0947da.iso"
			"en_windows_10_iot_enterprise_version_20h2_x64_dvd_c6ef5325.iso"
			
			"en_windows_10_business_editions_version_2004_x64_dvd_d06ef8c5.iso"
			"en_windows_10_business_editions_version_2004_x86_dvd_52bfcce8.iso"
			"en_windows_10_consumer_editions_version_2004_x64_dvd_8d28c5d7.iso"
			"en_windows_10_consumer_editions_version_2004_x86_dvd_fa759348.iso"
			
			"en_windows_10_business_editions_version_1909_x64_dvd_ada535d0.iso"
			"en_windows_10_business_editions_version_1909_x86_dvd_3a5b8f60.iso"
			"en_windows_10_consumer_editions_version_1909_x64_dvd_be09950e.iso"
			"en_windows_10_consumer_editions_version_1909_x86_dvd_10bde8bb.iso"
			
			"en_windows_10_business_editions_version_1903_x64_dvd_37200948.iso"
			"en_windows_10_business_editions_version_1903_x86_dvd_ca4f0f49.iso"
			"en_windows_10_consumer_editions_version_1903_x64_dvd_b980e68c.iso"
			"en_windows_10_consumer_editions_version_1903_x86_dvd_b40c5211.iso"
		)
		Description = ""
		InboxApps   = @{
			ISO = @(
				"https://software-static.download.prss.microsoft.com/dbazure/888969d5-f34g-4e03-ac9d-1f9786c66749/19041.3031.230508-1728.vb_release_svc_prod3_amd64fre_InboxApps.iso"
			)
			Edition = @(
				@{
					Name = @(
						"Core"
						"CoreSingleLanguage"
						"Education"
						"Professional"
						"ProfessionalEducation"
						"ProfessionalWorkstation"
						"Enterprise"
						"IoTEnterprise"
						"ServerRdsh"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.0"
						"Microsoft.UI.Xaml.2.1"
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.Advertising.Xaml"
						"Microsoft.NET.Native.Framework.1.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.1.7"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.HEIFImageExtension"
						"Microsoft.WebpImageExtension"
						"Microsoft.VP9VideoExtensions"
						"Microsoft.WindowsStore"
						"Microsoft.Xbox.TCUI"
						"Microsoft.XboxApp"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxGamingOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.Cortana"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.GetHelp"
						"Microsoft.Getstarted"
						"Microsoft.Microsoft3DViewer"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.MicrosoftSolitaireCollection"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.MixedReality.Portal"
						"Microsoft.MSPaint"
						"Microsoft.Office.OneNote"
						"Microsoft.People"
						"Microsoft.ScreenSketch"
						"Microsoft.SkypeApp"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Wallet"
						"Microsoft.WebMediaExtensions"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsCalculator"
						"Microsoft.WindowsCamera"
						"Microsoft.windowscommunicationsapps"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.WindowsSoundRecorder"
						"Microsoft.YourPhone"
						"Microsoft.ZuneMusic"
						"Microsoft.ZuneVideo"
					)
				}
				@{
					Name = @(
						"EnterpriseN"
						"EnterpriseGN"
						"EnterpriseSN"
						"ProfessionalN"
						"CoreN"
						"EducationN"
						"ProfessionalWorkstationN"
						"ProfessionalEducationN"
						"CloudN"
						"CloudEN"
						"CloudEditionLN"
						"StarterN"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.0"
						"Microsoft.UI.Xaml.2.1"
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.Advertising.Xaml"
						"Microsoft.NET.Native.Framework.1.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.1.7"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.WindowsStore"
						"Microsoft.XboxApp"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.Cortana"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.GetHelp"
						"Microsoft.Getstarted"
						"Microsoft.Microsoft3DViewer"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.MicrosoftSolitaireCollection"
						"Microsoft.MicrosoftStickyNotes"
						"Microsoft.MSPaint"
						"Microsoft.Office.OneNote"
						"Microsoft.People"
						"Microsoft.ScreenSketch"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Wallet"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsCalculator"
						"Microsoft.WindowsCamera"
						"Microsoft.windowscommunicationsapps"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.YourPhone"
					)
				}
			)
			Rule = @(
				@{ Name ="Microsoft.UI.Xaml.2.0";                       Match = "UI.Xaml*2.0";                       License = "UI.Xaml*2.0";                       Dependencies = @(); }
				@{ Name ="Microsoft.UI.Xaml.2.1";                       Match = "UI.Xaml*2.1";                       License = "UI.Xaml*2.1";                       Dependencies = @(); }
				@{ Name ="Microsoft.UI.Xaml.2.3";                       Match = "UI.Xaml*2.3";                       License = "UI.Xaml*2.3";                       Dependencies = @(); }
				@{ Name ="Microsoft.Advertising.Xaml";                  Match = "Advertising.Xaml";                  License = "Advertising.Xaml";                  Dependencies = @(); }
				@{ Name ="Microsoft.NET.Native.Framework.1.7";          Match = "Native.Framework*1.7";              License = "Native.Framework*1.7";              Dependencies = @(); }
				@{ Name ="Microsoft.NET.Native.Framework.2.2";          Match = "Native.Framework*2.2";              License = "Native.Framework*2.2";              Dependencies = @(); }
				@{ Name ="Microsoft.NET.Native.Runtime.1.7";            Match = "Native.Runtime*1.7";                License = "Native.Runtime*1.7";                Dependencies = @(); }
				@{ Name ="Microsoft.NET.Native.Runtime.2.2";            Match = "Native.Runtime*2.2";                License = "Native.Runtime*2.2";                Dependencies = @(); }
				@{ Name ="Microsoft.VCLibs.140.00";                     Match = "VCLibs*14.00";                      License = "VCLibs*14.00";                      Dependencies = @(); }
				@{ Name ="Microsoft.VCLibs.140.00.UWPDesktop";          Match = "VCLibs*Desktop";                    License = "VCLibs*Desktop";                    Dependencies = @(); }
				@{ Name ="Microsoft.Services.Store.Engagement*{ARCHC}"; Match = "Services.Store.Engagement*{ARCHC}"; License = "Services.Store.Engagement*{ARCHC}"; Dependencies = @(); }
				@{ Name ="Microsoft.HEIFImageExtension";                Match = "HEIFImageExtension";                License = "HEIFImageExtension";                Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.WebpImageExtension";                Match = "WebpImageExtension";                License = "WebpImageExtension";                Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.VP9VideoExtensions";                Match = "VP9VideoExtensions";                License = "VP9VideoExtensions";                Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.WindowsStore";                      Match = "WindowsStore";                      License = "WindowsStore";                      Dependencies = @("Microsoft.UI.Xaml.2.3"; "Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.Xbox.TCUI";                         Match = "Xbox.TCUI";                         License = "Xbox.TCUI";                         Dependencies = @("Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.XboxApp";                           Match = "XboxApp";                           License = "XboxApp";                           Dependencies = @("Microsoft.NET.Native.Framework.1.7"; "Microsoft.NET.Native.Runtime.1.7"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.XboxGameOverlay";                   Match = "XboxGameOverlay";                   License = "XboxGameOverlay";                   Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.XboxGamingOverlay";                 Match = "XboxGamingOverlay";                 License = "XboxGamingOverlay";                 Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.XboxIdentityProvider";              Match = "XboxIdentityProvider";              License = "XboxIdentityProvider";              Dependencies = @("Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.XboxSpeechToTextOverlay";           Match = "XboxSpeechToTextOverlay";           License = "XboxSpeechToTextOverlay";           Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.Cortana";                           Match = "Cortana";                           License = "Cortana";                           Dependencies = @("Microsoft.UI.Xaml.2.3"; "Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"; "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name ="Microsoft.BingWeather";                       Match = "BingWeather";                       License = "BingWeather";                       Dependencies = @("Microsoft.UI.Xaml.2.1"; "Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"; "Microsoft.Advertising.Xaml"); }
				@{ Name ="Microsoft.DesktopAppInstaller";               Match = "DesktopAppInstaller";               License = "DesktopAppInstaller";               Dependencies = @("Microsoft.VCLibs.140.00"; "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name ="Microsoft.GetHelp";                           Match = "GetHelp";                           License = "GetHelp";                           Dependencies = @("Microsoft.NET.Native.Framework.1.7"; "Microsoft.NET.Native.Runtime.1.7"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.Getstarted";                        Match = "Getstarted";                        License = "Getstarted";                        Dependencies = @("Microsoft.UI.Xaml.2.3"; "Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.Microsoft3DViewer";                 Match = "Microsoft3DViewer";                 License = "Microsoft3DViewer";                 Dependencies = @("Microsoft.UI.Xaml.2.1"; "Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"; "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name ="Microsoft.MicrosoftOfficeHub";                Match = "MicrosoftOfficeHub";                License = "MicrosoftOfficeHub";                Dependencies = @("Microsoft.VCLibs.140.00"; "Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.MicrosoftSolitaireCollection";     Match = "MicrosoftSolitaireCollection";      License = "MicrosoftSolitaireCollection";      Dependencies = @("Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.MicrosoftStickyNotes";              Match = "MicrosoftStickyNotes";              License = "MicrosoftStickyNotes";              Dependencies = @("Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"; "Microsoft.Services.Store.Engagement"); }
				@{ Name ="Microsoft.MixedReality.Portal";               Match = "MixedReality.Portal";               License = "MixedReality.Portal";               Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.MSPaint";                           Match = "MSPaint";                           License = "MSPaint";                           Dependencies = @("Microsoft.UI.Xaml.2.0"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.Office.OneNote";                    Match = "Office.OneNote";                    License = "Office.OneNote";                    Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.People";                            Match = "People";                            License = "People";                            Dependencies = @("Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.ScreenSketch";                      Match = "ScreenSketch";                      License = "ScreenSketch";                      Dependencies = @("Microsoft.UI.Xaml.2.0"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.SkypeApp";                          Match = "SkypeApp";                          License = "SkypeApp";                          Dependencies = @("Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.StorePurchaseApp";                  Match = "StorePurchaseApp";                  License = "StorePurchaseApp";                  Dependencies = @("Microsoft.NET.Native.Framework.1.7"; "Microsoft.NET.Native.Runtime.1.7"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.Wallet";                            Match = "Wallet";                            License = "Wallet";                            Dependencies = @("Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.WebMediaExtensions";                Match = "WebMediaExtensions";                License = "WebMediaExtensions";                Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.Windows.Photos";                    Match = "Windows.Photos";                    License = "Windows.Photos";                    Dependencies = @("Microsoft.UI.Xaml.2.0"; "Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.WindowsAlarms";                     Match = "WindowsAlarms";                     License = "WindowsAlarms";                     Dependencies = @("Microsoft.UI.Xaml.2.3"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.WindowsCalculator";                 Match = "WindowsCalculator";                 License = "WindowsCalculator";                 Dependencies = @("Microsoft.UI.Xaml.2.0"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.WindowsCamera";                     Match = "WindowsCamera";                     License = "WindowsCamera";                     Dependencies = @("Microsoft.NET.Native.Framework.1.7"; "Microsoft.NET.Native.Runtime.1.7"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.windowscommunicationsapps";         Match = "windowscommunicationsapps";         License = "windowscommunicationsapps";         Dependencies = @("Microsoft.Advertising.Xaml"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.WindowsFeedbackHub";                Match = "WindowsFeedbackHub";                License = "WindowsFeedbackHub";                Dependencies = @("Microsoft.UI.Xaml.2.0"; "Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.WindowsMaps";                       Match = "WindowsMaps";                       License = "WindowsMaps";                       Dependencies = @("Microsoft.UI.Xaml.2.3"; "Microsoft.NET.Native.Framework.2.2"; "Microsoft.NET.Native.Runtime.2.2"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.WindowsSoundRecorder";              Match = "WindowsSoundRecorder";              License = "WindowsSoundRecorder";              Dependencies = @("Microsoft.UI.Xaml.2.3"; "Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.YourPhone";                         Match = "YourPhone";                         License = "YourPhone";                         Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.ZuneMusic";                         Match = "ZuneMusic";                         License = "ZuneMusic";                         Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name ="Microsoft.ZuneVideo";                         Match = "ZuneVideo";                         License = "ZuneVideo";                         Dependencies = @("Microsoft.VCLibs.140.00"); }
				@{ Name = "Microsoft.MinecraftEducationEdition";        Match = "MinecraftEducationEdition";         License = "MinecraftEducationEdition";         Dependencies = @("Microsoft.VCLibs.140.00.UWPDesktop"); }
				@{ Name = "Microsoft.Whiteboard";                       Match = "Whiteboard";                        License = "Whiteboard";                        Dependencies = @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00"); }
			)
		}
		Language = @{
			ISO = @(
				"https://software-download.microsoft.com/download/pr/19041.1.191206-1406.vb_release_CLIENTLANGPACKDVD_OEM_MULTI.iso"
				"https://software-download.microsoft.com/download/pr/19041.1.191206-1406.vb_release_amd64fre_FOD-PACKAGES_OEM_PT1_amd64fre_MULTI.iso"
			)
			Rule = @(
				@{
					Group = "Boot;Boot;"
					Rule = @(
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"; }
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "lp.cab";                           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "WinPE-Setup_{Lang}.cab";           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "WINPE-SETUP-CLIENT_{Lang}.CAB";    Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-securestartup_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-atbroker_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiocore_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiodrivers_{Lang}.cab";    Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-enhancedstorage_{Lang}.cab"; Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-narrator_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-scripting_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-speech-tts_{Lang}.cab";      Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srh_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srt_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wds-tools_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wmi_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
					)
				}
				@{
					Group = "Install;Install;"
					Rule = @(
						@{ Match = "Microsoft-Windows-LanguageFeatures-Fonts-{DiyLang}-Package~31bf3856ad364e35~{ARCH}~~.cab";     Structure = ""; }
						@{ Match = "Microsoft-Windows-Client-Language-Pack_{ARCHC}_{Lang}.cab";                                    Structure = "{ARCHC}\langpacks"; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-Basic-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";        Structure = ""; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-Handwriting-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";  Structure = ""; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-OCR-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";          Structure = ""; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-Speech-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab";       Structure = ""; }
						@{ Match = "Microsoft-Windows-LanguageFeatures-TextToSpeech-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab"; Structure = ""; }
						@{ Match = "Microsoft-Windows-InternetExplorer-Optional-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";      Structure = ""; }
						@{ Match = "Microsoft-Windows-MSPaint-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                     Structure = ""; }
						@{ Match = "Microsoft-Windows-MSPaint-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";                    Structure = ""; }
						@{ Match = "Microsoft-Windows-Notepad-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                     Structure = ""; }
						@{ Match = "Microsoft-Windows-Notepad-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";                    Structure = ""; }
						@{ Match = "Microsoft-Windows-PowerShell-ISE-FOD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";              Structure = ""; }
						@{ Match = "Microsoft-Windows-PowerShell-ISE-FOD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";             Structure = ""; }
						@{ Match = "Microsoft-Windows-Printing-WFS-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";               Structure = ""; }
						@{ Match = "Microsoft-Windows-Printing-PMCPPC-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";            Structure = ""; }
						@{ Match = "Microsoft-Windows-StepsRecorder-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                   Structure = ""; }
						@{ Match = "Microsoft-Windows-StepsRecorder-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";                  Structure = ""; }
						@{ Match = "Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab";                     Structure = ""; }
						@{ Match = "Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab";                    Structure = ""; }
						@{ Match = "Microsoft-Windows-InternationalFeatures-{Specific}-Package~31bf3856ad364e35~{ARCH}~~.cab";     Structure = ""; }
					)
				}
				@{
					Group = "Install;WinRE;"
					Rule = @(
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"; }
						@{ Match = "WinPE-FontSupport-{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "lp.cab";                           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-securestartup_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-atbroker_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiocore_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-audiodrivers_{Lang}.cab";    Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-enhancedstorage_{Lang}.cab"; Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-narrator_{Lang}.cab";        Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-scripting_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-speech-tts_{Lang}.cab";      Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srh_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-srt_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wds-tools_{Lang}.cab";       Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wmi_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-appxpackaging_{Lang}.cab";   Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-storagewmi_{Lang}.cab";      Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-wifi_{Lang}.cab";            Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-rejuv_{Lang}.cab";           Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-opcservices_{Lang}.cab";     Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
						@{ Match = "winpe-hta_{Lang}.cab";             Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"; }
					)
				}
			)
		}
	}
	#endregion
)

<#
	Template

	@{
		GUID        = "Template"
		Author      = ""
		Copyright   = ""
		Name        = "Template"
		ISO         = @(
			""
		)
		Description = ""
		InboxApps   = @{
			ISO = @(
				""
			)
			SN = @{
				Edition = @(
					"EnterpriseS"
					"EnterpriseSN"
					"IoTEnterpriseS"
				)
			}
			Edition = @(
				@{
					Name = @(
						"Core"
						"CoreN"
						"CoreSingleLanguage"
						"EnterpriseN"
						"EnterpriseGN"
						"EnterpriseSN"
						"ProfessionalN"
						"EducationN"
						"ProfessionalWorkstationN"
						"ProfessionalEducationN"
						"CloudN"
						"CloudEN"
						"CloudEditionLN"
						"StarterN"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
					)
				}
			)
			Rule = @(
				@{ Name ="Microsoft.ZuneVideo"; Match = "ZuneVideo"; License = "ZuneVideo"; Dependencies = @("Microsoft.VCLibs.140.00"); }
			)
		}
		Language = @{
			ISO = @()
			Rule = @(
				@{
					Group = "Boot;Boot;"
					Rule = @(
						@{ Match = "WinPE-FontSupport-{Lang}.cab"; Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"; }
					)
				}
				@{
					Group = "Install;Install;"
					Rule = @(
						@{ Match = "WinPE-FontSupport-{Lang}.cab"; Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"; }
					)
				}
				@{
					Group = "Install;WinRE;"
					Rule = @(
						@{ Match = "WinPE-FontSupport-{Lang}.cab"; Structure = "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"; }
					)
				}
			)
		}
	}
#>