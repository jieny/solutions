﻿<#
	.Exclusions when removing all UWP apps
	.删除所有 UWP 应用时排除项
#>
$Global:ExcludeUWPDeletedItems = @(
	"*Advertising.Xaml*"
	"*DesktopAppInstaller*"
	"*Native.Framework*1.7*"
	"*Native.Framework*2.2*"
	"*Native.Runtime*1.7*"
	"*Native.Runtime*2.2*"
	"*Services.Store.Engagement*"
	"*SecHealthUI*"
	"*UI.Xaml*2.0*"
	"*UI.Xaml*2.1*"
	"*UI.Xaml*2.3*"
	"*VCLibs*"
)

<#
	.预配置规则

	 Group        = 名称
	 GUID         = 规则唯一标识符
	 Description  = 描述

	* InBox Apps
	 	ISO       = 规则命名通过验证 ISO 文件。
		SN        = S 版、SN 版
		            Edition = Windows 操作系统版本识别

		N         = N 版
				    Edition = Windows 操作系统版本识别
					Exclude = 遇到 N 版时，排除的应用规则

	 	Rule      = 规则
	    	        安装包类型，唯一识别名，模糊查找名，依赖

	* Language
		ISO       = 规则命名通过验证 ISO 文件。
		Rule      = Boot
				  = Install


	.搜索机制

	{Lang}  = 语言标记
	{ARCH}  = 架构：原始 amd64
	{ARCHC} = 架构：转换后的结果：x64

	.排序：内核、系统类型、boot 或 Install、所需文件、文件路径
#>
$Global:Pre_Config_Rules = @(
	@{
		GUID        = "ec9e0561-3496-4b1a-8b29-03e60e549adf"
		Author      = "Yi"
		Copyright   = "FengYi, Inc. All rights reserved."
		Name        = "Windows 11"
		ISO         = @(
			"en-us_windows_11_business_editions_version_22h2_x64_dvd_17a08ce3.iso"     # magnet:?xt=urn:btih:0A96C933DBB5A34C22A5FC94B3C7551E94C74F8C
			"en-us_windows_11_consumer_editions_version_22h2_x64_dvd_e630fafd.iso"     # magnet:?xt=urn:btih:0A96C933DBB5A34C22A5FC94B3C7551E94C74F8C
			"en-us_windows_11_iot_enterprise_version_22h2_x64_dvd_eb39bf70.iso"        # magnet:?xt=urn:btih:2A20ABD7AB7339D897E9E16602164090B1C23D37

			"en-us_windows_11_business_editions_x64_dvd_3a304c08.iso"
			"en-us_windows_11_consumer_editions_x64_dvd_bd3cf8df.iso"
			"en-us_windows_11_iot_enterprise_x64_dvd_3ecc0e33.iso"
			"en-us_windows_11_iot_enterprise_arm64_dvd_49c627ac.iso"
		)
		Description = ""
		InboxApps   = @{
			ISO = @(
				# 22H2
				"https://software-static.download.prss.microsoft.com/dbazure/888969d5-f34g-4e03-ac9d-1f9786c66749/22621.1778.230511-2102.ni_release_svc_prod3_amd64fre_InboxApps.iso",
				"https://software-static.download.prss.microsoft.com/dbazure/988969d5-f34g-4e03-ac9d-1f9786c66749/22621.1.220506-1250.ni_release_amd64fre_InboxApps.iso",

				# 21H2
				"https://software-static.download.prss.microsoft.com/dbazure/888969d5-f34g-4e03-ac9d-1f9786c66749/22000.2003.230512-1746.co_release_svc_prod3_amd64fre_InboxApps.iso"
			)
			SN = @{
				Edition = @(
					"EnterpriseS"
					"EnterpriseSN"
					"IoTEnterpriseS"
				)
			}
			Edition = @(
				@{
					Name = @(
						"Core"
						"CoreN"
						"CoreSingleLanguage"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.HEIFImageExtension"
						"Microsoft.HEVCVideoExtension"
						"Microsoft.SecHealthUI"
						"Microsoft.VP9VideoExtensions"
						"Microsoft.WebpImageExtension"
						"Microsoft.WindowsStore"
						"Microsoft.GamingApp"
						"Microsoft.Sticky.Notes"
						"Microsoft.Paint"
						"Microsoft.PowerAutomateDesktop"
						"Microsoft.ScreenSketch"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsTerminal"
						"Clipchamp.Clipchamp"
						"Microsoft.Solitaire.Collection"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.ZuneMusic"
						"Microsoft.BingNews"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.WindowsCamera"
						"Microsoft.Getstarted"
						"Microsoft.Cortana"
						"Microsoft.BingWeather"
						"Microsoft.GetHelp"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.People"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.WebMediaExtensions"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsCalculator"
						"Microsoft.Windows.CommunicationsApps"
						"Microsoft.WindowsSoundRecorder"
						"Microsoft.Xbox.TCUI"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxGamingOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.YourPhone"
						"Microsoft.ZuneVideo"
						"MicrosoftCorporationII.QuickAssist"
						"MicrosoftWindows.Client.WebExperience"
						"Microsoft.RawImageExtension"
						"MicrosoftCorporationII.MicrosoftFamily"
					)
				}
				@{
					Name = @(
						"Education"
						"Professional"
						"ProfessionalEducation"
						"ProfessionalWorkstation"
						"Enterprise"
						"IoTEnterprise"
						"ServerRdsh"

#						"ServerStandardCore"
						"ServerStandard"
#						"ServerDataCenterCore"
						"ServerDatacenter"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.HEIFImageExtension"
						"Microsoft.HEVCVideoExtension"
						"Microsoft.SecHealthUI"
						"Microsoft.VP9VideoExtensions"
						"Microsoft.WebpImageExtension"
						"Microsoft.WindowsStore"
						"Microsoft.GamingApp"
						"Microsoft.Sticky.Notes"
						"Microsoft.Paint"
						"Microsoft.PowerAutomateDesktop"
						"Microsoft.ScreenSketch"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsTerminal"
						"Clipchamp.Clipchamp"
						"Microsoft.Solitaire.Collection"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.ZuneMusic"
						"Microsoft.BingNews"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.WindowsCamera"
						"Microsoft.Getstarted"
						"Microsoft.Cortana"
						"Microsoft.BingWeather"
						"Microsoft.GetHelp"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.People"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.WebMediaExtensions"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsCalculator"
						"Microsoft.Windows.CommunicationsApps"
						"Microsoft.WindowsSoundRecorder"
						"Microsoft.Xbox.TCUI"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxGamingOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.YourPhone"
						"Microsoft.ZuneVideo"
						"MicrosoftCorporationII.QuickAssist"
						"MicrosoftWindows.Client.WebExperience"
						"Microsoft.RawImageExtension"
					)
				}
				@{
					Name = @(
						"EnterpriseN"
						"EnterpriseGN"
						"EnterpriseSN"
						"ProfessionalN"
						"EducationN"
						"ProfessionalWorkstationN"
						"ProfessionalEducationN"
						"CloudN"
						"CloudEN"
						"CloudEditionN"
						"CloudEditionLN"
						"StarterN"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.UI.Xaml.2.4"
						"Microsoft.UI.Xaml.2.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.SecHealthUI"
						"Microsoft.WindowsStore"
						"Microsoft.Sticky.Notes"
						"Microsoft.Paint"
						"Microsoft.PowerAutomateDesktop"
						"Microsoft.ScreenSketch"
						"Microsoft.WindowsNotepad"
						"Microsoft.WindowsTerminal"
						"Clipchamp.Clipchamp"
						"Microsoft.Solitaire.Collection"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.BingNews"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.WindowsCamera"
						"Microsoft.Getstarted"
						"Microsoft.Cortana"
						"Microsoft.BingWeather"
						"Microsoft.GetHelp"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.People"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Todos"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsCalculator"
						"Microsoft.Windows.CommunicationsApps"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.YourPhone"
						"MicrosoftCorporationII.QuickAssist"
						"MicrosoftWindows.Client.WebExperience"
					)
				}
			)
			Rule = @(
				("appx",         "Microsoft.UI.Xaml.2.3",                  "UI.Xaml*{ARCHC}*2.3",            @()),
				("appx",         "Microsoft.UI.Xaml.2.4",                  "UI.Xaml*{ARCHC}*2.4",            @()),
				("appx",         "Microsoft.UI.Xaml.2.7",                  "UI.Xaml*{ARCHC}*2.7",            @()),
				("appx",         "Microsoft.NET.Native.Framework.2.2",     "Native.Framework*{ARCHC}*2.2",   @()),
				("appx",         "Microsoft.NET.Native.Runtime.2.2",       "Native.Runtime*{ARCHC}*2.2",     @()),
				("appx",         "Microsoft.VCLibs.140.00",                "VCLibs*{ARCHC}",                 @()),
				("appx",         "Microsoft.VCLibs.140.00.UWPDesktop",     "VCLibs*{ARCHC}*Desktop",         @()),
				("appxbundle",   "Microsoft.HEIFImageExtension",           "HEIFImageExtension*",            @("Microsoft.VCLibs.140.00")),
				("appx",         "Microsoft.HEVCVideoExtension",           "HEVCVideoExtension*",            @("Microsoft.VCLibs.140.00")),
				("appx",         "Microsoft.SecHealthUI",                  "SecHealthUI*{ARCHC}",            @("Microsoft.UI.Xaml.2.4", "Microsoft.VCLibs.140.00")),
				("appx",         "Microsoft.VP9VideoExtensions",           "VP9VideoExtensions*{ARCHC}",     @("Microsoft.VCLibs.140.00")),
				("appx",         "Microsoft.WebpImageExtension",           "WebpImageExtension*{ARCHC}",     @("Microsoft.VCLibs.140.00")),
				("msixbundle",   "Microsoft.WindowsStore",                 "WindowsStore",                   @("Microsoft.UI.Xaml.2.3", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("msixbundle",   "Microsoft.GamingApp",                    "GamingApp",                      @("Microsoft.UI.Xaml.2.3", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop")),
				("msixbundle",   "Microsoft.Sticky.Notes",                 "MicrosoftStickyNotes",           @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("msixbundle",   "Microsoft.Paint",                        "Paint",                          @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop", "Microsoft.UI.Xaml.2.7")),
				("msixbundle",   "Microsoft.PowerAutomateDesktop",         "PowerAutomateDesktop",           @("Microsoft.VCLibs.140.00.UWPDesktop")),
				("msixbundle",   "Microsoft.ScreenSketch",                 "ScreenSketch",                   @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00")),
				("msixbundle",   "Microsoft.WindowsNotepad",               "WindowsNotepad",                 @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop", "Microsoft.UI.Xaml.2.7")),
				("msixbundle",   "Microsoft.WindowsTerminal",              "WindowsTerminal",                @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00.UWPDesktop")),
				("msixbundle",   "Clipchamp.Clipchamp",                    "Clipchamp.Clipchamp",            @()),
				("msixbundle",   "Microsoft.Solitaire.Collection",         "MicrosoftSolitaireCollection",   @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("msixbundle",   "Microsoft.WindowsAlarms",                "WindowsAlarms",                  @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("msixbundle",   "Microsoft.WindowsFeedbackHub",           "WindowsFeedbackHub",             @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("msixbundle",   "Microsoft.WindowsMaps",                  "WindowsMaps",                    @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("msixbundle",   "Microsoft.ZuneMusic",                    "ZuneMusic",                      @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00")),
				("msixbundle",   "MicrosoftCorporationII.MicrosoftFamily", "MicrosoftFamily",                @()),
				("msixbundle",   "Microsoft.BingNews",                     "BingNews",                       @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("msixbundle",   "Microsoft.DesktopAppInstaller",          "DesktopAppInstaller",            @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00.UWPDesktop")),
				("msixbundle",   "Microsoft.WindowsCamera",                "WindowsCamera",                  @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("msixbundle",   "Microsoft.Getstarted",                   "Getstarted",                     @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Cortana",                      "Cortana",                        @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop")),
				("appxbundle",   "Microsoft.BingWeather",                  "BingWeather",                    @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.GetHelp",                      "GetHelp",                        @("Microsoft.UI.Xaml.2.7", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.MicrosoftOfficeHub",           "MicrosoftOfficeHub",             @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop")),
				("appxbundle",   "Microsoft.People",                       "People",                         @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.StorePurchaseApp",             "StorePurchaseApp",               @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Todos",                        "Todos",                          @("Microsoft.UI.Xaml.2.4", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WebMediaExtensions",           "WebMediaExtensions",             @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Windows.Photos",               "Windows.Photos",                 @("Microsoft.UI.Xaml.2.4", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WindowsCalculator",            "WindowsCalculator",              @("Microsoft.UI.Xaml.2.4", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Windows.CommunicationsApps",   "WindowsCommunicationsApps",      @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WindowsSoundRecorder",         "WindowsSoundRecorder",           @("Microsoft.UI.Xaml.2.3", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Xbox.TCUI",                    "Xbox.TCUI",                      @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.XboxGameOverlay",              "XboxGameOverlay",                @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.XboxGamingOverlay",            "XboxGamingOverlay",              @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.XboxIdentityProvider",         "XboxIdentityProvider",           @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.XboxSpeechToTextOverlay",      "XboxSpeechToTextOverlay",        @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.YourPhone",                    "YourPhone",                      @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop")),
				("appxbundle",   "Microsoft.ZuneVideo",                    "ZuneVideo",                      @("Microsoft.UI.Xaml.2.7", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "MicrosoftCorporationII.QuickAssist",     "QuickAssist",                    @()),
				("appxbundle",   "MicrosoftWindows.Client.WebExperience",  "WebExperience",                  @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.RawImageExtension",            "RawImageExtension",              @())
			)
		}
		Language = @{
			ISO = @(
				"https://software-static.download.prss.microsoft.com/dbazure/988969d5-f34g-4e03-ac9d-1f9786c66749/22621.1.220506-1250.ni_release_amd64fre_CLIENT_LOF_PACKAGES_OEM.iso"
				"https://software-download.microsoft.com/download/sg/22000.1.210604-1628.co_release_amd64fre_CLIENT_LOF_PACKAGES_OEM.iso"
			)
			Rule = @(
				@{
					Group = "Install;Install;"
					Rule = @(
						("Microsoft-Windows-LanguageFeatures-Fonts-{DiyLang}-Package~31bf3856ad364e35~{ARCH}~~.cab",     "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-Client-Language-Pack_{ARCHC}_{Lang}.cab",                                    "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-LanguageFeatures-Basic-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab",        "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-LanguageFeatures-Handwriting-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab",  "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-LanguageFeatures-OCR-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab",          "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-LanguageFeatures-Speech-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab",       "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-LanguageFeatures-TextToSpeech-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab", "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-InternetExplorer-Optional-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",      "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-Notepad-System-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",             "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-Notepad-System-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab",              "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-MediaPlayer-Package-{ARCH}-{Lang}.cab",                                      "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-MediaPlayer-Package-wow64-{Lang}.cab",                                       "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-PowerShell-ISE-FOD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",             "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-PowerShell-ISE-FOD-Package~31bf3856ad364e35~wow64~{Lang}~.cab",              "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-Printing-PMCPPC-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",            "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-StepsRecorder-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",                  "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-StepsRecorder-Package~31bf3856ad364e35~wow64~{Lang}~.cab",                   "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-WMIC-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",                       "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-WMIC-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab",                        "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",                    "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab",                     "LanguagesAndOptionalFeatures"),
						("Microsoft-Windows-Lip-Language-Pack_{ARCH}_{Lang}.cab",                                        "LanguagesAndOptionalFeatures")
					)
				}
				@{
					Group = "Install;WinRE;"
					Rule = @(
						("lp.cab",                                                                                       "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("WinPE-FontSupport-{Lang}.cab",                                                                 "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"),
						("WinPE-FontSupport-{Lang}.cab",                                                                 "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-securestartup_{Lang}.cab",                                                               "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-atbroker_{Lang}.cab",                                                                    "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-audiocore_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-audiodrivers_{Lang}.cab",                                                                "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-enhancedstorage_{Lang}.cab",                                                             "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-narrator_{Lang}.cab",                                                                    "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-scripting_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-speech-tts_{Lang}.cab",                                                                  "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-srh_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-srt_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-wds-tools_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-wmi_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-appxdeployment_{Lang}.cab",                                                              "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-appxpackaging_{Lang}.cab",                                                               "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-storagewmi_{Lang}.cab",                                                                  "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-wifi_{Lang}.cab",                                                                        "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-windowsupdate_{Lang}.cab",                                                               "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-rejuv_{Lang}.cab",                                                                       "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-opcservices_{Lang}.cab",                                                                 "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-hta_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}")
					)
				}
				@{
					Group = "Boot;Boot;"
					Rule = @(
						("lp.cab",                                                                                       "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("WinPE-Setup_{Lang}.cab",                                                                       "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("WINPE-SETUP-CLIENT_{Lang}.CAB",                                                                "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("WinPE-FontSupport-{Lang}.cab",                                                                 "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"),
						("WinPE-FontSupport-{Lang}.cab",                                                                 "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-securestartup_{Lang}.cab",                                                               "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-atbroker_{Lang}.cab",                                                                    "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-audiocore_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-audiodrivers_{Lang}.cab",                                                                "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-enhancedstorage_{Lang}.cab",                                                             "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-narrator_{Lang}.cab",                                                                    "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-scripting_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-speech-tts_{Lang}.cab",                                                                  "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-srh_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-srt_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-wds-tools_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-wmi_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}")
					)
				}
			)
		}
	}
	@{
		GUID        = "d33b848d-ef73-470b-ba0e-8b7f21536ccd"
		Author      = "Yi"
		Copyright   = "FengYi, Inc. All rights reserved."
		Name        = "Windows 10"
		ISO         = @(
			"en-us_windows_10_business_editions_version_22h2_x64_dvd_8cf17b79.iso"
			"en-us_windows_10_business_editions_version_22h2_x86_dvd_186a68c3.iso"
			"en-us_windows_10_consumer_editions_version_22h2_x64_dvd_8da72ab3.iso"
			"en-us_windows_10_consumer_editions_version_22h2_x86_dvd_90883feb.iso"
			"en-us_windows_10_iot_enterprise_version_22h2_arm64_dvd_39566b6b.iso"
			"en-us_windows_10_iot_enterprise_version_22h2_x64_dvd_51cc370f.iso"

			"en-us_windows_10_enterprise_ltsc_2021_x64_dvd_d289cf96.iso"
			"en-us_windows_10_enterprise_ltsc_2021_x86_dvd_9f4aa95f.iso"
			"en-us_windows_10_iot_enterprise_ltsc_2021_x64_dvd_257ad90f.iso"
			"en_windows_10_business_editions_version_21h1_x64_dvd_ec5a76c1.iso"
			"en_windows_10_business_editions_version_21h1_x86_dvd_1495793c.iso"
			"en_windows_10_consumer_editions_version_21h1_x64_dvd_540c0dd4.iso"
			"en_windows_10_consumer_editions_version_21h1_x86_dvd_68cee121.iso"
			
			"en_windows_10_business_editions_version_20h2_x64_dvd_4788fb7c.iso"
			"en_windows_10_business_editions_version_20h2_x86_dvd_fae4084e.iso"
			"en_windows_10_consumer_editions_version_20h2_x64_dvd_ab0e3e0a.iso"
			"en_windows_10_consumer_editions_version_20h2_x86_dvd_ea9a9e3f.iso"
			"en_windows_10_iot_enterprise_version_20h2_arm64_dvd_fe0947da.iso"
			"en_windows_10_iot_enterprise_version_20h2_x64_dvd_c6ef5325.iso"
			
			"en_windows_10_business_editions_version_2004_x64_dvd_d06ef8c5.iso"
			"en_windows_10_business_editions_version_2004_x86_dvd_52bfcce8.iso"
			"en_windows_10_consumer_editions_version_2004_x64_dvd_8d28c5d7.iso"
			"en_windows_10_consumer_editions_version_2004_x86_dvd_fa759348.iso"
			
			"en_windows_10_business_editions_version_1909_x64_dvd_ada535d0.iso"
			"en_windows_10_business_editions_version_1909_x86_dvd_3a5b8f60.iso"
			"en_windows_10_consumer_editions_version_1909_x64_dvd_be09950e.iso"
			"en_windows_10_consumer_editions_version_1909_x86_dvd_10bde8bb.iso"
			
			"en_windows_10_business_editions_version_1903_x64_dvd_37200948.iso"
			"en_windows_10_business_editions_version_1903_x86_dvd_ca4f0f49.iso"
			"en_windows_10_consumer_editions_version_1903_x64_dvd_b980e68c.iso"
			"en_windows_10_consumer_editions_version_1903_x86_dvd_b40c5211.iso"
		)
		Description = ""
		InboxApps   = @{
			ISO = @(
				"https://software-static.download.prss.microsoft.com/dbazure/888969d5-f34g-4e03-ac9d-1f9786c66749/19041.3031.230508-1728.vb_release_svc_prod3_amd64fre_InboxApps.iso"
			)
			Edition = @(
				@{
					Name = @(
						"Core"
						"CoreSingleLanguage"
						"Education"
						"Professional"
						"ProfessionalEducation"
						"ProfessionalWorkstation"
						"Enterprise"
						"IoTEnterprise"
						"ServerRdsh"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.0"
						"Microsoft.UI.Xaml.2.1"
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.Advertising.Xaml"
						"Microsoft.NET.Native.Framework.1.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.1.7"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.HEIFImageExtension"
						"Microsoft.WebpImageExtension"
						"Microsoft.VP9VideoExtensions"
						"Microsoft.WindowsStore"
						"Microsoft.Xbox.TCUI"
						"Microsoft.XboxApp"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxGamingOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.Cortana"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.GetHelp"
						"Microsoft.Getstarted"
						"Microsoft.Microsoft3DViewer"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.Solitaire.Collection"
						"Microsoft.Sticky.Notes"
						"Microsoft.MixedReality.Portal"
						"Microsoft.MSPaint"
						"Microsoft.Office.OneNote"
						"Microsoft.People"
						"Microsoft.ScreenSketch"
						"Microsoft.SkypeApp"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Wallet"
						"Microsoft.WebMediaExtensions"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsCalculator"
						"Microsoft.WindowsCamera"
						"Microsoft.Windows.CommunicationsApps"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.WindowsSoundRecorder"
						"Microsoft.YourPhone"
						"Microsoft.ZuneMusic"
						"Microsoft.ZuneVideo"
					)
				}
				@{
					Name = @(
						"EnterpriseN"
						"EnterpriseGN"
						"EnterpriseSN"
						"ProfessionalN"
						"CoreN"
						"EducationN"
						"ProfessionalWorkstationN"
						"ProfessionalEducationN"
						"CloudN"
						"CloudEN"
						"CloudEditionN"
						"CloudEditionLN"
						"StarterN"
					)
					Apps = @(
						"Microsoft.UI.Xaml.2.0"
						"Microsoft.UI.Xaml.2.1"
						"Microsoft.UI.Xaml.2.3"
						"Microsoft.Advertising.Xaml"
						"Microsoft.NET.Native.Framework.1.7"
						"Microsoft.NET.Native.Framework.2.2"
						"Microsoft.NET.Native.Runtime.1.7"
						"Microsoft.NET.Native.Runtime.2.2"
						"Microsoft.VCLibs.140.00"
						"Microsoft.VCLibs.140.00.UWPDesktop"
						"Microsoft.Services.Store.Engagement"
						"Microsoft.WindowsStore"
						"Microsoft.XboxApp"
						"Microsoft.XboxGameOverlay"
						"Microsoft.XboxIdentityProvider"
						"Microsoft.XboxSpeechToTextOverlay"
						"Microsoft.Cortana"
						"Microsoft.BingWeather"
						"Microsoft.DesktopAppInstaller"
						"Microsoft.GetHelp"
						"Microsoft.Getstarted"
						"Microsoft.Microsoft3DViewer"
						"Microsoft.MicrosoftOfficeHub"
						"Microsoft.Solitaire.Collection"
						"Microsoft.Sticky.Notes"
						"Microsoft.MSPaint"
						"Microsoft.Office.OneNote"
						"Microsoft.People"
						"Microsoft.ScreenSketch"
						"Microsoft.StorePurchaseApp"
						"Microsoft.Wallet"
						"Microsoft.Windows.Photos"
						"Microsoft.WindowsAlarms"
						"Microsoft.WindowsCalculator"
						"Microsoft.WindowsCamera"
						"Microsoft.Windows.CommunicationsApps"
						"Microsoft.WindowsFeedbackHub"
						"Microsoft.WindowsMaps"
						"Microsoft.YourPhone"
					)
				}
			)
			Rule = @(
				("appx",         "Microsoft.UI.Xaml.2.0",                  "UI.Xaml*2.0",                    @()),
				("appx",         "Microsoft.UI.Xaml.2.1",                  "UI.Xaml*2.1",                    @()),
				("appx",         "Microsoft.UI.Xaml.2.3",                  "UI.Xaml*2.3",                    @()),
				("appx",         "Microsoft.Advertising.Xaml",             "Advertising.Xaml",               @()),
				("appx",         "Microsoft.NET.Native.Framework.1.7",     "Native.Framework*1.7",           @()),
				("appx",         "Microsoft.NET.Native.Framework.2.2",     "Native.Framework*2.2",           @()),
				("appx",         "Microsoft.NET.Native.Runtime.1.7",       "Native.Runtime*1.7",             @()),
				("appx",         "Microsoft.NET.Native.Runtime.2.2",       "Native.Runtime*2.2",             @()),
				("appx",         "Microsoft.VCLibs.140.00",                "VCLibs*14.00",                   @()),
				("appx",         "Microsoft.VCLibs.140.00.UWPDesktop",     "VCLibs*Desktop",                 @()),
				("appx",         "Microsoft.Services.Store.Engagement",    "Services.Store.Engagement",      @()),
				("appx",         "Microsoft.HEIFImageExtension",           "HEIFImageExtension",             @("Microsoft.VCLibs.140.00")),
				("appx",         "Microsoft.WebpImageExtension",           "WebpImageExtension",             @("Microsoft.VCLibs.140.00")),
				("appx",         "Microsoft.VP9VideoExtensions",           "VP9VideoExtensions",             @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WindowsStore",                 "WindowsStore",                   @("Microsoft.UI.Xaml.2.3", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Xbox.TCUI",                    "Xbox.TCUI",                      @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.XboxApp",                      "XboxApp",                        @("Microsoft.NET.Native.Framework.1.7", "Microsoft.NET.Native.Runtime.1.7", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.XboxGameOverlay",              "XboxGameOverlay",                @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.XboxGamingOverlay",            "XboxGamingOverlay",              @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.XboxIdentityProvider",         "XboxIdentityProvider",           @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.XboxSpeechToTextOverlay",      "XboxSpeechToTextOverlay",        @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Cortana",                      "Cortana",                        @("Microsoft.UI.Xaml.2.3", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop")),
				("appxbundle",   "Microsoft.BingWeather",                  "BingWeather",                    @("Microsoft.UI.Xaml.2.1", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.Advertising.Xaml")),
				("appxbundle",   "Microsoft.DesktopAppInstaller",          "DesktopAppInstaller",            @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop")),
				("appxbundle",   "Microsoft.GetHelp",                      "GetHelp",                        @("Microsoft.NET.Native.Framework.1.7", "Microsoft.NET.Native.Runtime.1.7", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Getstarted",                   "Getstarted",                     @("Microsoft.UI.Xaml.2.3", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Microsoft3DViewer",            "Microsoft3DViewer",              @("Microsoft.UI.Xaml.2.1", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop")),
				("appxbundle",   "Microsoft.MicrosoftOfficeHub",           "MicrosoftOfficeHub",             @("Microsoft.VCLibs.140.00", "Microsoft.VCLibs.140.00.UWPDesktop")),
				("appxbundle",   "Microsoft.Solitaire.Collection",         "MicrosoftSolitaireCollection",   @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Sticky.Notes",                 "MicrosoftStickyNotes",           @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00", "Microsoft.Services.Store.Engagement")),
				("appxbundle",   "Microsoft.MixedReality.Portal",          "MixedReality.Portal",            @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.MSPaint",                      "MSPaint",                        @("Microsoft.UI.Xaml.2.0", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Office.OneNote",               "Office.OneNote",                 @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.People",                       "People",                         @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.ScreenSketch",                 "ScreenSketch",                   @("Microsoft.UI.Xaml.2.0", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.SkypeApp",                     "SkypeApp",                       @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.StorePurchaseApp",             "StorePurchaseApp",               @("Microsoft.NET.Native.Framework.1.7", "Microsoft.NET.Native.Runtime.1.7", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Wallet",                       "Wallet",                         @("Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WebMediaExtensions",           "WebMediaExtensions",             @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Windows.Photos",               "Windows.Photos",                 @("Microsoft.UI.Xaml.2.0", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WindowsAlarms",                "WindowsAlarms",                  @("Microsoft.UI.Xaml.2.3", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WindowsCalculator",            "WindowsCalculator",              @("Microsoft.UI.Xaml.2.0", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WindowsCamera",                "WindowsCamera",                  @("Microsoft.NET.Native.Framework.1.7", "Microsoft.NET.Native.Runtime.1.7", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.Windows.CommunicationsApps",   "windowscommunicationsapps",      @("Microsoft.Advertising.Xaml", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WindowsFeedbackHub",           "WindowsFeedbackHub",             @("Microsoft.UI.Xaml.2.0", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WindowsMaps",                  "WindowsMaps",                    @("Microsoft.UI.Xaml.2.3", "Microsoft.NET.Native.Framework.2.2", "Microsoft.NET.Native.Runtime.2.2", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.WindowsSoundRecorder",         "WindowsSoundRecorder",           @("Microsoft.UI.Xaml.2.3", "Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.YourPhone",                    "YourPhone",                      @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.ZuneMusic",                    "ZuneMusic",                      @("Microsoft.VCLibs.140.00")),
				("appxbundle",   "Microsoft.ZuneVideo",                    "ZuneVideo",                      @("Microsoft.VCLibs.140.00"))
			)
		}
		Language = @{
			ISO = @(
				"https://software-download.microsoft.com/download/pr/19041.1.191206-1406.vb_release_CLIENTLANGPACKDVD_OEM_MULTI.iso"
				"https://software-download.microsoft.com/download/pr/19041.1.191206-1406.vb_release_amd64fre_FOD-PACKAGES_OEM_PT1_amd64fre_MULTI.iso"
			)
			Rule = @(
				@{
					Group = "Install;Install;"
					Rule = @(
						("Microsoft-Windows-LanguageFeatures-Fonts-{DiyLang}-Package~31bf3856ad364e35~{ARCH}~~.cab",     ""),
						("Microsoft-Windows-Client-Language-Pack_{ARCHC}_{Lang}.cab",                                    "{ARCHC}\langpacks"),
						("Microsoft-Windows-LanguageFeatures-Basic-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab",        ""),
						("Microsoft-Windows-LanguageFeatures-Handwriting-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab",  ""),
						("Microsoft-Windows-LanguageFeatures-OCR-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab",          ""),
						("Microsoft-Windows-LanguageFeatures-Speech-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab",       ""),
						("Microsoft-Windows-LanguageFeatures-TextToSpeech-{Lang}-Package~31bf3856ad364e35~{ARCH}~~.cab", ""),
						("Microsoft-Windows-InternetExplorer-Optional-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",      ""),
						("Microsoft-Windows-MSPaint-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab",                     ""),
						("Microsoft-Windows-MSPaint-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",                    ""),
						("Microsoft-Windows-Notepad-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab",                     ""),
						("Microsoft-Windows-Notepad-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",                    ""),
						("Microsoft-Windows-PowerShell-ISE-FOD-Package~31bf3856ad364e35~wow64~{Lang}~.cab",              ""),
						("Microsoft-Windows-PowerShell-ISE-FOD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",             ""),
						("Microsoft-Windows-Printing-WFS-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",               ""),
						("Microsoft-Windows-Printing-PMCPPC-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",            ""),
						("Microsoft-Windows-StepsRecorder-Package~31bf3856ad364e35~wow64~{Lang}~.cab",                   ""),
						("Microsoft-Windows-StepsRecorder-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",                  ""),
						("Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~wow64~{Lang}~.cab",                     ""),
						("Microsoft-Windows-WordPad-FoD-Package~31bf3856ad364e35~{ARCH}~{Lang}~.cab",                    "")
					)
				}
				@{
					Group = "Install;WinRE;"
					Rule = @(
						("lp.cab",                                                                                       "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("WinPE-FontSupport-{Lang}.cab",                                                                 "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"),
						("WinPE-FontSupport-{Lang}.cab",                                                                 "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-securestartup_{Lang}.cab",                                                               "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-atbroker_{Lang}.cab",                                                                    "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-audiocore_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-audiodrivers_{Lang}.cab",                                                                "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-enhancedstorage_{Lang}.cab",                                                             "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-narrator_{Lang}.cab",                                                                    "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-scripting_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-speech-tts_{Lang}.cab",                                                                  "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-srh_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-srt_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-wds-tools_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-wmi_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-appxpackaging_{Lang}.cab",                                                               "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-storagewmi_{Lang}.cab",                                                                  "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-wifi_{Lang}.cab",                                                                        "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-rejuv_{Lang}.cab",                                                                       "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-opcservices_{Lang}.cab",                                                                 "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-hta_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}")
					)
				}
				@{
					Group = "Boot;Boot;"
					Rule = @(
						("lp.cab",                                                                                       "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("WinPE-Setup_{Lang}.cab",                                                                       "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("WINPE-SETUP-CLIENT_{Lang}.CAB",                                                                "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("WinPE-FontSupport-{Lang}.cab",                                                                 "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs"),
						("WinPE-FontSupport-{Lang}.cab",                                                                 "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-securestartup_{Lang}.cab",                                                               "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-atbroker_{Lang}.cab",                                                                    "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-audiocore_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-audiodrivers_{Lang}.cab",                                                                "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-enhancedstorage_{Lang}.cab",                                                             "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-narrator_{Lang}.cab",                                                                    "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-scripting_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-speech-tts_{Lang}.cab",                                                                  "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-srh_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-srt_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-wds-tools_{Lang}.cab",                                                                   "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}"),
						("winpe-wmi_{Lang}.cab",                                                                         "Windows Preinstallation Environment\{ARCHC}\WinPE_OCs\{Lang}")
					)
				}
			)
		}
	}
)