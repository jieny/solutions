﻿<#
	.Menu: Language
	.菜单：语言
#>
Function Solutions_Menu
{
	if (-not $Global:EventQueueMode) {
		Logo -Title $($lang.Solution)
		Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"

		Write-Host "   $($lang.MountImageTo)" -NoNewline
		Write-Host " $($Global:MountToRouting)" -ForegroundColor Yellow

		Write-Host "   $($lang.MainImageFolder)" -NoNewline
		Write-Host " $($Global:MountTo)" -NoNewline -ForegroundColor Yellow
		if (Test-Path "$($Global:MountTo)" -PathType Container) {
			Write-Host " $($lang.ImageLoaded)" -ForegroundColor Green
		} else {
			Write-Host " $($lang.NotMounted)" -ForegroundColor Red
			ToMainpage -wait 2
		}
		Image_Get_Mount_Status
	}

	Write-Host "`n   $($lang.Menu)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	Write-Host "      C   $($lang.Solution): $($lang.IsCreate)" -ForegroundColor Green

	Write-Host "`n   $($Global:MountTo)" -ForegroundColor Yellow

	if (Test-Path "$($Global:MountTo)\Sources\`$OEM$" -PathType Container) {
		Write-Host "      1   $($lang.Del): " -NoNewline -ForegroundColor Green
		Write-host "\Sources\`$OEM$" -ForegroundColor Green
	} else {
		Write-Host "      1   $($lang.Del): " -NoNewline -ForegroundColor Red
		Write-host "\Sources\`$OEM$" -ForegroundColor Green
	}

	if (Test-Path "$($Global:MountTo)\Sources\Unattend.xml" -PathType leaf) {
		Write-Host "      2   $($lang.Del): " -NoNewline -ForegroundColor Green
		Write-host "\Sources\Unattend.xml" -ForegroundColor Green
	} else {
		Write-Host "      2   $($lang.Del): " -NoNewline -ForegroundColor Red
		Write-host "\Sources\Unattend.xml" -ForegroundColor Green
	}

	if (Test-Path "$($Global:MountTo)\Autounattend.xml" -PathType leaf) {
		Write-Host "      3   $($lang.Del): " -NoNewline -ForegroundColor Green
		Write-host "\Autounattend.xml" -ForegroundColor Green
	} else {
		Write-Host "      3   $($lang.Del): " -NoNewline -ForegroundColor Red
		Write-host "\Autounattend.xml" -ForegroundColor Green
	}

	Write-Host ""
	if ((Test-Path "$($Global:MountTo)\Autounattend.xml" -PathType Leaf) -or
		(Test-Path "$($Global:MountTo)\Sources\Unattend.xml" -PathType Leaf) -or
		(Test-Path "$($Global:MountTo)\Sources\`$OEM$" -PathType Container))
	{
		Write-Host "      A   $($lang.EnglineDoneClearFull)" -ForegroundColor Green
	} else {
		Write-Host "      A   $($lang.EnglineDoneClearFull)" -ForegroundColor Red
	}

	$select = Read-Host "`n   $($lang.Choose)"
	switch ($select)
	{
		'c' {
			Solutions
			ToMainpage -wait 2 -To 7
		}
		'1' {
			Write-Host "`n   $($Global:MountTo)\Sources\`$OEM$" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.Del)".PadRight(28) -NoNewline
			if (Test-Path "$($Global:MountTo)\Sources\`$OEM$" -PathType Container) {
				Remove_Tree "$($Global:MountTo)\Sources\`$OEM$"
				Write-Host "   $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   $($lang.RemoveFolderFailed)`n" -ForegroundColor Red
			}

			ToMainpage -wait 2 -To 7
		}
		'2' {
			Write-Host "`n   $($Global:MountTo)\Sources\Unattend.xml" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.Del)".PadRight(28) -NoNewline
			if (Test-Path "$($Global:MountTo)\Sources\Unattend.xml" -PathType leaf) {
				Remove_Tree "$($Global:MountTo)\Sources\Unattend.xml"
				Write-Host "   $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   $($lang.RemoveFolderFailed)`n" -ForegroundColor Red
			}

			ToMainpage -wait 2 -To 7
		}
		'3' {
			Write-Host "`n   $($Global:MountTo)\Autounattend.xml" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.Del)".PadRight(28) -NoNewline
			if (Test-Path "$($Global:MountTo)\Autounattend.xml" -PathType leaf) {
				Remove_Tree "$($Global:MountTo)\Autounattend.xml"
				Write-Host "   $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   $($lang.RemoveFolderFailed)`n" -ForegroundColor Red
			}

			ToMainpage -wait 2 -To 7
		}
		'a' {
			Write-Host "`n   $($Global:MountTo)\Sources\`$OEM$" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.Del)".PadRight(28) -NoNewline
			if (Test-Path "$($Global:MountTo)\Sources\`$OEM$" -PathType Container) {
				Remove_Tree "$($Global:MountTo)\Sources\`$OEM$"
				Write-Host "   $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   $($lang.RemoveFolderFailed)`n" -ForegroundColor Red
			}

			Write-Host "`n   $($Global:MountTo)\Sources\Unattend.xml" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.Del)".PadRight(28) -NoNewline
			if (Test-Path "$($Global:MountTo)\Sources\Unattend.xml" -PathType leaf) {
				Remove_Tree "$($Global:MountTo)\Sources\Unattend.xml"
				Write-Host "   $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   $($lang.RemoveFolderFailed)`n" -ForegroundColor Red
			}

			Write-Host "`n   $($Global:MountTo)\Autounattend.xml" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "   $($lang.Del)".PadRight(28) -NoNewline
			if (Test-Path "$($Global:MountTo)\Autounattend.xml" -PathType leaf) {
				Remove_Tree "$($Global:MountTo)\Autounattend.xml"
				Write-Host "   $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   $($lang.RemoveFolderFailed)`n" -ForegroundColor Red
			}

			ToMainpage -wait 2 -To 7
		}
		default {
			Mainpage
		}
	}
}