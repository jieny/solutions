<#
	.Menu: Convert image
	.菜单：转换映像
#>
Function Image_Convert
{
	if (-not $Global:EventQueueMode) {
		Logo -Title $($lang.Convert)
		Write-Host "   $($lang.Dashboard)" -ForegroundColor Yellow
		Write-host "   $('-' * 80)"

		Write-Host "   $($lang.MountImageTo)" -NoNewline
		Write-Host " $($Global:MountToRouting)" -ForegroundColor Yellow

		Write-Host "   $($lang.MainImageFolder)" -NoNewline
		Write-Host " $($Global:MountTo)" -NoNewline -ForegroundColor Yellow
		if (Test-Path "$($Global:MountTo)" -PathType Container) {
			Write-Host " $($lang.ImageLoaded)" -ForegroundColor Green
		} else {
			Write-Host " $($lang.NotMounted)" -ForegroundColor Red
			ToMainpage -wait 2
		}
		Image_Get_Mount_Status

		if (Image_Is_Mount) {
			Write-Host "`n    $($lang.AssignNeedMount)" -ForegroundColor Yellow
			Write-host "   $('-' * 80)"
			Write-Host "    $($lang.Inoperable)" -ForegroundColor Red
			return
		}
	}

	<#
		.Assign available tasks
		.分配可用的任务
	#>
	Event_Assign -Rule "Image_Convert_UI" -Run
}

<#
	.Convert image user interface
	.转换映像用户界面
#>
Function Image_Convert_UI
{
	Write-Host "`n   $($lang.Convert)" -ForegroundColor Yellow
	Write-host "   $('-' * 80)"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	<#
		.事件：强行结束按需任务
	#>
	$UI_Main_Suggestion_Stop_Click = {
		$UI_Main.Hide()
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		Event_Reset_Variable
		$UI_Main.Close()
	}

	<#
		.刷新选择状态
	#>
	Function Image_Convert_Refresh
	{
		param
		(
			[switch]$Skip
		)

		if ($Skip) {
			$Script:AllowUnlockConvertESD = $True
		} else {
			$Script:AllowUnlockConvertESD = $False
		}

		<#
			.选择了 ESD 转换成 WIM
		#>
		if ($GUIImageConvertToESD.Checked) {
			<#
				.禁用拆分功能
			#>
			if ($GUIImageConvertSkip.Checked) {
				$GUIImageConvertSplit.Text = $($lang.ConvertSplitESDWIMDynamicNo -f "esd")
				$GUIImageConvertRebuld.Enabled = $False

				if ($Script:AllowUnlockConvertESD) {
					$GUIImageConvertSplit.Enabled = $True
					if ($GUIImageConvertSplit.Enabled) {
						if ($GUIImageConvertSplit.Checked) {
							$GUIImageConvertSplitSelect.Enabled = $True
							$GUIImageConvertSplitMB.Enabled = $True
						} else {
							$GUIImageConvertSplitSelect.Enabled = $False
							$GUIImageConvertSplitMB.Enabled = $False
						}
					} else {
						$GUIImageConvertSplitSelect.Enabled = $False
						$GUIImageConvertSplitMB.Enabled = $False
					}
				} else {
					$GUIImageConvertSplit.Enabled = $False
					$GUIImageConvertSplitSelect.Enabled = $False
					$GUIImageConvertSplitMB.Enabled = $False
					$GUIImageConvertSplitStatus.Text = $lang.ConvertEsdNotSuggested
					$GUIImageConvertSplitUnlock.Visible = $True
				}
			} else {
				$GUIImageConvertSplit.Enabled = $True
				$GUIImageConvertSplit.Text = $($lang.ConvertSplitESDWIMDynamicSave -f "wim")
				$GUIImageConvertRebuld.Enabled = $False
				if ($Script:AllowUnlockConvertESD) {
					if ($GUIImageConvertSplit.Checked) {
						$GUIImageConvertSplitSelect.Enabled = $True
						$GUIImageConvertSplitMB.Enabled = $True
					} else {
						$GUIImageConvertSplitSelect.Enabled = $False
						$GUIImageConvertSplitMB.Enabled = $False
					}
				} else {
					if ($GUIImageConvertSplit.Checked) {
						$GUIImageConvertSplitSelect.Enabled = $True
						$GUIImageConvertSplitMB.Enabled = $True
						$GUIImageConvertSplitUnlock.Visible = $False
						$GUIImageConvertSplitStatus.Text = $lang.Operable
					} else {
						$GUIImageConvertSplitSelect.Enabled = $False
						$GUIImageConvertSplitMB.Enabled = $False
						$GUIImageConvertSplitUnlock.Visible = $False
						$GUIImageConvertSplitStatus.Text = $lang.Operable
					}
				}
			}
		}

		<#
			.选择了 WIM 转换成 ESD
		#>
		if ($GUIImageConvertToWIM.Checked) {
			if ($GUIImageConvertSkip.Checked) {
				$GUIImageConvertToWIM.Text = $($lang.ConvertImageNot -f "WIM", "ESD")

				$GUIImageConvertSplit.Enabled = $True
				if ($GUIImageConvertSplit.Checked) {
					$GUIImageConvertSplitSelect.Enabled = $True
					$GUIImageConvertSplitMB.Enabled = $True
				} else {
					$GUIImageConvertSplitSelect.Enabled = $False
					$GUIImageConvertSplitMB.Enabled = $False
				}
				
				$GUIImageConvertSplitStatus.Text = $lang.Operable
				$GUIImageConvertSplitUnlock.Visible = $False

				$GUIImageConvertSplit.Text = $($lang.ConvertSplitESDWIMDynamicNo -f "wim")
				$GUIImageConvertRebuld.Enabled = $True
			} else {
				$GUIImageConvertToWIM.Text = $($lang.ConvertImageSwitch -f "WIM", "ESD")
				if ($Script:AllowUnlockConvertESD) {
					$GUIImageConvertSplit.Enabled = $True
					if ($GUIImageConvertSplit.Enabled) {
						if ($GUIImageConvertSplit.Checked) {
							$GUIImageConvertSplitSelect.Enabled = $True
							$GUIImageConvertSplitMB.Enabled = $True
						} else {
							$GUIImageConvertSplitSelect.Enabled = $False
							$GUIImageConvertSplitMB.Enabled = $False
						}
					} else {
						$GUIImageConvertSplitSelect.Enabled = $False
						$GUIImageConvertSplitMB.Enabled = $False
					}
				} else {
					$GUIImageConvertSplit.Enabled = $False
					$GUIImageConvertSplitSelect.Enabled = $False
					$GUIImageConvertSplitMB.Enabled = $False
				}

				$GUIImageConvertSplitStatus.Text = $lang.ConvertEsdNotSuggested
				$GUIImageConvertSplitUnlock.Visible = $True
				$GUIImageConvertSplit.Text = $($lang.ConvertSplitESDWIMDynamicSave -f "esd")
				$GUIImageConvertRebuld.Enabled = $False
			}
		}
	}

	$UI_Main           = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 1075
		Text           = $lang.Convert
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}

	<#
		.创建前备份
	#>
	$GUIImageConvertBackup = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "15,15"
		Height         = 25
		Width          = 400
		Text           = $lang.ConvertBackup
		Checked        = $True
	}
	$GUIImageConvertBackupTips = New-Object system.Windows.Forms.Label -Property @{
		Location       = "31,45"
		Height         = 36
		Width          = 390
		Text           = $lang.ConvertBackupTips
	}

	<#
		.跳过转换，执行其它
	#>
	$GUIImageConvertSkip = New-Object System.Windows.Forms.CheckBox -Property @{
		Location        = "15,95"
		Height          = 35
		Width           = 454
		Text            = $lang.ConvertSkip
		add_Click       = { Image_Convert_Refresh }
	}
	$GUIImageConvertToESD = New-Object system.Windows.Forms.RadioButton -Property @{
		Location        = "33,130"
		Height          = 35
		Width           = 436
		Text            = $($lang.ConvertImageSwitch -f "ESD", "WIM")
		add_Click       = { Image_Convert_Refresh }
	}
	$GUIImageConvertToWIM = New-Object system.Windows.Forms.RadioButton -Property @{
		Location        = "33,165"
		Height          = 35
		Width           = 436
		Text            = $($lang.ConvertImageSwitch -f "WIM", "ESD")
		add_Click       = { Image_Convert_Refresh }
	}

	<#
		SWM
	#>
	$GUIImageSWM       = New-Object system.Windows.Forms.RadioButton -Property @{
		Location       = "33,200"
		Height         = 28
		Width          = 436
		Text           = $lang.ConvertSWM
		Tag            = "wim"
		add_Click      = {
			$GUIImageConvertSplit.Enabled = $False
			$GUIImageConvertSplitSelect.Enabled = $False
			$GUIImageConvertSplitMB.Enabled = $False
			$GUIImageConvertSplitStatus.Text = ""
			$GUIImageConvertSplitUnlock.Visible = $False
			$GUIImageConvertRebuld.Enabled = $False
		}
	}
	$GUIImageSWMTips   = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 421
		Text           = $lang.ConvertSWMTips
		Location       = "48,235"
	}

	<#
		.可选功能
	#>
	$GUIImageConvertAdv = New-Object System.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 437
		Text           = $lang.AdvOption
		Location       = '31,285'
	}
	$GUIImageConvertRebuld = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "50,310"
		Height         = 35
		Width          = 418
		Text           = $lang.ConvertRebuld
		Checked        = $True
		Enabled        = $False
	}

	<#
		.拆分 Install
	#>
	$GUIImageConvertSplit = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 35
		Width          = 418
		Text           = $lang.ConvertSplit
		Location       = '50,345'
		add_Click      = { Image_Convert_Refresh -Skip }
		Enabled        = $False
	}
	$GUIImageConvertSplitSelect = New-Object System.Windows.Forms.NumericUpDown -Property @{
		Height         = 25
		Width          = 60
		Location       = "68,385"
		Value          = 1
		Minimum        = 1
		Maximum        = 9999
		TextAlign      = 1
		Enabled        = $False
	}
	$GUIImageConvertSplitMB = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 265
		Text           = "MB"
		Location       = "133,385"
		Enabled        = $False
	}
	$GUIImageConvertSplitStatus = New-Object system.Windows.Forms.Label -Property @{
		Height         = 25
		Width          = 400
		Text           = ""
		Location       = "67,420"
	}
	$GUIImageConvertSplitUnlock = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 25
		Width          = 400
		Text           = $lang.ConvertUnlockSplit
		Location       = "67,450"
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		Visible        = 0
		add_Click      = {
			$Script:AllowUnlockConvertESD = $False

			$GUIImageConvertSplit.Enabled = $True
			if ($GUIImageConvertSplit.Checked) {
				$GUIImageConvertSplitSelect.Enabled = $True
				$GUIImageConvertSplitMB.Enabled = $True
			} else {
				$GUIImageConvertSplitSelect.Enabled = $False
				$GUIImageConvertSplitMB.Enabled = $False
			}
		}
	}

	<#
		.Note
		.注意
	#>
	$UI_Main_Tips      = New-Object System.Windows.Forms.RichTextBox -Property @{
		Height         = 440
		Width          = 470
		BorderStyle    = 0
		Location       = "570,20"
		Text           = $lang.ConvertSplitTips
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}

	<#
		.End on-demand mode
		.结束按需模式
	#>
	$UI_Main_Suggestion_Manage = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 25
		Width          = 280
		Text           = $lang.AssignSetting
		Location       = '570,495'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Event_Assign_Setting }
	}
	$UI_Main_Suggestion_Stop_Not_Mounted = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 25
		Width          = 415
		Text           = $lang.AssignEndNoMount
		Location       = '570,525'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = {
			$UI_Main.Hide()
			$Global:Queue_Assign_Not_Monuted_Expand_Select = @()
			$UI_Main.Close()
		}
	}
	$UI_Main_Event_Assign_Stop = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 25
		Width          = 280
		Text           = $lang.AssignForceEnd
		Location       = '570,555'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Suggestion_Stop_Click
	}

	<#
		.Suggested content
		.建议的内容
	#>
	$UI_Main_Suggestion_Not = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 25
		Width          = 280
		Text           = $lang.SuggestedSkip
		Location       = '570,495'
		add_Click      = {
			if ($UI_Main_Suggestion_Not.Checked) {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -name "IsSuggested" -value "True" -String
				$UI_Main_Suggestion_Setting.Enabled = $False
				$UI_Main_Suggestion_Stop.Enabled = $False
			} else {
				Save_Dynamic -regkey "Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -name "IsSuggested" -value "False" -String
				$UI_Main_Suggestion_Setting.Enabled = $True
				$UI_Main_Suggestion_Stop.Enabled = $True
			}
		}
	}
	$UI_Main_Suggestion_Setting = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 25
		Width          = 280
		Text           = $lang.AssignSetting
		Location       = '586,526'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Event_Assign_Setting }
	}
	$UI_Main_Suggestion_Stop = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 25
		Width          = 280
		Text           = $lang.AssignForceEnd
		Location       = '586,555'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $UI_Main_Suggestion_Stop_Click
	}

	$UI_Main_Error     = New-Object system.Windows.Forms.Label -Property @{
		Location       = "10,646"
		Height         = 25
		Width          = 455
		Text           = ""
	}
	$UI_Main_OK        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "560,635"
		Height         = 36
		Width          = 240
		Text           = $lang.OK
		add_Click      = {
			$MarkSelectESDConverMode = $False
			$Global:QueueConvert = $False

			if ($GUIImageConvertToESD.Checked) {
				$MarkSelectESDConverMode = $True
				$Global:QueueConvert = $True
				$Script:ConvertType = 'esd'
			}

			if ($GUIImageConvertToWIM.Checked) {
				$MarkSelectESDConverMode = $True
				$Global:QueueConvert = $True
				$Script:ConvertType = 'wim'
			}

			if ($GUIImageSWM.Checked) {
				$MarkSelectESDConverMode = $True
				$Global:QueueConvert = $True
				$Script:ConvertType = 'swm'
			}

			if ($MarkSelectESDConverMode) {
				$UI_Main.Hide()
				<#
					.转换前创建备份
				#>
				Write-Host "`n   $($lang.ConvertBackup)" -ForegroundColor Green
				if ($GUIImageConvertBackup.Enabled) {
					if ($GUIImageConvertBackup.Checked) {
						$Script:QueueConvertBackup = $True
						Write-Host "   $($lang.Operable)" -ForegroundColor Green
					} else {
						$Script:QueueConvertBackup = $False
						Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
					}
				} else {
					$Script:QueueConvertBackup = $False
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
				}

				<#
					.跳过转换映像
				#>
				Write-Host "`n   $($lang.ConvertSkip)" -ForegroundColor Green
				if ($GUIImageConvertSkip.Enabled) {
					if ($GUIImageConvertSkip.Checked) {
						$Script:QueueConvertSkip = $True
						Write-Host "   $($lang.Operable)" -ForegroundColor Green
					} else {
						$Script:QueueConvertSkip = $False
						Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
					}
				} else {
					$Script:QueueConvertSkip = $False
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
				}

				<#
					.拆分前重建 install.wim
				#>
				Write-Host "`n   $($lang.ConvertRebuld)" -ForegroundColor Green
				if ($GUIImageConvertRebuld.Enabled) {
					if ($GUIImageConvertRebuld.Checked) {
						$Script:QueueConvertRebuld = $True
						Write-Host "   $($lang.Operable)" -ForegroundColor Green
					} else {
						$Script:QueueConvertRebuld = $False
						Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
					}
				} else {
					$Script:QueueConvertRebuld = $False
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
				}

				<#
					.允许拆分
				#>
				Write-Host "`n   $($lang.ConvertSplit)" -ForegroundColor Green
				if ($GUIImageConvertSplit.Enabled) {
					if ($GUIImageConvertSplit.Checked) {
						$Script:QueueConvertSplit = $True
						$Script:QueueConvertSplitSize = $GUIImageConvertSplitSelect.Text
						Write-Host "   $($lang.Operable)" -ForegroundColor Green
					} else {
						$Script:QueueConvertSplit = $False
						Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
					}
				} else {
					$Script:QueueConvertSplit = $False
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
				}

				if ($UI_Main_Suggestion_Not.Checked) {
					Init_Canel_Event
				}
				$UI_Main.Close()
			} else {
				$UI_Main_Error.Text = "$($lang.SelectFromError)$($lang.NoChoose)"
			}
		}
	}
	$UI_Main_Canel     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "807,635"
		Height         = 36
		Width          = 240
		Text           = $lang.Cancel
		add_Click      = {
			$UI_Main.Hide()
			Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
			$Global:QueueConvert = $False
			$Script:QueueConvertBackup = $False
			$Script:QueueConvertSkip = $False
			$Script:QueueConvertBackup = $False

			if ($UI_Main_Suggestion_Not.Checked) {
				Init_Canel_Event
			}
			$UI_Main.Close()
		}
	}
	$UI_Main.controls.AddRange((
		$GUIImageConvertToESD,
		$GUIImageConvertToWIM,
		$GUIImageConvertAdv,
		$GUIImageConvertRebuld,
		$GUIImageConvertSkip,
		$GUIImageConvertBackup,
		$GUIImageConvertBackupTips,
		$GUIImageSWM,
		$GUIImageSWMTips,
		$GUIImageConvertSplit,
		$GUIImageConvertSplitSelect,
		$GUIImageConvertSplitMB,
		$GUIImageConvertSplitStatus,
		$GUIImageConvertSplitUnlock,
		$UI_Main_Tips,
		$UI_Main_Error,
		$UI_Main_OK,
		$UI_Main_Canel
	))

	if (Test-Path "$($Global:MountTo)\sources\install.esd" -PathType Leaf) {
		$GUIImageConvertToESD.Enabled = $True
	} else {
		$GUIImageConvertToESD.Enabled = $False
	}

	if (Test-Path "$($Global:MountTo)\sources\install.wim" -PathType Leaf) {
		$GUIImageConvertToWIM.Enabled = $True
	} else {
		$GUIImageConvertToWIM.Enabled = $False
	}

	<#
		.初始化 SWM
	#>
	$GUIImageConvertSplitSelect.Text = 3892

	if (Test-Path "$($Global:MountTo)\sources\install.swm" -PathType Leaf) {
		$GUIImageSWM.Enabled = $True
		$GUIImageSWMTips.Enabled = $True
	} else {
		$GUIImageSWM.Enabled = $False
		$GUIImageSWMTips.Enabled = $False
	}

	if ($Global:EventQueueMode) {
		$UI_Main.Text = "$($UI_Main.Text) [ $($lang.QueueMode) ]"
		$UI_Main.controls.AddRange((
			$UI_Main_Suggestion_Manage,
			$UI_Main_Suggestion_Stop_Not_Mounted,
			$UI_Main_Event_Assign_Stop
		))
	} else {
		<#
			.初始化复选框：不再建议
		#>
		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions\ImageSources\$($Global:MainImage)\Suggested\$($Global:Event_Guid)" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
				"True" {
					$UI_Main_Suggestion_Not.Checked = $True
					$UI_Main_Suggestion_Setting.Enabled = $False
					$UI_Main_Suggestion_Stop.Enabled = $False
				}
				"False" {
					$UI_Main_Suggestion_Not.Checked = $False
					$UI_Main_Suggestion_Setting.Enabled = $True
					$UI_Main_Suggestion_Stop.Enabled = $True
				}
			}
		} else {
			$UI_Main_Suggestion_Not.Checked = $False
			$UI_Main_Suggestion_Setting.Enabled = $True
			$UI_Main_Suggestion_Stop.Enabled = $True
		}

		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) {
			if ((Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "IsSuggested" -ErrorAction SilentlyContinue) -eq "True") {
				$UI_Main.controls.AddRange((
					$UI_Main_Suggestion_Not,
					$UI_Main_Suggestion_Setting,
					$UI_Main_Suggestion_Stop
				))
			}
		}
	}

	<#
		.Allow open windows to be on top
		.允许打开的窗口后置顶
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -Name "TopMost" -ErrorAction SilentlyContinue) {
			"True" { $UI_Main.TopMost = $True }
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$UI_Main.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$UI_Main.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$UI_Main.FormBorderStyle = 'Fixed3D'
	$UI_Main.ShowDialog() | Out-Null
}

<#
	.Start processing: Convert image
	.开始处理：转换映像
#>
Function Image_Convert_Process
{
	<#
	    .初始化时间：所有任务
	#>
	$Script:CovertTasksTimeStart = Get-Date -Format "yyyy/MM/dd HH:mm:ss"
	$Script:CovertTasksTime = New-Object System.Diagnostics.Stopwatch
	$Script:CovertTasksTime.Reset()
	$Script:CovertTasksTime.Start()

	Write-Host "`n   $('-' * 80)"
	Write-host "   $($lang.TimeStart)" -NoNewline
	Write-host " $($Script:CovertTasksTimeStart -f "yyyy/MM/dd HH:mm:ss")" -ForegroundColor Green
	Write-Host "   $('-' * 80)"
	$Host.UI.RawUI.WindowTitle = "$((Get-Module -Name Solutions).Author)'s Solutions | $($lang.Convert)"

	<#
		.Determine the conversion type
		.判断转换类型
	#>
	$RandomGuid = [guid]::NewGuid()

	switch ($Script:ConvertType)
	{
		'wim'
		{
			<#
				.WIM 转换成 ESD
			#>
			Write-Host "`n   $($lang.Converting -f "WIM", "ESD")"
			Write-Host "   $($Global:MountTo)\sources\install.wim`n"
			if ($Script:QueueConvertBackup) {
				Write-Host "`n   $($lang.ConvertBackup)"
				Write-Host "   $($Global:MountTo)\sources\install.wim"
				Write-Host "   >> "
				Write-Host "   $($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)\install.wim"

				Check_Folder -chkpath "$($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)"

				Copy-Item "$($Global:MountTo)\sources\install.wim" -Destination "$($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)\install.wim" -ErrorAction SilentlyContinue
				Image_Convert_Create_Info_Process -Sources "$($Global:MountTo)\sources\install.wim" -SaveTo "$($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)"
				Write-Host "   $($lang.Done)" -ForegroundColor Green
			}

			<#
				.跳过转换映像
			#>
			Write-Host "`n   $($lang.ConvertSkip)"
			if ($Script:QueueConvertSkip) {
				<#
					.1、跳过转换 install.esd 为 install.wim
					.2、拆分前重建 install.wim
					.3、拆分为 SWM
				#>
				Write-Host "   $($lang.Operable)" -ForegroundColor Green

				<#
					.拆分前重建 install.wim
				#>
				Write-Host "`n   $($lang.ConvertRebuld)"
				if ($Script:QueueConvertSplit) {
					Write-Host "   $($lang.Operable)" -ForegroundColor Green
					Rebuild_Image_File -Filename "$($Global:MountTo)\sources\install.wim"

					Write-Host "   $($lang.Done)" -ForegroundColor Green
				} else {
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
				}

				<#
					.拆分为 SWM
				#>
				Write-Host "`n   $($lang.ConvertSplit)"
				if ($Script:QueueConvertSplit) {
					Write-Host "   $($lang.Operable)" -ForegroundColor Green
					Get-ChildItem -Path "$($Global:MountTo)\sources" -Recurse -include "*.swm" | ForEach-Object {
						Write-Host "   $($lang.Del) ( $($_.Fullname) )`n" -ForegroundColor Green
						Remove-Item -Path $_.Fullname -ErrorAction SilentlyContinue
					}

					if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
						Write-Host "`n   $($lang.Command)" -ForegroundColor Green
						Write-host "   $($lang.Developers_Mode_Location)1" -ForegroundColor Green
						Write-host "   $('-' * 80)"
						write-host "   Split-WindowsImage -ImagePath ""$($Global:MountTo)\sources\install.wim"" -SplitImagePath ""$($Global:MountTo)\sources\install.swm"" -FileSize ""$($Script:QueueConvertSplitSize)"" -CheckIntegrity" -ForegroundColor Green
						Write-host "   $('-' * 80)`n"
					}

					Split-WindowsImage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -ImagePath "$($Global:MountTo)\sources\install.wim" -SplitImagePath "$($Global:MountTo)\sources\install.swm" -FileSize "$($Script:QueueConvertSplitSize)" -CheckIntegrity

					if (Test-Path "$($Global:MountTo)\sources\install.swm" -PathType leaf) {
						Remove_Tree -Path "$($Global:MountTo)\sources\install.wim"
					}

					Write-Host "   $($lang.Done)" -ForegroundColor Green
				} else {
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
				}
			} else {
				<#
					.1、转换 install.wim 为 install.esd
					.2、拆分为 SWM
				#>
				Write-Host "   $($lang.Operable)" -ForegroundColor Green

				if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
					Write-Host "`n   $($lang.Command)" -ForegroundColor Green
					Write-host "   $($lang.Developers_Mode_Location)2" -ForegroundColor Green
					Write-host "   $('-' * 80)"
					write-host "   Get-WindowsImage -ImagePath ""$($Global:MountTo)\sources\install.wim""" -ForegroundColor Green
					Write-host "   $('-' * 80)`n"
				}

				Get-WindowsImage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -ImagePath "$($Global:MountTo)\sources\install.wim" -ErrorAction SilentlyContinue | ForEach-Object {
					Write-Host "   $($lang.SettingIndex)$($_.ImageIndex)"
					$Host.UI.RawUI.WindowTitle = "$($lang.Converting -f "WIM", "ESD"): $($_.ImageIndex)"

					dism /ScratchDir:"""$(Get_Mount_To_Temp)""" /LogPath:"$($Global:SaveToDism)" /export-image /SourceImageFile:"""$($Global:MountTo)\sources\install.wim""" /SourceIndex:"""$($_.ImageIndex)""" /DestinationImageFile:"""$($Global:MountTo)\sources\install.esd""" /Compress:recovery /CheckIntegrity

					Write-Host "   $($lang.Done)" -ForegroundColor Green
				}

				<#
					转换为 ESD 后，判断是否存在新的 install.wim，存在则删除旧的 install.esd
				#>
				if (Test-Path "$($Global:MountTo)\sources\install.esd" -PathType leaf) {
					Remove_Tree -Path "$($Global:MountTo)\sources\install.wim"
				}

				<#
					.拆分 SWM
				#>
				Write-Host "`n   $($lang.ConvertSplit)"
				if ($Script:QueueConvertSplit) {
					Write-Host "   $($lang.Operable)" -ForegroundColor Green
					Get-ChildItem -Path "$($Global:MountTo)\sources" -Recurse -include "*.swm" | ForEach-Object {
						Write-Host "   $($lang.Del) ( $($_.Fullname) )`n" -ForegroundColor Green
						Remove-Item -Path $_.Fullname -ErrorAction SilentlyContinue
					}

					Write-Host "`n   $($Global:MountTo)\sources\install.esd" -ForegroundColor Green
					if (Test-Path "$($Global:MountTo)\sources\install.esd" -PathType leaf) {
						Write-Host "   $($lang.Operable)" -ForegroundColor Green

						if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
							Write-Host "`n   $($lang.Command)" -ForegroundColor Green
							Write-host "   $($lang.Developers_Mode_Location)3" -ForegroundColor Green
							Write-host "   $('-' * 80)"
							write-host "   Split-WindowsImage -ImagePath ""$($Global:MountTo)\sources\install.esd"" -SplitImagePath ""$($Global:MountTo)\sources\install.swm"" -FileSize ""$($Script:QueueConvertSplitSize)"" -CheckIntegrity" -ForegroundColor Green
							Write-host "   $('-' * 80)`n"
						}
	
						Split-WindowsImage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -ImagePath "$($Global:MountTo)\sources\install.esd" -SplitImagePath "$($Global:MountTo)\sources\install.swm" -FileSize "$($Script:QueueConvertSplitSize)" -CheckIntegrity

						if (Test-Path "$($Global:MountTo)\sources\install.swm" -PathType leaf) {
							Remove_Tree -Path "$($Global:MountTo)\sources\install.esd"
							Write-Host "   $($lang.Done)" -ForegroundColor Green
						} else {
							Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
						}
					} else {
						Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
					}

					Write-Host "   $($lang.Done)" -ForegroundColor Green
				} else {
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
				}
			}
			Write-Host "   $($lang.Converting -f "WIM", "ESD") $($lang.Done)" -ForegroundColor Green
		}
		'esd'
		{
			<#
				.ESD 转换成 WIM
			#>
			Write-Host "`n   $($lang.Converting -f "ESD", "WIM")"
			Write-Host "   $($Global:MountTo)\sources\install.esd`n"
			if ($Script:QueueConvertBackup) {
				Write-Host "`n   $($lang.ConvertBackup)"
				Write-Host "   $($Global:MountTo)\sources\install.esd"
				Write-Host "   >> "
				Write-Host "   $($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)\install.esd"

				Check_Folder -chkpath "$($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)"

				Copy-Item "$($Global:MountTo)\sources\install.esd" -Destination "$($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)\install.esd" -ErrorAction SilentlyContinue
				Image_Convert_Create_Info_Process -Sources "$($Global:MountTo)\sources\install.esd" -SaveTo "$($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)"
				Write-Host "   $($lang.Done)" -ForegroundColor Green
			}

			<#
				.跳过转换映像
			#>
			Write-Host "`n   $($lang.ConvertSkip)"
			if ($Script:QueueConvertSkip) {
				<#
					.1、跳过转换 install.wim 为 install.esd
					.2、拆分为 SWM
				#>
				Write-Host "   $($lang.Operable)" -ForegroundColor Green
	
				Write-Host "`n   $($lang.ConvertSplit)"
				if ($Script:QueueConvertSplit) {
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
					Get-ChildItem -Path "$($Global:MountTo)\sources" -Recurse -include "*.swm" | ForEach-Object {
						Write-Host "   $($lang.Del) ( $($_.Fullname) )`n" -ForegroundColor Green
						Remove-Item -Path $_.Fullname -ErrorAction SilentlyContinue
					}

					if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
						Write-Host "`n   $($lang.Command)" -ForegroundColor Green
						Write-host "   $($lang.Developers_Mode_Location)5" -ForegroundColor Green
						Write-host "   $('-' * 80)"
						write-host "   Split-WindowsImage -ImagePath ""$($Global:MountTo)\sources\install.esd"" -SplitImagePath ""$($Global:MountTo)\sources\install.swm"" -FileSize ""$($Script:QueueConvertSplitSize)"" -CheckIntegrity" -ForegroundColor Green
						Write-host "   $('-' * 80)`n"
					}

					Split-WindowsImage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -ImagePath "$($Global:MountTo)\sources\install.wim" -SplitImagePath "$($Global:MountTo)\sources\install.swm" -FileSize "$($Script:QueueConvertSplitSize)" -CheckIntegrity

					if (Test-Path "$($Global:MountTo)\sources\install.swm" -PathType leaf) {
						Remove_Tree -Path "$($Global:MountTo)\sources\install.wim"
					}

					Write-Host "   $($lang.Done)" -ForegroundColor Green
				} else {
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
				}
			} else {
				<#
					.1、转换 install.esd 为 install.wim
					.2、拆分为 SWM
				#>
				Write-Host "   $($lang.Operable)" -ForegroundColor Green

				if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
					Write-Host "`n   $($lang.Command)" -ForegroundColor Green
					Write-host "   $($lang.Developers_Mode_Location)6" -ForegroundColor Green
					Write-host "   $('-' * 80)"
					write-host "   Get-WindowsImage -ImagePath ""$($Global:MountTo)\sources\install.esd""" -ForegroundColor Green
					Write-host "   $('-' * 80)`n"
				}

				Get-WindowsImage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -ImagePath "$($Global:MountTo)\sources\install.esd" -ErrorAction SilentlyContinue | ForEach-Object {
					Write-Host "   $($lang.SettingIndex)$($_.ImageIndex)"
					$Host.UI.RawUI.WindowTitle = "$($lang.Converting -f "ESD", "WIM"): $($_.ImageIndex)"

					dism /ScratchDir:"""$(Get_Mount_To_Temp)""" /LogPath:"$($Global:SaveToDism)" /export-image /SourceImageFile:"""$($Global:MountTo)\sources\install.esd""" /SourceIndex:"""$($_.ImageIndex)""" /DestinationImageFile:"""$($Global:MountTo)\sources\install.wim""" /Compress:max /CheckIntegrity

					Write-Host "   $($lang.Done)" -ForegroundColor Green
				}

				<#
					转换为 wim 后，判断是否存在新的 install.wim，存在则删除旧的 install.esd
				#>
				if (Test-Path "$($Global:MountTo)\sources\install.wim" -PathType leaf) {
					Remove_Tree -Path "$($Global:MountTo)\sources\install.esd"
				}

				<#
					.拆分 SWM
				#>
				Write-Host "`n   $($lang.ConvertSplit)"
				if ($Script:QueueConvertSplit) {
					Write-Host "   $($lang.Operable)" -ForegroundColor Green
					Get-ChildItem -Path "$($Global:MountTo)\sources" -Recurse -include "*.swm" | ForEach-Object {
						Write-Host "   $($lang.Del) ( $($_.Fullname) )`n" -ForegroundColor Green
						Remove-Item -Path $_.Fullname -ErrorAction SilentlyContinue
					}

					Write-Host "`n   $($Global:MountTo)\sources\install.wim" -ForegroundColor Green
					if (Test-Path "$($Global:MountTo)\sources\install.wim" -PathType leaf) {
						Write-Host "   $($lang.Operable)" -ForegroundColor Green

						if ((Get-ItemProperty -Path "HKCU:\SOFTWARE\$((Get-Module -Name Solutions).Author)\Solutions" -ErrorAction SilentlyContinue).'ShowCommand' -eq "True") {
							Write-Host "`n   $($lang.Command)" -ForegroundColor Green
							Write-host "   $($lang.Developers_Mode_Location)7" -ForegroundColor Green
							Write-host "   $('-' * 80)"
							write-host "   Split-WindowsImage -ImagePath ""$($Global:MountTo)\sources\install.wim"" -SplitImagePath ""$($Global:MountTo)\sources\install.swm"" -FileSize ""$($Script:QueueConvertSplitSize)"" -CheckIntegrity" -ForegroundColor Green
							Write-host "   $('-' * 80)`n"
						}
	
						Split-WindowsImage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -ImagePath "$($Global:MountTo)\sources\install.wim" -SplitImagePath "$($Global:MountTo)\sources\install.swm" -FileSize "$($Script:QueueConvertSplitSize)" -CheckIntegrity

						if (Test-Path "$($Global:MountTo)\sources\install.swm" -PathType leaf) {
							Remove_Tree -Path "$($Global:MountTo)\sources\install.wim"
							Write-Host "   $($lang.Done)" -ForegroundColor Green
						} else {
							Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
						}
					} else {
						Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
					}

					Write-Host "   $($lang.Done)" -ForegroundColor Green
				} else {
					Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
				}
			}
			Write-Host "   $($lang.Converting -f "ESD", "WIM") $($lang.Done)" -ForegroundColor Green
		}
		'swm'
		{
			Write-Host "`n   $($lang.Converting -f "Swm", "wim")"
			Write-Host "   $($Global:MountTo)\sources\install.swm`n"

			if ($Script:QueueConvertBackup) {
				Write-Host "`n   $($lang.ConvertBackup)"
				Write-Host "   $($Global:MountTo)\sources\install*.swm"
				Write-Host "   >> "
				Write-Host "   $($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)\install*.swm"

				Check_Folder -chkpath "$($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)"

				Copy-Item "$($Global:MountTo)\sources\*.swm" -Destination "$($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)" -ErrorAction SilentlyContinue
				Image_Convert_Create_Info_Process -Sources "$($Global:MountTo)\sources\install.swm" -SaveTo "$($Global:MainMasterFolder)\Backup\Install.wim\$($RandomGuid)"
				Write-Host "   $($lang.Done)`n" -ForegroundColor Green
			}

			if (Test-Path "$($Global:MountTo)\sources\install.wim" -PathType leaf) {
				Remove-Item -Path "$($Global:MountTo)\sources\install.wim" -ErrorAction SilentlyContinue
			}

			Get-WindowsImage -ScratchDirectory "$(Get_Mount_To_Temp)" -LogPath "$($Global:SaveToDism)" -ImagePath "$($Global:MountTo)\sources\install.swm" -ErrorAction SilentlyContinue | ForEach-Object {
				Write-Host "   $($lang.SettingIndex)$($_.ImageIndex)"
				$Host.UI.RawUI.WindowTitle = "$($lang.Converting -f "Swm", "WIM: $($_.ImageIndex)")"

				dism /ScratchDir:"""$(Get_Mount_To_Temp)""" /LogPath:"$($Global:SaveToDism)" /export-image /SourceImageFile:"""$($Global:MountTo)\sources\install.swm""" /swmfile:"""$($Global:MountTo)\sources\install*.swm""" /SourceIndex:"""$($_.ImageIndex)""" /DestinationImageFile:"""$($Global:MountTo)\sources\install.wim""" /Compress:max /CheckIntegrity

				Write-Host "   $($lang.Done)`n" -ForegroundColor Green
			}

			if (Test-Path "$($Global:MountTo)\sources\install.wim" -PathType leaf) {
				Get-ChildItem -Path "$($Global:MountTo)\sources" -Recurse -include "*.swm" | ForEach-Object {
					Write-Host "   $($lang.Del) ( $($_.Fullname) )" -ForegroundColor Green
					Remove-Item -Path $_.Fullname -ErrorAction SilentlyContinue
				}
			}
			Write-Host "   $($lang.Converting -f "Swm", "WIM: $($lang.Done)")" -ForegroundColor Green
		}
	}

	$Script:CovertTasksTime.Stop()
	Write-Host "`n   $('-' * 80)"
	Write-Host "   $($lang.TimeStart)" -NoNewline
	Write-Host "$($Script:CovertTasksTimeStart -f "yyyy/MM/dd HH:mm:ss")" -ForegroundColor Yellow

	Write-Host "   $($lang.TimeEnd)" -NoNewline
	Write-Host "$(Get-Date -Format "yyyy/MM/dd HH:mm:ss")" -ForegroundColor Yellow

	Write-Host "   $($lang.TimeEndAll)" -NoNewline
	Write-Host "$($Script:CovertTasksTime.Elapsed)" -ForegroundColor Yellow

	Write-Host "   $($lang.TimeEndAllseconds)" -NoNewline
	Write-Host "$($Script:CovertTasksTime.ElapsedMilliseconds) $($lang.TimeMillisecond)" -ForegroundColor Yellow
	Write-Host "   $('-' * 80)"

	Write-Host "   $($lang.Done)`n" -ForegroundColor Green
}