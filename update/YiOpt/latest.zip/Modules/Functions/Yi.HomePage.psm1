﻿<#
	.LOGO
#>
Function Logo
{
	param
	(
		$Title
	)
	Clear-Host
	$Host.UI.RawUI.WindowTitle = "$($Global:UniqueID)'s Solutions | $($Title)"
	Write-Host "`n   Author: $($Global:UniqueID) ( $($Global:AuthorURL) )

   From: $($Global:UniqueID)'s Solutions
   buildstring: $((Get-Module -Name Yi).Version.ToString()).bs_release.220201-1208`n"
}

<#
	.主界面
	.Main interface
#>
Function Mainpage
{
	Logo -Title $($lang.Mainname)
	Write-Host "   $($lang.Mainname)`n   ---------------------------------------------------"

	write-host "   1. $($lang.Update)
   2. $($lang.FirstExperience)
   3. $($lang.RestorePoint)" -ForegroundColor Green

   write-host  "`n   [*] A. $($lang.Oneclick) BCDEFGH"

	write-host  "       B. $($lang.LocationUserFolder)
       C. $($lang.DeskIcon)
       D. $($lang.Optimize) $($lang.System)
       E. $($lang.Optimize) $($lang.Service)
       F. $($lang.Instl) $($lang.MostUsedSoftware)
       G. $($lang.Delete) $($lang.ComesWith)
       H. $($lang.Delete) $($lang.UninstallUWP)


   L. $($lang.SwitchLanguage)
   R. $($lang.RefreshModules)
   Q. $($lang.Exit)`n"

	$select = Read-Host "   $($lang.Choose)"
	switch ($select)
	{
		"1" {
			Update
			ToMainpage -wait 2
		}
		"2" {
			FirstExperience
			ToMainpage -wait 2
		}
		"3" {
			Restore_Point_Create_UI
			ToMainpage -wait 2
		}
		"a" {
			if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\YiOpt" -Name "RestorePointPrompt" -ErrorAction SilentlyContinue) {
				$GetRestorePointPrompt = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\YiOpt" -Name "RestorePointPrompt"
				switch ($GetRestorePointPrompt) {
					"False" { Restore_Point_Create_UI }
				}
			} else {
				Restore_Point_Create_UI
			}

			Change_Location -Force
			Desktop -Force
			Optimization_System_UI -Force
			Optimization_Service_UI -Force
			System_Software_UI -Force
			UWP_Uninstall -Force
			Most_Used_Software -Force
			Wait_Process_End
			ToMainpage -wait 4
		}
		"b" { Change_Location }
		"c" { Desktop }
		"d" { Optimization_System_UI }
		"e" { Optimization_Service_UI }
		"f" { Most_Used_Software }
		"g" { System_Software_UI }
		"h" { UWP_Uninstall }
		"l" {
			Language -Reset
			Mainpage
		}
		"r" {
			Modules_Refresh
		}
		"q" {
			Modules_Import
			exit
		}
		default { Mainpage }
	}
}

<#
	.返回到主界面
	.Return to the main interface
#>
Function ToMainpage
{
	param
	(
		[int]$wait
	)

	if ($Global:QUIT) {
		$Global:QUIT = $False
		Write-Host $($lang.ToQuit -f $wait) -ForegroundColor Red
		Start-Sleep -s $wait
		Modules_Import
		exit
	} else {
		Write-Host $($lang.ToMsg -f $wait) -ForegroundColor Red
		Start-Sleep -s $wait
		Mainpage
	}
}