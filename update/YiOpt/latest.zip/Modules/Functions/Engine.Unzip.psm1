﻿<#
 .Synopsis
  Unzip the compressed package

 .Description
  Unzip the compressed package Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Unzip the compressed package
	.解压压缩包
#>
Function UnzipThePackage
{
	<#
		.Extracting passwords
		.解压：密码
	#>
	$UnpackPasswordFiles = @(
		,("dControl*",  "dControl",           "sordum")
	)

	foreach ($item in $UnpackPasswordFiles) {
		Get-ChildItem –Path "$($PSScriptRoot)\..\..\AIO" -filter "$($item[1]).zip" –Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
			Write-host "   * $($_.FullName)"
			$SaveToName = [IO.Path]::GetDirectoryName($_.FullName)

			if ($item[2] -eq "sordum") {
				Add-MpPreference -ExclusionPath "$SaveToName" -ErrorAction SilentlyContinue | Out-Null
			}

			Archive -Password $($item[2]) -filename $_.FullName -to $SaveToName
	
			Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue
		}
	}
	Write-Host ""
}

Function PinToStart
{
	$syspin    = "$(GetArchitecturePacker -Path "$($PSScriptRoot)\..\..\AIO\syspin")\syspin.exe"
	$StartMenu = "$($env:SystemDrive)\ProgramData\Microsoft\Windows\Start Menu\Programs\$($Global:UniqueID)'s Solutions"

	if (Test-Path $syspin -PathType Leaf) {
		Start-Process -FilePath $syspin -ArgumentList """$($StartMenu)\- $($Global:UniqueID)'s Solutions -.lnk"" ""51201""" -Wait -WindowStyle Hidden
	}
}

Export-ModuleMember -Function * -Alias *