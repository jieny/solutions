﻿<#
   .Summary
	Yi's Solutions

   .Feature
	- Automatic recognition system subject
	- Rebuild Desktop.ini
	- Modify the contents of the registry
#>

Set-Location "$PSScriptRoot\.."
$global:UniqueID = "Yi"

function RefreshIconCache
{
	$code = @'
	private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
	private const int WM_SETTINGCHANGE = 0x1a;
	private const int SMTO_ABORTIFHUNG = 0x0002;

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
private static extern IntPtr SendMessageTimeout ( IntPtr hWnd, int Msg, IntPtr wParam, string lParam, uint fuFlags, uint uTimeout, IntPtr lpdwResult );

[System.Runtime.InteropServices.DllImport("Shell32.dll")] 
private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

public static void Refresh() {
	SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);
	SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);
}
'@

	Add-Type -MemberDefinition $code -Namespace MyWinAPI -Name Explorer
	[MyWinAPI.Explorer]::Refresh()
}

function SetDeskedit
{
	param
	(
		[string]$ico
	)
	$Deskedit = "$PSScriptRoot\AIO\DeskEdit\DeskEdit.exe"

	if (Test-Path $Deskedit -PathType Leaf) {
		Start-Process -FilePath $Deskedit -ArgumentList "/F=""$(Get-Location)"" /S=.ShellClassInfo /L=IconResource=""$(Get-Location)\$($global:UniqueID)\icons\$($ico),0"""
	}
}

function SetRightMenu
{
	param
	(
		[string]$ico
	)
	$ProductCodeMenu   = "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($global:UniqueID)"

	if (Get-ItemProperty -Path $ProductCodeMenu -Name 'icon' -ErrorAction SilentlyContinue) {
		New-ItemProperty -Path $ProductCodeMenu -Name "icon" -Value "$(Get-Location)\$($global:UniqueID)\icons\$($ico)" -PropertyType STRING -Force | Out-Null
	}
}

function IsDark
{
	$SysTheme = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
	$ProductCode       = "HKCU:\SOFTWARE\$($global:UniqueID)"

	if (-not (Get-ItemProperty -Path $SysTheme -Name 'AppsUseLightTheme' -ErrorAction SilentlyContinue)) {
		write-host "6x0"
		exit
	}

	if (-not (Test-Path $ProductCode)) {
		New-Item -Path $ProductCode -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath $ProductCode -Name 'isDark' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	}

	if (-not (Get-ItemProperty -Path $ProductCode -Name 'isDark' -ErrorAction SilentlyContinue)) {
		New-ItemProperty -LiteralPath $ProductCode -Name 'isDark' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	}

	$resultSysTheme = Get-ItemPropertyValue -Path $SysTheme -Name "AppsUseLightTheme"
	$resultProductCodeTheme = Get-ItemPropertyValue -Path $ProductCode -Name "isDark"

	switch($resultSysTheme)
	{
		"0"
		{
			Write-Output "Dark mode process"
			switch($resultProductCodeTheme)
			{
				"0"
				{
					Write-Output "1. Jump over..."
				}
				"1"
				{
					Write-Output "2. Change"
					SetDeskedit -ico "$($global:UniqueID).Dark.ico"
					SetRightMenu -ico "$($global:UniqueID).Dark.ico"
					New-ItemProperty -Path $ProductCode -Name "isDark" -Value "0" -PropertyType STRING -Force | Out-Null
					RefreshIconCache
				}
				default
				{
					Write-Output "3. Change"
					SetDeskedit -ico "$($global:UniqueID).Dark.ico"
					SetRightMenu -ico "$($global:UniqueID).Dark.ico"
					New-ItemProperty -Path $ProductCode -Name "isDark" -Value "0" -PropertyType STRING -Force | Out-Null
					RefreshIconCache
				}
			}
		}
		"1"
		{
			Write-Output "Light mode process"
			switch($resultProductCodeTheme)
			{
				"0"
				{
					Write-Output "4. Change"
					SetDeskedit -ico "$($global:UniqueID).ico"
					SetRightMenu -ico "$($global:UniqueID).ico"
					New-ItemProperty -Path $ProductCode -Name "isDark" -Value "1" -PropertyType STRING -Force | Out-Null
					RefreshIconCache
				}
				"1"
				{
					Write-Output "5. Jump over..."
				}
				default
				{
					Write-Output "6. Change"
					SetDeskedit -ico "$($global:UniqueID).ico"
					SetRightMenu -ico "$($global:UniqueID).ico"
					New-ItemProperty -Path $ProductCode -Name "isDark" -Value "1" -PropertyType STRING -Force | Out-Null
					RefreshIconCache
				}
			}
		}
	}
}

IsDark