﻿<#
 .Synopsis
  Essential software

 .Description
  Essential software Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Install prerequisite software
	.安装必备软件
#>
$Global:PrerequisiteApp = @(
	("Google Chrome",
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Queue,
	 $env:SystemDrive,
	 "$($Global:UniqueID)\00\Google Chrome",
	 "",
	 "https://google.com/chrome/google.exe",
	 "",
	 "",
	 "GoogleChrome*",
	 "/silent /install",
	 "",
	 "Chrome"),
	("7Zip",
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Queue,
	 $env:SystemDrive,
	 "$($Global:UniqueID)\00\7Z",
	 "",
	 "https://www.7-zip.org/a/7z2103.exe",
	 "https://www.7-zip.org/a/7z2103-x64.exe",
	 "https://www.7-zip.org/a/7z2103-arm64.exe",
	 "7z*",
	 "/S",
	 "",
	 ""),
	("WinRAR",
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Queue,
	 $env:SystemDrive,
	 "$($Global:UniqueID)\00\WinRAR",
	 "",
	 $($lang.Winrar),
	 $($lang.WinrarAMD64),
	 "",
	 "winrar*",
	 "/S",
	 "",
	 ""),
	("VisualCppRedist AIO",
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Queue,
	 $env:SystemDrive,
	 "$($Global:UniqueID)\00\VisualCppRedist",
	 "",
	 "https://github.com/abbodi1406/vcredist/releases/download/v0.53.0/VisualCppRedist_AIO_x86_x64_53.exe",
	 "",
	 "",
	 "VisualCppRedist*",
	 "/y",
	 "",
	 "")
)

Function Prerequisite
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title "$($lang.Instl) $($lang.Necessary)"
	Write-Host "   $($lang.Necessary)`n   ---------------------------------------------------"
   
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIPreMenuAllSelClick = {
		$GUIPrePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true }
		}
	}
	$GUIPreMenuAllClearClick = {
		$GUIPrePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false }
		}
	}
	$GUIPreCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIPre.Close()
	}
	$GUIPreOKClick = {
		$GUIPre.Hide()
		$GUIPrePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Checked) {
					$NewName = $_.Tag
					switch ($NewName) {
						"MS" {
							if ($GUIPreMSOffice.Checked) {
								InstallProcess -appname "Microsoft Office" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\00\OInstall" -pwd "OInstall" -url "https://microsoft.com/OInstall.zip" -urlAMD64 "" -urlarm64 "" -filename "OInstall*" -param "" -Before "" -After ""
							}
						}
						"WPS" { if ($GUIPreWPS.Checked) { WPS -Silent -Force } }
						Default {
							InstallProcess -appname $Global:PrerequisiteApp[$NewName][0] -status "Enable" -act $Global:PrerequisiteApp[$NewName][2] -mode $Global:PrerequisiteApp[$NewName][3] -todisk $Global:PrerequisiteApp[$NewName][4] -structure $Global:PrerequisiteApp[$NewName][5] -pwd $Global:PrerequisiteApp[$NewName][6] -url $Global:PrerequisiteApp[$NewName][7] -urlAMD64 $Global:PrerequisiteApp[$NewName][8] -urlarm64 $Global:PrerequisiteApp[$NewName][9] -filename $Global:PrerequisiteApp[$NewName][10] -param $Global:PrerequisiteApp[$NewName][11] -Before $Global:PrerequisiteApp[$NewName][12] -After $Global:PrerequisiteApp[$NewName][13]
						}
					}
				}
			}
		}
		$GUIPre.Close()
	}
	$GUIPre            = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 600
		Width          = 450
		Text           = "$($lang.Instl) $($lang.Necessary)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUIPrePanel       = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 500
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 1
	}
	$GUIPreMSOffice    = New-Object System.Windows.Forms.CheckBox -Property @{
		UseVisualStyleBackColor = $True
		Location       = "345,515"
		Height         = 28
		Width          = 405
		Text           = "Microsoft Office"
		Tag            = "MS"
	}
	$GUIPreWPS         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = $lang.OfficeWPS
		Tag            = "WPS"
		Checked        = $true
	}
	$GUIPreOK          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "10,515"
		Height         = 36
		Width          = 202
		add_Click      = $GUIPreOKClick
		Text           = $lang.OK
	}
	$GUIPreCanel       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "218,515"
		Height         = 36
		Width          = 202
		add_Click      = $GUIPreCanelClick
		Text           = $lang.Cancel
	}
	$GUIPre.controls.AddRange((
		$GUIPrePanel,
		$GUIPreOK,
		$GUIPreCanel
	))

	for ($i=0; $i -lt $Global:PrerequisiteApp.Count; $i++) {
		$CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
			Height = 28
			Width  = 405
			Text   = $Global:PrerequisiteApp[$i][0]
			Tag    = $i
		}

		if ($Global:PrerequisiteApp[$i][1] -like "Enable") {
			$CheckBox.Checked = $true
		} else {
			$CheckBox.Checked = $false
		}
		$GUIPrePanel.controls.AddRange($CheckBox)		
	}

	if (Test-Path "$PSScriptRoot\..\..\..\00\OInstall\$((Get-Culture).Name)\OInstall.*" -PathType Leaf) {
		$GUIPrePanel.controls.AddRange($GUIPreMSOffice)
	} else {
		if (Test-Path "$PSScriptRoot\..\..\..\00\OInstall\en-US\OInstall.*" -PathType Leaf) {
			$GUIPrePanel.controls.AddRange($GUIPreMSOffice)
		}
	}
	$GUIPrePanel.controls.AddRange($GUIPreWPS)

	$GUIPreMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIPreMenu.Items.Add($lang.AllSel).add_Click($GUIPreMenuAllSelClick)
	$GUIPreMenu.Items.Add($lang.AllClear).add_Click($GUIPreMenuAllClearClick)
	$GUIPre.ContextMenuStrip = $GUIPreMenu

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIPre.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIPre.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$GUIPre.FormBorderStyle = 'Fixed3D'
	$GUIPre.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

Enum Status
{
	Enable
	Disable
}

Enum Mode
{
	Wait
	Fast
	Queue
}

Enum Action
{
	Install
	NoInst
	To
	Unzip
}

Export-ModuleMember -Function * -Alias *