﻿<#
 .Synopsis
  Change Location

 .Description
  Change Location Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

Function ChangeLocation {
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.LocationUserFolder)
	Write-Host "   $($lang.LocationUserFolder)`n   ---------------------------------------------------"

	<#
		.初始化：获取当前位置
	#>
	$DesktopOldpath = [Environment]::GetFolderPath("Desktop")
	$MyDocumentsOldpath = [Environment]::GetFolderPath("MyDocuments")
	$DownloadsOldpath = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
	$MusicOldpath = [Environment]::GetFolderPath("MyMusic")
	$PicturesOldpath = [Environment]::GetFolderPath("MyPictures")
	$VideoOldpath = [Environment]::GetFolderPath("MyVideos")

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	Function SelectNewFolder {
		param
		(
			[Parameter(Mandatory = $true)]
			[ValidateSet('Desktop', 'Documents', 'Downloads', 'Music', 'Pictures', 'Videos')]
            [string]$KnownFolder
		)

		$GUILocationErrorMsg.Text = ""
		$FolderBrowser   = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{
			RootFolder   = "MyComputer"
			Description  = "Select a folder"
			SelectedPath = $initialDirectory
		}
	
		if ($FolderBrowser.ShowDialog() -eq "OK") {
			if (TestAvailableDisk -Path $FolderBrowser.SelectedPath) {
				switch ($KnownFolder) {
					"Desktop"   { $GUILocationItemDesktopShow.Text = $FolderBrowser.SelectedPath }
					"Documents" { $GUILocationItemDocumentsShow.Text = $FolderBrowser.SelectedPath }
					"Downloads" { $GUILocationItemDownloadsShow.Text = $FolderBrowser.SelectedPath }
					"Music"     { $GUILocationItemMusicShow.Text = $FolderBrowser.SelectedPath }
					"Pictures"  { $GUILocationItemPicturesShow.Text = $FolderBrowser.SelectedPath }
					"Videos"    { $GUILocationItemVideosShow.Text = $FolderBrowser.SelectedPath }
				}
			} else {
				$GUILocationErrorMsg.Text = $lang.LocationFolderError
			}
		}
	}
	Function RefreshGetMountDisk {
		$GUILocationPane1.controls.Clear()
		Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
			if (TestAvailableDisk -Path $_.Root) {
				$RadioButton  = New-Object System.Windows.Forms.RadioButton -Property @{
					Height    = 22
					Width     = 320
					Text      = $_.Root
					Tag       = $_.Description
					add_Click = { RefreshLoction }
				}
				if ($GUILocationLowSize.Checked) {
					if (-not (VerifyAvailableSize -Disk $_.Root -Size $SelectLowSize.Text)) {
						$RadioButton.Enabled = $False
					}
				}
				$GUILocationPane1.controls.AddRange($RadioButton)
			}
		}
	}
	Function RefreshLoction {
		$GUILocationErrorMsg.Text = ""
		$FlagCheckDiskSelect = $False
		$GUILocationPane1.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Checked) {
					$FlagCheckDiskSelect = $True
					$FlagsNewLabelSpecify = $_.Text

					if ($GUILocationCustomize.Checked) {
						<#
							.Mark: Determine the directory prefix
							.标记：判断目录前缀
						#>
						$FlagCheckFolderPrefix = $False

						<#
							.Necessary judgment
							.必备判断
						#>
						<#
							.Judgment: 1. Null value
							.判断：1. 空值
						#>
						if ([string]::IsNullOrEmpty($GUILocationCustomizeShow.Text)) {
							$GUILocationErrorMsg.Text = "$($lang.SelectFromError -f $($lang.NoSetFolderLabel))"
							return
						}

						<#
							.Judgment: 2. The prefix cannot contain spaces
							.判断：2. 前缀不能带空格
						#>
						if ($GUILocationCustomizeShow.Text -match '^\s') {
							$GUILocationErrorMsg.Text = "$($lang.SelectFromError -f $($lang.ISO9660TipsErrorSpace))"
							return
						}

						<#
							.Judgment: 3. No spaces at the end
							.判断：3. 前缀不能带空格
						#>
						if ($GUILocationCustomizeShow.Text -match '\s$') {
							$GUILocationErrorMsg.Text = "$($lang.SelectFromError -f $($lang.ISO9660TipsErrorSpace))"
							return
						}

						<#
							.Judgment: 4. There can be no two spaces in between
							.判断：4. 中间不能含有二个空格
						#>
						if ($GUILocationCustomizeShow.Text -match '\s{2,}') {
							$GUILocationErrorMsg.Text = "$($lang.SelectFromError -f $($lang.ISO9660TipsErrorSpace))"
							return
						}

						<#
							.Judgment: 5. Cannot contain: \\ /: *? "" <> |
							.判断：5, 不能包含：\\ / : * ? "" < > |
						#>
						if ($GUILocationCustomizeShow.Text -match '[~#$@!%&*{}\\:<>?/|+"]') {
							$GUILocationErrorMsg.Text = "$($lang.SelectFromError -f $($lang.ISO9660TipsErrorOther))"
							return
						}
						<#
							.Judgment: 6. No more than 260 characters
							.判断：6. 不能大于 260 字符
						#>
						if ($GUILocationCustomizeShow.Text.length -gt 128) {
							$GUILocationErrorMsg.Text = "$($lang.SelectFromError -f $($lang.ISOLengthError -f "260"))"
							return
						}

						$FlagsNewLabelSpecify += "$($GUILocationCustomizeShow.Text)\"
						DynamicSave -regkey "UserFolder" -name "Folder" -value "$($GUILocationCustomizeShow.Text)" -String
					}

					if ($GUILocationComputer.Checked) {
						$FlagsNewLabelSpecify += "$($env:COMPUTERNAME)\"
					}

					if ($GUILocationUsers.Checked) {
						$FlagsNewLabelSpecify += "Users\"
					}

					if ($GUILocationUserName.Checked) {
						$FlagsNewLabelSpecify += "$($env:UserName)\"
					}

					if ($GUILocationItemDesktop.Checked) {
						$GUILocationItemDesktopShow.Text = "$($FlagsNewLabelSpecify)Desktop"
					}

					if ($GUILocationItemDocuments.Checked) {
						$GUILocationItemDocumentsShow.Text = "$($FlagsNewLabelSpecify)Documents"
					}

					if ($GUILocationItemDownloads.Checked) {
						$GUILocationItemDownloadsShow.Text = "$($FlagsNewLabelSpecify)Downloads"
					}

					if ($GUILocationItemMusic.Checked) {
						$GUILocationItemMusicShow.Text = "$($FlagsNewLabelSpecify)Music"
					}

					if ($GUILocationItemPictures.Checked) {
						$GUILocationItemPicturesShow.Text = "$($FlagsNewLabelSpecify)Pictures"
					}

					if ($GUILocationItemVideos.Checked) {
						$GUILocationItemVideosShow.Text = "$($FlagsNewLabelSpecify)Videos"
					}
				}
			}
		}
		if (-not ($FlagCheckDiskSelect)) {
			$GUILocationItemDesktopShow.Text = $DesktopOldpath
			$GUILocationItemDocumentsShow.Text = $MyDocumentsOldpath
			$GUILocationItemDownloadsShow.Text = $DownloadsOldpath
			$GUILocationItemMusicShow.Text = $MusicOldpath
			$GUILocationItemPicturesShow.Text = $PicturesOldpath
			$GUILocationItemVideosShow.Text = $VideoOldpath
		}
	}
	$GUILocationLowSizeClick = {
		if ($GUILocationLowSize.Checked) {
			$SelectLowSize.Enabled = $True
		} else {
			$SelectLowSize.Enabled = $False
		}
		RefreshGetMountDisk
	}

	$GUILocationItemDesktopClick = {
		if ($GUILocationItemDesktop.Checked) {
			$GUILocationItemDesktopSelect.Enabled = $True
		} else {
			$GUILocationItemDesktopSelect.Enabled = $False
		}
	}

	$GUILocationItemDocumentsClick = {
		if ($GUILocationItemDocuments.Checked) {
			$GUILocationItemDocumentsSelect.Enabled = $True
		} else {
			$GUILocationItemDocumentsSelect.Enabled = $False
		}
	}

	$GUILocationItemDownloadsClick = {
		if ($GUILocationItemDownloads.Checked) {
			$GUILocationItemDownloadsSelect.Enabled = $True
		} else {
			$GUILocationItemDownloadsSelect.Enabled = $False
		}
	}

	$GUILocationItemMusicClick = {
		if ($GUILocationItemMusic.Checked) {
			$GUILocationItemMusicSelect.Enabled = $True
		} else {
			$GUILocationItemMusicSelect.Enabled = $False
		}
	}

	$GUILocationItemPicturesClick = {
		if ($GUILocationItemPictures.Checked) {
			$GUILocationItemPicturesSelect.Enabled = $True
		} else {
			$GUILocationItemPicturesSelect.Enabled = $False
		}
	}

	$GUILocationItemVideosClick = {
		if ($GUILocationItemVideos.Checked) {
			$GUILocationItemVideosSelect.Enabled = $True
		} else {
			$GUILocationItemVideosSelect.Enabled = $False
		}
	}
	$GUILocationCurrentClick = {
		$GUILocationItemDesktopShow.Text = $DesktopOldpath
		$GUILocationItemDocumentsShow.Text = $MyDocumentsOldpath
		$GUILocationItemDownloadsShow.Text = $DownloadsOldpath
		$GUILocationItemMusicShow.Text = $MusicOldpath
		$GUILocationItemPicturesShow.Text = $PicturesOldpath
		$GUILocationItemVideosShow.Text = $VideoOldpath
	}
	$GUILocationInitialClick = {
		$GUILocationItemDesktopShow.Text = "$($env:USERPROFILE)\Desktop"
		$GUILocationItemDocumentsShow.Text = "$($env:USERPROFILE)\Documents"
		$GUILocationItemDownloadsShow.Text = "$($env:USERPROFILE)\Downloads"
		$GUILocationItemMusicShow.Text = "$($env:USERPROFILE)\Music"
		$GUILocationItemPicturesShow.Text = "$($env:USERPROFILE)\Pictures"
		$GUILocationItemVideosShow.Text = "$($env:USERPROFILE)\Videos"
	}
	$GUILocationCustomizeClick = {
		if ($GUILocationCustomize.Checked) {
			$GUILocationCustomizeShow.Enabled = $True
			DynamicSave -regkey "UserFolder" -name "AllowCustomize" -value "True" -String
		} else {
			$GUILocationCustomizeShow.Enabled = $False
			DynamicSave -regkey "UserFolder" -name "AllowCustomize" -value "False" -String
		}
		RefreshLoction
	}
	$GUILocationCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUILocation.Close()
	}
	$GUILocationOKClick = {
		$GUILocation.Hide()
		if ($GUILocationFinishSync.Checked) {
			$Global:LocationFinishSync = $True
		} else {
			$Global:LocationFinishSync = $False
		}

		if ($GUILocationFinishClear.Checked) {
			$Global:LocationFinishClear = $True
		} else {
			$Global:LocationFinishClear = $False
		}

		if ($GUILocationItemDesktop.Checked) {
			SetKnownFolderPath -KnownFolder "Desktop" -Path $($GUILocationItemDesktopShow.Text)
		}

		if ($GUILocationItemDocuments.Checked) {
			SetKnownFolderPath -KnownFolder "Documents" -Path $($GUILocationItemDocumentsShow.Text)
		}

		if ($GUILocationItemDownloads.Checked) {
			SetKnownFolderPath -KnownFolder "Downloads" -Path $($GUILocationItemDownloadsShow.Text)
		}

		if ($GUILocationItemMusic.Checked) {
			SetKnownFolderPath -KnownFolder "Music" -Path $($GUILocationItemMusicShow.Text)
		}

		if ($GUILocationItemPictures.Checked) {
			SetKnownFolderPath -KnownFolder "Pictures" -Path $($GUILocationItemPicturesShow.Text)
		}

		if ($GUILocationItemVideos.Checked) {
			SetKnownFolderPath -KnownFolder "Videos" -Path $($GUILocationItemVideosShow.Text)
		}
		$GUILocation.Close()
	}
	$GUILocation       = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 600
		Width          = 935
		Text           = $lang.LocationUserFolder
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	<#
		.可选功能
	#>
	$GUILocationAdv    = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.AdvOption
		Location       = '10,5'
	}
	$GUILocationStructure = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 400
		Text           = $lang.LocationStructure
		Location       = '24,28'
	}
	$GUILocationCustomize = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 360
		Text           = $lang.FolderLabel
		Location       = '40,50'
		add_Click      = $GUILocationCustomizeClick
	}
	$GUILocationCustomizeShow = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 335
		Text           = ""
		Location       = '56,75'
		BackColor      = "#FFFFFF"
	}
	$GUILocationCustomizeTips = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 62
		Width          = 345
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $False
		Padding        = 0
		Dock           = 0
		Location       = '51,100'
	}
	$GUILocationVerifyErrorMsg = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		Text           = $lang.VerifyNameTips
	}
	$GUILocationComputer = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 360
		Text           = $lang.LocationComputer
		Location       = '40,165'
		add_Click      = { RefreshLoction }
	}
	$GUILocationUsers  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 360
		Text           = "Users"
		Location       = '40,190'
		add_Click      = { RefreshLoction }
	}
	$GUILocationUserName = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 360
		Text           = $lang.LocationUserName
		Location       = '40,215'
		Checked        = $True
		add_Click      = { RefreshLoction }
	}

	$GUILocationSize   = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 400
		Text           = $lang.SelectAutoAvailable
		Location       = '10,255'
	}
	$GUILocationLowSize = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 400
		Text           = $lang.SelectCheckAvailable
		Location       = '26,278'
		Checked        = $True
		add_Click      = $GUILocationLowSizeClick
	}
	$SelectLowSize     = New-Object System.Windows.Forms.NumericUpDown -Property @{
		Height         = 22
		Width          = 60
		Location       = "45,305"
		Value          = 1
		Minimum        = 1
		Maximum        = 999999
		TextAlign      = 1
		add_Click      = { RefreshGetMountDisk }
	}
	$SelectLowUnit     = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 80
		Text           = "GB"
		Location       = "115,308"
	}
	$GUILocationTitle  = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.ChangeInstallDisk
		Location       = '24,340'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { RefreshGetMountDisk }
	}
	$GUILocationPane1  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 90
		Width          = 365
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 0
		Location       = '30,362'
	}

	$GUILocationCurrent = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.LocationCurrent
		Location       = '30,470'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $GUILocationCurrentClick
	}
	$GUILocationInitial = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.LocationInitial
		Location       = '30,495'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = $GUILocationInitialClick
	}

	<#
		.迁移的项目
	#>
	$GUILocationItem   = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.LocationUserFolderTips
		Location       = '472,5'
	}
	$GUILocationItemPanel = New-Object System.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 322
		Width          = 412
		autoSizeMode   = 1
		Padding        = "8,0,8,0"
		Location       = '490,28'
		autoScroll     = $True
	}
	$GUILocationItemDesktop = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 374
		Text           = $lang.LocationDesktop
		Location       = '0,0'
		Checked        = $True
		add_Click      = $GUILocationItemDesktopClick
	}
	$GUILocationItemDesktopShow = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 335
		Text           = ""
		Location       = '18,25'
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}
	$GUILocationItemDesktopSelect = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = '360,25'
		Height         = 22
		Width          = 25
		add_Click      = { SelectNewFolder -KnownFolder "Desktop" }
		Text           = "..."
	}
	$GUILocationItemDocuments = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 374
		Text           = $lang.LocationDocuments
		Location       = '0,65'
		Checked        = $True
		add_Click      = $GUILocationItemDocumentsClick
	}
	$GUILocationItemDocumentsShow = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 335
		Text           = ""
		Location       = '18,90'
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}
	$GUILocationItemDocumentsSelect = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = '360,90'
		Height         = 22
		Width          = 25
		add_Click      = { SelectNewFolder -KnownFolder "Documents" }
		Text           = "..."
	}
	$GUILocationItemDownloads = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 374
		Text           = $lang.LocationDownloads
		Location       = '0,130'
		Checked        = $True
		add_Click      = $GUILocationItemDownloadsClick
	}
	$GUILocationItemDownloadsShow = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 335
		Text           = ""
		Location       = '18,155'
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}
	$GUILocationItemDownloadsSelect = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = '360,155'
		Height         = 22
		Width          = 25
		add_Click      = { SelectNewFolder -KnownFolder "Downloads" }
		Text           = "..."
	}
	$GUILocationItemMusic = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 374
		Text           = $lang.LocationMusic
		Location       = '0,195'
		Checked        = $True
		add_Click      = $GUILocationItemMusicClick
	}
	$GUILocationItemMusicShow = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 335
		Text           = ""
		Location       = '18,220'
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}
	$GUILocationItemMusicSelect = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = '360,220'
		Height         = 22
		Width          = 25
		add_Click      = { SelectNewFolder -KnownFolder "Music" }
		Text           = "..."
	}
	$GUILocationItemPictures = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 374
		Text           = $lang.LocationPictures
		Location       = '0,260'
		Checked        = $True
		add_Click      = $GUILocationItemPicturesClick
	}
	$GUILocationItemPicturesShow = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 335
		Text           = ""
		Location       = '18,285'
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}
	$GUILocationItemPicturesSelect = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = '360,285'
		Height         = 22
		Width          = 25
		add_Click      = { SelectNewFolder -KnownFolder "Pictures" }
		Text           = "..."
	}
	$GUILocationItemVideos = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 374
		Text           = $lang.LocationVideos
		Location       = '0,325'
		Checked        = $True
		add_Click      = $GUILocationItemVideosClick
	}
	$GUILocationItemVideosShow = New-Object System.Windows.Forms.TextBox -Property @{
		Height         = 30
		Width          = 335
		Text           = ""
		Location       = '18,350'
		BackColor      = "#FFFFFF"
		ReadOnly       = $True
	}
	$GUILocationItemVideosSelect = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = '360,350'
		Height         = 22
		Width          = 25
		add_Click      = { SelectNewFolder -KnownFolder "Videos" }
		Text           = "..."
	}


	<#
		.迁移完成后
	#>
	$GUILocationFinish = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.LocationDone
		Location       = '472,380'
	}
	$GUILocationFinishSync = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 360
		Text           = $lang.LocationDoneSync
		Location       = '492,405'
		Checked        = $True
	}
	$GUILocationFinishClear = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 360
		Text           = $lang.LocationDoneClean
		Location       = '492,430'
		ForeColor      = "#0000FF"
	}
	$GUILocationFinishClearTips = New-Object System.Windows.Forms.Label -Property @{
		Height         = 38
		Width          = 390
		Text           = $lang.LocationDoneCleanTips
		Location       = '506,455'
	}
	$GUILocationErrorMsg = New-Object system.Windows.Forms.Label -Property @{
		Location       = "16,530"
		Height         = 28
		Width          = 408
		Text           = ""
	}
	$GUILocationOK     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "472,515"
		Height         = 36
		Width          = 214
		add_Click      = $GUILocationOKClick
		Text           = $lang.OK
	}
	$GUILocationCanel  = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "692,515"
		Height         = 36
		Width          = 214
		add_Click      = $GUILocationCanelClick
		Text           = $lang.Cancel
	}
	$GUILocation.controls.AddRange((
		$GUILocationSize,
		$GUILocationLowSize,
		$SelectLowSize,
		$SelectLowUnit,
		$GUILocationTitle,
		$GUILocationPane1,
		$GUILocationAdv,
		$GUILocationCustomize,
		$GUILocationCustomizeShow,
		$GUILocationCustomizeTips,
		$GUILocationStructure,
		$GUILocationComputer,
		$GUILocationUsers,
		$GUILocationUserName,
		$GUILocationFinish,
		$GUILocationFinishSync,
		$GUILocationFinishClear,
		$GUILocationFinishClearTips,
		$GUILocationItem,
		$GUILocationItemPanel,
		$GUILocationErrorMsg,
		$GUILocationCurrent,
		$GUILocationInitial,
		$GUILocationOK,
		$GUILocationCanel
	))
	$GUILocationItemPanel.controls.AddRange((
		$GUILocationItemDesktop,
		$GUILocationItemDesktopShow,
		$GUILocationItemDesktopSelect,
		$GUILocationItemDocuments,
		$GUILocationItemDocumentsShow,
		$GUILocationItemDocumentsSelect,
		$GUILocationItemDownloads,
		$GUILocationItemDownloadsShow,
		$GUILocationItemDownloadsSelect,
		$GUILocationItemMusic,
		$GUILocationItemMusicShow,
		$GUILocationItemMusicSelect,
		$GUILocationItemPictures,
		$GUILocationItemPicturesShow,
		$GUILocationItemPicturesSelect,
		$GUILocationItemVideos,
		$GUILocationItemVideosShow,
		$GUILocationItemVideosSelect
	))
	$GUILocationCustomizeTips.controls.AddRange((
		$GUILocationVerifyErrorMsg
	))

	<#
		.Checkbox: Customize the new directory
		.复选框：自定义新的目录
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\UserFolder" -Name "AllowCustomize" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\UserFolder" -Name "AllowCustomize" -ErrorAction SilentlyContinue) {
			"True" {
				$GUILocationCustomize.Checked = $True
				$GUILocationCustomizeShow.Enabled = $True
			}
			"False" {
				$GUILocationCustomize.Checked = $False
				$GUILocationCustomizeShow.Enabled = $False
			}
		}
	} else {
		$GUILocationCustomize.Checked = $False
		$GUILocationCustomizeShow.Enabled = $False
		DynamicSave -regkey "UserFolder" -name "AllowCustomize" -value "False" -String
	}

	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\UserFolder" -Name "Folder" -ErrorAction SilentlyContinue) {
		$GetNewFolder = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\UserFolder" -Name "Folder" -ErrorAction SilentlyContinue
		$GUILocationCustomizeShow.Text = $GetNewFolder
	} else {
		$GUILocationCustomizeShow.Text = $Global:MainImageLang
	}

	RefreshLoction
	RefreshGetMountDisk

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUILocation.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUILocation.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$GUILocation.FormBorderStyle = 'Fixed3D'
	$GUILocation.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

<#
	Sources:
	http://stackoverflow.com/questions/25709398/set-location-of-special-folders-with-powershell
#>
function SetKnownFolderPath {
	Param
	(
		[Parameter(Mandatory = $true)]
		[ValidateSet('3DObjects', 'AddNewPrograms', 'AdminTools', 'AppUpdates', 'CDBurning', 'ChangeRemovePrograms', 'CommonAdminTools', 'CommonOEMLinks', 'CommonPrograms', 'CommonStartMenu', 'CommonStartup', 'CommonTemplates', 'ComputerFolder', 'ConflictFolder', 'ConnectionsFolder', 'Contacts', 'ControlPanelFolder', 'Cookies', 'Desktop', 'Documents', 'Downloads', 'Favorites', 'Fonts', 'Games', 'GameTasks', 'History', 'InternetCache', 'InternetFolder', 'Links', 'LocalAppData', 'LocalAppDataLow', 'LocalizedResourcesDir', 'Music', 'NetHood', 'NetworkFolder', 'OriginalImages', 'PhotoAlbums', 'Pictures', 'Playlists', 'PrintersFolder', 'PrintHood', 'Profile', 'ProgramData', 'ProgramFiles', 'ProgramFilesX64', 'ProgramFilesX86', 'ProgramFilesCommon', 'ProgramFilesCommonX64', 'ProgramFilesCommonX86', 'Programs', 'Public', 'PublicDesktop', 'PublicDocuments', 'PublicDownloads', 'PublicGameTasks', 'PublicMusic', 'PublicPictures', 'PublicVideos', 'QuickLaunch', 'Recent', 'RecycleBinFolder', 'ResourceDir', 'RoamingAppData', 'SampleMusic', 'SamplePictures', 'SamplePlaylists', 'SampleVideos', 'SavedGames', 'SavedSearches', 'SEARCH_CSC', 'SEARCH_MAPI', 'SearchHome', 'SendTo', 'SidebarDefaultParts', 'SidebarParts', 'StartMenu', 'Startup', 'SyncManagerFolder', 'SyncResultsFolder', 'SyncSetupFolder', 'System', 'SystemX86', 'Templates', 'TreeProperties', 'UserProfiles', 'UsersFiles', 'Videos', 'Windows')]
		[string]$KnownFolder,
		
		[Parameter(Mandatory = $true)]
		[string]$Path
	)

	# Define known folder GUIDs
	$KnownFolders = @{
		'3DObjects' = '31C0DD25-9439-4F12-BF41-7FF4EDA38722';
		'AddNewPrograms' = 'de61d971-5ebc-4f02-a3a9-6c82895e5c04';
		'AdminTools' = '724EF170-A42D-4FEF-9F26-B60E846FBA4F';
		'AppUpdates' = 'a305ce99-f527-492b-8b1a-7e76fa98d6e4';
		'CDBurning' = '9E52AB10-F80D-49DF-ACB8-4330F5687855';
		'ChangeRemovePrograms' = 'df7266ac-9274-4867-8d55-3bd661de872d';
		'CommonAdminTools' = 'D0384E7D-BAC3-4797-8F14-CBA229B392B5';
		'CommonOEMLinks' = 'C1BAE2D0-10DF-4334-BEDD-7AA20B227A9D';
		'CommonPrograms' = '0139D44E-6AFE-49F2-8690-3DAFCAE6FFB8';
		'CommonStartMenu' = 'A4115719-D62E-491D-AA7C-E74B8BE3B067';
		'CommonStartup' = '82A5EA35-D9CD-47C5-9629-E15D2F714E6E';
		'CommonTemplates' = 'B94237E7-57AC-4347-9151-B08C6C32D1F7';
		'ComputerFolder' = '0AC0837C-BBF8-452A-850D-79D08E667CA7';
		'ConflictFolder' = '4bfefb45-347d-4006-a5be-ac0cb0567192';
		'ConnectionsFolder' = '6F0CD92B-2E97-45D1-88FF-B0D186B8DEDD';
		'Contacts' = '56784854-C6CB-462b-8169-88E350ACB882';
		'ControlPanelFolder' = '82A74AEB-AEB4-465C-A014-D097EE346D63';
		'Cookies' = '2B0F765D-C0E9-4171-908E-08A611B84FF6';
		'Desktop' = 'B4BFCC3A-DB2C-424C-B029-7FE99A87C641';
		'Documents' = 'FDD39AD0-238F-46AF-ADB4-6C85480369C7';
		'Downloads' = '374DE290-123F-4565-9164-39C4925E467B';
		'Favorites' = '1777F761-68AD-4D8A-87BD-30B759FA33DD';
		'Fonts' = 'FD228CB7-AE11-4AE3-864C-16F3910AB8FE';
		'Games' = 'CAC52C1A-B53D-4edc-92D7-6B2E8AC19434';
		'GameTasks' = '054FAE61-4DD8-4787-80B6-090220C4B700';
		'History' = 'D9DC8A3B-B784-432E-A781-5A1130A75963';
		'InternetCache' = '352481E8-33BE-4251-BA85-6007CAEDCF9D';
		'InternetFolder' = '4D9F7874-4E0C-4904-967B-40B0D20C3E4B';
		'Links' = 'bfb9d5e0-c6a9-404c-b2b2-ae6db6af4968';
		'LocalAppData' = 'F1B32785-6FBA-4FCF-9D55-7B8E7F157091';
		'LocalAppDataLow' = 'A520A1A4-1780-4FF6-BD18-167343C5AF16';
		'LocalizedResourcesDir' = '2A00375E-224C-49DE-B8D1-440DF7EF3DDC';
		'Music' = '4BD8D571-6D19-48D3-BE97-422220080E43';
		'NetHood' = 'C5ABBF53-E17F-4121-8900-86626FC2C973';
		'NetworkFolder' = 'D20BEEC4-5CA8-4905-AE3B-BF251EA09B53';
		'OriginalImages' = '2C36C0AA-5812-4b87-BFD0-4CD0DFB19B39';
		'PhotoAlbums' = '69D2CF90-FC33-4FB7-9A0C-EBB0F0FCB43C';
		'Pictures' = '33E28130-4E1E-4676-835A-98395C3BC3BB';
		'Playlists' = 'DE92C1C7-837F-4F69-A3BB-86E631204A23';
		'PrintersFolder' = '76FC4E2D-D6AD-4519-A663-37BD56068185';
		'PrintHood' = '9274BD8D-CFD1-41C3-B35E-B13F55A758F4';
		'Profile' = '5E6C858F-0E22-4760-9AFE-EA3317B67173';
		'ProgramData' = '62AB5D82-FDC1-4DC3-A9DD-070D1D495D97';
		'ProgramFiles' = '905e63b6-c1bf-494e-b29c-65b732d3d21a';
		'ProgramFilesX64' = '6D809377-6AF0-444b-8957-A3773F02200E';
		'ProgramFilesX86' = '7C5A40EF-A0FB-4BFC-874A-C0F2E0B9FA8E';
		'ProgramFilesCommon' = 'F7F1ED05-9F6D-47A2-AAAE-29D317C6F066';
		'ProgramFilesCommonX64' = '6365D5A7-0F0D-45E5-87F6-0DA56B6A4F7D';
		'ProgramFilesCommonX86' = 'DE974D24-D9C6-4D3E-BF91-F4455120B917';
		'Programs' = 'A77F5D77-2E2B-44C3-A6A2-ABA601054A51';
		'Public' = 'DFDF76A2-C82A-4D63-906A-5644AC457385';
		'PublicDesktop' = 'C4AA340D-F20F-4863-AFEF-F87EF2E6BA25';
		'PublicDocuments' = 'ED4824AF-DCE4-45A8-81E2-FC7965083634';
		'PublicDownloads' = '3D644C9B-1FB8-4f30-9B45-F670235F79C0';
		'PublicGameTasks' = 'DEBF2536-E1A8-4c59-B6A2-414586476AEA';
		'PublicMusic' = '3214FAB5-9757-4298-BB61-92A9DEAA44FF';
		'PublicPictures' = 'B6EBFB86-6907-413C-9AF7-4FC2ABF07CC5';
		'PublicVideos' = '2400183A-6185-49FB-A2D8-4A392A602BA3';
		'QuickLaunch' = '52a4f021-7b75-48a9-9f6b-4b87a210bc8f';
		'Recent' = 'AE50C081-EBD2-438A-8655-8A092E34987A';
		'RecycleBinFolder' = 'B7534046-3ECB-4C18-BE4E-64CD4CB7D6AC';
		'ResourceDir' = '8AD10C31-2ADB-4296-A8F7-E4701232C972';
		'RoamingAppData' = '3EB685DB-65F9-4CF6-A03A-E3EF65729F3D';
		'SampleMusic' = 'B250C668-F57D-4EE1-A63C-290EE7D1AA1F';
		'SamplePictures' = 'C4900540-2379-4C75-844B-64E6FAF8716B';
		'SamplePlaylists' = '15CA69B3-30EE-49C1-ACE1-6B5EC372AFB5';
		'SampleVideos' = '859EAD94-2E85-48AD-A71A-0969CB56A6CD';
		'SavedGames' = '4C5C32FF-BB9D-43b0-B5B4-2D72E54EAAA4';
		'SavedSearches' = '7d1d3a04-debb-4115-95cf-2f29da2920da';
		'SEARCH_CSC' = 'ee32e446-31ca-4aba-814f-a5ebd2fd6d5e';
		'SEARCH_MAPI' = '98ec0e18-2098-4d44-8644-66979315a281';
		'SearchHome' = '190337d1-b8ca-4121-a639-6d472d16972a';
		'SendTo' = '8983036C-27C0-404B-8F08-102D10DCFD74';
		'SidebarDefaultParts' = '7B396E54-9EC5-4300-BE0A-2482EBAE1A26';
		'SidebarParts' = 'A75D362E-50FC-4fb7-AC2C-A8BEAA314493';
		'StartMenu' = '625B53C3-AB48-4EC1-BA1F-A1EF4146FC19';
		'Startup' = 'B97D20BB-F46A-4C97-BA10-5E3608430854';
		'SyncManagerFolder' = '43668BF8-C14E-49B2-97C9-747784D784B7';
		'SyncResultsFolder' = '289a9a43-be44-4057-a41b-587a76d7e7f9';
		'SyncSetupFolder' = '0F214138-B1D3-4a90-BBA9-27CBC0C5389A';
		'System' = '1AC14E77-02E7-4E5D-B744-2EB1AE5198B7';
		'SystemX86' = 'D65231B0-B2F1-4857-A4CE-A8E7C6EA7D27';
		'Templates' = 'A63293E8-664E-48DB-A079-DF759E0509F7';
		'TreeProperties' = '5b3749ad-b49f-49c1-83eb-15370fbd4882';
		'UserProfiles' = '0762D272-C50A-4BB0-A382-697DCD729B80';
		'UsersFiles' = 'f3ce0f7c-4901-4acc-8648-d5d44b04ef8f';
		'Videos' = '18989B1D-99B5-455B-841C-AB7C74E4DDFC';
		'Windows' = 'F38BF404-1D43-42F2-9305-67DE0B28FC23';
	}

# Define SHSetKnownFolderPath if it hasn't been defined already
    $Type1 = ([System.Management.Automation.PSTypeName]'KnownFolders').Type
    if (-not $Type1) {
        $Signature = @'
[DllImport("shell32.dll")]
public extern static int SHSetKnownFolderPath(ref Guid folderId, uint flags, IntPtr token, [MarshalAs(UnmanagedType.LPWStr)] string path);
'@
        $Type1 = Add-Type -MemberDefinition $Signature -Name 'KnownFolders' -Namespace 'SHSetKnownFolderPath' -PassThru
    }

    $Type2 = ([System.Management.Automation.PSTypeName]'ChangeNotify').Type
    if (-not $Type2) {
        $Signature = @'
[DllImport("Shell32.dll")]
public static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
'@
        $Type2 = Add-Type -MemberDefinition $Signature -Name 'ChangeNotify' -Namespace 'SHChangeNotify' -PassThru
    }

	$DesktopOldpath = [Environment]::GetFolderPath("Desktop")
	$MyDocumentsOldpath = [Environment]::GetFolderPath("MyDocuments")
	$DownloadsOldpath = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
	$MusicOldpath = [Environment]::GetFolderPath("MyMusic")
	$PicturesOldpath = [Environment]::GetFolderPath("MyPictures")
	$VideoOldpath = [Environment]::GetFolderPath("MyVideos")
	$FlagsCheckNewPath = ""

	switch ($KnownFolder) {
		"Desktop" {
			$FlagsCheckNewPath = $DesktopOldpath
			Write-Host "   $($lang.LocationDesktop)" -ForegroundColor Green
		}
		"Documents" {
			$FlagsCheckNewPath = $MyDocumentsOldpath
			Write-Host "   $($lang.LocationDocuments)" -ForegroundColor Green
		}
		"Downloads" {
			$FlagsCheckNewPath = $DownloadsOldpath
			Write-Host "   $($lang.LocationDownloads)" -ForegroundColor Green
		}
		"Music" {
			$FlagsCheckNewPath = $MusicOldpath
			Write-Host "   $($lang.LocationMusic)" -ForegroundColor Green
		}
		"Pictures" {
			$FlagsCheckNewPath = $PicturesOldpath
			Write-Host "   $($lang.LocationPictures)" -ForegroundColor Green
		}
		"Videos" {
			Write-Host "   $($lang.LocationVideos)" -ForegroundColor Green
			$FlagsCheckNewPath = $VideoOldpath
		}
	}
	
	Write-Host "   $($lang.LocationFolderOld -f $FlagsCheckNewPath)"
	Write-Host "   $($lang.LocationFolderNew -f $Path)"
	if ($FlagsCheckNewPath -eq $Path) {
		write-host "   $($lang.LocationFolderSame)`n" -ForegroundColor Red
		return
	} else {
		CheckCatalog -chkpath $Path

		if (TestAvailableDisk -Path $Path) {
			$Type1::SHSetKnownFolderPath([ref]$KnownFolders[$KnownFolder], 0, 0, $Path)
			$Type2::SHChangeNotify(0x8000000, 0x1000, 0, 0)

			write-host "   $($lang.LocationDoneSync)"
			if ($Global:LocationFinishSync) {
				Copy-Item -Path "$($FlagsCheckNewPath)\*" -Destination $Path -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
				attrib +r $Path
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
			}

			write-host "   $($lang.LocationDoneClean)"
			if ($Global:LocationFinishClear) {
				Remove-Item $FlagsCheckNewPath -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
			}
		} else {
			Write-Host "   - $($lang.FailedCreateFolder -f $Path)`n" -ForegroundColor Red
		}
	}
}

Export-ModuleMember -Function * -Alias *