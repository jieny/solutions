﻿<#
 .Synopsis
  Shortcut

 .Description
  Shortcut Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>


<#
	.Start processing refresh task
	.开始处理刷新任务
#>
Function ShortcutProcess
{
	<#
		.Get the required application software path
		.获取所需的应用软件路径
	#>
	$Shortcut  = "$(GetArchitecturePacker -Path "$($PSScriptRoot)\..\..\AIO\Shortcut")\Shortcut.exe"
	$syspin    = "$(GetArchitecturePacker -Path "$($PSScriptRoot)\..\..\AIO\syspin")\syspin.exe"
	$DeskEdit  = "$(GetArchitecturePacker -Path "$($PSScriptRoot)\..\..\AIO\DeskEdit")\DeskEdit.exe"
	$StartMenu = "$($env:SystemDrive)\ProgramData\Microsoft\Windows\Start Menu\Programs\$($Global:UniqueID)'s Solutions"

	<#
		.Obtain deployment conditions: 1. Clean up the entire solution; clean up the main engine after running. Set the mark after being satisfied: $True
		.获取部署条件：1、清理整个解决方案；运行后清理主引擎。满足后设置标记为：$True
	#>
	$FlagsClearSolutionsRule = $Flase
	if (Test-Path -Path "$($PSScriptRoot)\..\..\Deploy\ClearSolutions" -PathType Leaf) {
		$FlagsClearSolutionsRule = $True
	}
	if (Test-Path -Path "$($PSScriptRoot)\..\..\Deploy\ClearEngine" -PathType Leaf) {
		$FlagsClearSolutionsRule = $True
	}

	Write-Host "   $($lang.AddTo) $($lang.DeskIcon)"
	if (Test-Path $syspin -PathType Leaf) {
		Start-Process -FilePath $syspin -ArgumentList """$($StartMenu)\- $($Global:UniqueID)'s Solutions -.lnk"" ""51394""" -Wait -WindowStyle Hidden
	}
	Remove-Item -Path "$($env:SystemDrive)\Users\Public\Desktop\Bundled Solutions.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$($env:SystemDrive)\Users\Public\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$($env:SystemDrive)\Users\Public\Desktop\附贈解決方案.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$($env:SystemDrive)\Users\Public\Desktop\보너스 솔루션.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$($env:SystemDrive)\Users\Public\Desktop\ボーナスソリューション.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$($env:SystemDrive)\Users\Public\Desktop\Bonuslösung.lnk" -ErrorAction SilentlyContinue

	<#
		.Clean up old connections
		.清理旧连接
	#>
	$CleanOldLNK = @(
		"*.lnk"
		"00\*.lnk"
		"10\*.lnk"
		"30\*.lnk"
		"40\*.lnk"
		"50\*.lnk"
		"60\*.lnk"
		"70\*.lnk"
	)

	foreach ($item in $CleanOldLNK) {
		Remove-Item -Path "$($Global:UniqueMainFolder)\$($item)" -ErrorAction SilentlyContinue
	}

	<#
		.Clean up old connections
		.清理旧文件
	#>
	RemoveTree -Path $StartMenu
	CheckCatalog -chkpath $StartMenu

	$FlagFolder00 = "$($PSScriptRoot)\..\..\..\00"
	$FlagFolder10 = "$($PSScriptRoot)\..\..\..\10"
	$FlagFolder20 = "$($PSScriptRoot)\..\..\..\20"
	$FlagFolder30 = "$($PSScriptRoot)\..\..\..\30"
	$FlagFolder40 = "$($PSScriptRoot)\..\..\..\40"
	$FlagFolder50 = "$($PSScriptRoot)\..\..\..\50"

	<#
		.Unzip the compressed package
		.解压压缩包
	#>
	UnzipThePackage

	<#
		.Pre-configuration processing
		.预配置处理
	#>
	if ($FlagsClearSolutionsRule) {
	} else {
		Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($Global:UniqueMainFolder)"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($Global:UniqueID)'s Solutions"""
		Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($env:SystemDrive)\Users\Public\Desktop\$($lang.MainHisName).lnk"" /a:c /t:""$($Global:UniqueMainFolder)"" /i:""$($Global:EngineMainFolder)\icons\Engine.Gift.ico""" -WindowStyle Hidden
		Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\- $($lang.Location) -.lnk"" /a:c /t:""$($Global:UniqueMainFolder)"" /i:""$($Global:EngineMainFolder)\icons\Engine.Gift.ico""" -WindowStyle Hidden

		Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\- $($Global:UniqueID)'s Solutions -.lnk"" /a:c /t:""powershell"" /p:""-Command \""Start-Process 'Powershell.exe' -Argument '-File \""$($Global:EnginePath)\""' -Verb RunAs"" /i:""$($Global:EngineMainFolder)\icons\MainPanel.ico""" -WindowStyle Hidden -Wait
		Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($FlagFolder00)\- $($lang.InstlOffice -f "WPS") -.lnk"" /a:c /t:""powershell"" /p:""-Command \""Start-Process 'Powershell.exe' -Argument '-File \""$($Global:EnginePath)\"" -Functions \\\""WPS -Quit\\\""' -Verb RunAs"" /i:""$($Global:EngineMainFolder)\icons\run.ico""" -WindowStyle Hidden
		Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\- $($Global:UniqueID)'s Solutions -.lnk"" /a:c /t:""powershell"" /p:""-Command \""Start-Process 'Powershell.exe' -Argument '-File \""$($Global:EnginePath)\""' -Verb RunAs"" /i:""$($Global:EngineMainFolder)\icons\MainPanel.ico""" -WindowStyle Hidden

		if (Test-Path "$($UniqueMainFolder)\Engine\Modules\$($Global:IUniqueIDsLang)\Instl.ps1" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($FlagFolder00)\- $($lang.EditAndInstl) -.lnk"" /a:c /t:""$($Global:EngineMainFolder)\Modules\$($Global:IsLang)\instl.ps1""" -WindowStyle Hidden
		} else {
			if (Test-Path "$($UniqueMainFolder)\Engine\Modules\en-US\Instl.ps1" -PathType Leaf) {
				Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($FlagFolder00)\- $($lang.EditAndInstl) -.lnk"" /a:c /t:""$($Global:EngineMainFolder)\Modules\en-US\instl.ps1""" -WindowStyle Hidden
			}
		}

		Start-Process -FilePath $syspin -ArgumentList """$($StartMenu)\- $($Global:UniqueID)'s Solutions -.lnk"" ""51201""" -Wait -WindowStyle Hidden
		PinToStart
	}

	if (Test-Path $FlagFolder00 -PathType Container) {
		if ($FlagsClearSolutionsRule) {
			Move-Item $FlagFolder00 "$($UniqueMainFolder)\$($lang.InstlPacker)" -Force -ErrorAction SilentlyContinue
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($FlagFolder00)"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.InstlPacker)"""
		}
	}

	if (Test-Path $FlagFolder10 -PathType Container) {
		if ($FlagsClearSolutionsRule) {
			Move-Item $FlagFolder10 "$($UniqueMainFolder)\$($lang.ActivationKit)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.ActivationKit)
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($FlagFolder10)"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.ActivationKit)"""
			$NewFolderName = "10"
		}
	}

	if (Test-Path $FlagFolder20 -PathType Container) {
		CheckCatalog -chkpath "$($StartMenu)\$($lang.MostUsedSoftware)"
		if ($FlagsClearSolutionsRule) {
			write-host "$($UniqueMainFolder)\$($lang.MostUsedSoftware)"
			Move-Item $FlagFolder20 "$($UniqueMainFolder)\$($lang.MostUsedSoftware)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.MostUsedSoftware)
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($FlagFolder20)"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.MostUsedSoftware)"""
			$NewFolderName = "20"
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\AdvancedIPScanner")"
		if (Test-Path "$($ShortcutNew)\advanced_ip_scanner.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Advanced IP Scanner.lnk"" /a:c /t:""$($ShortcutNew)\advanced_ip_scanner.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\advanced_ip_scanner.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\Advanced IP Scanner.lnk"" /a:c /t:""$($ShortcutNew)\advanced_ip_scanner.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\advanced_ip_scanner.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\VLC")"
		if (Test-Path "$($ShortcutNew)\vlc.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\VLC media player.lnk"" /a:c /t:""$($ShortcutNew)\vlc.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\vlc.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\VLC media player.lnk"" /a:c /t:""$($ShortcutNew)\vlc.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\vlc.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\360DrvMgr")"
		if (Test-Path "$($ShortcutNew)\360DrvMgr.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.DrvMgr).lnk"" /a:c /t:""$($ShortcutNew)\360DrvMgr.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\360DrvMgr.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\$($lang.DrvMgr).lnk"" /a:c /t:""$($ShortcutNew)\360DrvMgr.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\360DrvMgr.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\DiskGenius")"
		if (Test-Path "$($ShortcutNew)\Diskgenius.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\DiskGenius.lnk"" /a:c /t:""$($ShortcutNew)\Diskgenius.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Diskgenius.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\DiskGenius.lnk"" /a:c /t:""$($ShortcutNew)\Diskgenius.exe"" /w:""$($NewFolderName)"" /i:""$($ShortcutNew)\Diskgenius.exe"" /R:7""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\WinNTSetup")"
		if (Test-Path "$($ShortcutNew)\WinNTSetup.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinNTSetup.lnk"" /a:c /t:""$($ShortcutNew)\WinNTSetup.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\WinNTSetup.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\WinNTSetup.lnk"" /a:c /t:""$($ShortcutNew)\WinNTSetup.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\WinNTSetup.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\rufus")"
		if (Test-Path "$($ShortcutNew)\rufus.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Rufus.lnk"" /a:c /t:""$($ShortcutNew)\rufus.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\rufus.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\Rufus.lnk"" /a:c /t:""$($ShortcutNew)\rufus.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\rufus.exe"" /R:7""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\FastCopy")"
		if (Test-Path "$($ShortcutNew)\FastCopy.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\FastCopy.lnk"" /a:c /t:""$($ShortcutNew)\FastCopy.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\FastCopy.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\FastCopy.lnk"" /a:c /t:""$($ShortcutNew)\FastCopy.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\FastCopy.exe"" /R:7""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\DnsJumper")"
		if (Test-Path "$($ShortcutNew)\DnsJumper.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\DNS Jumper.lnk"" /a:c /t:""$($ShortcutNew)\DnsJumper.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\DnsJumper.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\DNS Jumper.lnk"" /a:c /t:""$($ShortcutNew)\DnsJumper.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\DnsJumper.exe"" /R:7""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\RegeditX")"
		if (Test-Path "$($ShortcutNew)\RegEditX.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegEditX.lnk"" /a:c /t:""$($ShortcutNew)\RegEditX.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\RegEditX.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\RegEditX.lnk"" /a:c /t:""$($ShortcutNew)\RegEditX.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\RegEditX.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\Beyond Compare")"
		if (Test-Path "$($ShortcutNew)\BCompare.bat" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Beyond Compare.lnk"" /a:c /t:""$($ShortcutNew)\BCompare.bat"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\BComparePortable.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\Beyond Compare.lnk"" /a:c /t:""$($ShortcutNew)\BCompare.bat"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\BComparePortable.exe"" /R:7""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\WipeFile")"
		if (Test-Path "$($ShortcutNew)\WipeFile.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\WipeFile.lnk"" /a:c /t:""$($ShortcutNew)\WipeFile.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\WipeFile.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\WipeFile.lnk"" /a:c /t:""$($ShortcutNew)\WipeFile.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\WipeFile.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\Everything")"
		if (Test-Path "$($ShortcutNew)\Everything.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Everything.lnk"" /a:c /t:""$($ShortcutNew)\Everything.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Everything.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\Everything.lnk"" /a:c /t:""$($ShortcutNew)\Everything.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Everything.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\Everything")"
		if (Test-Path "$($ShortcutNew)\SDCardFormatter.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\SD Card Formatter.lnk"" /a:c /t:""$($ShortcutNew)\SDCardFormatter.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\SDCardFormatter.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\SD Card Formatter.lnk"" /a:c /t:""$($ShortcutNew)\SDCardFormatter.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\SDCardFormatter.exe"" /R:7""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\TopMost")"
		if (Test-Path "$($ShortcutNew)\TopMost.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\TopMost.lnk"" /a:c /t:""$($ShortcutNew)\TopMost.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\TopMost.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\TopMost.lnk"" /a:c /t:""$($ShortcutNew)\TopMost.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\TopMost.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\geek")"
		if (Test-Path "$($ShortcutNew)\geek.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Geek Uninstaller.lnk"" /a:c /t:""$($ShortcutNew)\geek.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\geek.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\Geek Uninstaller.lnk"" /a:c /t:""$($ShortcutNew)\geek.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\geek.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\AutoRuns")"
		if (Test-Path "$($ShortcutNew)\AutoRuns.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns.lnk"" /a:c /t:""$($ShortcutNew)\AutoRuns.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\AutoRuns.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\AutoRuns.lnk"" /a:c /t:""$($ShortcutNew)\AutoRuns.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\AutoRuns.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($ShortcutNew)\Autoruns64a.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns.lnk"" /a:c /t:""$($ShortcutNew)\Autoruns64a.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Autoruns64a.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\AutoRuns.lnk"" /a:c /t:""$($ShortcutNew)\Autoruns64a.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Autoruns64a.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\ProcessExplorer")"
		if (Test-Path "$($ShortcutNew)\ProcessExplorer.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Process Explorer.lnk"" /a:c /t:""$($ShortcutNew)\ProcessExplorer.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\ProcessExplorer.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\Process Explorer.lnk"" /a:c /t:""$($ShortcutNew)\ProcessExplorer.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\ProcessExplorer.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\ProcessMonitor")"
		if (Test-Path "$($ShortcutNew)\Procmon.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Process Monitor.lnk"" /a:c /t:""$($ShortcutNew)\Procmon.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Procmon.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.MostUsedSoftware)\Process Monitor.lnk"" /a:c /t:""$($ShortcutNew)\Procmon.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Procmon.exe""" -WindowStyle Hidden
		}
	}

	if (Test-Path $FlagFolder30 -PathType Container) {
		CheckCatalog -chkpath "$($StartMenu)\$($lang.HardwareDetection)"
		if ($FlagsClearSolutionsRule) {
			Move-Item $FlagFolder30 "$($UniqueMainFolder)\$($lang.HardwareDetection)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.HardwareDetection)
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($FlagFolder30)"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.HardwareDetection)"""
			$NewFolderName = "30"
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\AIDA64")"
		if (Test-Path "$($ShortcutNew)\aida64.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\AIDA64.lnk"" /a:c /t:""$($ShortcutNew)\aida64.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\aida64.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.HardwareDetection)\AIDA64.lnk"" /a:c /t:""$($ShortcutNew)\aida64.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\aida64.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\ASSSDBenchmark")"
		if (Test-Path "$($ShortcutNew)\ASSSDBenchmark.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\AS SSD Benchmark.lnk"" /a:c /t:""$($ShortcutNew)\ASSSDBenchmark.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\ASSSDBenchmark.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.HardwareDetection)\AS SSD Benchmark.lnk"" /a:c /t:""$($ShortcutNew)\ASSSDBenchmark.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\ASSSDBenchmark.exe"" /R:7""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\CPU-Z")"
		if (Test-Path "$($ShortcutNew)\cpu-z.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\CPU-Z.lnk"" /a:c /t:""$($ShortcutNew)\cpu-z.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\cpu-z.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.HardwareDetection)\CPU-Z.lnk"" /a:c /t:""$($ShortcutNew)\cpu-z.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\cpu-z.exe"" /R:7""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\GPU-Z")"
		if (Test-Path "$($ShortcutNew)\GPU-Z.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPU-Z.lnk"" /a:c /t:""$($ShortcutNew)\GPU-Z.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\GPU-Z.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.HardwareDetection)\GPU-Z.lnk"" /a:c /t:""$($ShortcutNew)\GPU-Z.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\GPU-Z.exe"" /R:7""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\HDDScan")"
		if (Test-Path "$($ShortcutNew)\HDDScan.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDDScan.lnk"" /a:c /t:""$($ShortcutNew)\HDDScan.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\HDDScan.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.HardwareDetection)\HDDScan.lnk"" /a:c /t:""$($ShortcutNew)\HDDScan.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\HDDScan.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\HDSpeed")"
		if (Test-Path "$($ShortcutNew)\HDSpeed.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDSpeed.lnk"" /a:c /t:""$($ShortcutNew)\HDSpeed.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\HDSpeed.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.HardwareDetection)\HDSpeed.lnk"" /a:c /t:""$($ShortcutNew)\HDSpeed.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\HDSpeed.exe"" /R:7""" -WindowStyle Hidden
		}
	}

	if (Test-Path $FlagFolder40 -PathType Container) {
		CheckCatalog -chkpath "$($StartMenu)\$($lang.SetupTool)"
		if ($FlagsClearSolutionsRule) {
			Move-Item $FlagFolder40 "$($UniqueMainFolder)\$($lang.SetupTool)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.SetupTool)
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($FlagFolder40)"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.SetupTool)"""
			$NewFolderName = "40"
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\dControl")"
		if (Test-Path "$($ShortcutNew)\dfControl.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\- $($lang.DefenderControl) -.lnk"" /a:c /t:""$($ShortcutNew)\dfControl.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\dfControl.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.SetupTool)\$($lang.DefenderControl).lnk"" /a:c /t:""$($ShortcutNew)\dfControl.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\dfControl.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\Wub")"
		if (Test-Path "$($ShortcutNew)\Wub.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\- $($lang.Wub) -.lnk"" /a:c /t:""$($ShortcutNew)\Wub.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Wub.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.SetupTool)\$($lang.Wub).lnk"" /a:c /t:""$($ShortcutNew)\Wub.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Wub.exe""" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\Fab")"
		if (Test-Path "$($ShortcutNew)\Fab.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\- $($lang.Fab) -.lnk"" /a:c /t:""$($ShortcutNew)\Fab.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Fab.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.SetupTool)\$($lang.Fab).lnk"" /a:c /t:""$($ShortcutNew)\Fab.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\Fab.exe""" -WindowStyle Hidden
		}
	}

	if (Test-Path $FlagFolder50 -PathType Container) {
		CheckCatalog -chkpath "$($StartMenu)\$($lang.RemoteTool)"
		if ($FlagsClearSolutionsRule) {
			Move-Item $FlagFolder50 "$($UniqueMainFolder)\$($lang.RemoteTool)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.RemoteTool)
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($FlagFolder50)"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.RemoteTool)"""
			$NewFolderName = "50"
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\AnyDesk")"
		if (Test-Path "$($ShortcutNew)\AnyDesk.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\AnyDesk.lnk"" /a:c /t:""$($ShortcutNew)\AnyDesk.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\AnyDesk.exe" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.RemoteTool)\AnyDesk.lnk"" /a:c /t:""$($ShortcutNew)\AnyDesk.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\AnyDesk.exe" -WindowStyle Hidden
		}

		$ShortcutNew = "$(GetArchitectureLang -Path "$($UniqueMainFolder)\$($NewFolderName)\TeamViewer")"
		if (Test-Path "$($ShortcutNew)\TeamViewer.exe" -PathType Leaf) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\TeamViewer.lnk"" /a:c /t:""$($ShortcutNew)\TeamViewer.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\TeamViewer.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($StartMenu)\$($lang.RemoteTool)\TeamViewer.lnk"" /a:c /t:""$($ShortcutNew)\TeamViewer.exe"" /w:""$($ShortcutNew)"" /i:""$($ShortcutNew)\TeamViewer.exe""" -WindowStyle Hidden
		}
	}

	Wait-Process -Name "Shortcut" -ErrorAction SilentlyContinue
}

<#
	.Unzip the compressed package
	.解压压缩包
#>
Function UnzipThePackage
{
	<#
		.Extracting passwords
		.解压：密码
	#>
	$UnpackPasswordFiles = @(
		("HEU*",       "HEU_KMS_Activator",  "HEU"),
		("dControl*",  "dControl",           "sordum")
	)

	foreach ($item in $UnpackPasswordFiles) {
		Get-ChildItem –Path "$($PSScriptRoot)\..\..\..\" -filter "$($item[1]).zip" –Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
			Write-host "   * $($_.FullName)"
			$SaveToName = [IO.Path]::GetDirectoryName($_.FullName)

			if ($item[2] -eq "HEU") {
				Get-ChildItem –Path "$($PSScriptRoot)\..\..\..\" -filter "$($item[0]).exe" –Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					Add-MpPreference -ExclusionPath $_.FullName -ErrorAction SilentlyContinue | Out-Null
				}
				Add-MpPreference -ExclusionPath "$($env:systemroot)\System32\SECOPatcher.dll" -ErrorAction SilentlyContinue | Out-Null
			}

			if ($item[2] -eq "sordum") {
				Add-MpPreference -ExclusionPath "$SaveToName" -ErrorAction SilentlyContinue | Out-Null
			}

			Archive -Password $($item[2]) -filename $_.FullName -to $SaveToName
	
			Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue
		}
	}

	Get-ChildItem –Path "$($PSScriptRoot)\..\..\..\" -filter "*.zip" –Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
		Write-host "   * $($_.FullName)"
		$SaveToName = [IO.Path]::GetDirectoryName($_.FullName)

		Archive -filename $_.FullName -to $SaveToName

		Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue
	}
	Write-Host ""
}

Function PinToStart
{
	$syspin    = "$(GetArchitecturePacker -Path "$($PSScriptRoot)\..\..\AIO\syspin")\syspin.exe"
	$StartMenu = "$($env:SystemDrive)\ProgramData\Microsoft\Windows\Start Menu\Programs\$($Global:UniqueID)'s Solutions"

	if (Test-Path $syspin -PathType Leaf) {
		Start-Process -FilePath $syspin -ArgumentList """$($StartMenu)\- $($Global:UniqueID)'s Solutions -.lnk"" ""51201""" -Wait -WindowStyle Hidden
	}
}

Export-ModuleMember -Function * -Alias *