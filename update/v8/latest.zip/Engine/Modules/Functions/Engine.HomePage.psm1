﻿<#
 .Synopsis
  Main interface

 .Description
  Main interface Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.LOGO
#>
Function Logo
{
	param
	(
		$Title
	)
	Clear-Host
	$Host.UI.RawUI.WindowTitle = "$($Global:UniqueID)'s Solutions | $($Title)"
	Write-Host "`n   Author: $($Global:UniqueID) ( $($Global:AuthorURL) )

   From: $($Global:UniqueID)'s Solutions
   buildstring: $($ProductVersion).bs_release.210814-1208`n"
}

<#
	.主界面
	.Main interface
#>
Function Mainpage
{
	Logo -Title $($lang.Mainpage)
	Write-Host "   $($lang.Mainpage)`n   ---------------------------------------------------"

	write-host "   1. $($lang.Update)
   2. $($lang.Reset) $($lang.Mainname)
   3. $($lang.Delete) $($lang.Mainname)
   4. $($lang.RestorePoint)" -ForegroundColor Green

   write-host  "`n   [*] A. $($lang.Oneclick) BCDEFGHIJ"

	Get-Command -CommandType function | ForEach-Object {
		if ($_ -like "Activate") {
			Write-Host "       B. $($lang.ActivationKit)"
		}
	}

	write-host  "       C. $($lang.LocationUserFolder)
       D. $($lang.DeskIcon)
       E. $($lang.Optimize) $($lang.System)
       F. $($lang.Optimize) $($lang.Service)
       G. $($lang.Instl) $($lang.Necessary)
       H. $($lang.Instl) $($lang.MostUsedSoftware)
       I. $($lang.Delete) $($lang.ComesWith)
       J. $($lang.Delete) $($lang.UninstallUWP)


   L. $($lang.SwitchLanguage)
   R. $($lang.RefreshModules)
   Q. $($lang.Exit)`n"

	$select = Read-Host "   $($lang.Choose)"
	switch ($select)
	{
		"1" {
			Update
			ToMainpage -wait 2
		}
		"2" {
			Signup
			ToMainpage -wait 2
		}
		"3" {
			Uninstall
			ToMainpage -wait 2
		}
		"4" {
			RestorePointGUI
			ToMainpage -wait 2
		}
		"a" {
			if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Engine" -Name "RestorePointPrompt" -ErrorAction SilentlyContinue) {
				$GetRestorePointPrompt = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Engine" -Name "RestorePointPrompt"
				switch ($GetRestorePointPrompt) {
					"False" { RestorePointGUI }
				}
			} else {
				RestorePointGUI
			}

			Get-Command -CommandType function | ForEach-Object {
				if ($_ -like "Activate") {
					Invoke-Expression -Command "Activate -Force"
				}
			}
			
			ChangeLocation -Force
			Desktop -Force
			Optimization -Force
			OptimizationService -Force
			Prerequisite -Force
			SystemSoftware -Force
			UninstallApps -Force
			MostUsedSoftware -Force
			WaitEnd
			ToMainpage -wait 4
		}
		"b" {
			Get-Command -CommandType function | ForEach-Object {
				if ($_ -like "Activate") {
					Invoke-Expression -Command Activate
				}
			}
		}
		"c" { ChangeLocation }
		"d" { Desktop }
		"e" { Optimization }
		"f" { OptimizationService }
		"g" { Prerequisite }
		"h" { MostUsedSoftware }
		"i" { SystemSoftware }
		"j" { UninstallApps }
		"l" {
			Language -Reset
			Mainpage
		}
		"r" {
			RefreshModules
		}
		"q" { exit }
		default { Mainpage }
	}
}

<#
	.返回到主界面
	.Return to the main interface
#>
Function ToMainpage
{
	param
	(
		[int]$wait
	)

	if ($Global:QUIT) {
		$Global:QUIT = $False
		Write-Host $($lang.ToQuit -f $wait) -ForegroundColor Red
		Start-Sleep -s $wait
		exit
	} else {
		Write-Host $($lang.ToMsg -f $wait) -ForegroundColor Red
		Start-Sleep -s $wait
		Mainpage
	}
}

Export-ModuleMember -Function * -Alias *