﻿<#
 .Synopsis
  Install WPS

 .Description
  Install WPS Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Install WPS user interface
	.安装 WPS 用户界面
#>
Function WPS
{
	param
	(
		[switch]$Force,
		[Switch]$Silent,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	if ($Silent) {
		Logo -Title $($lang.InstlOffice -f "WPS")
		Write-Host "   $($lang.InstlOffice -f "WPS")`n   ---------------------------------------------------"
	}

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIWpsCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIWps.Close()
	}
	$GUIWpsOKClick = {
		$GUIWps.Hide()
		if ($GUIWpsDisconnected.Checked) {
			InstallProcess -appname "Net Disabler" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\Engine\AIO\NetDisabler" -pwd "" -url "https://www.sordum.org/files/download/net-disabler/NetDisabler.zip" -urlAMD64 "" -urlarm64 "" -filename "NetDisabler*" -param "/D" -Before "" -After ""
		}
		if ($GUIWpsOffice.Checked) {
			InstallProcess -appname "WPS Office" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\00\WPS" -pwd "" -url "https://pacakge.cache.wpscdn.cn/wps/download/W.P.S.10495.12012.2019.exe" -urlAMD64 "" -urlarm64 "" -filename "WPS*" -param "/s" -Before "" -After ""
		}
		if ($GUIWpsPatch.Checked) {
			Write-Host "   - $($lang.Patch)`n"
			if (Test-Path "$PSScriptRoot\..\..\..\00\WPS\en-US\WPS.exe" -PathType Leaf) {
				if (Test-Path "$PSScriptRoot\..\..\..\00\WPS\en-US\auth.dll" -PathType Leaf) {
					InstallProcess -appname "Net Disabler" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\Engine\AIO\NetDisabler" -pwd "" -url "https://www.sordum.org/files/download/net-disabler/NetDisabler.zip" -urlAMD64 "" -urlarm64 "" -filename "NetDisabler*" -param "/D" -Before "" -After ""

					Stop-Process -ProcessName wpscenter -ErrorAction SilentlyContinue | Out-Null
					Stop-Process -ProcessName wpscloudsvr -ErrorAction SilentlyContinue | Out-Null
					if (Test-Path "$($env:USERPROFILE)\AppData\Local\Kingsoft\WPS Office\11.2.0.9629\office6\auth.dll" -PathType Leaf) {
						Copy-Item -Path "$PSScriptRoot\..\..\..\00\WPS\en-US\auth.dll" -Destination "$($env:USERPROFILE)\AppData\Local\Kingsoft\WPS Office\11.2.0.9629\office6\auth.dll" -Force -ErrorAction SilentlyContinue
					}
				}
			}
		}
		InstallProcess -appname "Net Disabler" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\Engine\AIO\NetDisabler" -pwd "" -url "https://www.sordum.org/files/download/net-disabler/NetDisabler.zip" -urlAMD64 "" -urlarm64 "" -filename "NetDisabler*" -param "/E" -Before "" -After ""

		if ($GUIWpsRedundant.Checked) {
			Write-Host "   - $($lang.Delete) $($lang.Redundant)`n"
			Remove-Item -Path "$($env:SystemDrive)\Users\Public\Desktop\WPS PDF.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$($env:SystemDrive)\Users\Public\Desktop\WPS演示.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$($env:USERPROFILE)\Desktop\WPS PDF.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$($env:USERPROFILE)\Desktop\WPS演示.lnk" -ErrorAction SilentlyContinue
		}
		if ($GUIWpsUpdate.Checked) {
			Write-Host "   - $($lang.Disable) ( WpsUpdateTask_Administrator )`n"
			Disable-ScheduledTask -TaskPath "\" -TaskName "WpsUpdateTask_Administrator" -ErrorAction SilentlyContinue | Out-Null
		}
		if ($GUIWpsTaskBar.Checked) { ResetTaskBar }
		if ($GUIWpsResetDesk.Checked) { ResetDesktop }
		WaitEnd
		$GUIWps.Close()
	}
	$GUIWps            = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 550
		Text           = $($lang.InstlOffice -f "WPS")
		TopMost        = $False
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUIWpsPanel       = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 455
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 1
	}
	$GUIWpsOffice      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 495
		Text           = "$($lang.Instl) $($lang.OfficeWPS)"
		Checked        = $true
	}
	$GUIWpsDisconnected = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 495
		Text           = $lang.Disconnected
	}
	$GUIWpsPatch       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 495
		Text           = $lang.Patch
		Checked        = $true
	}
	$GUIWpsRedundant   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 495
		Text           = "$($lang.Delete) $($lang.Redundant)"
		Checked        = $true
	}
	$GUIWpsUpdate      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 495
		Text           = "$($lang.Disable) ( WpsUpdateTask_Administrator )"
		Checked        = $true
	}

	<#
		.Other
		.其它
	#>
	$GUIWpsSortName    = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 512
		Text           = $lang.AdvOption
		Location       = '10,485'
	}
	$GUIWpsSortPanel   = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 60
		Width          = 530
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		WrapContents   = $true
		Padding        = "22,0,8,0"
		Location       = "0,510"
	}
	$GUIWpsTaskBar     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 480
		Text           = "$($lang.Reset) $($lang.TaskBar)"
	}
	$GUIWpsResetDesk   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 480
		Text           = $lang.ResetDesk
		Checked        = $true
	}
	$GUIWpsOK          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,595"
		Height         = 36
		Width          = 515
		add_Click      = $GUIWpsOKClick
		Text           = $lang.OK
	}
	$GUIWpsCanel       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,635"
		Height         = 36
		Width          = 515
		add_Click      = $GUIWpsCanelClick
		Text           = $lang.Cancel
	}
	$GUIWps.controls.AddRange((
		$GUIWpsPanel,
		$GUIWpsSortName,
		$GUIWpsSortPanel,
		$GUIWpsOK,
		$GUIWpsCanel
	))

	$GUIWpsPanel.controls.AddRange((
		$GUIWpsOffice,
		$GUIWpsDisconnected
	))

	if (Test-Path "$PSScriptRoot\..\..\..\00\WPS\en-US\auth.dll" -PathType Leaf) {
		$GUIWpsPanel.controls.AddRange($GUIWpsPatch)
	}

	$GUIWpsPanel.controls.AddRange((
		$GUIWpsRedundant,
		$GUIWpsUpdate
	))

	$GUIWpsSortPanel.controls.AddRange((
		$GUIWpsTaskBar,
		$GUIWpsResetDesk
	))

	$GUIWpsMenuAllSelClick = {
		$GUIWpsPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIWpsMenuAllClearClick = {
		$GUIWpsPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIWpsMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIWpsMenu.Items.Add($lang.AllSel).add_Click($GUIWpsMenuAllSelClick)
	$GUIWpsMenu.Items.Add($lang.AllClear).add_Click($GUIWpsMenuAllClearClick)
	$GUIWpsPanel.ContextMenuStrip = $GUIWpsMenu

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIWps.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIWps.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$GUIWps.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$GUIWps.FormBorderStyle = 'Fixed3D'
	$GUIWps.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

Export-ModuleMember -Function * -Alias *