﻿<#
 .Synopsis
  Install WPS

 .Description
  Install WPS Feature Modules
#>

<#
	.Install WPS user interface
	.安装 WPS 用户界面
#>
Function WPS
{
	param
	(
		[switch]$Force,
		[Switch]$Silent,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	if ($Silent) {
		Logo -Title $($lang.InstlOffice -f "WPS")
		Write-Host "   $($lang.PlanTask)`n   ---------------------------------------------------"
	}

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIWpsMenuAllSelClick = {
		$GUIWpsPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true }
		}
	}
	$GUIWpsMenuAllClearClick = {
		$GUIWpsPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false }
		}
	}
	$GUIWpsCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIWps.Close()
	}
	$GUIWpsOKClick = {
		$GUIWps.Hide()
		if ($GUIWpsDisconnected.Checked) {
			StartInstallSoftware -appname "Net Disabler" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\Engine\AIO\NetDisabler" -url "https://www.sordum.org/files/download/net-disabler/NetDisabler.zip" -urlAMD64 "" -urlarm64 "" -filename "NetDisabler*" -param "/D" -method ""
		}
		if ($GUIWpsOffice.Checked) {
			StartInstallSoftware -appname "WPS Office" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\00\WPS" -url "https://pacakge.cache.wpscdn.cn/wps/download/W.P.S.10495.12012.2019.exe" -urlAMD64 "" -urlarm64 "" -filename "WPS*" -param "/s" -method ""
		}
		if ($GUIWpsPatch.Checked) {
			Write-Host "   - $($lang.Patch)`n"
			if (Test-Path -Path "$PSScriptRoot\..\..\..\00\WPS\WPS.en-US.exe") {
				if (Test-Path -Path "$PSScriptRoot\..\..\..\00\WPS\auth.dll") {
					StartInstallSoftware -appname "Net Disabler" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\Engine\AIO\NetDisabler" -url "https://www.sordum.org/files/download/net-disabler/NetDisabler.zip" -urlAMD64 "" -urlarm64 "" -filename "NetDisabler*" -param "/D" -method ""
					Stop-Process -ProcessName wpscenter -ErrorAction SilentlyContinue | Out-Null
					Stop-Process -ProcessName wpscloudsvr -ErrorAction SilentlyContinue | Out-Null
					if (Test-Path -Path "$env:USERPROFILE\AppData\Local\Kingsoft\WPS Office\11.2.0.9629\office6\auth.dll") {
						Copy-Item -Path "$PSScriptRoot\..\..\..\00\WPS\auth.dll" -Destination "$env:USERPROFILE\AppData\Local\Kingsoft\WPS Office\11.2.0.9629\office6\auth.dll" -Force -ErrorAction SilentlyContinue
					}
				}
			}
		}
		StartInstallSoftware -appname "Net Disabler" -status "Enable" -act "Install" -mode "Wait" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\Engine\AIO\NetDisabler" -url "https://www.sordum.org/files/download/net-disabler/NetDisabler.zip" -urlAMD64 "" -urlarm64 "" -filename "NetDisabler*" -param "/E" -method ""

		if ($GUIWpsRedundant.Checked) {
			Write-Host "   - $($lang.Delete) $($lang.Redundant)`n"
			Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\WPS PDF.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\WPS演示.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$env:USERPROFILE\Desktop\WPS PDF.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$env:USERPROFILE\Desktop\WPS演示.lnk" -ErrorAction SilentlyContinue
		}
		if ($GUIWpsUpdate.Checked) {
			Write-Host "   - $($lang.Disable) $($lang.PlanTask) ( WpsUpdateTask_Administrator )`n"
			Disable-ScheduledTask -TaskPath "\" -TaskName "WpsUpdateTask_Administrator" -ErrorAction SilentlyContinue | Out-Null
		}
		if ($GUIWpsTaskBar.Checked) { ResetTaskBar }
		if ($GUIWpsResetDesk.Checked) { ResetDesktop }
		WaitEnd
		$GUIWps.Close()
	}
	$GUIWps            = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = $($lang.InstlOffice -f "WPS")
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUIWpsPanel       = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$GUIWpsOffice      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Instl) $($lang.OfficeWPS)"
		Checked        = $true
	}
	$GUIWpsDisconnected = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = $lang.Disconnected
	}
	$GUIWpsPatch       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = $lang.Patch
		Checked        = $true
	}
	$GUIWpsRedundant   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Delete) $($lang.Redundant)"
		Checked        = $true
	}
	$GUIWpsUpdate      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.PlanTask) ( WpsUpdateTask_Administrator )"
		Checked        = $true
	}
	$GUIWpsTaskBar     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Reset) $($lang.TaskBar)"
	}
	$GUIWpsResetDesk   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = $lang.ResetDesk
		Checked        = $true
	}
	$GUIWpsOK          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "10,482"
		Height         = 36
		Width          = 202
		add_Click      = $GUIWpsOKClick
		Text           = $lang.OK
	}
	$GUIWpsCanel       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "218,482"
		Height         = 36
		Width          = 202
		add_Click      = $GUIWpsCanelClick
		Text           = $lang.Cancel
	}
	$GUIWps.controls.AddRange((
		$GUIWpsPanel,
		$GUIWpsOK,
		$GUIWpsCanel
	))
	$GUIWpsPanel.controls.AddRange((
		$GUIWpsOffice,
		$GUIWpsDisconnected
	))

	switch ((Get-Culture).Name) {
		"zh-CN" {
			if (Test-Path -Path "$PSScriptRoot\..\..\..\00\WPS\WPS.zh-CN.exe") {
				$GUIWpsDisconnected.Checked = $False
			}
		}
		Default {
			if (Test-Path -Path "$PSScriptRoot\..\..\..\00\WPS\WPS.en-US.exe") {
				$GUIWpsDisconnected.Checked = $True
				if (Test-Path -Path "$PSScriptRoot\..\..\..\00\WPS\auth.dll") {
					$GUIWpsPanel.controls.AddRange($GUIWpsPatch)
				}
			}
		}
	}

	$GUIWpsPanel.controls.AddRange((
		$GUIWpsRedundant,
		$GUIWpsUpdate,
		$GUIWpsTaskBar,
		$GUIWpsResetDesk
	))

	$GUIWpsMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIWpsMenu.Items.Add($lang.AllSel).add_Click($GUIWpsMenuAllSelClick)
	$GUIWpsMenu.Items.Add($lang.AllClear).add_Click($GUIWpsMenuAllClearClick)
	$GUIWps.ContextMenuStrip = $GUIWpsMenu

	$GUIWps.FormBorderStyle = 'Fixed3D'
	$GUIWps.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

Export-ModuleMember -Function "WPS"