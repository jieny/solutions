﻿<#
 .Synopsis
  Receive all installed software interfaces

 .Description
  Receive all installed software interfaces Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.初始化自动选择磁盘最低大小：1GB
	.The minimum size of the disk is automatically selected during initialization: 1GB
#>
$Global:DiskMinSize = 1

<#
	.等待队列
	.Waiting queue
#>
$Global:AppQueue = @()

<#
	.Start processing all software installation requests
	.开始处理所有安装软件请求
#>
function InstallProcess
{
	param
	(
		$appname,
		$status,
		$act,
		$mode,
		$todisk,
		$structure,
		$pwd,
		$url,
		$urlAMD64,
		$urlarm64,
		$filename,
		$param,
		$method
	)

	GetArchitecture
	SetFreeDiskSize
	SetFreeDiskAvailable
	SetFreeDiskTo

	Switch ($status)
	{
		Enable
		{
			Write-Host "   $($lang.Instling) - $($appname)" -ForegroundColor Green
		}
		Disable
		{
			Write-Host "   $($lang.InstlSkip) - $($appname)" -ForegroundColor Red
			return
		}
	}

	switch ($Global:InstlArchitecture) {
		"arm64" {
			if ([string]::IsNullOrEmpty($urlarm64)) {
				if ([string]::IsNullOrEmpty($urlAMD64)) {
					if ([string]::IsNullOrEmpty($url)) {
						$FilenameTo = $urlAMD64
					} else {
						$url = $url
						$FilenameTo = $url
					}
				} else {
					$url = $urlAMD64
					$FilenameTo = $urlAMD64
				}
			} else {
				$url = $urlarm64
				$FilenameTo = $urlarm64
			}
		}
		"AMD64" {
			if ($Global:InstlArchitecture -eq "AMD64") {
				if ([string]::IsNullOrEmpty($urlAMD64)) {
					if ([string]::IsNullOrEmpty($url)) {
						$FilenameTo = $urlAMD64
					} else {
						$url = $url
						$FilenameTo = $url
					}
				} else {
					$url = $urlAMD64
					$FilenameTo = $urlAMD64
				}
			}
		}
		Default {
			if ($Global:InstlArchitecture -eq "x86") {
				if ([string]::IsNullOrEmpty($url)) {
					$FilenameTo = $urlAMD64
				} else {
					$url = $url
					$FilenameTo = $url
				}
			}
		}
	}

	$SaveToName = [IO.Path]::GetFileName($FilenameTo)
	$packer = [IO.Path]::GetFileNameWithoutExtension($FilenameTo)
	$types =  [IO.Path]::GetExtension($FilenameTo).Replace(".", "")

	Switch ($todisk)
	{
		auto
		{
			Get-PSDrive -PSProvider FileSystem | ForEach-Object {
				$TempRootPath = $_.Root
				$tempoutputfoldoer = Join-Path -Path $($TempRootPath) -ChildPath "$($structure)"
				Get-ChildItem -Path $tempoutputfoldoer -Filter "*$($filename)*$((Get-Culture).Name)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($TempRootPath)" -ChildPath "$($structure)"
					$OutAny = $($_.fullname)
					break
				}
				Get-ChildItem -Path $tempoutputfoldoer -Filter "*$($filename)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($TempRootPath)" -ChildPath "$($structure)"
					$OutAny = $($_.fullname)
					break
				}
				Get-ChildItem -Path $tempoutputfoldoer -Filter "*$($packer)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($TempRootPath)" -ChildPath "$($structure)"
					$OutAny = $($_.fullname)
					break
				}
				$OutTo = Join-Path -Path $Global:FreeDiskTo -ChildPath "$($structure)"
				$OutAny = Join-Path -Path $Global:FreeDiskTo -ChildPath "$($structure)\$SaveToName"
			}
		}
		default
		{
			$OutTo = Join-Path -Path $($todisk) -ChildPath "$($structure)"
			$OutAny = Join-Path -Path $($todisk) -ChildPath "$($structure)\$SaveToName"
			Get-ChildItem -Path $OutTo -Filter "*$($filename)*$((Get-Culture).Name)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutAny = $($_.fullname)
				break
			}
			Get-ChildItem -Path $OutTo -Filter "*$($filename)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutAny = $($_.fullname)
				break
			}
			Get-ChildItem -Path $OutTo -Filter "*$($packer)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutAny = $($_.fullname)
				break
			}
		}
	}

	Switch ($types)
	{
		zip
		{
			Switch ($act)
			{
				Install
				{
					Get-ChildItem -Path $OutTo -Filter "*$($filename)*$((Get-Culture).Name)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)`n     $($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
					Get-ChildItem -Path $OutTo -Filter "*$($filename)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)`n     $($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
					Get-ChildItem -Path $OutTo -Filter "*$($packer)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "    - $($lang.LocallyExist)`n     $($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
					if (Test-Path -Path $OutAny) {
						Write-Host "    - $($lang.ExistingPacker)"
					} else {
						Write-Host "    * $($lang.StartDown)"
						if ([string]::IsNullOrEmpty($url)) {
							Write-Host "    - $($lang.DownloadLinkError)" -ForegroundColor Red
						} else {
							if (TestURI $url) {
								Write-Host "      > $($lang.ConnectTo)`n        $url`n      + $($lang.SaveTo)`n        $OutAny"
								CheckCatalog -chkpath $OutTo
								Invoke-WebRequest -Uri $url -OutFile "$($OutAny)" -ErrorAction SilentlyContinue | Out-Null
							} else {
								Write-Host "      - $($lang.NotAvailable)" -ForegroundColor Red
							}
						}
					}
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.Unpacking)"
						Archive -filename $OutAny -to $OutTo
						Write-Host "   - $($lang.UnzipDone)"
						Remove-Item -path $OutAny -force -ErrorAction SilentlyContinue
					} else {
						Write-Host "   - $($lang.ErrorDown)`n" -ForegroundColor Red
					}
					Get-ChildItem -Path $OutTo -Filter "*$($filename)*$((Get-Culture).Name)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)`n     $($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
					Get-ChildItem -Path $OutTo -Filter "*$($filename)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)`n     $($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
					Get-ChildItem -Path $OutTo -Filter "*$($packer)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)`n     $($_.fullname)"
						OpenApp -filename $($_.fullname) -param $param -mode $mode -method $method
						break
					}
				}
				NoInst
				{
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.BeenInstl)`n"
					} else {
						Write-Host "    * $($lang.StartDown)"
						if ([string]::IsNullOrEmpty($url)) {
							Write-Host "      - $($lang.DownloadLinkError)" -ForegroundColor Red
						} else {
							if (TestURI $url) {
								Write-Host "      > $($lang.ConnectTo)`n        $url`n      + $($lang.SaveTo)`n        $OutAny"
								CheckCatalog -chkpath $OutTo
								Invoke-WebRequest -Uri $url -OutFile "$($OutAny)" -ErrorAction SilentlyContinue | Out-Null
							} else {
								Write-Host "      - $($lang.NotAvailable)`n" -ForegroundColor Red
							}
						}
					}
				}
				To
				{
					$newoutputfoldoer = "$($OutTo)\$($packer)"
					if (Test-Path $newoutputfoldoer -PathType Container) {
						Write-Host "   - $($lang.BeenInstl)`n"
						break
					}
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.ExistingInstlPacker)"
					} else {
						Write-Host "    * $($lang.StartDown)"
						if ([string]::IsNullOrEmpty($url)) {
							Write-Host "      - $($lang.DownloadLinkError)" -ForegroundColor Red
						} else {
							Write-Host "      > $($lang.ConnectTo)`n        $url`n      + $($lang.SaveTo)`n        $OutAny"
							Invoke-WebRequest -Uri $url -OutFile $OutAny -ErrorAction SilentlyContinue | Out-Null
						}
					}
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.UnzipOnly)"
						Archive -filename $OutAny -to $newoutputfoldoer
						Write-Host "   - $($lang.UnzipDone)`n"
						Remove-Item -path $OutAny -force -ErrorAction SilentlyContinue
					} else {
						Write-Host "   - $($lang.ErrorDown)`n" -ForegroundColor Red
					}
				}
				Unzip
				{
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.ExistingPacker)"
					} else {
						Write-Host "    * $($lang.StartDown)"
						if ([string]::IsNullOrEmpty($url)) {
							Write-Host "      - $($lang.DownloadLinkError)" -ForegroundColor Red
						} else {
							if (TestURI $url) {
								Write-Host "      > $($lang.ConnectTo)`n        $url`n      + $($lang.SaveTo)`n        $OutAny"
								CheckCatalog -chkpath $OutTo
								Invoke-WebRequest -Uri $url -OutFile $OutAny -ErrorAction SilentlyContinue | Out-Null
							} else {
								Write-Host "      - $($lang.NotAvailable)`n" -ForegroundColor Red
							}
						}
					}
					if (Test-Path -Path $OutAny) {
						Write-Host "   - $($lang.UnzipOnly)"
						Archive -filename $OutAny -to $OutTo
						Write-Host "   - $($lang.UnzipDone)`n"
						Remove-Item -path $OutAny -force -ErrorAction SilentlyContinue
					} else {
						Write-Host "   - $($lang.ErrorDown)`n" -ForegroundColor Red
					}
				}
			}
		}
		default
		{
			if ((Test-Path $OutAny -PathType Leaf))
			{
				OpenApp -filename $OutAny -param $param -mode $mode -method $method
			} else {
				Write-Host "    * $($lang.StartDown)"
				if ([string]::IsNullOrEmpty($url)) {
					Write-Host "      - $($lang.DownloadLinkError)`n" -ForegroundColor Red
				} else {
					Write-Host "      > $($lang.ConnectTo)`n        $url"
					if (TestURI $url) {
						Write-Host "      + $($lang.SaveTo)`n        $OutAny"
						CheckCatalog -chkpath $OutTo
						Invoke-WebRequest -Uri $url -OutFile $OutAny -ErrorAction SilentlyContinue | Out-Null
						OpenApp -filename $OutAny -param $param -mode $mode -method $method
					} else {
						Write-Host "      - $($lang.NotAvailable)`n" -ForegroundColor Red
					}
				}
			}
		}
	}
}


<#
	.Set interface
	.设置界面
#>
Function SetupGUI
{
	GetArchitecture
	SetFreeDiskSize
	SetFreeDiskAvailable
	SetFreeDiskTo

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	Function GetDiskAvailable
	{
		$GetSaveDiskAvailable = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskStatus"
		$SelectLowSize.Text = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskMinSize"
		switch ($GetSaveDiskAvailable) {
			1 {
				$FormSelectDiSKLowSize.Checked = $True
				$SelectLowSize.Enabled = $True
			}
			Default {
				$FormSelectDiSKLowSize.Checked = $False
				$SelectLowSize.Enabled = $False
			}
		}
	}
	$GetDiskAvailable_Click = {
		if ($FormSelectDiSKLowSize.Checked) {
			$SelectLowSize.Enabled = $True
		} else {
			$SelectLowSize.Enabled = $False
		}
	}
	$Canel_Click = {
		$FormSelectDiSK.Close()
	}
	$OK_ArchitectureARM64_Click = {
		$SoftwareTipsErrorMsg.Text = $lang.SelectArm64
	}
	$OK_ArchitectureAMD64_Click = {
		$SoftwareTipsErrorMsg.Text = $lang.SelectAMD64
	}
	$OK_ArchitectureX86_Click = {
		$SoftwareTipsErrorMsg.Text = $lang.Selectx86
	}
	$OK_Click = {
		if ($ArchitectureARM64.Checked) { SetArchitecture -Type "ARM64" }
		if ($ArchitectureAMD64.Checked) { SetArchitecture -Type "AMD64" }
		if ($ArchitectureX86.Checked) { SetArchitecture -Type "x86" }

		if ($FormSelectDiSKLowSize.Checked) {
			SetNewFreeDiskAvailable -Status 1
		} else {
			SetNewFreeDiskAvailable -Status 2
		}

		$VerifyAvailableSelect = 0
		$FormSelectDiSKPane1.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Checked) {
					if ($FormSelectDiSKLowSize.Checked) {
						if (VerifyAvailableSize -Disk $_.Text -Size $SelectLowSize.Text) {
							SetNewFreeDiskSize -Size $($SelectLowSize.Text)
							SetNewFreeDiskTo -Disk $_.Text
							$FormSelectDiSK.Close()
						} else {
							$VerifyAvailableSelect = 1
						}
					} else {
						SetNewFreeDiskSize -Size $($SelectLowSize.Text)
						SetNewFreeDiskTo -Disk $_.Text
						$FormSelectDiSK.Close()
					}
				}
			}
		}
		switch ($VerifyAvailableSelect) {
			0 { $ErrorMsg.Text = "$($lang.SelectFromError -f $($lang.SelectNoDisk))" }
			1 { $ErrorMsg.Text = "$($lang.SelectFromError -f $($lang.SelectNoAvailable))" }
		}
	}
	$FormSelectDiSK    = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = $lang.Setting
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$ArchitectureTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.PreferredDownload
		Location       = '10,10'
	}
	$GroupArchitecture = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 28
		Width          = 400
		autoSizeMode   = 1
		Padding        = 8
		Location       = '10,35'
	}
	$ArchitectureARM64 = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 60
		Text           = "arm64"
		Location       = '10,0'
		add_Click      = $OK_ArchitectureARM64_Click
	}
	$ArchitectureAMD64 = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 60
		Text           = "x64"
		Location       = '80,0'
		add_Click      = $OK_ArchitectureAMD64_Click
	}
	$ArchitectureX86    = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 60
		Text           = "x86"
		Location       = '140,0'
		add_Click      = $OK_ArchitectureX86_Click
	}
	$SoftwareTips      = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 50
		Width          = 392
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $False
		Padding        = 0
		Dock           = 0
		Location       = '18,68'
	}
	$SoftwareTipsErrorMsg = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		Text           = ""
	}
	$FormSelectDiSKSize = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 395
		Text           = $lang.SelectAutoAvailable
		Location       = '10,115'
	}
	$FormSelectDiSKLowSize = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 360
		Text           = $lang.SelectCheckAvailable
		Location       = '26,140'
		add_Click      = $GetDiskAvailable_Click
	}
	$SelectLowSize     = New-Object System.Windows.Forms.NumericUpDown -Property @{
		Height         = 22
		Width          = 60
		Location       = "45,165"
		Value          = 1
		Minimum        = 1
		Maximum        = 999999
		TextAlign      = 1
		add_Click      = $RefresISOLabelNEW_Click
	}
	$SelectLowUnit     = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 80
		Text           = "GB"
		Location       = "115,168"
	}
	$FormSelectDiSKTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.ChangeInstallDisk
		Location       = '24,205'
	}
	$FormSelectDiSKPane1 = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 210
		Width          = 380
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 0
		Dock           = 0
		Location       = '24,228'
	}
	$ErrorMsg          = New-Object system.Windows.Forms.Label -Property @{
		Location       = "10,455"
		Height         = 26
		Width          = 408
		Text           = ""
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "10,482"
		Height         = 36
		Width          = 202
		add_Click      = $OK_Click
		Text           = $lang.OK
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "218,482"
		Height         = 36
		Width          = 202
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$FormSelectDiSK.controls.AddRange((
		$ArchitectureTitle,
		$GroupArchitecture,
		$SoftwareTips,
		$FormSelectDiSKSize,
		$FormSelectDiSKLowSize,
		$SelectLowSize,
		$SelectLowUnit,
		$FormSelectDiSKTitle,
		$FormSelectDiSKPane1,
		$ErrorMsg,
		$Start,
		$Canel
	))
	$SoftwareTips.controls.AddRange((
		$SoftwareTipsErrorMsg
	))
	$GroupArchitecture.controls.AddRange((
		$ArchitectureARM64,
		$ArchitectureAMD64,
		$ArchitectureX86
	))

	switch ($Global:InstlArchitecture) {
		"ARM64" {
			$ArchitectureARM64.Checked = $True
		}
		"AMD64" {
			if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") {
				$ArchitectureARM64.Enabled = $True
			} else {
				$ArchitectureARM64.Enabled = $False
			}

			$ArchitectureAMD64.Checked = $True
		}
		Default {
			if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") {
				$ArchitectureARM64.Enabled = $True
			} else {
				$ArchitectureARM64.Enabled = $False
			}
			
			if ($env:PROCESSOR_ARCHITECTURE -eq "AMD64") {
				$ArchitectureAMD64.Enabled = $True
			} else {
				$ArchitectureAMD64.Enabled = $False
			}

			$ArchitectureX86.Checked = $True
		}
	}

	Get-PSDrive -PSProvider FileSystem | ForEach-Object {
		if (TestAvailableDisk -Path $_.Root) {
			$RadioButton = New-Object System.Windows.Forms.RadioButton -Property @{
				Height = 20
				Width  = 370
				Text   = $_.Root
			}

			$FormSelectDiSKPane1.controls.AddRange($RadioButton)
		}
	}

	$GetDiskTo = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskTo"
	if (TestAvailableDisk -Path $GetDiskTo) {
		$FormSelectDiSKPane1.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Text -eq $GetDiskTo) {
					$_.Checked = $True
				}
			}
		}
	} else {
		$FormSelectDiSKPane1.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Text -eq (JoinMainFolder -Path $env:SystemDrive)) {
					$_.Checked = $True
				}
			}
		}
	}

	GetDiskAvailable	

	switch ($Global:IsLang) {
		"zh-CN" {
			$FormSelectDiSK.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$FormSelectDiSK.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$FormSelectDiSK.FormBorderStyle = 'Fixed3D'
	$FormSelectDiSK.ShowDialog() | Out-Null
}



<#
	.系统结构
	.System structure
#>
function GetArchitecture
{
	<#
		.从注册表获取：用户指定系统架构
		.Obtain from the registry: user-specified system architecture
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "Architecture" -ErrorAction SilentlyContinue) {
		$Global:InstlArchitecture = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "Architecture"
		return
	}

	<#
		.初始化：系统架构
		.Initialization: system architecture
	#>
	SetArchitecture -Type $env:PROCESSOR_ARCHITECTURE
}

<#
	.设置系统架构
	.Set up the system architecture
#>
Function SetArchitecture
{
	param
	(
		[string]$Type
	)

	$Path = "HKCU:\SOFTWARE\$($Global:UniqueID)\Install"

	if (-not (Test-Path $Path)) {
		New-Item -Path $Path -Force -ErrorAction SilentlyContinue | Out-Null
	}
	New-ItemProperty -LiteralPath $Path -Name "Architecture" -Value $Type -PropertyType String -Force -ea SilentlyContinue | Out-Null

	$Global:InstlArchitecture = $Type
}

<#
	.自动选择磁盘
	.Automatically select disk
#>
# 获取自动选择磁盘
# Get automatic disk selection
Function SetFreeDiskTo
{
	<#
		.从注册表里获取：选择的磁盘并判断，如果是强行设置磁盘，跳过检查剩余磁盘空间了，继续
		.Obtain from the registry: select the disk and judge, if the disk is forcibly set, skip checking the remaining disk space, continue
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskTo" -ErrorAction SilentlyContinue) {
		$GetDiskTo = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskTo"
		if (TestAvailableDisk -Path $GetDiskTo) {
			$Global:FreeDiskTo = $GetDiskTo
			return
		}
	}

	<#
		.搜索磁盘条件，排除系统盘
		.Search disk conditions, exclude system disks
	#>
	$drives = Get-PSDrive -PSProvider FileSystem | Where-Object { -not ((JoinMainFolder -Path $env:SystemDrive) -eq $_.Root) } | Select-Object -ExpandProperty 'Root'

	<#
		.从注册表里获取是否检查磁盘可用空间
		.Get from the registry whether to check the disk free space
	#>
	$GetDiskStatus = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskStatus"

	<#
		.从注册表里获取选择的磁盘
		Get the selected disk from the registry
	#>
	$GetDiskMinSize = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskMinSize"

	<#
		.搜索磁盘条件，排除系统盘
		.Search disk conditions, exclude system disks
	#>
	foreach ($drive in $drives) {
		if (TestAvailableDisk -Path $drive) {
			switch ($GetDiskStatus) {
				1 {
					if (VerifyAvailableSize -Disk $drive -Size $GetDiskMinSize) {
						SetNewFreeDiskTo -Disk $drive
						return
					}
				}
				Default {
					SetNewFreeDiskTo -Disk $drive
					return
				}
			}
		}
	}

	<#
		.未找到可用磁盘，初始化：当前系统盘
		.No available disk found, initialization: current system disk
	#>
	SetNewFreeDiskTo -Disk (JoinMainFolder -Path $env:SystemDrive)
}

Function SetNewFreeDiskTo
{
	param
	(
		[string]$Disk
	)

	$Path = "HKCU:\SOFTWARE\$($Global:UniqueID)\Install"

	if (-not (Test-Path $Path)) {
		New-Item -Path $Path -Force -ErrorAction SilentlyContinue | Out-Null
	}
	New-ItemProperty -LiteralPath $Path -Name "DiskTo" -Value $Disk -PropertyType String -Force -ea SilentlyContinue | Out-Null

	$Global:FreeDiskTo = $Disk
}

Function SetFreeDiskSize
{
	<#
		.从注册表里获取选择的磁盘并判断，如果是强行设置磁盘，跳过检查剩余磁盘空间了，继续
		.Obtain the selected disk from the registry and judge. If the disk is forcibly set, skip checking the remaining disk space and continue
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskMinSize" -ErrorAction SilentlyContinue) {
		$GetDiskMinSize = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskMinSize"

		if ([string]::IsNullOrEmpty($GetDiskMinSize)) {
			SetNewFreeDiskSize -Size $Global:DiskMinSize
		}

		if (-not ($GetDiskMinSize -ge $Global:DiskMinSize)) {
			SetNewFreeDiskSize -Size $Global:DiskMinSize
		}
	} else {
		SetNewFreeDiskSize -Size $Global:DiskMinSize
	}
}

Function SetNewFreeDiskSize
{
	param
	(
		[string]$Size
	)

	$Path = "HKCU:\SOFTWARE\$($Global:UniqueID)\Install"

	if (-not (Test-Path $Path)) {
		New-Item -Path $Path -Force -ErrorAction SilentlyContinue | Out-Null
	}
	New-ItemProperty -LiteralPath $Path -Name "DiskMinSize" -Value $Size -PropertyType String -Force -ea SilentlyContinue | Out-Null
}

<#
	.Get from the registry whether to check the disk free space
	.从注册表里获取是否检查磁盘可用空间
#>
Function SetFreeDiskAvailable
{
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskStatus" -ErrorAction SilentlyContinue) {
		$GetDiskStatus = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskStatus"

		if ([string]::IsNullOrEmpty($GetDiskStatus)) {
			SetNewFreeDiskAvailable -Status 1
		} else {
			$Global:FreeDiskStatus = $GetDiskStatus
		}
	} else {
		SetNewFreeDiskAvailable -Status 1
	}
}

<#
	.Set free disk
	.设置可用磁盘
#>
Function SetNewFreeDiskAvailable
{
	param
	(
		[string]$Status
	)

	$Path = "HKCU:\SOFTWARE\$($Global:UniqueID)\Install"

	if (-not (Test-Path $Path)) {
		New-Item -Path $Path -Force -ErrorAction SilentlyContinue | Out-Null
	}
	New-ItemProperty -LiteralPath $Path -Name "DiskStatus" -Value $Status -PropertyType String -Force -ea SilentlyContinue | Out-Null

	$Global:FreeDiskStatus = $Status
}

<#
	.验证可用磁盘大小
	.Verify the available disk size
#>
Function VerifyAvailableSize
{
	param
	(
		[string]$Disk,
		[int]$Size
	)

	$TempCheckVerify = $false

	Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | Where-Object { ((JoinMainFolder -Path $Disk) -eq $_.Root) } | ForEach-Object {
		if ($_.Free -gt (ConvertSize -From GB -To Bytes $Size)) {
			$TempCheckVerify = $True
		} else {
			$TempCheckVerify = $false
		}
	}

	return $TempCheckVerify
}

<#
	.Convert disk space size
	.转换磁盘空间大小
#>
Function ConvertSize
{
	param (
		[validateset("Bytes","KB","MB","GB","TB")]
		[string]$From,
		[validateset("Bytes","KB","MB","GB","TB")]
		[string]$To,
		[Parameter(Mandatory=$true)]
		[double]$Value,
		[int]$Precision = 4
	)
	switch($From) {
		"Bytes" { $value = $Value }
		"KB" { $value = $Value * 1024 }
		"MB" { $value = $Value * 1024 * 1024 }
		"GB" { $value = $Value * 1024 * 1024 * 1024 }
		"TB" { $value = $Value * 1024 * 1024 * 1024 * 1024 }
	}
	switch ($To) {
		"Bytes" { return $value }
		"KB" { $Value = $Value/1KB }
		"MB" { $Value = $Value/1MB }
		"GB" { $Value = $Value/1GB }
		"TB" { $Value = $Value/1TB }
	}

	return [Math]::Round($value,$Precision,[MidPointRounding]::AwayFromZero)
}

<#
	.Create a temporary file to determine whether the disk is readable or not
	.创建临时文件，判断磁盘是否可读用
#>
Function TestAvailableDisk
{
	param
	(
		[string]$Path
	)

	$test_tmp_filename = "writetest-"+[guid]::NewGuid()
	$test_filename = Join-Path -Path "$($Path)" -ChildPath "$($test_tmp_filename)" -ErrorAction SilentlyContinue

	try
	{
		[io.file]::OpenWrite($test_filename).close()

		if ((Test-Path -Path $test_filename))
		{
			Remove-Item $test_filename -ErrorAction SilentlyContinue
			return $true
		}
		$false
	}
	catch
	{
		return $false
	}
}

<#
	.Join URL
	.加入网址
#>
Function JoinUrl
{
	param
	(
		[parameter(Mandatory = $True, HelpMessage = "Base Path")]
		[ValidateNotNullOrEmpty()]
		[string]$Path,
		[parameter(Mandatory = $True, HelpMessage = "Child Path or Item Name")]
		[ValidateNotNullOrEmpty()]
		[string]$ChildPath
	)
	if ($Path.EndsWith('/')) {
		return "$Path" + "$ChildPath"
	} else {
		return "$Path/$ChildPath"
	}
}

<#
	.Test if the URL address is available
	.测试 URL 地址是否可用
#>
Function TestURI
{
	Param
	(
		[Parameter(Position=0,Mandatory,HelpMessage="HTTP or HTTPS")]
		[ValidatePattern( "^(http|https)://" )]
		[Alias("url")]
		[string]$URI,
		[Parameter(ParameterSetName="Detail")]
		[Switch]$Detail,
		[ValidateScript({$_ -ge 0})]
		[int]$Timeout = 30
	)
	Process
	{
		Try
		{
			$paramHash = @{
				UseBasicParsing = $True
				DisableKeepAlive = $True
				Uri = $uri
				Method = 'Head'
				ErrorAction = 'stop'
				TimeoutSec = $Timeout
			}
			$test = Invoke-WebRequest @paramHash
			if ($Detail) {
				$test.BaseResponse | Select-Object ResponseURI,ContentLength,ContentType,LastModified, @{Name="Status";Expression={$Test.StatusCode}}
			} else {
				if ($test.statuscode -ne 200) { $False } else { $True }
			}
		} Catch {
			write-verbose -message $_.exception
			if ($Detail) {
				$objProp = [ordered]@{
					ResponseURI = $uri
					ContentLength = $null
					ContentType = $null
					LastModified = $null
					Status = 404
				}
				New-Object -TypeName psobject -Property $objProp
			} else { $False }
		}
	}
}

<#
	.Wait for the queue to complete
	.等待队列完成
#>
function WaitEnd
{
	Write-Host "`n   $($lang.WaitQueue)"
	for ($i=0; $i -lt $Global:AppQueue.Count; $i++) {
		Write-Host "    * PID: $($Global:AppQueue[$i]['ID'])".PadRight(16) -NoNewline
		if ((Get-Process -ID $($Global:AppQueue[$i]['ID']) -ErrorAction SilentlyContinue).Path -eq $Global:AppQueue[$i]['PATH']) {
			Wait-Process -id $($Global:AppQueue[$i]['ID']) -ErrorAction SilentlyContinue
		}
		Write-Host "    - $($lang.Done)" -ForegroundColor Green
	}
	$Global:AppQueue = @()
}

<#
	.Run any application
	.运行任意应用程序
#>
Function OpenApp
{
	param
	(
		$filename,
		$param,
		$mode,
		$method
	)
	$Select = $method -split ":"

	switch ($Select[0])
	{
		1
		{
			$TestCfg = "$(Split-Path $filename)\$($Select[1]).$($Select[2])"
			$TestDefault = "$(Split-Path $filename)\$($Select[1]).default.$($Select[2])"
			$TestLanguage = "$(Split-Path $filename)\$($Select[1]).$((Get-Culture).Name).$($Select[2])"
			if (Test-Path $TestCfg -PathType Leaf) {
				break
			} else {
				if (Test-Path $TestLanguage -PathType Leaf) {
					Copy-Item -Path $TestLanguage -Destination $TestCfg -Force -ErrorAction SilentlyContinue
				} else {
					if (Test-Path $TestDefault -PathType Leaf) {
						Copy-Item -Path $TestDefault -Destination $TestCfg -Force -ErrorAction SilentlyContinue
					}
				}
			}
		}
		6
		{
			Add-MpPreference -ExclusionPath "$env:Programfiles\KMSpico"
			Add-MpPreference -ExclusionPath "$env:SystemRoot\SECOH-QAD.exe"
			Add-MpPreference -ExclusionPath "$env:SystemRoot\SECOH-QAD.dll"
		}
		default
		{
		}
	}

	if ((Test-Path $filename -PathType Leaf))
	{
		Switch ($mode)
		{
			Fast
			{
				Write-Host "   - $($lang.QucikRun)"
				if ([string]::IsNullOrEmpty($param)) {
					Write-Host "     $filename`n"
					Start-Process -FilePath $filename
				} else {
					Write-Host "   - $($lang.Parameter)`n     $param`n"
					Start-Process -FilePath $filename -ArgumentList $param
				}
			}
			Wait
			{
				Write-Host "   - $($lang.WaitDone)`n     $filename"
				if ([string]::IsNullOrEmpty($param)) {
					Start-Process -FilePath $filename -Wait
				} else {
					Write-Host "   - $($lang.Parameter)`n     $param`n"
					Start-Process -FilePath $filename -ArgumentList $param -Wait
				}
			}
			Queue
			{
				Write-Host "   - $($lang.QucikRun)`n     $filename"
				if ([string]::IsNullOrEmpty($param)) {
					$AppRunQueue = Start-Process -FilePath $filename -passthru
					$Global:AppQueue += @{
						ID="$($AppRunQueue.Id)";
						PATH="$($filename)"
					}
					Write-Host "   - $($lang.AddQueue)$($AppRunQueue.Id)`n"
				} else {
					$AppRunQueue = Start-Process -FilePath $filename -ArgumentList $param -passthru
					$Global:AppQueue += @{
						ID="$($AppRunQueue.Id)";
						PATH="$($filename)"
					}
					Write-Host "   - $($lang.Parameter)`n     $param`n   - $($lang.AddQueue)$($AppRunQueue.Id)`n"
				}
			}
		}
	} else {
		Write-Host "   - $($lang.InstlNo)$filename`n" -ForegroundColor Red
	}

	switch ($Select[0])
	{
		2
		{
			stop-service "GoogleChromeElevationService" -force -NoWait -ErrorAction SilentlyContinue | Out-Null
			stop-service "gupdate" -force -NoWait -ErrorAction SilentlyContinue | Out-Null
			stop-service "gupdatem" -force -NoWait -ErrorAction SilentlyContinue | Out-Null
			set-service "GoogleChromeElevationService" -startuptype disabled -ErrorAction SilentlyContinue | Out-Null
			set-service "gupdate" -startuptype disabled -ErrorAction SilentlyContinue | Out-Null
			set-service "gupdatem" -startuptype disabled -ErrorAction SilentlyContinue | Out-Null
			Disable-ScheduledTask -TaskPath "\" -TaskName "GoogleUpdateTaskMachineCore" -ErrorAction SilentlyContinue | Out-Null
			Disable-ScheduledTask -TaskPath "\" -TaskName "GoogleUpdateTaskMachineUA" -ErrorAction SilentlyContinue | Out-Null
		}
	}
}

Export-ModuleMember -Function InstallProcess, SetupGUI, GetDiskAvailable, GetArchitecture, SetArchitecture, SetFreeDiskTo, SetNewFreeDiskTo, SetFreeDiskSize, SetNewFreeDiskSize, SetFreeDiskAvailable, SetNewFreeDiskAvailable, VerifyAvailableSize, ConvertSize, TestAvailableDisk, JoinUrl, TestURI, WaitEnd, OpenApp