﻿<#
 .Synopsis
  Signup

 .Description
  Signup Feature Modules
#>

<#
	.Register user interface
	.注册用户界面
#>
Function Signup
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.Reset)
	Write-Host "   $($lang.PlanTask)`n   ---------------------------------------------------"

	if ($Force) {
		if (Test-Path "$PSScriptRoot\..\..\Deploy\DoNotUpdate" -PathType Leaf) {
			Write-Host "   - $($lang.UpdateSkipUpdateCheck)"
		} else {
			Write-Host "   - $($lang.ForceUpdate)"
			Update -Force -IsProcess
		}

		SignupProcess
	} else {
		SignupGUI
	}
}

Function SignupGUI
{
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	Write-Host "`n   $($lang.Reset)"

	$GUISignupVolumePanelClick = {
		if ($GUISignupVolume.Checked) {
			$GUISignupVolumePanel.Enabled = $True
		} else {
			$GUISignupVolumePanel.Enabled = $False
		}
	}
	$GUISignupDeskMenuClick = {
		if ($GUISignupDeskMenu.Checked) {
			$GUISignupDeskMenuShift.Enabled = $True
		} else {
			$GUISignupDeskMenuShift.Enabled = $False
		}
	}
	$GUISignupCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUISignup.Close()
	}
	$GUISignupOKClick = {
		$GUISignup.Hide()
		if ($GUISignupVolume.Enabled) {
			if ($GUISignupVolume.Checked) {
				if ($GUISignupVolumeDefault.Checked) {
					SystemDiskLabel -Default
				}
				if ($GUISignupVolumeSync.Checked) {
					SystemDiskLabel
				}
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
			}
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUISignupDeskMenu.Enabled) {
			if ($GUISignupDeskMenu.Checked) {
				SignupDeskMenu -Del
				if ($GUISignupDeskMenuShift.Checked) {
					SignupDeskMenu -Add -Hide
				} else {	
					SignupDeskMenu -Add
				}
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			} else {
				SignupDeskMenu -Del
				Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red	
			}
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.ExcludeDefenders)"
		if ($GUISignupDefenders.Checked) {
			ExclusionFirewall -Add
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUISignupLangAndKeyboard.Checked) {
			LanguageSetting
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUISignupFixMainFolder.Checked) {
			FixMainFolder
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.FDPermissions)"
		if ($GUISignupFDPermissions.Checked) {
			Permissions
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.Shortcut)"
		if ($GUISignupShortcut.Checked) {
			RefreshStart
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}
		
		$GUISignup.Close()
	}
	$GUISignup         = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = $lang.Reset
		TopMost        = $True
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}
	$GUISignupPanel    = New-Object system.Windows.Forms.Panel -Property @{
		Height         = 468
		Width          = 450
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = 0
		Dock           = 1
	}
	$GUISignupVolume   = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,5"
		Height         = 22
		Width          = 390
		Text           = $lang.SelectVolumename
		Checked        = $True
		add_Click      = $GUISignupVolumePanelClick
	}
	$GUISignupVolumePanel = New-Object system.Windows.Forms.Panel -Property @{
		Height         = 50
		Width          = 370
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = 0
		Location       = "16,30"
	}
	$GUISignupVolumeDefault = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 300
		Text           = "OS"
		Location       = '10,0'
		Checked        = $True
	}
	$GUISignupVolumeSync = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 300
		Text           = $($Global:UniqueID)
		Location       = '10,25'
	}
	$GUISignupDeskMenu = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,90"
		Height         = 22
		Width          = 390
		Text           = $lang.DesktopMenu
		Checked        = $True
		add_Click      = $GUISignupDeskMenuClick
	}
	$GUISignupDeskMenuShift = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "26,115"
		Height         = 22
		Width          = 380
		Text           = $lang.DesktopMenuShift
	}
	$GUISignupDefenders = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,148"
		Height         = 22
		Width          = 390
		Text           = $lang.ExcludeDefenders
		Checked        = $True
	}
	$GUISignupLangAndKeyboard = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,178"
		Height         = 22
		Width          = 390
		Text           = $lang.SettingLangAndKeyboard
		Checked        = $True
	}
	$GUISignupFixMainFolder = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,208"
		Height         = 22
		Width          = 390
		Text           = "$($lang.FixMainFolder -f $($Global:UniqueID))"
		Checked        = $True
	}
	$GUISignupFDPermissions = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,238"
		Height         = 22
		Width          = 390
		Text           = $lang.FDPermissions
		Checked        = $True
	}
	$GUISignupShortcut = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,268"
		Height         = 22
		Width          = 390
		Text           = $lang.Shortcut
		Checked        = $True
	}	
	$GUISignupOK       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "10,482"
		Height         = 36
		Width          = 202
		add_Click      = $GUISignupOKClick
		Text           = $lang.OK
	}
	$GUISignupCanel    = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "218,482"
		Height         = 36
		Width          = 202
		add_Click      = $GUISignupCanelClick
		Text           = $lang.Cancel
	}
	$GUISignup.controls.AddRange((
		$GUISignupPanel,
		$GUISignupOK,
		$GUISignupCanel
	))
	$GUISignupPanel.controls.AddRange((
		$GUISignupVolume,
		$GUISignupVolumePanel,
		$GUISignupDeskMenu,
		$GUISignupDeskMenuShift,
		$GUISignupDefenders,
		$GUISignupLangAndKeyboard,
		$GUISignupFixMainFolder,
		$GUISignupFDPermissions,
		$GUISignupShortcut
	))
	$GUISignupVolumePanel.controls.AddRange((
		$GUISignupVolumeDefault,
		$GUISignupVolumeSync
	))
 
	$GUISignup.FormBorderStyle = 'Fixed3D'
	$GUISignup.ShowDialog() | Out-Null
}

<#
	.Start processing registration tasks
	.开始处理注册任务
#>
Function SignupProcess
{
	<#
		.Prevent Windows 10 from automatically deleting unused language packs
		.防止 Windows 10 自动删除未使用的语言包
	#>
	If (-not (Test-Path "HKLM:\Software\Policies\Microsoft\Control Panel\International")) { New-Item -Path "HKLM:\Software\Policies\Microsoft\Control Panel\International" -Force | Out-Null }
	Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Control Panel\International" -Name "BlockCleanupOfUnusedPreinstalledLangPacks" -Type DWord -Value 1 -ErrorAction SilentlyContinue | Out-Null
	gpupdate /force | out-null

	<#
		.After using the $OEM$ mode to add files, the default is read-only. Change all files to: Normal.
		.使用 $OEM$ 模式添加文件后默认为只读，更改所有文件为：正常。
	#>
	Get-ChildItem "$env:SystemDrive\$($Global:UniqueID)" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.Attributes="Normal" }

	<#
		.Change system disk volume label
		.更改系统盘卷标
	#>
	SystemDiskLabel

	<#
		.Close the pop-up after entering the system for the first time: Network Location Wizard
		.关闭第一次进入系统后弹出：网络位置向导
	#>
	Write-Host "`n   $($lang.Disable) $($lang.NetworkLocationWizard)"
	New-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Network\NewNetworkWindowOff" -Force -ErrorAction SilentlyContinue | Out-Null

	<#
		.Add exclusion to firewall
		.向防火墙添加排除
	#>
	ExclusionFirewall -Add

	<#
	 	.Desktop right-click menu
		.桌面右键菜单
	#>
	if (Test-Path "$PSScriptRoot\..\..\Deploy\DesktopMenu" -PathType Leaf) {
		SignupDeskMenu -Del

		if (Test-Path "$PSScriptRoot\..\..\Deploy\DesktopMenuShift" -PathType Leaf) {
			SignupDeskMenu -Add -Hide
		} else {
			SignupDeskMenu -Add
		}
	} else {
		SignupDeskMenu -Del
	}

	<#
		.Set system language, keyboard, etc.
		.设置系统语言、键盘等
	#>
	LanguageSetting

	<#
		.Refresh icon cache
		.刷新图标缓存
	#>
	RefreshIconCache

	<#
		.Set folder and file permissions
		.设置文件夹、文件权限
	#>
	Permissions

	<#
		.Install fonts
		.安装字体
	#>
	InstallFontsStart

	<#
		.Obtain deployment conditions: 1. Clean up the entire solution; clean up the main engine after running. Set the mark after being satisfied: $True
		.获取部署条件：1、清理整个解决方案；运行后清理主引擎。满足后设置标记为：$True
	#>
	$FlagsPreProcess = $Flase
	if ((Test-Path -path "$PSScriptRoot\..\..\Deploy\ClearSolutions" -PathType Leaf) -or
		(Test-Path -path "$PSScriptRoot\..\..\Deploy\ClearEngine" -PathType Leaf))
	{
		$FlagsPreProcess = $True
	}

	<#
		.Judging the deployment flag
		.判断部署标记
	#>
	if ($FlagsPreProcess) {
		<#
			.Activation Kit
			.激活工具
		#>
		StartInstallSoftware -appname $ActivateApp[0][0] -status "Enable" -act $ActivateApp[0][2] -mode $ActivateApp[0][3] -todisk $ActivateApp[0][4] -structure $ActivateApp[0][5] -url $ActivateApp[0][6] -urlAMD64 $ActivateApp[0][7] -urlarm64 $ActivateApp[0][8] -filename $ActivateApp[0][9] -param $ActivateApp[0][10] -method $ActivateApp[0][11]
#		StartInstallSoftware -appname $ActivateApp[1][0] -status "Enable" -act $ActivateApp[1][2] -mode $ActivateApp[1][3] -todisk $ActivateApp[1][4] -structure $ActivateApp[1][5] -url $ActivateApp[1][6] -urlAMD64 $ActivateApp[1][7] -urlarm64 $ActivateApp[1][8] -filename $ActivateApp[1][9] -param $ActivateApp[1][10] -method $ActivateApp[1][11]

		<#
			.Desktop icons，
			.桌面图标，添加到所有用户 -AllUsers 
		#>
		DesktopICONThisPC -AllUsers           # 此电脑          | This computer
#		DesktopICONRecycleBin -AllUsers       # 回收站          | Recycle Bin
		DesktopICONUser -AllUsers             # 用户            | User
#		DesktopICONControlPanel -AllUsers     # 控制面板        | Control Panel
#		DesktopICONNetwork -AllUsers          # 网络            | Network
#		DesktopICONGodMode                    # 上帝模式        | God Mode
#		DesktopICONIE -AllUsers               # Internet Explorer
		ResetDesktop                          # 重新排列桌面图标 | Rearrange desktop icons

		<#
			.优化系统
			.Optimize the system
		#>
		DisableTakeOwnership          # Del $lang.AddOwnership
		EnableTakeOwnership           # Add $lang.AddOwnership
		DisableHibernation            # $lang.Hibernation

		<#
			.优化电源前判断计算机类型
			.Determine the computer type before optimizing the power supply
		#>
		$NoSelectPowerSupply = @(8, 9, 10, 11, 14)
		Get-CimInstance -ClassName Win32_SystemEnclosure | ForEach-Object {
			if ($NoSelectPowerSupply -notcontains $_.SecurityStatus) {
				SetPowerSupply                # $lang.PowerSupply
			}
		}

		DisableAppRestartScreen       # $lang.AppRestartScreen
		DisableArrow                  # $lang.ShortcutArrow
		EnableNumlock                 # $lang.Numlock
		SetSearchBox -Type "icon"     # $lang.SearchBox
		SetUACNever                   # $lang.UAC $lang.UACNever
		DisableSmartScreen            # $lang.SmartScreen
		DisableMaintain               # $lang.Maintain
		SetExperience                 # $lang.Experience
		DisableDefragmentation        # $lang.Defragmentation
		DisableCompatibility          # $lang.Compatibility
		OptAnimationEffects           # $lang.AnimationEffects
		EnableSafetyWarnings          # $lang.SafetyWarnings
		DisableQOS                    # $lang.QOS
		DisableNetworkTuning          # $lang.NetworkTuning
		DisableECN                    # $lang.ECN
		DisableErrorRecovery          # $lang.ErrorRecovery
#		DisableDEPPAE                 # $lang.DEP
		DisablePowerFailure           # $lang.PowerFailure
		DisableAutoDetect             # $lang.IEAutoSet
#		IEProxy                       # $lang.IEProxy
		DisableScheduledTasks         # $lang.ScheduledTasks
		SetMergeTaskbarNever          # $lang.MergeTaskbarNever
		SetNotificationAlways         # $lang.NotificationAlways
		SetNavShowAll                 # $lang.NavShowAll
		SetCortana                    # $lang.Cortana
		SetPwdUnlimited               # $lang.PwdUnlimited
		SetRAM                        # $lang.RAM
		EnablePhotoPreview            # $lang.PhotoPreview
		HideRecentShortcuts           # $lang.QuickAccess
		DisableGamebar                # $lang.Gamebar
		DisableGameMode               # $lang.GameMode
		DisableProtected              # $lang.Protected
		DisableMultipleIncrease       # $lang.MultipleIncrease
#		DisableAutoplay               # $lang.Autoplay
#		DisableAutorun                # $lang.Autorun
		DisableErrorReporting         # $lang.ErrorReporting
#		DisableF8BootMenu             # $lang.F8BootMenu
		OptSSD                        # $lang.OptSSD
		DisableMemoryCompression      # $lang.MemoryCompression
		DisablePrelaunch              # $lang.Prelaunch
		DisableOptUser                # $lang.OptUser
		DisableOptUpdate              # $lang.OptUpdate
		DisableFixPrivacy             # $lang.FixPrivacy
		DisableTimelineTime           # $lang.TimelineTime
		DisableCollectActivity        # $lang.CollectActivity
		SendTo                        # $lang.SendTo
		CleanSystemLog                # $lang.Logs
#		CleanSxS                      # $lang.SxS
#		DisableActionCenter           # $lang.Notification $lang.Full
		DisableActionCenterPart       # $lang.Notification $lang.Part
		PagingSize -size 8            # $lang.PagingSize 8G and 16G

		<#
			.Optimize service
			.优化服务
		#>
		$PreServices = @(
#			"Spooler"
			"DPS"
			"DiagTrack"
			"WdiSystemHost"
			"WdiServiceHost"
			"diagnosticshub.standardcollector.service"
			"dmwappushservice"
			"lfsvc"
			"MapsBroker"
			"NetTcpPortSharing"
			"RemoteAccess"
			"RemoteRegistry"
			"SharedAccess"
			"TrkWks"
			"WbioSrvc"
			"WlanSvc"
			"WMPNetworkSvc"
			"WSearch"
			"XblAuthManager"
			"XblGameSave"
			"XboxNetApiSvc"
		)

		foreach ($item in $PreServices) {
			Write-Host "   $($lang.Close) $item"
			Get-Service -Name $item | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
			Stop-Service $item -Force -NoWait -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		}

		<#
			.Turn off Microsoft Defender Antivirus
			.关闭 Microsoft Defender 防病毒
		#>
#		StartInstallSoftware -appname $CloseSoftwareApp[[0]][0] -status "Enable" -act $CloseSoftwareApp[[0]][2] -mode $CloseSoftwareApp[[0]][3] -todisk $CloseSoftwareApp[[0]][4] -structure $CloseSoftwareApp[[0]][5] -url $CloseSoftwareApp[[0]][6] -urlAMD64 $CloseSoftwareApp[[0]][7] -urlarm64 $CloseSoftwareApp[[0]][8] -filename $CloseSoftwareApp[[0]][9] -param $CloseSoftwareApp[[0]][10] -method $CloseSoftwareApp[[0]][11]

		<#
			.Turn off Microsoft Defender firewall
			.关闭 Microsoft Defender 防火墙
		#>
#		StartInstallSoftware -appname $CloseSoftwareApp[[1]][0] -status "Enable" -act $CloseSoftwareApp[[1]][2] -mode $CloseSoftwareApp[[1]][3] -todisk $CloseSoftwareApp[[1]][4] -structure $CloseSoftwareApp[[1]][5] -url $CloseSoftwareApp[[1]][6] -urlAMD64 $CloseSoftwareApp[[1]][7] -urlarm64 $CloseSoftwareApp[[1]][8] -filename $CloseSoftwareApp[[1]][9] -param $CloseSoftwareApp[[1]][10] -method $CloseSoftwareApp[[1]][11]

		<#
			.Turn off Windows Update
			.关闭 Windows 更新
		#>
#		StartInstallSoftware -appname $CloseSoftwareApp[[3]][0] -status "Enable" -act $CloseSoftwareApp[[3]][2] -mode $CloseSoftwareApp[[3]][3] -todisk $CloseSoftwareApp[[3]][4] -structure $CloseSoftwareApp[[3]][5] -url $CloseSoftwareApp[[3]][6] -urlAMD64 $CloseSoftwareApp[[3]][7] -urlarm64 $CloseSoftwareApp[[3]][8] -filename $CloseSoftwareApp[[3]][9] -param $CloseSoftwareApp[[3]][10] -method $CloseSoftwareApp[[3]][11]

		<#
			.Delete OneDrive
			.删除 OneDrive
		#>
#		DelOneDrive         # Remove OneDrive

		<#
			.Delete Edge
			.删除 Edge
		#>
#		DelEdge             # Remove Edge

		<#
			.Delete UWP app
			.删除 UWP 应用
		#>
		[Windows.Management.Deployment.PackageManager, Windows.Web, ContentType = WindowsRuntime]::new().FindPackages() | Select-Object -ExpandProperty Id -Property DisplayName | Where-Object -FilterScript {
			($_.Name -in (Get-AppxPackage -PackageTypeFilter Bundle -AllUsers).Name) -and ($null -ne $_.DisplayName)} | ForEach-Object {
			if (($AppsUncheck + $AppsExcluded) -Contains $_.Name) {
			} else {
				Write-Host "   $($lang.UninstallNow -f $_.Name)"
				Get-AppXProvisionedPackage -Online | Where-Object DisplayName -Like "$($_.Name)" | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction SilentlyContinue | Out-Null
				Get-AppxPackage -Name "$($_.Name)" | Remove-AppxPackage | Out-Null
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			}
		}
		Write-Host ""

		<#
			.Install prerequisite software
			.安装必备软件
		#>
		for ($i=0; $i -lt $PrerequisiteApp.Count; $i++) {
			StartInstallSoftware -appname $PrerequisiteApp[$i][0] -status $PrerequisiteApp[$i][1] -act $PrerequisiteApp[$i][2] -mode $PrerequisiteApp[$i][3] -todisk $PrerequisiteApp[$i][4] -structure $PrerequisiteApp[$i][5] -url $PrerequisiteApp[$i][6] -urlAMD64 $PrerequisiteApp[$i][7] -urlarm64 $PrerequisiteApp[$i][8] -filename $PrerequisiteApp[$i][9] -param $PrerequisiteApp[$i][10] -method $PrerequisiteApp[$i][11]
		}

		<#
			.Install common software
			.安装常用软件
		#>
#		MostUsedSoftware -Force        # $lang.MostUsedSoftware

		<#
			.Wait for the queue to finish
			.等待队列运行结束
		#>
		WaitEnd
	}

	<#
		.Synchronization home directory icon
		.同步主目录图标
	#>
	FixMainFolder

	<#
		.Create Shortcut
		.创建快捷方式
	#>
	RefreshStart

	<#
		.Recovery PowerShell strategy
		.恢复 PowerShell 策略
	#>
	if (Test-Path "$PSScriptRoot\..\..\Deploy\ResetExecutionPolicy" -PathType Leaf) {
		Set-ExecutionPolicy -ExecutionPolicy Restricted -Force -ErrorAction SilentlyContinue
	}

	<#
		.Clean up the main engine
		.清理主引擎
	#>
	if (Test-Path "$PSScriptRoot\..\..\Deploy\ClearEngine" -PathType Leaf) {
		Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
		RemoveTree -Path "$($Global:UniqueMainFolder)\Engine"
	}

	<#
		.Clean up the solution
		.清理解决方案
	#>
	if (Test-Path "$PSScriptRoot\..\..\Deploy\ClearSolutions" -PathType Leaf) {
		Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
		RemoveTree -Path "$($Global:UniqueMainFolder)"

		<#
			.In order to prevent the solution from being unable to be cleaned up, the next time you log in, execute it again
			.为了防止无法清理解决方案，下次登录时，再次执行
		#>
		Write-Host "   $($lang.NextDelete)`n" -ForegroundColor Green
		$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
		$regKey = "Clear $($Global:UniqueID) Folder"
		$regValue = "cmd.exe /c rd /s /q ""$($Global:UniqueMainFolder)"""
		if ((Test-Path $regPath)) {
			New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
		} else {
			New-Item -Path $regPath -Force | Out-Null
			New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
		}
	}

	<#
		.After entering the system for the first time, search for Bat and PS1
		.第一次进入系统后，全盘搜索 Bat、PS1
	#>
	write-host "`n   $($lang.DiskSearch)"
	$SearchBatFile = @(
		"$($Global:UniqueID).bat"
		"$($Global:UniqueID)\$($Global:UniqueID).bat"
	)
	$SearchPSFile = @(
		"$($Global:UniqueID).ps1"
		"$($Global:UniqueID)\$($Global:UniqueID).ps1"
	)
	foreach ($item in $SearchBatFile) {
		Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
			$TempFilePath = Join-Path -Path "$($_.Root)" -ChildPath "$($item)" -ErrorAction SilentlyContinue

			Write-Host "   - $TempFilePath"
			if (Test-Path $TempFilePath -PathType Leaf) {
				write-host	"   - $($lang.DiskSearchFind -f $($TempFilePath))`n" -ForegroundColor Gray
				Start-Process "cmd" -ArgumentList $TempFilePath -Wait -WindowStyle Minimized
			}
		}
	}
	foreach ($item in $SearchPSFile) {
		Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
			$TempFilePath = Join-Path -Path "$($_.Root)" -ChildPath "$($item)" -ErrorAction SilentlyContinue

			Write-Host "   - $TempFilePath"
			if (Test-Path $TempFilePath -PathType Leaf) {
				write-host	"   - $($lang.DiskSearchFind -f $($TempFilePath))`n" -ForegroundColor Gray
				Start-Process "powershell" -ArgumentList "-file ""$TempFilePath"" -Force" -Wait -WindowStyle Minimized
			}
		}
	}

	<#
		.非预配置，第一次进入系统后弹出“主界面”
		.Not pre-configured, the "main interface" pops up after entering the system for the first time
	#>
	$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
	if (-not (Test-Path $regPath)) {
		New-Item -Path $regPath -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if (-not ($FlagsPreProcess)) {
		$regValue = "powershell -Command ""Start-Process 'Powershell' -Argument '-File ""$($Global:UniqueMainFolder)\Engine\Engine.ps1""' -Verb RunAs"""
		New-ItemProperty -Path $regPath -Name "$($Global:UniqueID)" -Value $regValue -PropertyType STRING -Force | Out-Null
	}

	<#
		.Whether to enter Sysprep mode
		.是否进入 Sysprep 模式
	#>
	if (Test-Path "$PSScriptRoot\..\..\Deploy\Sysprep" -PathType Leaf) {
		if (Test-Path "$PSScriptRoot\..\..\Deploy\Reboot" -PathType Leaf) {
			Start-Process "$env:SystemDrive\Windows\System32\Sysprep\Sysprep.exe" -ArgumentList "/oobe /generalize /Reboot"
			RemoveTree -Path "$PSScriptRoot\..\..\Deploy"
			exit
		}
			if (Test-Path "$PSScriptRoot\..\..\Deploy\Shutdown" -PathType Leaf) {
			Start-Process "$env:SystemDrive\Windows\System32\Sysprep\Sysprep.exe" -ArgumentList "/oobe /generalize /shutdown"
			RemoveTree -Path "$PSScriptRoot\..\..\Deploy"
			exit
		}

		Start-Process "$env:SystemDrive\Windows\System32\Sysprep\Sysprep.exe"
		RemoveTree -Path "$PSScriptRoot\..\..\Deploy"
		exit
	}

	<#
		.Clean up deployment configuration
		.清理部署配置
	#>
	RemoveTree -Path "$PSScriptRoot\..\..\Deploy"

	<#
		.Reboot Computer
		.重启计算机
	#>
	Restart-Computer -Force
}

<#
	.Change system disk volume label
	.更改系统盘卷标
#>
Function SystemDiskLabel
{
	param (
		[switch]$Default
	)

	$FlagSyncVolumeName = $True
	if (Test-Path -path "$PSScriptRoot\..\..\Deploy\SyncVolumeName" -PathType Leaf) {
		$FlagSyncVolumeName = $False
	}

	if ($Default) {
		$FlagSyncVolumeName = $True
	} else {
		$FlagSyncVolumeName = $False
	}

	if ($FlagSyncVolumeName) {
		$NewSystemVolumeName = "OS"
	} else {
		$NewSystemVolumeName = $Global:UniqueID
	}

	Write-Host "`n   $($lang.VolumeLabel -f $NewSystemVolumeName)"
	(New-Object -ComObject "Shell.Application").NameSpace($env:SystemDrive).Self.Name = $NewSystemVolumeName
}

<#
	.Add exclusion to firewall
	.向防火墙添加排除
#>
Function ExclusionFirewall
{
	param (
		[switch]$Add
	)

	$ExcludeMpPreference = @(
		"$env:SystemDrive\$($Global:UniqueID)"
	)

	$FlagExcludeDefender = $False
	if (Test-Path -path "$PSScriptRoot\..\..\Deploy\ExcludeDefender" -PathType Leaf) {
		$FlagExcludeDefender = $True
	}
	
	if ($Add) {
		$FlagExcludeDefender = $True
	}
	
	if ($FlagExcludeDefender) {
		Write-Host "`n   $($lang.AddTo) $($lang.Exclude)"
		foreach ($item in $ExcludeMpPreference) {
			Write-Host "   * $item"
			Add-MpPreference -ExclusionPath $item -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		}
	}
}

Function FixMainFolder
{
	Write-Host "`n   $($lang.FixMainFolder -f $($Global:UniqueID))`n"
	$DeskEdit = "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\DeskEdit")\DeskEdit.exe"
	if (Test-Path $DeskEdit -PathType Leaf) {
		Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($Global:UniqueMainFolder)"" /S=.ShellClassInfo /L=IconResource=""$($Global:UniqueMainFolder)\Engine\icons\Engine.ico,0"""
	}
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Export-ModuleMember -Function "Signup"
Export-ModuleMember -Function "SignupProcess"