﻿<#
 .Synopsis
  Signup

 .Description
  Signup Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Register user interface
	.注册用户界面
#>
Function Signup
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.Reset)
	Write-Host "   $($lang.PlanTask)`n   ---------------------------------------------------"

	if ($Force) {
		if (Test-Path "$PSScriptRoot\..\..\Deploy\DoNotUpdate" -PathType Leaf) {
			Write-Host "   - $($lang.UpdateSkipUpdateCheck)"
		} else {
			Write-Host "   - $($lang.ForceUpdate)"
			Update -Auto -IsProcess
		}

		SignupProcess
	} else {
		SignupGUI
	}
}

Function SignupGUI
{
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	Write-Host "`n   $($lang.Reset)"

	$GUISignupVolumePanelClick = {
		if ($GUISignupVolume.Checked) {
			$GUISignupVolumePanel.Enabled = $True
		} else {
			$GUISignupVolumePanel.Enabled = $False
		}
	}
	$GUISignupDeskMenuClick = {
		if ($GUISignupDeskMenu.Checked) {
			$GUISignupDeskMenuShift.Enabled = $True
		} else {
			$GUISignupDeskMenuShift.Enabled = $False
		}
	}
	$GUISignupCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUISignup.Close()
	}
	$GUISignupOKClick = {
		$GUISignup.Hide()
		if ($GUISignupVolume.Enabled) {
			if ($GUISignupVolume.Checked) {
				if ($GUISignupVolumeDefault.Checked) {
					SystemDiskLabel -VolumeName "OS"
				}
				if ($GUISignupVolumeSync.Checked) {
					SystemDiskLabel -VolumeName $Global:UniqueID
				}
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
			}
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUISignupDeskMenu.Enabled) {
			if ($GUISignupDeskMenu.Checked) {
				SignupDeskMenu -Del
				if ($GUISignupDeskMenuShift.Checked) {
					SignupDeskMenu -Add -Hide
				} else {	
					SignupDeskMenu -Add
				}
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			} else {
				SignupDeskMenu -Del
				Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red	
			}
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.ExcludeDefenders)"
		if ($GUISignupDefenders.Checked) {
			ExclusionFirewall
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUISignupLangAndKeyboard.Checked) {
			LanguageSetting
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUISignupFixMainFolder.Checked) {
			FixMainFolder
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.FDPermissions)"
		if ($GUISignupFDPermissions.Checked) {
			Permissions
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.Shortcut)"
		if ($GUISignupShortcut.Checked) {
			ShortcutProcess
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}
		
		$GUISignup.Close()
	}
	$GUISignup         = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 600
		Width          = 450
		Text           = $lang.Reset
		TopMost        = $True
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}
	$GUISignupPanel    = New-Object system.Windows.Forms.Panel -Property @{
		Height         = 500
		Width          = 450
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
		Dock           = 1
	}
	$GUISignupVolume   = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,5"
		Height         = 22
		Width          = 390
		Text           = $lang.SelectVolumename
		Checked        = $True
		add_Click      = $GUISignupVolumePanelClick
	}
	$GUISignupVolumePanel = New-Object system.Windows.Forms.Panel -Property @{
		Height         = 50
		Width          = 370
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
		Location       = "16,30"
	}
	$GUISignupVolumeDefault = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 300
		Text           = "OS"
		Location       = '10,0'
		Checked        = $True
	}
	$GUISignupVolumeSync = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 300
		Text           = $($Global:UniqueID)
		Location       = '10,25'
	}
	$GUISignupDeskMenu = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,90"
		Height         = 22
		Width          = 390
		Text           = $lang.DesktopMenu
		Checked        = $True
		add_Click      = $GUISignupDeskMenuClick
	}
	$GUISignupDeskMenuShift = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "26,115"
		Height         = 22
		Width          = 380
		Text           = $lang.DesktopMenuShift
	}
	$GUISignupDefenders = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,148"
		Height         = 22
		Width          = 390
		Text           = $lang.ExcludeDefenders
		Checked        = $True
	}
	$GUISignupLangAndKeyboard = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,178"
		Height         = 22
		Width          = 390
		Text           = $lang.SettingLangAndKeyboard
		Checked        = $True
	}
	$GUISignupFixMainFolder = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,208"
		Height         = 22
		Width          = 390
		Text           = "$($lang.FixMainFolder -f $($Global:UniqueID))"
		Checked        = $True
	}
	$GUISignupFDPermissions = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,238"
		Height         = 22
		Width          = 390
		Text           = $lang.FDPermissions
		Checked        = $True
	}
	$GUISignupShortcut = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = "10,268"
		Height         = 22
		Width          = 390
		Text           = $lang.Shortcut
		Checked        = $True
	}	
	$GUISignupOK       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "10,515"
		Height         = 36
		Width          = 202
		add_Click      = $GUISignupOKClick
		Text           = $lang.OK
	}
	$GUISignupCanel    = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "218,515"
		Height         = 36
		Width          = 202
		add_Click      = $GUISignupCanelClick
		Text           = $lang.Cancel
	}
	$GUISignup.controls.AddRange((
		$GUISignupPanel,
		$GUISignupOK,
		$GUISignupCanel
	))
	$GUISignupPanel.controls.AddRange((
		$GUISignupVolume,
		$GUISignupVolumePanel,
		$GUISignupDeskMenu,
		$GUISignupDeskMenuShift,
		$GUISignupDefenders,
		$GUISignupLangAndKeyboard,
		$GUISignupFixMainFolder,
		$GUISignupFDPermissions,
		$GUISignupShortcut
	))
	$GUISignupVolumePanel.controls.AddRange((
		$GUISignupVolumeDefault,
		$GUISignupVolumeSync
	))
 
	switch ($Global:IsLang) {
		"zh-CN" {
			$GUISignup.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUISignup.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$GUISignup.FormBorderStyle = 'Fixed3D'
	$GUISignup.ShowDialog() | Out-Null
}

<#
	.Start processing registration tasks
	.开始处理注册任务
#>
Function SignupProcess
{
	<#
		.According to the official requirements of Microsoft, add the strategy: Prevent Windows 10 from automatically deleting unused language packs
		.按照微软官方要求，添加策略：防止 Windows 10 自动删除未使用的语言包
	#>
	If (-not (Test-Path "HKLM:\Software\Policies\Microsoft\Control Panel\International")) { New-Item -Path "HKLM:\Software\Policies\Microsoft\Control Panel\International" -Force | Out-Null }
	Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Control Panel\International" -Name "BlockCleanupOfUnusedPreinstalledLangPacks" -Type DWord -Value 1 -ErrorAction SilentlyContinue | Out-Null

	<#
		.After using the $OEM$ mode to add files, the default is read-only. Change all files to: Normal.
		.使用 $OEM$ 模式添加文件后默认为只读，更改所有文件为：正常。
	#>
	Get-ChildItem "$env:SystemDrive\$($Global:UniqueID)" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.Attributes="Normal" }

	<#
		.Close the pop-up after entering the system for the first time: Network Location Wizard
		.关闭第一次进入系统后弹出：网络位置向导
	#>
	Write-Host "`n   $($lang.Disable) $($lang.NetworkLocationWizard)"
	New-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Network\NewNetworkWindowOff" -Force -ErrorAction SilentlyContinue | Out-Null

	<#
		.Change system disk volume label
		.更改系统盘卷标
	#>
	if (Test-Path -Path "$PSScriptRoot\..\..\Deploy\SyncVolumeName" -PathType Leaf) {
		SystemDiskLabel -VolumeName $Global:UniqueID
	} else {
		SystemDiskLabel -VolumeName "OS"
	}

	<#
		.Add exclusion to firewall
		.向防火墙添加排除
	#>
	if (Test-Path -Path "$PSScriptRoot\..\..\Deploy\ExcludeDefender" -PathType Leaf) {
		ExclusionFirewall
	}

	<#
	 	.Desktop right-click menu
		.桌面右键菜单
	#>
	if (Test-Path -Path "$PSScriptRoot\..\..\Deploy\DesktopMenu" -PathType Leaf) {
		SignupDeskMenu -Del

		if (Test-Path -Path "$PSScriptRoot\..\..\Deploy\DesktopMenuShift" -PathType Leaf) {
			SignupDeskMenu -Add -Hide
		} else {
			SignupDeskMenu -Add
		}
	} else {
		SignupDeskMenu -Del
	}

	<#
		.Set system language, keyboard, etc.
		.设置系统语言、键盘等
	#>
	LanguageSetting

	<#
		.Refresh icon cache
		.刷新图标缓存
	#>
	RefreshIconCache

	<#
		.Set folder and file permissions
		.设置文件夹、文件权限
	#>
	Permissions

	<#
		.Install fonts
		.安装字体
	#>
	InstallFontsProcess

	<#
		.Obtain deployment conditions: 1. Clean up the entire solution; clean up the main engine after running. Set the mark after being satisfied: $True
		.获取部署条件：1、清理整个解决方案；运行后清理主引擎。满足后设置标记为：$True
	#>
	$FlagsPreProcess = $Flase
	if ((Test-Path -Path "$PSScriptRoot\..\..\Deploy\ClearSolutions" -PathType Leaf) -or
		(Test-Path -Path "$PSScriptRoot\..\..\Deploy\ClearEngine" -PathType Leaf))
	{
		$FlagsPreProcess = $True
	}

	<#
		.Judging the deployment flag
		.判断部署标记
	#>
	if ($FlagsPreProcess) {
		<#
			.Change user directory
			.更改用户目录
		#>
#		SetKnownFolderPath -KnownFolder 'Desktop'   -Path "D:\Users\Administrator\Desktop"
#		SetKnownFolderPath -KnownFolder 'Documents' -Path "D:\Users\Administrator\Documents"
#		SetKnownFolderPath -KnownFolder 'Downloads' -Path "D:\Users\Administrator\Downloads"
#		SetKnownFolderPath -KnownFolder 'Music'     -Path "D:\Users\Administrator\Music"
#		SetKnownFolderPath -KnownFolder 'Pictures'  -Path "D:\Users\Administrator\Pictures"
#		SetKnownFolderPath -KnownFolder 'Videos'    -Path "D:\Users\Administrator\Videos"

		<#
			.Activation Kit
			.激活工具
		#>
		InstallProcess -appname $ActivateApp[0][0] -status "Enable" -act $ActivateApp[0][2] -mode $ActivateApp[0][3] -todisk $ActivateApp[0][4] -structure $ActivateApp[0][5] -pwd $ActivateApp[0][6] -url $ActivateApp[0][7] -urlAMD64 $ActivateApp[0][8] -urlarm64 $ActivateApp[0][9] -filename $ActivateApp[0][10] -param $ActivateApp[0][11] -method $ActivateApp[0][12]
#		InstallProcess -appname $ActivateApp[1][0] -status "Enable" -act $ActivateApp[1][2] -mode $ActivateApp[1][3] -todisk $ActivateApp[1][4] -structure $ActivateApp[1][5] -pwd $ActivateApp[1][6] -url $ActivateApp[1][7] -urlAMD64 $ActivateApp[1][8] -urlarm64 $ActivateApp[1][9] -filename $ActivateApp[1][10] -param $ActivateApp[1][11] -method $ActivateApp[1][12]

		<#
			.Desktop icons，
			.桌面图标，添加到所有用户 -AllUsers 
		#>
		DesktopICONThisPC -AllUsers           # 此电脑          | This computer
#		DesktopICONRecycleBin -AllUsers       # 回收站          | Recycle Bin
		DesktopICONUser -AllUsers             # 用户            | User
#		DesktopICONControlPanel -AllUsers     # 控制面板        | Control Panel
#		DesktopICONNetwork -AllUsers          # 网络            | Network
#		DesktopICONGodMode                    # 上帝模式        | God Mode
#		DesktopICONIE -AllUsers               # Internet Explorer
		ResetDesktop                          # 重新排列桌面图标 | Rearrange desktop icons

		<#
			.优化电源前判断计算机类型
			.Determine the computer type before optimizing the power supply
		#>
		$NoSelectPowerSupply = @(8, 9, 10, 11, 14)
		Get-CimInstance -ClassName Win32_SystemEnclosure | ForEach-Object {
			if ($NoSelectPowerSupply -notcontains $_.SecurityStatus) {
				PowerSupply -Optimize         # Optimize, Restore | $lang.PowerSupply
			}
		}

		<#
			.优化系统
			.Optimize the system
		#>
		TakeOwnership -Remove           # Del $lang.AddOwnership
		TakeOwnership -Add              # Add $lang.AddOwnership
		Hibernation -Disable            # Disable, Enable   | $lang.Hibernation
		AppRestartScreen -Disable       # Disable, Enable   | $lang.AppRestartScreen
		ShortcutArrow -Disable          # Disable, Enable   | $lang.ShortcutArrow
		Numlock -Enable                 # Disable, Enable   | $lang.Numlock
		SearchBox -Type "icon"          # icon, Box         | $lang.SearchBox
		UACNever -Disable               # Disable, Enable   | $lang.UAC $lang.UACNever
		SmartScreen -Disable            # Disable, Enable   | $lang.SmartScreen
		Maintain -Disable               # Disable, Enable   | $lang.Maintain
		Experience -Disable             # Disable, Enable   | $lang.Experience
		Defragmentation -Disable        # Disable, Enable   | $lang.Defragmentation
		Compatibility -Disable          # Disable, Enable   | $lang.Compatibility
		AnimationEffects -Optimize      # Optimize, Restore | $lang.AnimationEffects
		SafetyWarnings -Disable         # Disable, Enable   | $lang.SafetyWarnings
		QOS -Disable                    # Disable, Enable   | $lang.QOS
		NetworkTuning -Disable          # Disable, Enable   | $lang.NetworkTuning
		ECN -Disable                    # Disable, Enable   | $lang.ECN
		ErrorRecovery -Disable          # Disable, Enable   | $lang.ErrorRecovery
#		DEPPAE -Disable                 # Disable, Enable   | $lang.DEP
		PowerFailure -Disable           # Disable, Enable   | $lang.PowerFailure
		AutoDetect -Disable             # Disable, Enable   | $lang.IEAutoSet
#		IEProxy                         # Disable, Enable   | $lang.IEProxy
		ScheduledTasks -Disable         # Disable, Restore  | $lang.ScheduledTasks
		MergeTaskbarNever -Enable       # Disable, Enable   | $lang.MergeTaskbarNever
		NotificationAlways -Enable      # Disable, Enable   | $lang.NotificationAlways
		NavShowAll -Enable              # Disable, Enable   | $lang.NavShowAll
		Cortana -Disable                # Disable, Enable   | $lang.Cortana
		PwdUnlimited -Disable           # Disable, Enable   | $lang.PwdUnlimited
		RAM -Disable                    # Disable, Enable   | $lang.RAM
		PhotoPreview -Enable            # Disable, Enable   | $lang.PhotoPreview
		RecentShortcuts -Disable        # Disable, Enable   | $lang.QuickAccess
		Gamebar -Disable                # Disable, Enable   | $lang.Gamebar
		GameMode -Disable               # Disable, Enable   | $lang.GameMode
		Protected -Disable              # Disable, Enable   | $lang.Protected
		MultipleIncrease -Disable       # Disable, Enable   | $lang.MultipleIncrease
#		Autoplay -Disable               # Disable, Enable   | $lang.Autoplay
#		Autorun -Disable                # Disable, Enable   | $lang.Autorun
		ErrorReporting -Disable         # Disable, Enable   | $lang.ErrorReporting
#		F8BootMenu -Disable             # Disable, Enable   | $lang.F8BootMenu
		SSD -Disable                    # Disable, Enable   | $lang.OptSSD
		MemoryCompression -Disable      # Disable, Enable   | $lang.MemoryCompression
		Prelaunch -Disable              # Disable, Enable   | $lang.Prelaunch
		OptUser -Disable                # Disable, Restore  | $lang.OptUser
		OptUpdate -Disable              # Disable, Restore  | $lang.OptUpdate

		<#
			.Paging size
			.分页大小
		#>
		PagingSize -Enable -size 8      # 8, 16           | $lang.PagingSize 8G and 16G

		<#
			.Privacy
			.隐私
		#>
		FixPrivacy -Disable             # Disable, Restore | $lang.FixPrivacy
		TimelineTime -Disable           # Disable, Enable  | $lang.TimelineTime
		CollectActivity -Disable        # Disable, Enable  | $lang.CollectActivity

		<#
			.Notification Center
			.通知中心
		#>
#		NotificationCenter -Disable     # Disable, Enable  | $lang.Notification $lang.Full
		NotificationCenterPart -Disable # Disable, Enable  | $lang.Notification $lang.Part

		<#
			.Other
			.其它
		#>
#		RemoteDesktop                   # $lang.StRemote
#		SMBFileShare                    # $lang.StSMB

		<#
			.Clean
			.清理
		#>
		SendTo                          # $lang.SendTo
		CleanSystemLog                  # $lang.Logs
#		CleanSxS                        # $lang.SxS

		<#
			.Optimize service
			.优化服务
		#>
		$PreServices = @(
#			"Spooler"
			"DPS"
			"DiagTrack"
			"WdiSystemHost"
			"WdiServiceHost"
			"diagnosticshub.standardcollector.service"
			"dmwappushservice"
			"lfsvc"
			"MapsBroker"
			"NetTcpPortSharing"
			"RemoteAccess"
			"RemoteRegistry"
			"SharedAccess"
			"TrkWks"
			"WbioSrvc"
			"WlanSvc"
			"WMPNetworkSvc"
			"WSearch"
			"XblAuthManager"
			"XblGameSave"
			"XboxNetApiSvc"
		)

		foreach ($item in $PreServices) {
			Write-Host "   $($lang.Close) $item"
			Get-Service -Name $item | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
			Stop-Service $item -Force -NoWait -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		}

		<#
			.Turn off Microsoft Defender Antivirus
			.关闭 Microsoft Defender 防病毒
		#>
#		InstallProcess -appname "$($lang.Close) $($lang.DefenderControlTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50" -pwd "sordum" -url "https://www.sordum.org/files/download/d-control/dControl.zip" -urlAMD64 "" -urlarm64 "" -filename "dControl*" -param "/D" -method "1:dControl:ini"

		<#
			.Turn off Microsoft Defender firewall
			.关闭 Microsoft Defender 防火墙
		#>
#		InstallProcess -appname "$($lang.Close) $($lang.FabTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50" -pwd "" -url "https://www.sordum.org/files/download/firewall-app-blocker/fab.zip" -urlAMD64 "" -urlarm64 "" -filename "fab*" -param "/S 3" -method "1:Fab:ini"

		<#
			.Turn off Windows Update
			.关闭 Windows 更新
		#>
#		InstallProcess -appname "$($lang.Close) $($lang.WubTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50" -pwd "" -url "https://www.sordum.org/files/download/windows-update-blocker/Wub.zip" -urlAMD64 "" -urlarm64 "" -filename "Wub*" -param "/D /P" -method "1:Wub:ini"

		<#
			.Delete OneDrive
			.删除 OneDrive
		#>
#		DelOneDrive         # Remove OneDrive

		<#
			.Delete Edge
			.删除 Edge
		#>
#		DelEdge             # Remove Edge

		<#
			.Delete UWP app
			.删除 UWP 应用
		#>
		[Windows.Management.Deployment.PackageManager, Windows.Web, ContentType = WindowsRuntime]::new().FindPackages() | Select-Object -ExpandProperty Id -Property DisplayName | Where-Object -FilterScript {
			($_.Name -in (Get-AppxPackage -PackageTypeFilter Bundle -AllUsers).Name) -and ($null -ne $_.DisplayName)} | ForEach-Object {
			if (($AppsUncheck + $AppsExcluded) -Contains $_.Name) {
			} else {
				Write-Host "   $($lang.UninstallNow -f $_.Name)"
				Get-AppXProvisionedPackage -Online | Where-Object DisplayName -Like "$($_.Name)" | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction SilentlyContinue | Out-Null
				Get-AppxPackage -Name "$($_.Name)" | Remove-AppxPackage | Out-Null
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			}
		}
		Write-Host ""

		<#
			.Install prerequisite software
			.安装必备软件
		#>
		for ($i=0; $i -lt $Global:PrerequisiteApp.Count; $i++) {
			InstallProcess -appname $Global:PrerequisiteApp[$i][0] -status $Global:PrerequisiteApp[$i][1] -act $Global:PrerequisiteApp[$i][2] -mode $Global:PrerequisiteApp[$i][3] -todisk $Global:PrerequisiteApp[$i][4] -structure $Global:PrerequisiteApp[$i][5] -pwd $Global:PrerequisiteApp[$i][6] -url $Global:PrerequisiteApp[$i][7] -urlAMD64 $Global:PrerequisiteApp[$i][8] -urlarm64 $Global:PrerequisiteApp[$i][9] -filename $Global:PrerequisiteApp[$i][10] -param $Global:PrerequisiteApp[$i][11] -method $Global:PrerequisiteApp[$i][12]
		}

		<#
			.Install common software
			.安装常用软件
		#>
#		MostUsedSoftware -Force        # $lang.MostUsedSoftware

		<#
			.Wait for the queue to finish
			.等待队列运行结束
		#>
		WaitEnd
	} else {
		<#
			.非预配置，第一次进入系统后弹出“主界面”
			.Not pre-configured, the "main interface" pops up after entering the system for the first time
		#>
		$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
		if (-not (Test-Path $regPath)) {
			New-Item -Path $regPath -Force -ErrorAction SilentlyContinue | Out-Null
		}

		$regValue = "powershell -Command ""Start-Process 'Powershell' -Argument '-ExecutionPolicy ByPass -File ""$($Global:UniqueMainFolder)\Engine\Engine.ps1""' -Verb RunAs"""
		New-ItemProperty -Path $regPath -Name "$($Global:UniqueID)" -Value $regValue -PropertyType STRING -Force | Out-Null
	}

	<#
		.Synchronization home directory icon
		.同步主目录图标
	#>
	FixMainFolder

	<#
		.Create Shortcut
		.创建快捷方式
	#>
	ShortcutProcess

	<#
		.After entering the system for the first time, search for Bat and PS1
		.第一次进入系统后，全盘搜索 Bat、PS1
	#>
	write-host "`n   $($lang.DiskSearch)"
	$SearchBatFile = @(
		"$($Global:UniqueID).bat"
		"$($Global:UniqueID)\$($Global:UniqueID).bat"
	)
	foreach ($item in $SearchBatFile) {
		Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
			$TempFilePath = Join-Path -Path "$($_.Root)" -ChildPath "$($item)" -ErrorAction SilentlyContinue

			Write-Host "   - $TempFilePath"
			if (Test-Path $TempFilePath -PathType Leaf) {
				write-host	"   - $($lang.DiskSearchFind -f $($TempFilePath))`n" -ForegroundColor Gray
				Start-Process "cmd" -ArgumentList $TempFilePath -Wait -WindowStyle Minimized
			}
		}
	}

	$SearchPSFile = @(
		"$($Global:UniqueID).ps1"
		"$($Global:UniqueID)\$($Global:UniqueID).ps1"
	)
	foreach ($item in $SearchPSFile) {
		Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
			$TempFilePath = Join-Path -Path "$($_.Root)" -ChildPath "$($item)" -ErrorAction SilentlyContinue

			Write-Host "   - $TempFilePath"
			if (Test-Path $TempFilePath -PathType Leaf) {
				write-host	"   - $($lang.DiskSearchFind -f $($TempFilePath))`n" -ForegroundColor Gray
				Start-Process "powershell" -ArgumentList "-ExecutionPolicy ByPass -file ""$TempFilePath"" -Force" -Wait -WindowStyle Minimized
			}
		}
	}

	<#
		.Recovery PowerShell strategy
		.恢复 PowerShell 策略
	#>
	if (Test-Path "$PSScriptRoot\..\..\Deploy\ResetExecutionPolicy" -PathType Leaf) {
		Set-ExecutionPolicy -ExecutionPolicy Restricted -Force -ErrorAction SilentlyContinue
	}

	<#
		.Clean up the solution
		.清理解决方案
	#>
	if (Test-Path "$PSScriptRoot\..\..\Deploy\ClearSolutions" -PathType Leaf) {
		Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
		RemoveTree -Path "$($Global:UniqueMainFolder)"

		<#
			.In order to prevent the solution from being unable to be cleaned up, the next time you log in, execute it again
			.为了防止无法清理解决方案，下次登录时，再次执行
		#>
		Write-Host "   $($lang.NextDelete)`n" -ForegroundColor Green
		$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
		$regKey = "Clear $($Global:UniqueID) Folder"
		$regValue = "cmd.exe /c rd /s /q ""$($Global:UniqueMainFolder)"""
		if ((Test-Path $regPath)) {
			New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
		} else {
			New-Item -Path $regPath -Force | Out-Null
			New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
		}
	}

	<#
		.Clean up the main engine
		.清理主引擎
	#>
	if (Test-Path "$PSScriptRoot\..\..\Deploy\ClearEngine" -PathType Leaf) {
		Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
		RemoveTree -Path "$($Global:UniqueMainFolder)\Engine"
	}

	<#
		.Clean up deployment configuration
		.清理部署配置
	#>
	RemoveTree -Path "$PSScriptRoot\..\..\Deploy"

	<#
		.Reboot Computer
		.重启计算机
	#>
	Restart-Computer -Force
}

<#
	.Change system disk volume label
	.更改系统盘卷标
#>
Function SystemDiskLabel
{
	param (
		[string]$VolumeName
	)

	Write-Host "`n   $($lang.VolumeLabel -f $VolumeName)"
	(New-Object -ComObject "Shell.Application").NameSpace($env:SystemDrive).Self.Name = $VolumeName
}

<#
	.Add exclusion to firewall
	.向防火墙添加排除
#>
Function ExclusionFirewall
{
	$ExcludeMpPreference = @(
		"$env:SystemDrive\$($Global:UniqueID)"
	)

	Write-Host "`n   $($lang.AddTo) $($lang.Exclude)"
	foreach ($item in $ExcludeMpPreference) {
		Write-Host "   * $item"
		Add-MpPreference -ExclusionPath $item -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

Function FixMainFolder
{
	Write-Host "`n   $($lang.FixMainFolder -f $($Global:UniqueID))`n"
	$DeskEdit = "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\DeskEdit")\DeskEdit.exe"
	if (Test-Path $DeskEdit -PathType Leaf) {
		Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($Global:UniqueMainFolder)"" /S=.ShellClassInfo /L=IconResource=""$($Global:UniqueMainFolder)\Engine\icons\Engine.ico,0"""
	}
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Export-ModuleMember -Function * -Alias *