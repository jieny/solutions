﻿<#
 .Synopsis
  UWP Apps

 .Description
  UWP Apps Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Exclude UWP apps
	.排除 UWP 应用
#>
$AppsExcluded = @(
	"Microsoft.549981C3F5F10"
	"Microsoft.DesktopAppInstaller"
	"Microsoft.StorePurchaseApp"
	"Microsoft.WindowsStore"
	"Microsoft.WebMediaExtensions"
	"Microsoft.BioEnrollment"
	"Microsoft.XboxGameCallableUI"
	"Microsoft.XboxIdentityProvider"
	"Microsoft.XboxApp"
	"Microsoft.GamingApp"
	"Microsoft.GamingServices"
	"Microsoft.Xbox.TCUI"
	"Microsoft.XboxSpeechToTextOverlay"
	"Microsoft.XboxGamingOverlay"
	"Microsoft.XboxGameOverlay"
)

<#
	.UWP apps not selected
	.不选择的 UWP 应用
#>
$AppsUncheck = @(
	# default Windows 10 apps
#	"Microsoft.549981C3F5F10"
	"MicrosoftTeams"
	"Microsoft.3DBuilder"
	"Microsoft.Appconnector"
	"Microsoft.BingFinance"
	"Microsoft.BingNews"
	"Microsoft.BingSports"
	"Microsoft.BingTranslator"
	"Microsoft.BingWeather"
#	"Microsoft.FreshPaint"
	"Microsoft.GamingServices"
	"Microsoft.Microsoft3DViewer"
	"Microsoft.MicrosoftOfficeHub"
	"Microsoft.MicrosoftPowerBIForWindows"
#	"Microsoft.MicrosoftSolitaireCollection"
#	"Microsoft.MicrosoftStickyNotes"
	"Microsoft.MinecraftUWP"
	"Microsoft.NetworkSpeedTest"
	"Microsoft.Office.OneNote"
	"Microsoft.People"
	"Microsoft.Print3D"
	"Microsoft.SkypeApp"
	"Microsoft.Wallet"
#	"Microsoft.Windows.Photos"
#	"Microsoft.WindowsAlarms"
#	"Microsoft.WindowsCalculator"
#	"Microsoft.WindowsCamera"
	"microsoft.windowscommunicationsapps"
	"Microsoft.WindowsMaps"
	"Microsoft.WindowsPhone"
	"Microsoft.WindowsSoundRecorder"
#	"Microsoft.WindowsStore"   # can't be re-installed
	"Microsoft.Xbox.TCUI"
	"Microsoft.XboxApp"
	"Microsoft.XboxGameOverlay"
	"Microsoft.XboxGamingOverlay"
	"Microsoft.XboxSpeechToTextOverlay"
	"Microsoft.YourPhone"
	"Microsoft.ZuneMusic"
	"Microsoft.ZuneVideo"

	# Threshold 2 apps
	"Microsoft.CommsPhone"
	"Microsoft.ConnectivityStore"
	"Microsoft.GetHelp"
	"Microsoft.Getstarted"
	"Microsoft.Messaging"
	"Microsoft.Office.Sway"
	"Microsoft.OneConnect"
	"Microsoft.WindowsFeedbackHub"

	# Creators Update apps
	"Microsoft.Microsoft3DViewer"
#	"Microsoft.MSPaint"

	# Redstone apps
	"Microsoft.BingFoodAndDrink"
	"Microsoft.BingHealthAndFitness"
	"Microsoft.BingTravel"
	"Microsoft.WindowsReadingList"

	# Redstone 5 apps
	"Microsoft.MixedReality.Portal"
	"Microsoft.ScreenSketch"
	"Microsoft.XboxGamingOverlay"
	"Microsoft.YourPhone"

	# non-Microsoft
	"2FE3CB00.PicsArt-PhotoStudio"
	"46928bounde.EclipseManager"
	"4DF9E0F8.Netflix"
	"613EBCEA.PolarrPhotoEditorAcademicEdition"
	"6Wunderkinder.Wunderlist"
	"7EE7776C.LinkedInforWindows"
	"89006A2E.AutodeskSketchBook"
	"9E2F88E3.Twitter"
	"A278AB0D.DisneyMagicKingdoms"
	"A278AB0D.MarchofEmpires"
	"ActiproSoftwareLLC.562882FEEB491" # next one is for the Code Writer from Actipro Software LLC
	"CAF9E577.Plex"  
	"ClearChannelRadioDigital.iHeartRadio"
	"D52A8D61.FarmVille2CountryEscape"
	"D5EA27B7.Duolingo-LearnLanguagesforFree"
	"DB6EA5DB.CyberLinkMediaSuiteEssentials"
	"DolbyLaboratories.DolbyAccess"
	"DolbyLaboratories.DolbyAccess"
	"Drawboard.DrawboardPDF"
	"Facebook.Facebook"
	"Fitbit.FitbitCoach"
	"Flipboard.Flipboard"
	"GAMELOFTSA.Asphalt8Airborne"
	"KeeperSecurityInc.Keeper"
	"NORDCURRENT.COOKINGFEVER"
	"PandoraMediaInc.29680B314EFC2"
	"Playtika.CaesarsSlotsFreeCasino"
	"ShazamEntertainmentLtd.Shazam"
	"SlingTVLLC.SlingTV"
	"SpotifyAB.SpotifyMusic"
#	"TheNewYorkTimes.NYTCrossword"
	"ThumbmunkeysLtd.PhototasticCollage"
	"TuneIn.TuneInRadio"
	"WinZipComputing.WinZipUniversal"
	"XINGAG.XING"
	"flaregamesGmbH.RoyalRevolt2"
	"king.com.*"
	"king.com.BubbleWitch3Saga"
	"king.com.CandyCrushSaga"
	"king.com.CandyCrushSodaSaga"

	# apps which cannot be removed using Remove-AppxPackage
#	"Microsoft.BioEnrollment"
#	"Microsoft.MicrosoftEdge"
#	"Microsoft.Windows.Cortana"
#	"Microsoft.WindowsFeedback"
#	"Microsoft.XboxGameCallableUI"
#	"Microsoft.XboxIdentityProvider"
#	"Windows.ContactSupport"

	# apps which other apps depend on
	"Microsoft.Advertising.Xaml"
)

<#
	.Uninstall UWP app user interface
	.卸载 UWP 应用用户界面
#>
Function UninstallApps
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title "$($lang.Delete) $($lang.UninstallUWP)"
	Write-Host "   $($lang.Delete) $($lang.UninstallUWP)`n   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	Function RefreshUWPList
	{
		$GUIUWPRefresh.Enabled = $False
		$GUIUWPPanel.controls.Clear()
		$GUIUWPRelyPanel.controls.Clear()

		switch ((Get-Host).Version.Major) {
			7 {
				Get-AppxProvisionedPackage -Online | ForEach-Object {
					if (($AppsExcluded) -notcontains $_.DisplayName) {
						$CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
							Height = 28
							Width  = 470
							Text   = $_.DisplayName
							Tag    = $_.DisplayName
						}

						if (($AppsUncheck + $AppsExcluded) -Contains $_.DisplayName) {
							$CheckBox.Checked = $True
						}
						$GUIUWPPanel.controls.AddRange($CheckBox)
					}
				}

				Get-AppxProvisionedPackage -Online | ForEach-Object {
					if (($AppsExcluded) -Contains $_.DisplayName) {
						$CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
							Height = 28
							Width  = 470
							Text   = $_.DisplayName
							Tag    = $_.DisplayName
						}
		
						if (($AppsUncheck) -Contains $_.DisplayName) {
							$CheckBox.Checked = $True
						}
						$GUIUWPRelyPanel.controls.AddRange($CheckBox)
					}
				}
			}
			Default {
				Get-AppxProvisionedPackage -Online | ForEach-Object {
					if ($_.DisplayName -like "MicrosoftTeams") {
						$CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
							Height = 28
							Width  = 470
							Text   = "MicrosoftTeams"
							Tag    = "MicrosoftTeams"
						}
		   
						if (($AppsUncheck + $AppsExcluded) -Contains $_.Name) {
							$CheckBox.Checked = $True
						}
						$GUIUWPPanel.controls.AddRange($CheckBox)
					}
				}

				[Windows.Management.Deployment.PackageManager, Windows.Web, ContentType = WindowsRuntime]::new().FindPackages() | Select-Object -ExpandProperty Id -Property DisplayName | Where-Object -FilterScript {
					($_.Name -in (Get-AppxPackage -PackageTypeFilter Bundle -AllUsers).Name) -and ($_.Name -notin $AppsExcluded) -and ($null -ne $_.DisplayName)} | ForEach-Object {
					 $CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
						Height = 28
						Width  = 470
						Text   = $_.DisplayName
						Tag    = $_.Name
					}
		
					if (($AppsUncheck + $AppsExcluded) -Contains $_.Name) {
						$CheckBox.Checked = $True
					}
					$GUIUWPPanel.controls.AddRange($CheckBox)
				}

				[Windows.Management.Deployment.PackageManager, Windows.Web, ContentType = WindowsRuntime]::new().FindPackages() | Select-Object -ExpandProperty Id -Property DisplayName | Where-Object -FilterScript {
					($_.Name -in (Get-AppxPackage -PackageTypeFilter Bundle -AllUsers).Name) -and ($null -ne $_.DisplayName)} | ForEach-Object {
					if (($AppsExcluded) -Contains $_.Name) {
						$CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
							Height = 28
							Width  = 470
							Text   = $_.DisplayName
							Tag    = $_.Name
						}
		
						if (($AppsUncheck) -Contains $_.Name) {
							$CheckBox.Checked = $True
						}
						$GUIUWPRelyPanel.controls.AddRange($CheckBox)
					}
				}
			}
		}

		$GUIUWPRefresh.Enabled = $True
	}
	$GUIUWPPanelTitleClick = {
		if ($GUIUWPPanelTitle.Checked) {
			$GUIUWPPanel.Enabled = $True
		} else {
			$GUIUWPPanel.Enabled = $False
		}
	}
	$GUIUWPDefaultTitleClick = {
		if ($GUIUWPDefaultTitle.Checked) {
			$GUIUWPRelyPanel.Enabled = $True
		} else {
			$GUIUWPRelyPanel.Enabled = $False
		}
	}
	$GUIUWPCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIUWP.Close()
	}
	$GUIUWPOKClick = {
		$GUIUWP.Hide()
		if ($GUIUWPPanelTitle.Enabled) {
			if ($GUIUWPPanelTitle.Checked) {
				$GUIUWPPanel.Controls | ForEach-Object {
					if ($_ -is [System.Windows.Forms.CheckBox]) {
						if ($_.Checked) {
							Write-Host "   $($_.Text)"
							Write-host "   $($lang.Delete)".PadRight(22) -NoNewline
							if ($GUIUWPAllUser.Checked) {
								Get-AppXProvisionedPackage -Online | Where-Object DisplayName -Like "$($_.Tag)" | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction SilentlyContinue | Out-Null
								Get-AppxPackage -Name "$($_.Tag)" | Remove-AppxPackage | Out-Null
								Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
							} else {
								Get-AppxPackage -Name "$($_.Tag)" | Remove-AppxPackage | Out-Null
								Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
							}
						}
					}
				}
			}
		}

		if ($GUIUWPDefaultTitle.Enabled) {
			if ($GUIUWPDefaultTitle.Checked) {
				$GUIUWPRelyPanel.Controls | ForEach-Object {
					if ($_ -is [System.Windows.Forms.CheckBox]) {
						if ($_.Checked) {
							Write-Host "   $($_.Text)"
							Write-host "   $($lang.Delete)".PadRight(22) -NoNewline
							if ($GUIUWPAllUser.Checked) {
								Get-AppXProvisionedPackage -Online | Where-Object DisplayName -Like "$($_.Tag)" | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction SilentlyContinue | Out-Null
								Get-AppxPackage -Name "$($_.Tag)" | Remove-AppxPackage | Out-Null
								Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
							} else {
								Get-AppxPackage -Name "$($_.Tag)" | Remove-AppxPackage | Out-Null
								Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
							}
						}
					}
				}
			}
		}

		Write-Host "`n   $($lang.PreventsApps)"
		if ($GUIUWPPreventsApps.Checked) {
			$cdm = @(
				"ContentDeliveryAllowed"
				"FeatureManagementEnabled"
				"OemPreInstalledAppsEnabled"
				"PreInstalledAppsEnabled"
				"PreInstalledAppsEverEnabled"
				"SilentInstalledAppsEnabled"
			)
	
			New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Force -ErrorAction SilentlyContinue | Out-Null
			foreach ($item in $cdm) {
				New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name $item -Value 0 -PropertyType DWord -Force -ea SilentlyContinue
			}
		} else {
			Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIUWPSuggestedContent.Checked) {
			TaskbarSuggestedContent -Hide
		} else {
			Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
		}

		Write-Host "   $($lang.CloseStoreAuto)"
		if ($GUIUWPCloseStoreAuto.Checked) {
			Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
			New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore" -Force -ErrorAction SilentlyContinue | Out-Null
			New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' -Name 'AutoDownload' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue
		} else {
			Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
		}

		Write-Host "   $($lang.PreventsSuggestApps)"
		if ($GUIUWPPreventsSuggestApps.Checked) {
			Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
			New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Force -ErrorAction SilentlyContinue | Out-Null
			New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsConsumerFeatures' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue
		} else {
			Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIUWPSuggestionsDevice.Checked) {
			SuggestionsDevice -Disable
		}
		
		$GUIUWP.Close()
	}
	$GUIUWP            = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 1120
		Text           = "$($lang.Delete) $($lang.UninstallUWP)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUIUWPPanelTitle  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 395
		Text           = $lang.UninstallUWP
		Location       = '10,10'
		Checked        = $True
		add_click      = $GUIUWPPanelTitleClick
	}
	$GUIUWPPanel       = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 645
		Width          = 510
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
		Location       = '10,38'
	}

	<#
		.依赖性
	#>
	$GUIUWPDefaultTitle = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 510
		Text           = $lang.UninstallUWPRely
		Location       = '580,10'
		add_click      = $GUIUWPDefaultTitleClick
	}
	$GUIUWPRelyPanel   = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 275
		Width          = 510
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
		Location       = '580,38'
		Enabled        = $False
	}

	$GUIUWPOtherTips   = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 510
		Text           = $lang.AdvOption
		Location       = '580,338'
	}
	$GUIUWPPreventsApps = New-Object System.Windows.Forms.CheckBox -Property @{
		UseVisualStyleBackColor = $True
		Location       = '598,366'
		Height         = 22
		Width          = 490
		Text           = $lang.PreventsApps
		Checked        = $True
	}
	$GUIUWPSuggestedContent = New-Object System.Windows.Forms.CheckBox -Property @{
		Location       = '598,394'
		Height         = 22
		Width          = 490
		Text           = "$($lang.Hide) $($lang.TaskbarSuggestedContent)"
		Checked        = $true
	}
	$GUIUWPCloseStoreAuto = New-Object System.Windows.Forms.CheckBox -Property @{
		UseVisualStyleBackColor = $True
		Location       = '598,422'
		Height         = 22
		Width          = 490
		Text           = $lang.CloseStoreAuto
		Checked        = $True
	}
	$GUIUWPPreventsSuggestApps = New-Object System.Windows.Forms.CheckBox -Property @{
		UseVisualStyleBackColor = $True
		Location       = '598,450'
		Height         = 22
		Width          = 490
		Text           = $lang.PreventsSuggestApps
		Checked        = $True
	}
	$GUIUWPSuggestionsDevice = New-Object System.Windows.Forms.CheckBox -Property @{
		UseVisualStyleBackColor = $True
		Location       = '598,478'
		Height         = 22
		Width          = 490
		Text           = "$($lang.Disable) $($lang.SuggestionsDevice)"
		Checked        = $true
	}
	$GUIUWPAllUser     = New-Object System.Windows.Forms.CheckBox -Property @{
		UseVisualStyleBackColor = $True
		Location       = '582,525'
		Height         = 22
		Width          = 510
		Text           = $lang.DeleteAllUser
		Checked        = $true
	}
	$GUIUWPRefresh     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "580,555"
		Height         = 36
		Width          = 515
		add_Click      = { RefreshUWPList }
		Text           = $lang.Refresh
	}
	$GUIUWPOK          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "580,595"
		Height         = 36
		Width          = 515
		add_Click      = $GUIUWPOKClick
		Text           = $lang.OK
	}
	$GUIUWPCanel       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "580,635"
		Height         = 36
		Width          = 515
		add_Click      = $GUIUWPCanelClick
		Text           = $lang.Cancel
	}
	$GUIUWP.controls.AddRange((
		$GUIUWPPanelTitle,
		$GUIUWPPanel,
		$GUIUWPDefaultTitle,
		$GUIUWPRelyPanel,
		$GUIUWPOtherTips,
		$GUIUWPPreventsApps,
		$GUIUWPSuggestedContent,
		$GUIUWPCloseStoreAuto,
		$GUIUWPPreventsSuggestApps,
		$GUIUWPSuggestionsDevice,
		$GUIUWPAllUser,
		$GUIUWPRefresh,
		$GUIUWPOK,
		$GUIUWPCanel
	))

	RefreshUWPList

	$GUIUWPAllSelClick = {
		$GUIUWPPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIUWPAllClearClick = {
		$GUIUWPPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIUWPMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIUWPMenu.Items.Add($lang.AllSel).add_Click($GUIUWPAllSelClick)
	$GUIUWPMenu.Items.Add($lang.AllClear).add_Click($GUIUWPAllClearClick)
	$GUIUWPPanel.ContextMenuStrip = $GUIUWPMenu

	$GUIUWPRelyAllSelClick = {
		$GUIUWPRelyPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIUWPRelyAllClearClick = {
		$GUIUWPRelyPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIUWPRelyMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIUWPRelyMenu.Items.Add($lang.AllSel).add_Click($GUIUWPRelyAllSelClick)
	$GUIUWPRelyMenu.Items.Add($lang.AllClear).add_Click($GUIUWPRelyAllClearClick)
	$GUIUWPRelyPanel.ContextMenuStrip = $GUIUWPRelyMenu

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIUWP.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIUWP.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$GUIUWP.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$GUIUWP.FormBorderStyle = 'Fixed3D'
	$GUIUWP.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

Export-ModuleMember -Function * -Alias *