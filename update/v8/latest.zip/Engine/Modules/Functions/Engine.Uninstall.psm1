﻿<#
 .Synopsis
  Uninstall

 .Description
  Uninstall Feature Modules
#>

<#
	.Uninstall the user interface
	.卸载用户界面
#>
Function Uninstall
{
	Logo -Title "$($lang.Delete) $($lang.MainHisName)"
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIUninstallAllSelClick = {
		$GUIUninstallPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true }
		}
	}
	$GUIUninstallAllClearClick = {
		$GUIUninstallPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false }
		}
	}
	$GUIUninstallCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIUninstall.Close()
	}
	$GUIUninstallOKClick = {
		$GUIUninstall.Hide()
		$Global:QUIT = $true
		if ($GUIUninstallAllIcon.Checked) {
			$syspin   = "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\syspin")\syspin.exe"

			Write-Host "   $($lang.Delete) $($lang.Redundant)" -ForegroundColor Green
			Write-Host "   - $($lang.Delete) $env:USERPROFILE\Desktop\$($lang.MainHisName).lnk"
			Remove-Item -Path "$env:USERPROFILE\Desktop\Bundled Solutions.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$env:USERPROFILE\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue
			Write-Host "   - $($lang.Delete) $env:SystemDrive\Users\Public\Desktop\$($lang.MainHisName).lnk"
			Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\Bundled Solutions.lnk" -ErrorAction SilentlyContinue
			Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue

			$StartMenu = "$env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs\$($Global:UniqueID)'s Solutions"
			Write-Host "   - $($lang.Delete) $($StartMenu)`n"
			RemoveTree -Path $StartMenu

			if (Test-Path $syspin -PathType Leaf) {
				Start-Process -FilePath $syspin -ArgumentList """$StartMenu\- $($lang.Mainpage) -.lnk"" ""51394""" -Wait -WindowStyle Hidden
			}
		}
		if ($GUIUninstallDeskMenu.Checked) {
			SignupDeskMenu -Del
		}
		if ($GUIUninstallExclude.Checked) {
			Write-Host "   $($lang.Delete) $($lang.Exclude) ( $($Global:UniqueMainFolder) )`n" -ForegroundColor Green
			Remove-MpPreference -ExclusionPath "$($Global:UniqueMainFolder)"
		}
		if ($GUIUninstallRestricted.Checked) {
			Write-Host "   $($lang.Restricted)`n" -ForegroundColor Green
			Set-ExecutionPolicy -ExecutionPolicy Restricted -Force -ErrorAction SilentlyContinue
		}
		if ($GUIUninstallNextDelete.Checked) {
			<#
				.In order to prevent the solution from being unable to be cleaned up, the next time you log in, execute it again
				.为了防止无法清理解决方案，下次登录时，再次执行
			#>
			Write-Host "   $($lang.NextDelete)`n" -ForegroundColor Green
			$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
			$regKey = "Clear $($Global:UniqueID) Folder"
			$regValue = "cmd.exe /c rd /s /q ""$($Global:UniqueMainFolder)"""
			if ((Test-Path $regPath)) {
				New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
			} else {
				New-Item -Path $regPath -Force | Out-Null
				New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
			}
		}
		if ($GUIUninstallCleanAll.Checked) {
			Write-Host "   $($lang.Delete) $($lang.MainHisName) ( $($Global:UniqueMainFolder) )`n" -ForegroundColor Green
			RemoveTree -Path "$($Global:UniqueMainFolder)"
		}
		$GUIUninstall.Close()
	}
	$GUIUninstall      = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = "$($lang.Delete) $($lang.MainHisName)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUIUninstallPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$GUIUninstallAllIcon = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Delete) $($lang.Redundant)"
		Checked        = $true
	}
	$GUIUninstallDeskMenu = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Delete) $($lang.DeskMenu) ( $($Global:UniqueID)'s Solutions )"
		Checked        = $true
	}
	$GUIUninstallExclude = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Delete) $($lang.Exclude) ( $($Global:UniqueMainFolder) )"
		Checked        = $true
	}
	$GUIUninstallRestricted = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = $lang.Restricted
		Checked        = $true
	}
	$GUIUninstallNextDelete = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = $lang.NextDelete
		Checked        = $true
	}
	$GUIUninstallCleanAll = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Delete) $($lang.MainHisName)"
		Checked        = $true
	}
	$GUIUninstallOK    = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "10,482"
		Height         = 36
		Width          = 202
		add_Click      = $GUIUninstallOKClick
		Text           = $lang.OK
	}
	$GUIUninstallCanel = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "218,482"
		Height         = 36
		Width          = 202
		add_Click      = $GUIUninstallCanelClick
		Text           = $lang.Cancel
	}
	$GUIUninstall.controls.AddRange((
		$GUIUninstallPanel,
		$GUIUninstallOK,
		$GUIUninstallCanel
	))
	$GUIUninstallPanel.controls.AddRange((
		$GUIUninstallAllIcon,
		$GUIUninstallDeskMenu,
		$GUIUninstallExclude,
		$GUIUninstallRestricted,
		$GUIUninstallNextDelete,
		$GUIUninstallCleanAll
	))

	$GUIUninstallMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIUninstallMenu.Items.Add($lang.AllSel).add_Click($GUIUninstallAllSelClick)
	$GUIUninstallMenu.Items.Add($lang.AllClear).add_Click($GUIUninstallAllClearClick)
	$GUIUninstall.ContextMenuStrip = $GUIUninstallMenu

	$GUIUninstall.FormBorderStyle = "Fixed3D"
	$GUIUninstall.ShowDialog() | Out-Null
}

Export-ModuleMember -Function "Uninstall"