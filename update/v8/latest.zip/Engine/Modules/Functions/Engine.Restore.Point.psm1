﻿<#
 .Synopsis
  Restore point

 .Description
  Restore point Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Restore point user interface
	.还原点用户界面
#>
Function RestorePointGUI
{
	param
	(
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.RestorePoint)
	Write-Host "   $($lang.RestorePoint)`n   ---------------------------------------------------"

	$Path = "HKCU:\SOFTWARE\$($Global:UniqueID)\Engine"
	if (-not (Test-Path $Path)) {
		New-Item -Path $Path -Force -ErrorAction SilentlyContinue | Out-Null
	}

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIRPointCanelClick = {
		if ($GUIRPointNoReminders.Checked) {
			New-ItemProperty -Path $Path -Name "RestorePointPrompt" -Value "True" -PropertyType string -Force | Out-Null
		} else {
			New-ItemProperty -Path $Path -Name "RestorePointPrompt" -Value "False" -PropertyType string -Force | Out-Null
		}
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIRPoint.Close()
	}
	$GUIRPointOKClick = {
		$GUIRPoint.Hide()
		if ($GUIRPointCreate.Checked) { RestorePointCreate }
		if ($GUIRPointNoReminders.Checked) {
			New-ItemProperty -Path $Path -Name "RestorePointPrompt" -Value "True" -PropertyType string -Force | Out-Null
		} else {
			New-ItemProperty -Path $Path -Name "RestorePointPrompt" -Value "False" -PropertyType string -Force | Out-Null
		}
		$GUIRPoint.Close()
	}
	$GUIRPoint         = New-Object system.Windows.Forms.Form -Property @{
		AutoScaleMode  = 2
		Height         = 720
		Width          = 550
		Text           = $($lang.RestorePoint)
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUIRPointCreate   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 508
		Text           = "$($lang.RestorePointCreate)"
		Location       = "12,10"
		Checked        = $true
	}
	$GUIRPointCreateTips = New-Object System.Windows.Forms.Label -Property @{
		Height         = 100
		Width          = 492
		Text           = $lang.RestorePointCreateTips
		Location       = '27,38'
	}
	$GUIRPointNoReminders = New-Object System.Windows.Forms.Checkbox -Property @{
		Height         = 22
		Width          = 508
		Text           = $lang.RestorePointNoReminders
		Location       = "12,565"
	}
	$GUIRPointOK       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,595"
		Height         = 36
		Width          = 515
		add_Click      = $GUIRPointOKClick
		Text           = $lang.OK
	}
	$GUIRPointCanel    = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,635"
		Height         = 36
		Width          = 515
		add_Click      = $GUIRPointCanelClick
		Text           = $lang.Cancel
	}
	$GUIRPoint.controls.AddRange((
		$GUIRPointCreate,
		$GUIRPointCreateTips,
		$GUIRPointNoReminders,
		$GUIRPointOK,
		$GUIRPointCanel
	))

	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Engine" -Name "RestorePointPrompt" -ErrorAction SilentlyContinue) {
		$GetRestorePointPrompt = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Engine" -Name "RestorePointPrompt"
		switch ($GetRestorePointPrompt) {
			"True" { $GUIRPointNoReminders.Checked = $True }
			"False" { $GUIRPointNoReminders.Checked = $False }
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIRPoint.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIRPoint.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$GUIRPoint.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$GUIRPoint.FormBorderStyle = 'Fixed3D'
	$GUIRPoint.ShowDialog() | Out-Null
}

<#
	.Create a system restore
	.创建系统还原
#>
Function RestorePointCreate
{
	Enable-ComputerRestore -drive $env:SystemDrive -ErrorAction SilentlyContinue
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name 'SystemRestorePointCreationFrequency' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Checkpoint-Computer -description "$($Global:UniqueID)" -restorepointtype "Modify_Settings" -ErrorAction SilentlyContinue
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name 'SystemRestorePointCreationFrequency' -Value 1440 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Disable-ComputerRestore -Drive $env:SystemDrive -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Export-ModuleMember -Function * -Alias *