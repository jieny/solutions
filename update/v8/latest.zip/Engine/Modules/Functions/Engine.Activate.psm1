﻿<#
 .Synopsis
  Activate

 .Description
  Activate Feature Modules
#>

<#
	.Active software list
	.激活软件列表
#>
$ActivateApp = @(
	("KMSpico",
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Queue,
	 $env:SystemDrive,
	 "$($Global:UniqueID)\10",
	 "https://KMSpico-setup.exe",
	 "",
	 "",
	 "KMSpico*",
	 "/silent",
	 "6"),
	($lang.CloudMoe,
	 [Status]::Disable,
	 [Action]::Install,
	 [Mode]::Queue,
	 $env:SystemDrive,
	 "$($Global:UniqueID)\10",
	 "https://github.com/TGSAN/CMWTAT_Digital_Edition/raw/master/CMWTAT_Digital_Release_2_5_0_0.exe",
	 "",
	 "",
	 "CMWTAT*",
	 "-a -e -h",
	 "")
)

<#
	.Activate the system warning interface
	.激活系统警告界面
#>
Function ActivatePact
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	<#
		.Get the current background color
		.获取当前背景颜色
	#>
	$DefaultBackground = (Get-Host).UI.RawUI.BackgroundColor
	$DefaultForeground = (Get-Host).UI.RawUI.ForegroundColor
	$Host.UI.RawUI.BackgroundColor = 'DarkRed'
	$Host.UI.RawUI.ForegroundColor = 'White'

	Logo -Title $($lang.Warning)
	Write-Host "   $($lang.Warning)
   ---------------------------------------------------
   $($lang.WarningMsg)`n"

	$caption = $lang.AcceptTerms
	$message = $lang.AcceptTermsYN
	$choices = @("&Yes","&No")
	$choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription]
	$choices | ForEach-Object { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))}
	$prompt = $Host.ui.PromptForChoice($caption, $message, $choicedesc, 1)
	$Host.UI.RawUI.BackgroundColor = $DefaultBackground
	$Host.UI.RawUI.ForegroundColor = $DefaultForeground
	Switch ($prompt)
	{
		0 {
			if ($Force) {
				Activate -Force
				break
			} else {
				Activate
				ToMainpage -wait 6
			}
		}
		1 {
			if ($Force) {
				break
			} else {
				ToMainpage -wait 2
			}
		}
	}
}


<#
	.Activate the system user interface
	.激活系统用户界面
#>
Function Activate
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.ActivationKit)
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIActivateCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIActivate.Close()
	}
	$GUIActivateOKClick = {
		$GUIActivate.Hide()
		$GUIActivatePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Checked) {
					StartInstallSoftware -appname $ActivateApp[$_.Tag][0] -status "Enable" -act $ActivateApp[$_.Tag][2] -mode $ActivateApp[$_.Tag][3] -todisk $ActivateApp[$_.Tag][4] -structure $ActivateApp[$_.Tag][5] -url $ActivateApp[$_.Tag][6] -urlAMD64 $ActivateApp[$_.Tag][7] -urlarm64 $ActivateApp[$_.Tag][8] -filename $ActivateApp[$_.Tag][9] -param $ActivateApp[$_.Tag][10] -method $ActivateApp[$_.Tag][11]
				}
			}
		}
		$GUIActivate.Close()
	}
	$GUIActivate       = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = $lang.ActivationKit
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUIActivatePanel  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$GUIActivateOK     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "10,482"
		Height         = 36
		Width          = 202
		add_Click      = $GUIActivateOKClick
		Text           = $lang.OK
	}
	$GUIActivateCanel  = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "218,482"
		Height         = 36
		Width          = 202
		add_Click      = $GUIActivateCanelClick
		Text           = $lang.Cancel
	}
	$GUIActivate.controls.AddRange((
		$GUIActivatePanel,
		$GUIActivateOK,
		$GUIActivateCanel
	))

	for ($i=0; $i -lt $ActivateApp.Count; $i++) {
		$CheckBox  = New-Object System.Windows.Forms.RadioButton -Property @{
			Height = 28
			Width  = 405
			Text   = $ActivateApp[$i][0]
			Tag    = $i
		}

		if ($ActivateApp[$i][1] -like "Enable") {
			$CheckBox.Checked = $true
		} else {
			$CheckBox.Checked = $false
		}
		$GUIActivatePanel.controls.AddRange($CheckBox)		
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIActivate.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIActivate.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$GUIActivate.FormBorderStyle = 'Fixed3D'
	$GUIActivate.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

Enum Status
{
	Enable
	Disable
}

Enum Mode
{
	Wait
	Fast
	Queue
}

Enum Action
{
	Install
	NoInst
	To
	Unzip
}

Export-ModuleMember -Function "ActivatePact"
Export-ModuleMember -Function "Activate"