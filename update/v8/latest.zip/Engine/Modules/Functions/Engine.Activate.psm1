﻿<#
 .Synopsis
  Activate

 .Description
  Activate Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Active software list
	.激活软件列表

	Usage:
	用法：

       Only one URL address must be added in front of the, number, multiple addresses do not need to be added, example:
       只有一个 URL 地址必须在前面添加 , 号，多地址不用添加，示例：

	$PreServerList = @(
		,("HEUKMS",
	      "")
	)
#>
$ActivateApp = @(
	,("HEUKMS",
	 [Status]::Enable,
	 [Action]::Install,
	 [Mode]::Queue,
	 $env:SystemDrive,
	 "$($Global:UniqueID)\10",
	 "HEU",
	 "",
	 "",
	 "",
	 "HEUKMS*",
	 "/kwi /kof /ren /dig /nologo",
	 "HEUKMS",
	 "")
)

<#
	.Activate the system warning interface
	.激活系统警告界面
#>
Function Activate
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.ActivationKit)
	Write-Host "   $($lang.ActivationKit)`n   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIActivateSelectClick = {
		$GUIActivateErrorMsg.Text = ""
		if ($GUIActivateSelect.Checked) {
			$GUIActivatePanel.Enabled = $True
			$GUIActivateTips.BackColor = "#FFFFFF"
			$GUIActivate.BackColor = "#FFFFFF"
		} else {
			$GUIActivatePanel.Enabled = $False
			$GUIActivateTips.BackColor = "#FFB6C1"
			$GUIActivate.BackColor = "#FFB6C1"
		}
	}
	$GUIActivateCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIActivate.Close()
	}
	$GUIActivateOKClick = {
		if ($GUIActivateSelect.Checked) {
			$FlagsCheckSelect = $False
			$GUIActivatePanel.Controls | ForEach-Object {
				if ($_ -is [System.Windows.Forms.RadioButton]) {
					if ($_.Checked) {
						$FlagsCheckSelect = $True
					}
				}
			}
			if ($FlagsCheckSelect) {
				$GUIActivate.Hide()
				$GUIActivatePanel.Controls | ForEach-Object {
					if ($_ -is [System.Windows.Forms.RadioButton]) {
						if ($_.Checked) {
							InstallProcess -appname $ActivateApp[$_.Tag][0] -status "Enable" -act $ActivateApp[$_.Tag][2] -mode $ActivateApp[$_.Tag][3] -todisk $ActivateApp[$_.Tag][4] -structure $ActivateApp[$_.Tag][5] -pwd $ActivateApp[$_.Tag][6] -url $ActivateApp[$_.Tag][7] -urlAMD64 $ActivateApp[$_.Tag][8] -urlarm64 $ActivateApp[$_.Tag][9] -filename $ActivateApp[$_.Tag][10] -param $ActivateApp[$_.Tag][11] -Before $ActivateApp[$_.Tag][12] -After $ActivateApp[$_.Tag][13]
						}
					}
				}
				$GUIActivate.Close()
			} else {
				$GUIActivateErrorMsg.Text = $lang.ActiveToolsNoSelect
			}
		} else {
			$GUIActivateErrorMsg.Text = $lang.AcceptTermsNoSelect
		}
	}
	$GUIActivate       = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 1015
		Text           = $lang.ActivationKit
		TopMost        = $False
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#FFB6C1"
	}
	$GUIActivateWarning = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 395
		Text           = $lang.Warning
		Location       = '10,10'
	}
	$GUIActivateTips   = New-Object System.Windows.Forms.RichTextBox -Property @{
		Height         = 555
		Width          = 380
		BorderStyle    = 0
		Location       = "26,32"
		BackColor      = "#FFB6C1"
		ReadOnly       = $True
		Text           = $lang.WarningMsg
	}
	$GUIActivateSelect = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 395
		Text           = $lang.AcceptTerms
		Location       = '16,645'
		add_Click      = $GUIActivateSelectClick
	}
	$GUIActivatePanelTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 510
		Text           = $lang.ActivationKit
		Location       = '472,10'
	}
	$GUIActivatePanel  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 505
		Width          = 510
		Location       = '472,34'
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 0
		Enabled        = $False
	}	
	$GUIActivateErrorMsg = New-Object system.Windows.Forms.Label -Property @{
		Location       = "472,570"
		Height         = 22
		Width          = 408
		Text           = ""
	}
	$GUIActivateOK     = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "472,595"
		Height         = 36
		Width          = 515
		add_Click      = $GUIActivateOKClick
		Text           = $lang.OK
	}
	$GUIActivateCanel  = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "472,635"
		Height         = 36
		Width          = 515
		add_Click      = $GUIActivateCanelClick
		Text           = $lang.Cancel
	}
	$GUIActivate.controls.AddRange((
		$GUIActivateWarning,
		$GUIActivateTips,
		$GUIActivateSelect,
		$GUIActivatePanelTitle,
		$GUIActivatePanel,
		$GUIActivateErrorMsg,
		$GUIActivateOK,
		$GUIActivateCanel
	))

	for ($i=0; $i -lt $ActivateApp.Count; $i++) {
		$CheckBox  = New-Object System.Windows.Forms.RadioButton -Property @{
			Height = 22
			Width  = 470
			Text   = $ActivateApp[$i][0]
			Tag    = $i
		}

		if ($ActivateApp[$i][1] -like "Enable") {
			$CheckBox.Checked = $true
		} else {
			$CheckBox.Checked = $false
		}
		$GUIActivatePanel.controls.AddRange($CheckBox)		
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIActivate.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIActivate.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$GUIActivate.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$GUIActivate.FormBorderStyle = 'Fixed3D'
	$GUIActivate.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

Enum Status
{
	Enable
	Disable
}

Enum Mode
{
	Wait
	Fast
	Queue
}

Enum Action
{
	Install
	NoInst
	To
	Unzip
}

Export-ModuleMember -Variable ActivateApp
Export-ModuleMember -Function * -Alias *