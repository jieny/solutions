﻿<#
 .Synopsis
  Optimize the system

 .Description
  Optimize the system Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Optimize the system user interface
	.优化系统用户界面
#>
Function Optimization
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title "$($lang.Optimize) $($lang.System)"
	Write-Host "   $($lang.Optimize) $($lang.System)`n   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIOptOSClick = {
		if ($GUIOptOS.Checked) {
			$GUIOptOSPanel.Enabled = $True
		} else {
			$GUIOptOSPanel.Enabled = $False
		}
	}
	$GUIExplorerClick = {
		if ($GUIExplorer.Checked) {
			$GUIExplorerPanel.Enabled = $True
		} else {
			$GUIExplorerPanel.Enabled = $False
		}
	}
	$GUIRightMenuClick = {
		if ($GUIRightMenu.Checked) {
			$GUIRightMenuPanel.Enabled = $True
		} else {
			$GUIRightMenuPanel.Enabled = $False
		}
	}
	$GUIGameBarClick = {
		if ($GUIGameBar.Checked) {
			$GUIGUIGameBarPanel.Enabled = $True
		} else {
			$GUIGUIGameBarPanel.Enabled = $False
		}
	}

	$GUIStartClick = {
		if ($GUIStart.Checked) {
			$GUIStartPanel.Enabled = $True
		} else {
			$GUIStartPanel.Enabled = $False
		}
	}
	$GUIPrivateClick = {
		if ($GUIPrivate.Checked) {
			$GUIPrivatePanel.Enabled = $True
		} else {
			$GUIPrivatePanel.Enabled = $False
		}
	}
	$GUIOptNotificationClick = {
		if ($GUIOptNotification.Checked) {
			$GUIOptNotificationPanel.Enabled = $True
		} else {
			$GUIOptNotificationPanel.Enabled = $False
		}
	}
	$GUIOptPagingSizeClick = {
		if ($GUIOptPagingSize.Checked) {
			$GUIOptPagingSizePanel.Enabled = $True
		} else {
			$GUIOptPagingSizePanel.Enabled = $False
		}
	}
	$GUIOptOtherClick = {
		if ($GUIOptOther.Checked) {
			$GUIOptOtherPanel.Enabled = $True
		} else {
			$GUIOptOtherPanel.Enabled = $False
		}
	}
	$GUIOptClearClick = {
		if ($GUIOptClear.Checked) {
			$GUIOptClearPanel.Enabled = $True
		} else {
			$GUIOptClearPanel.Enabled = $False
		}
	}
	$GUIOptCanelClick = { 
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIOpt.Close()
	}
	$GUIOptRestoreClick = {
		$GUIOpt.Hide()
		if ($GUIOptOS.Enabled) {
			if ($GUIOptOS.Checked) {
				if ($GUIOptTPM.Checked) { Win11TPM -Enable }
				if ($GUIOptKeepSpace.Checked) { KeepSpace -Enable }
				if ($GUIOptHibernation.Checked) { Hibernation -Enable }
				if ($GUIOptPowerSupply.Checked) { PowerSupply -Restore }
				if ($GUIOptAppRestartScreen.Checked) { AppRestartScreen -Enable }
				if ($GUIOptNumLock.Checked) { Numlock -Disable }
				if ($GUIOptUAC.Checked)  { UACNever -Enable }
				if ($GUIOptSmartScreenApps.Checked) { SmartScreenApps -Enable }
				if ($GUIOptSmartScreenSafe.Checked) { SmartScreenSafe -Enable }
				if ($GUIOptEasyAccessKeyboard.Checked) { EasyAccessKeyboard -Enable }
				if ($GUIOptMaintain.Checked) { Maintain -Enable }
				if ($GUIOptExperience.Checked) { Experience -Enable }
				if ($GUIOptDefragmentation.Checked) { Defragmentation -Enable }
				if ($GUIOptCompatibility.Checked) { Compatibility -Enable }
				if ($GUIOptAnimationEffects.Checked) { AnimationEffects -Restore }
				if ($GUIOptQOS.Checked) { QOS -Enable }
				if ($GUIOptNetworkTuning.Checked) { NetworkTuning -Enable }
				if ($GUIOptECN.Checked) { ECN -Enable }
				if ($GUIOptErrorRecovery.Checked) { ErrorRecovery -Enable }
				if ($GUIOptDEP.Checked) { DEPPAE -Enable }
				if ($GUIOptPowerFailure.Checked) { PowerFailure -Enable }
				if ($GUIOptIEAutoSet.Checked) { AutoDetect -Enable }
				if ($GUIOptScheduledTasks.Checked) { ScheduledTasks -Restore }
				if ($GUIOptPwdUnlimited.Checked) { PwdUnlimited -Enable }
				if ($GUIOptRAM.Checked) { RAM -Enable }
				if ($GUIOptStorageSense.Checked) { StorageSense -Enable }
				if ($GUIOptDelivery.Checked) { Delivery -Enable }
				if ($GUIOptPhotoPreview.Checked) { PhotoPreview -Disable }
				if ($GUIOptProtected.Checked) { Protected -Enable }
				if ($GUIOptErrorReporting.Checked) { ErrorReporting -Enable }
				if ($GUIOptF8BootMenu.Checked) { F8BootMenu -Enable }
				if ($GUIOptSSD.Checked) { SSD -Enable }
				if ($GUIOptMemoryCompression.Checked) { MemoryCompression -Enable }
				if ($GUIOptPrelaunch.Checked) { Prelaunch -Enable }
			}
		}

		<#
			.资源管理器
		#>
		if ($GUIExplorer.Enabled) {
			if ($GUIExplorer.Checked) {
				if ($GUIOptToThisPC.Checked) { ExplorerOpenTo -QuickAccess }
				if ($GUIOptAeroShake.Checked) {
					if ($GUIOptSyncAllUser.Checked) {
						AeroShake -Enable -AllUser
					} else {
						AeroShake -Enable
					}
				}
				if ($GUIOptFileExtensions.Checked) { FileExtensions -Hide }
				if ($GUIOptSafetyWarnings.Checked) { SafetyWarnings -Enable }
				if ($GUIOptFileTransfer.Checked) { FileTransferDialog -Simple }
				if ($GUIOptNavShowAll.Checked) { NavShowAll -Disable }
				if ($GUIOptAutoplay.Checked) { Autoplay -Enable }
				if ($GUIOptAutorun.Checked) { Autorun -Enable }
				if ($GUIOptQuickAccessFiles.Checked) { QuickAccessFiles -Show }
				if ($GUIOptQuickAccessFolders.Checked) { QuickAccessFolders -Show }
				if ($GUIOptShortcutArrow.Checked) { ShortcutArrow -Enable }
				if ($GUIOptThisPCDesktop.Checked) { ThisPCDesktop -Enable }
				if ($GUIOptThisPCDocument.Checked) { ThisPCDocument -Enable }
				if ($GUIOptThisPCDownload.Checked) { ThisPCDownload -Enable }
				if ($GUIOptThisPCMusic.Checked) { ThisPCMusic -Enable }
				if ($GUIOptThisPCPicture.Checked) { ThisPCPicture -Enable }
				if ($GUIOptThisPCVideo.Checked) { ThisPCVideo -Enable }
				if ($GUIOptThisPC3D.Checked) { ThisPC3D -Enable }
			}
		}

		<#
			.Right click menu
			.右键菜单
		#>
		if ($GUIRightMenu.Enabled) {
			if ($GUIRightMenu.Checked) {
				if ($GUIOptClassicModern.Checked) { Win11ContextMenu -Modern }
				if ($GUIOptOwnership.Checked) { TakeOwnership -Remove }
				if ($GUIOptCopyPath.Checked) { CopyPath -Remove }
				if ($GUIOptMultipleIncrease.Checked) { MultipleIncrease -Enable }
			}
		}

		<#
			.Start menu and taskbar
			.开始菜单和任务栏
		#>
		if ($GUIStart.Enabled) {
			if ($GUIStart.Checked) {
				if ($GUIOptSearchBox.Checked) {
					SearchBox -SearchBox
					RestartExplorer
				}
				if ($GUIOptMergeTaskbarNever.Checked) { MergeTaskbarNever -Disable }
				if ($GUIOptNotificationAlways.Checked) { NotificationAlways -Disable }
				if ($GUIOptCortana.Checked) {
					Cortana -Enable
					RestartExplorer
				}
				if ($GUIOptTaskView.Checked) { TaskView -Show }
			}
		}

		<#
			.Game Bar
		#>
		if ($GUIGameBar.Enabled) {
			if ($GUIGameBar.Checked) {
				if ($GUIOptGamebar.Checked) { Gamebar -Enable }
				if ($GUIOptGameMode.Checked) { GameMode -Enable }
				if ($GUIOptGameDVRAndBar.Checked) { GameDVRAndBar -Enable }
			}
		}

		<#
			.隐私类
		#>
		if ($GUIPrivate.Enabled) {
			if ($GUIPrivate.Checked) {
				if ($GUIOptPrivacyVoiceTyping.Checked) { PrivacyVoiceTyping -Enabled }
				if ($GUIOptPrivacyContactsSpeech.Checked) { PrivacyContactsSpeech -Enabled }
				if ($GUIOptPrivacyLanguageOptOut.Checked) { PrivacyLanguageOptOut -Enabled }
				if ($GUIOptPrivacyAds.Checked) { PrivacyAds -Enabled }
				if ($GUIOptLocatonAware.Checked) { PrivacyLocatonAware -Enabled }
				if ($GUIOptPrivacySetSync.Checked) { PrivacySetSync -Enabled }
				if ($GUIOptInkingTyping.Checked) { PrivacyInkingTyping -Enabled }
				if ($GUIOptShareUnpairedDevices.Checked) { PrivacyShareUnpairedDevices -Enabled }
				if ($GUIOptLocationSensor.Checked) { PrivacyLocationSensor -Enabled }
				if ($GUIOptBiometrics.Checked) { PrivacyBiometrics -Enabled }
				if ($GUIOptCompatibleTelemetry.Checked) { PrivacyCompatibleTelemetry -Enabled }
				if ($GUIOptDiagnosticData.Checked) { PrivacyDiagnosticData -Enabled }
				if ($GUIOptTailoredExperiences.Checked) { PrivacyTailoredExperiences -Enabled }
				if ($GUIOptFeedbackNotifications.Checked) { PrivacyFeedbackNotifications -Enabled }
				if ($GUIOptLocationTracking.Checked) { PrivacyLocationTracking -Enabled }
				if ($GUIOptExperiencesTelemetry.Checked) { PrivacyExperiencesTelemetry -Enabled }
				if ($GUIOptPrivacyBackgroundAccess.Checked) { PrivacyBackgroundAccess -Enabled }
				if ($GUIOptPrivacyDefenderSurvey.Checked) { PrivacyDefenderSurvey -Enabled }
				if ($GUIOptTimelineTime.Checked) { TimelineTime -Enable }
				if ($GUIOptCollectActivity.Checked) { CollectActivity -Enable }
			}
		}

		<#
			.系统盘分页大小
		#>
		if ($GUIOptPagingSize.Enabled) {
			if ($GUIOptPagingSize.Checked) {
				PagingSize -Disable
			}
		}

		<#
			.通知中心
		#>
		if ($GUIOptNotification.Enabled) {
			if ($GUIOptNotification.Checked) {
				NotificationCenter -Restore
			}
		}

		if ($GUIOptTaskBar.Checked) { ResetTaskBar }
		if ($GUIOptResetDesk.Checked) { ResetDesktop }
		gpupdate /force | out-null
		$GUIOpt.Close()
	}
	$GUIOptOKClick = {
		$GUIOpt.Hide()

		if ($GUIOptOS.Enabled) {
			if ($GUIOptOS.Checked) {
				if ($GUIOptTPM.Checked) { Win11TPM -Disable }
				if ($GUIOptKeepSpace.Checked) { KeepSpace -Disable }
				if ($GUIOptHibernation.Checked) { Hibernation -Disable }
				if ($GUIOptPowerSupply.Checked) { PowerSupply -Optimize }
				if ($GUIOptAppRestartScreen.Checked) { AppRestartScreen -Disable }
				if ($GUIOptNumLock.Checked) { Numlock -Enable }
				if ($GUIOptUAC.Checked) { UACNever -Disable }
				if ($GUIOptSmartScreenApps.Checked) { SmartScreenApps -Disable }
				if ($GUIOptSmartScreenSafe.Checked) { SmartScreenSafe -Disable }
				if ($GUIOptEasyAccessKeyboard.Checked) { EasyAccessKeyboard -Disable }
				if ($GUIOptMaintain.Checked) { Maintain -Disable }
				if ($GUIOptExperience.Checked) { Experience -Disable }
				if ($GUIOptDefragmentation.Checked) { Defragmentation -Disable }
				if ($GUIOptCompatibility.Checked) { Compatibility -Disable }
				if ($GUIOptAnimationEffects.Checked) { AnimationEffects -Optimize }
				if ($GUIOptQOS.Checked) { QOS -Disable }
				if ($GUIOptNetworkTuning.Checked) { NetworkTuning -Disable }
				if ($GUIOptECN.Checked) { ECN -Disable }
				if ($GUIOptErrorRecovery.Checked) { ErrorRecovery -Disable }
				if ($GUIOptDEP.Checked) { DEPPAE -Disable }
				if ($GUIOptPowerFailure.Checked) { PowerFailure -Disable }
				if ($GUIOptIEAutoSet.Checked) { AutoDetect -Disable }
				if ($GUIOptIEProxy.Checked) { IEProxy }
				if ($GUIOptScheduledTasks.Checked) { ScheduledTasks -Disable }
				if ($GUIOptPwdUnlimited.Checked) { PwdUnlimited -Disable }
				if ($GUIOptRAM.Checked) { RAM -Disable }
				if ($GUIOptStorageSense.Checked) { StorageSense -Disable }
				if ($GUIOptDelivery.Checked) { Delivery -Disable }
				if ($GUIOptPhotoPreview.Checked) { PhotoPreview -Enable }
				if ($GUIOptProtected.Checked) { Protected -Disable }
				if ($GUIOptErrorReporting.Checked) { ErrorReporting -Disable }
				if ($GUIOptF8BootMenu.Checked) { F8BootMenu -Disable }
				if ($GUIOptSSD.Checked) { SSD -Disable }
				if ($GUIOptMemoryCompression.Checked) { MemoryCompression -Disable }
				if ($GUIOptPrelaunch.Checked) { Prelaunch -Disable }
			}
		}

		<#
			.Resource manager
			.资源管理器
		#>
		if ($GUIExplorer.Enabled) {
			if ($GUIExplorer.Checked) {
				if ($GUIOptToThisPC.Checked) { ExplorerOpenTo -ThisPC }
				if ($GUIOptAeroShake.Checked) {
					if ($GUIOptSyncAllUser.Checked) {
						AeroShake -Disable -AllUser
					} else {
						AeroShake -Disable
					}
				}
				if ($GUIOptFileExtensions.Checked) { FileExtensions -Show }
				if ($GUIOptSafetyWarnings.Checked) { SafetyWarnings -Disable }
				if ($GUIOptFileTransfer.Checked) { FileTransferDialog -Detailed }
				if ($GUIOptNavShowAll.Checked) { NavShowAll -Enable }
				if ($GUIOptAutoplay.Checked) { Autoplay -Disable }
				if ($GUIOptAutorun.Checked) { Autorun -Disable }
				if ($GUIOptQuickAccessFiles.Checked) { QuickAccessFiles -Hide }
				if ($GUIOptQuickAccessFolders.Checked) { QuickAccessFolders -Hide }
				if ($GUIOptShortcutArrow.Checked) { ShortcutArrow -Disable }
				if ($GUIOptThisPCDesktop.Checked) { ThisPCDesktop -Disable }
				if ($GUIOptThisPCDocument.Checked) { ThisPCDocument -Disable }
				if ($GUIOptThisPCDownload.Checked) { ThisPCDownload -Disable }
				if ($GUIOptThisPCMusic.Checked) { ThisPCMusic -Disable }
				if ($GUIOptThisPCPicture.Checked) { ThisPCPicture -Disable }
				if ($GUIOptThisPCVideo.Checked) { ThisPCVideo -Disable }
				if ($GUIOptThisPC3D.Checked) { ThisPC3D -Disable }
			}
		}

		<#
			.Right click menu
			.右键菜单
		#>
		if ($GUIRightMenu.Enabled) {
			if ($GUIRightMenu.Checked) {
				if ($GUIOptClassicModern.Checked) { Win11ContextMenu -Classic }
				if ($GUIOptOwnership.Checked) {
					TakeOwnership -Remove
					TakeOwnership -Add
				}
				if ($GUIOptCopyPath.Checked) {
					CopyPath -Remove
					CopyPath -Add
				}
				if ($GUIOptMultipleIncrease.Checked) { MultipleIncrease -Disable }
			}
		}
	
		<#
			.开始菜单和任务栏
		#>
		if ($GUIStart.Enabled) {
			if ($GUIStart.Checked) {
				if ($GUIOptSearchBox.Checked) {
					SearchBox -SearchIcon
					RestartExplorer
				}
				if ($GUIOptMergeTaskbarNever.Checked) { MergeTaskbarNever -Enable }
				if ($GUIOptNotificationAlways.Checked) { NotificationAlways -Enable }
				if ($GUIOptCortana.Checked) {
					Cortana -Disable
					RestartExplorer
				}
				if ($GUIOptTaskView.Checked) { TaskView -Hide }
			}
		}

		<#
			.Game Bar
		#>
		if ($GUIGameBar.Enabled) {
			if ($GUIGameBar.Checked) {
				if ($GUIOptGamebar.Checked) { Gamebar -Disable }
				if ($GUIOptGameMode.Checked) { GameMode -Disable }
				if ($GUIOptGameDVRAndBar.Checked) { GameDVRAndBar -Disable }
			}
		}

		<#
			.隐私类
		#>
		if ($GUIPrivate.Enabled) {
			if ($GUIPrivate.Checked) {
				if ($GUIOptPrivacyVoiceTyping.Checked) { PrivacyVoiceTyping -Disable }
				if ($GUIOptPrivacyContactsSpeech.Checked) { PrivacyContactsSpeech -Disable }
				if ($GUIOptPrivacyLanguageOptOut.Checked) { PrivacyLanguageOptOut -Disable }
				if ($GUIOptPrivacyAds.Checked) { PrivacyAds -Disable }
				if ($GUIOptLocatonAware.Checked) { PrivacyLocatonAware -Disable }
				if ($GUIOptPrivacySetSync.Checked) { PrivacySetSync -Disable }
				if ($GUIOptInkingTyping.Checked) { PrivacyInkingTyping -Disable }
				if ($GUIOptShareUnpairedDevices.Checked) { PrivacyShareUnpairedDevices -Disable }
				if ($GUIOptLocationSensor.Checked) { PrivacyLocationSensor -Disable }
				if ($GUIOptBiometrics.Checked) { PrivacyBiometrics -Disable }
				if ($GUIOptCompatibleTelemetry.Checked) { PrivacyCompatibleTelemetry -Disable }
				if ($GUIOptDiagnosticData.Checked) { PrivacyDiagnosticData -Disable }
				if ($GUIOptTailoredExperiences.Checked) { PrivacyTailoredExperiences -Disable }
				if ($GUIOptFeedbackNotifications.Checked) { PrivacyFeedbackNotifications -Disable }
				if ($GUIOptLocationTracking.Checked) { PrivacyLocationTracking -Disable }
				if ($GUIOptExperiencesTelemetry.Checked) { PrivacyExperiencesTelemetry -Disable }
				if ($GUIOptPrivacyBackgroundAccess.Checked) { PrivacyBackgroundAccess -Disable }
				if ($GUIOptPrivacyDefenderSurvey.Checked) { PrivacyDefenderSurvey -Disable }
				if ($GUIOptTimelineTime.Checked) { TimelineTime -Disable }
				if ($GUIOptCollectActivity.Checked) { CollectActivity -Disable }
			}
		}

		<#
			.通知中心
		#>
		if ($GUIOptNotification.Enabled) {
			if ($GUIOptNotification.Checked) {
				if ($GUIOptNotificationFull.Checked) {
					NotificationCenter -Restore
					NotificationCenter -Full
				}
				if ($GUIOptNotificationPart.Checked) {
					NotificationCenter -Restore
					NotificationCenter -Part
				}
			}
		}

		<#
			.系统盘分页大小
		#>
		if ($GUIOptPagingSize.Enabled) {
			if ($GUIOptPagingSize.Checked) {
				if ($GUIOptPagingSizeLow.Checked) { PagingSize -Enable -size 8 }
				if ($GUIOptPagingSizeHigh.Checked) { PagingSize -Enable -size 16 }
			}
		}

		<#
			.其它类
		#>
		if ($GUIOptOther.Enabled) {
			if ($GUIOptOther.Checked) {
				if ($GUIOptRDS.Checked) { RemoteDesktop }
				if ($GUIOptSMB.Checked) { SMBFileShare }
			}
		}

		<#
			.清理类
		#>
		if ($GUIOptClear.Enabled) {
			if ($GUIOptClear.Checked) {
				if ($GUIOptSendTo.Checked) { SendTo }
				if ($GUIOptCleanSystemLog.Checked) { CleanSystemLog }
				if ($GUIOptCleanSxS.Checked) { CleanSxS }
			}
		}

		if ($GUIOptTaskBar.Checked) { ResetTaskBar }
		if ($GUIOptResetDesk.Checked) { ResetDesktop }

		gpupdate /force | out-null
		$GUIOpt.Close()
	}
	$GUIOpt            = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 600
		Width          = 980
		Text           = "$($lang.Optimize) $($lang.System)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUIOptLeaf        = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 56
		Width          = 475
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 3
		Location       = '0,0'
	}

	<#
		.其它类
	#>
	$GUIOptOther       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Related)"
		Location       = '505,5'
		Checked        = $True
		add_Click      = $GUIOptOtherClick
	}
	$GUIOptOtherPanel  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 110
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
		Location       = '510,30'
	}
	$GUIOptRDS         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = $($lang.StRemote)
	}
	$GUIOptSMB         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = $($lang.StSMB)
	}
	$GUIOptSMBTips     = New-Object System.Windows.Forms.Label -Property @{
		Height         = 30
		Width          = 415
		Text           = $lang.StSMBTips
		Padding        = "15,0,15,0"
	}

	<#
		.清理类
	#>
	$GUIOptClear       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Cleanup)"
		Location       = '505,160'
		Checked        = $True
		add_Click      = $GUIOptClearClick
	}
	$GUIOptClearPanel  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 110
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
		Location       = '510,185'
	}
	$GUIOptSendTo      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = $($lang.SendTo)
		Checked        = $true
	}
	$GUIOptCleanSystemLog = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = $($lang.Logs)
		Checked        = $true
	}
	$GUIOptCleanSxS    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = $($lang.SxS)
	}

	<#
		.优化类
	#>
	$GUIOptOS          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 390
		Text           = "$($lang.Optimize)"
		Checked        = $True
		add_click      = $GUIOptOSClick
		Margin         = "2,6,0,0"
	}
	$GUIOptOSPanel     = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 235
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIOptTPM         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Close) $($lang.TPMCheck)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptKeepSpace   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Close) $($lang.KeepSpace)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptHibernation = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Close) $($lang.Hibernation)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPowerSupply = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Setting) $($lang.PowerSupply)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptAppRestartScreen = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.AppRestartScreen)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptNumLock     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Setting) $($lang.NumLock)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptUAC         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Setting) $($lang.UAC)$($lang.UACNever)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptSmartScreenApps = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.SmartScreenApps)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptSmartScreenSafe = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.SmartScreenSafe)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptEasyAccessKeyboard = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.EasyAccessKeyboard)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptMaintain    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Close) $($lang.Maintain)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptExperience  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Close) $($lang.Experience)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptDefragmentation = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Defragmentation)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptCompatibility = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Close) $($lang.Compatibility)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptAnimationEffects = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Optimize) $($lang.AnimationEffects)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptQOS         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.QOS)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptNetworkTuning = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Optimize) $($lang.NetworkTuning)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptECN         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.ECN)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptErrorRecovery = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Close) $($lang.ErrorRecovery)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptDEP         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.DEP) ( $($lang.Restart) )"
		ForeColor      = "#008000"
	}
	$GUIOptPowerFailure = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Close) $($lang.PowerFailure)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptIEAutoSet   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.IEAutoSet)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptIEProxy     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Restore) $($lang.IEProxy)"
	}
	$GUIOptScheduledTasks = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.ScheduledTasks)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPwdUnlimited = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Setting) $($lang.PwdUnlimited)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptRAM         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.RAM)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptStorageSense = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.StorageSense)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptDelivery    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Delivery)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPhotoPreview = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Enable) $($lang.PhotoPreview)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptProtected   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Protected)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptErrorReporting = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.ErrorReporting)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptF8BootMenu  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.F8BootMenu)"
		ForeColor      = "#008000"
	}
	$GUIOptSSD         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Optimize) $($lang.OptSSD)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptMemoryCompression = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.MemoryCompression)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPrelaunch   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Prelaunch)"
		Checked        = $true
		ForeColor      = "#008000"
	}

	<#
		.Context Menu
		.上下文菜单
	#>
	$GUIRightMenu      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 390
		Text           = "$($lang.ContextMenu)"
		Checked        = $True
		add_click      = $GUIRightMenuClick
		Margin         = "2,22,0,0"
	}
	$GUIRightMenuPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 110
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIOptClassicModern = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Enable) $($lang.ClassicMenu)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptOwnership   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.AddTo) $($lang.TakeOwnership)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptCopyPath    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.AddTo) $($lang.CopyPath)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptMultipleIncrease = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.MultipleIncrease)"
		Checked        = $true
		ForeColor      = "#008000"
	}

	<#
		.资源管理器
	#>
	$GUIExplorer       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 390
		Text           = "$($lang.Explorer)"
		Checked        = $True
		add_click      = $GUIExplorerClick
		Margin         = "2,22,0,0"
	}
	$GUIExplorerPanel  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 235
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIOptToThisPC   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.ExplorerTo -f $($lang.ExplorerToThisPC))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptAeroShake   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.AeroShake)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptFileExtensions = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.FileExtensions)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptSafetyWarnings = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.SafetyWarnings)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptFileTransfer = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Setting) $($lang.FileTransfer)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptNavShowAll  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.NavShowAll)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptAutoplay    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Autoplay)"
		ForeColor      = "#008000"
	}
	$GUIOptAutorun     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Autorun)"
		ForeColor      = "#008000"
	}
	$GUIOptQuickAccessFiles = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.QuickAccessFiles)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptQuickAccessFolders = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.QuickAccessFolders)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptShortcutArrow = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Delete) $($lang.ShortcutArrow)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptThisPCDesktop = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationDesktop))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptThisPCDocument = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationDocuments))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptThisPCDownload = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationDownloads))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptThisPCMusic = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationMusic))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptThisPCPicture = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationPictures))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptThisPCVideo = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationVideos))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptThisPC3D    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.ThisPCRemove -f $($lang.Location3D))"
		Checked        = $true
		ForeColor      = "#008000"
	}

	<#
		.通知中心
	#>
	$GUIOptNotification = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Notification)"
		ForeColor      = "#008000"
		Checked        = $True
		add_click      = $GUIOptNotificationClick
		Margin         = "2,22,0,0"
	}
	$GUIOptNotificationPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 56
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIOptNotificationFull = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Close) $($lang.Notification) ( $($lang.Full) )"
	}
	$GUIOptNotificationPart = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Close) $($lang.Notification) ( $($lang.Part) )"
		Checked        = $true
	}

	<#
		.系统盘分页大小
	#>
	$GUIOptPagingSize  = New-Object System.Windows.Forms.CheckBox -Property @{
		autoSize       = $true
		Text           = "$($lang.PagingSize) ( $($lang.Restart) )"
		ForeColor      = "#008000"
		Checked        = $True
		add_Click      = $GUIOptPagingSizeClick
		Margin         = "2,22,0,0"
	}
	$GUIOptPagingSizePanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 56
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIOptPagingSizeLow = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Setting) $($lang.PagingSize) (8G)"
		Checked        = $true
	}
	$GUIOptPagingSizeHigh = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Setting) $($lang.PagingSize) (16G)"
	}

	<#
		.开始菜单和任务栏
	#>
	$GUIStart          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 390
		Text           = $lang.Start
		Checked        = $True
		add_click      = $GUIStartClick
		Margin         = "2,22,0,0"
	}
	$GUIStartPanel     = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 180
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIOptSearchBox   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Setting) $($lang.SearchBox)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptMergeTaskbarNever = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Setting) $($lang.MergeTaskbarNever)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptNotificationAlways = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Setting) $($lang.NotificationAlways)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptCortana     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = $lang.Cortana
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptTaskView    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = $lang.TaskView
		Checked        = $true
		ForeColor      = "#008000"
	}

	<#
		.Gaming
		.游戏
	#>
	$GUIGameBar        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 390
		Text           = "$($lang.Gaming)"
		Checked        = $True
		add_click      = $GUIGameBarClick
		Margin         = "2,22,0,0"
	}
	$GUIGUIGameBarPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 110
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIOptGamebar     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Gamebar)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptGameMode    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.GameMode)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptGameDVRAndBar= New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.GameDVRAndBar)"
		Checked        = $true
		ForeColor      = "#008000"
	}

	<#
		.隐私类
	#>
	$GUIPrivate        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 390
		Text           = "$($lang.FixPrivacy)"
		Checked        = $True
		add_click      = $GUIPrivateClick
		Margin         = "2,22,0,0"
	}
	$GUIPrivatePanel   = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 235
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIOptPrivacyVoiceTyping = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyVoiceTyping)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPrivacyContactsSpeech = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyContactsSpeech)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPrivacyLanguageOptOut = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyLanguageOptOut)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPrivacyAds = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyAds)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptLocatonAware = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyLocatonAware)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPrivacySetSync = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacySetSync)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptInkingTyping = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyInkingTyping)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptShareUnpairedDevices = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyShareUnpairedDevices)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptLocationSensor = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyLocationSensor)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptBiometrics = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyBiometrics)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptCompatibleTelemetry = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyCompatibleTelemetry)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptDiagnosticData = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyDiagnosticData)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptTailoredExperiences = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.TailoredExperiences)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptFeedbackNotifications = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyFeedbackNotifications)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptLocationTracking = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyLocationTracking)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptExperiencesTelemetry = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.ExperiencesTelemetry)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPrivacyBackgroundAccess = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyBackgroundAccess)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPrivacyDefenderSurvey = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.PrivacyDefenderSurvey)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptTimelineTime = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.TimelineTime)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptCollectActivity = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 415
		Text           = "$($lang.Disable) $($lang.CollectActivity)"
		Checked        = $true
		ForeColor      = "#008000"
	}

	$GUIAdvOption      = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 395
		Text           = $lang.AdvOption
		Location       = '505,350'
	}
	$GUIAdvOptionPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 110
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
		Location       = '505,370'
	}
	$GUIOptSyncAllUser = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 415
		Text           = "$($lang.SyncAllUser)"
		Checked        = $true
		Location       = '525,393'
	}
	$GUIOptTaskBar     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 415
		Text           = "$($lang.Reset) $($lang.TaskBar)"
		Location       = '525,420'
	}
	$GUIOptResetDesk   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 415
		Text           = $lang.ResetDesk
		Location       = '525,447'
	}
	$GUIOptTips        = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 415
		Text           = $lang.OptimizationTips
		Location       = '505,488'
	}
	$GUIOptReset       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "505,515"
		Height         = 36
		Width          = 145
		add_Click      = $GUIOptRestoreClick
		Text           = $lang.Restore
	}
	$GUIOptOK          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "655,515"
		Height         = 36
		Width          = 145
		add_Click      = $GUIOptOKClick
		Text           = $lang.OK
	}
	$GUIOptCanel       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "806,515"
		Height         = 36
		Width          = 145
		add_Click      = $GUIOptCanelClick
		Text           = $lang.Cancel
	}

	$GUIOpt.controls.AddRange((
		$GUIOptLeaf,
		$GUIOptOther,
		$GUIOptOtherPanel,
		$GUIOptClear,
		$GUIOptClearPanel,
		$GUIAdvOption,
		$GUIAdvOptionPanel,
		$GUIOptTips,
		$GUIOptReset,
		$GUIOptOK,
		$GUIOptCanel
	))

	$GUIOptLeaf.controls.AddRange((
		$GUIOptOS,
		$GUIOptOSPanel,
		$GUIExplorer,
		$GUIExplorerPanel,
		$GUIRightMenu,
		$GUIRightMenuPanel,
		$GUIOptNotification,
		$GUIOptNotificationPanel,
		$GUIOptPagingSize,
		$GUIOptPagingSizePanel,
		$GUIStart,
		$GUIStartPanel,
		$GUIGameBar,
		$GUIGUIGameBarPanel,
		$GUIPrivate,
		$GUIPrivatePanel
	))

	<#
		.通知中心
	#>
	$GUIOptNotificationPanel.controls.AddRange((
		$GUIOptNotificationFull,
		$GUIOptNotificationPart
	))

	$GUIOptClearPanel.controls.AddRange((
		$GUIOptSendTo,
		$GUIOptCleanSystemLog,
		$GUIOptCleanSxS
	))

	$GUIOptOtherPanel.controls.AddRange((
		$GUIOptRDS,
		$GUIOptSMB,
		$GUIOptSMBTips
	))

	
	if (IsWin11) {
		$GUIOptOSPanel.controls.AddRange((
			$GUIOptTPM
		))
	}

	$GUIOptOSPanel.controls.AddRange((
		$GUIOptKeepSpace,
		$GUIOptHibernation,
		$GUIOptPowerSupply,
		$GUIOptAppRestartScreen,
		$GUIOptNumLock,
		$GUIOptUAC,
		$GUIOptSmartScreenApps,
		$GUIOptSmartScreenSafe,
		$GUIOptEasyAccessKeyboard,
		$GUIOptMaintain,
		$GUIOptExperience,
		$GUIOptDefragmentation,
		$GUIOptCompatibility,
		$GUIOptAnimationEffects,
		$GUIOptQOS,
		$GUIOptNetworkTuning,
		$GUIOptECN,
		$GUIOptErrorRecovery,
		$GUIOptDEP,
		$GUIOptPowerFailure,
		$GUIOptIEAutoSet,
		$GUIOptIEProxy,
		$GUIOptScheduledTasks,
		$GUIOptPwdUnlimited,
		$GUIOptRAM,
		$GUIOptStorageSense,
		$GUIOptDelivery,
		$GUIOptPhotoPreview,
		$GUIOptProtected,
		$GUIOptErrorReporting,
		$GUIOptF8BootMenu,
		$GUIOptSSD,
		$GUIOptMemoryCompression,
		$GUIOptPrelaunch
	))

	$GUIOptPagingSizePanel.controls.AddRange((
		$GUIOptPagingSizeLow,
		$GUIOptPagingSizeHigh
	))

	$GUIExplorerPanel.controls.AddRange((
		$GUIOptToThisPC,
		$GUIOptAeroShake,
		$GUIOptFileExtensions,
		$GUIOptSafetyWarnings,
		$GUIOptFileTransfer,
		$GUIOptNavShowAll,
		$GUIOptAutoplay,
		$GUIOptAutorun,
		$GUIOptQuickAccessFiles,
		$GUIOptQuickAccessFolders,
		$GUIOptShortcutArrow,
		$GUIOptThisPCDesktop,
		$GUIOptThisPCDocument,
		$GUIOptThisPCDownload,
		$GUIOptThisPCMusic,
		$GUIOptThisPCPicture,
		$GUIOptThisPCVideo,
		$GUIOptThisPC3D
	))

	if (IsWin11) {
		$GUIRightMenuPanel.controls.AddRange((
			$GUIOptClassicModern
		))
	}
	$GUIRightMenuPanel.controls.AddRange((
		$GUIOptOwnership,
		$GUIOptCopyPath,
		$GUIOptMultipleIncrease
	))

	$GUIStartPanel.controls.AddRange((
		$GUIOptSearchBox,
		$GUIOptMergeTaskbarNever,
		$GUIOptNotificationAlways,
		$GUIOptCortana,
		$GUIOptTaskView
	))
	
	$GUIGUIGameBarPanel.controls.AddRange((
		$GUIOptGamebar,
		$GUIOptGameMode,
		$GUIOptGameDVRAndBar
	))

	<#
		.添加：隐私类
	#>
	$GUIPrivatePanel.controls.AddRange((
		$GUIOptPrivacyVoiceTyping,
		$GUIOptPrivacyContactsSpeech,
		$GUIOptPrivacyLanguageOptOut,
		$GUIOptPrivacyAds,
		$GUIOptLocatonAware,
		$GUIOptPrivacySetSync,
		$GUIOptInkingTyping,
		$GUIOptShareUnpairedDevices,
		$GUIOptLocationSensor,
		$GUIOptBiometrics,
		$GUIOptCompatibleTelemetry,
		$GUIOptDiagnosticData,
		$GUIOptTailoredExperiences,
		$GUIOptFeedbackNotifications,
		$GUIOptLocationTracking,
		$GUIOptExperiencesTelemetry,
		$GUIOptPrivacyBackgroundAccess,
		$GUIOptPrivacyDefenderSurvey
	))

	if (IsWin11) {
		
	} else {
		$GUIPrivatePanel.controls.AddRange((
			$GUIOptTimelineTime,
			$GUIOptCollectActivity
		))
	}

	$GUIAdvOptionPanel.controls.AddRange((
		$GUIOptSyncAllUser,
		$GUIOptTaskBar,
		$GUIOptResetDesk
	))

	<#
		.右键菜单：优化类
	#>
	$GUIOptMenuAllSelClick = {
		$GUIOptOSPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
	}
	$GUIOptMenuAllClearClick = {
		$GUIOptOSPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
	}
	$GUIOptMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptMenu.Items.Add($lang.AllSel).add_Click($GUIOptMenuAllSelClick)
	$GUIOptMenu.Items.Add($lang.AllClear).add_Click($GUIOptMenuAllClearClick)
	$GUIOptOSPanel.ContextMenuStrip = $GUIOptMenu

	<#
		.右键菜单：文件资源管理器
	#>
	$GUIOptFileExplorerMenuAllSelClick = {
		$GUIExplorerPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
	}
	$GUIOptFileExplorerMenuAllClearClick = {
		$GUIExplorerPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
	}
	$GUIOptFileExplorerMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptFileExplorerMenu.Items.Add($lang.AllSel).add_Click($GUIOptFileExplorerMenuAllSelClick)
	$GUIOptFileExplorerMenu.Items.Add($lang.AllClear).add_Click($GUIOptFileExplorerMenuAllClearClick)
	$GUIExplorerPanel.ContextMenuStrip = $GUIOptFileExplorerMenu

	<#
		.右键菜单：上下文菜单
	#>
	$GUIOptRightMenuAllSelClick = {
		$GUIRightMenuPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
	}
	$GUIOptRightMenuAllClearClick = {
		$GUIRightMenuPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
	}
	$GUIOptRightMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptRightMenu.Items.Add($lang.AllSel).add_Click($GUIOptRightMenuAllSelClick)
	$GUIOptRightMenu.Items.Add($lang.AllClear).add_Click($GUIOptRightMenuAllClearClick)
	$GUIRightMenuPanel.ContextMenuStrip = $GUIOptRightMenu

	<#
		.右键菜单：开始菜单和任务栏
	#>
	$GUIOptStartMenuAllSelClick = {
		$GUIStartPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
	}
	$GUIOptStartMenuAllClearClick = {
		$GUIStartPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
	}
	$GUIOptStartMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptStartMenu.Items.Add($lang.AllSel).add_Click($GUIOptStartMenuAllSelClick)
	$GUIOptStartMenu.Items.Add($lang.AllClear).add_Click($GUIOptStartMenuAllClearClick)
	$GUIStartPanel.ContextMenuStrip = $GUIOptStartMenu

	<#
		.右键菜单：游戏
	#>
	$GUIOptGamingMenuAllSelClick = {
		$GUIGUIGameBarPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
	}
	$GUIOptGamingMenuAllClearClick = {
		$GUIGUIGameBarPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
	}
	$GUIOptGamingMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptGamingMenu.Items.Add($lang.AllSel).add_Click($GUIOptGamingMenuAllSelClick)
	$GUIOptGamingMenu.Items.Add($lang.AllClear).add_Click($GUIOptGamingMenuAllClearClick)
	$GUIGUIGameBarPanel.ContextMenuStrip = $GUIOptGamingMenu

	<#
		.右键菜单：隐私设置
	#>
	$GUIOptPriavteMenuAllSelClick = {
		$GUIPrivatePanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
	}
	$GUIOptPriavteMenuAllClearClick = {
		$GUIPrivatePanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
	}
	$GUIOptPriavteMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptPriavteMenu.Items.Add($lang.AllSel).add_Click($GUIOptPriavteMenuAllSelClick)
	$GUIOptPriavteMenu.Items.Add($lang.AllClear).add_Click($GUIOptPriavteMenuAllClearClick)
	$GUIPrivatePanel.ContextMenuStrip = $GUIOptPriavteMenu

	<#
		.右键菜单：其它
	#>
	$GUIOptOtherMenuAllSelClick = {
		$GUIOptOtherPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
	}
	$GUIOptOtherMenuAllClearClick = {
		$GUIOptOtherPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
	}
	$GUIOptOtherMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptOtherMenu.Items.Add($lang.AllSel).add_Click($GUIOptOtherMenuAllSelClick)
	$GUIOptOtherMenu.Items.Add($lang.AllClear).add_Click($GUIOptOtherMenuAllClearClick)
	$GUIOptOtherPanel.ContextMenuStrip = $GUIOptOtherMenu

	<#
		.右键菜单：清理
	#>
	$GUIOptCleanMenuAllSelClick = {
		$GUIOptClearPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
	}
	$GUIOptCleanMenuAllClearClick = {
		$GUIOptClearPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
	}
	$GUIOptCleanMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptCleanMenu.Items.Add($lang.AllSel).add_Click($GUIOptCleanMenuAllSelClick)
	$GUIOptCleanMenu.Items.Add($lang.AllClear).add_Click($GUIOptCleanMenuAllClearClick)
	$GUIOptClearPanel.ContextMenuStrip = $GUIOptCleanMenu

	<#
		.右键菜单：主界面
	#>
	$GUIOptAllSelClick = {
		$GUIOptOSPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
		$GUIExplorerPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
		$GUIRightMenuPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
		$GUIStartPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
		$GUIGUIGameBarPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
		$GUIPrivatePanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
		$GUIOptOtherPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
		$GUIOptClearPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true } }
	}
	$GUIOptAllClearClick = {
		$GUIOptOSPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
		$GUIExplorerPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
		$GUIRightMenuPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
		$GUIStartPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
		$GUIGUIGameBarPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
		$GUIPrivatePanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
		$GUIOptOtherPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
		$GUIOptClearPanel.Controls | ForEach-Object { if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false } }
	}
	$GUIOptMainMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptMainMenu.Items.Add($lang.AllSel).add_Click($GUIOptAllSelClick)
	$GUIOptMainMenu.Items.Add($lang.AllClear).add_Click($GUIOptAllClearClick)
	$GUIOpt.ContextMenuStrip = $GUIOptMainMenu

	$NoSelectPowerSupply = @(8, 9, 10, 11, 14)
	Get-CimInstance -ClassName Win32_SystemEnclosure | ForEach-Object {
		if ($NoSelectPowerSupply -contains $_.SecurityStatus) {
			$GUIOptHibernation.Checked = $False
			$GUIOptPowerSupply.Checked = $False
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIOpt.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIOpt.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$GUIOpt.FormBorderStyle = 'Fixed3D'
	$GUIOpt.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

<#
	....................................
	Modules
	....................................
#>

<#
	.Take ownership to the right-click menu
	.Windows 11 上下文菜单传统、现代
#>
Function Win11ContextMenu
{
	param
	(
		[switch]$Classic,
		[switch]$Modern
	)

	if ($Classic) {
		Write-Host "   $($lang.ClassicMenu)"
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32") -ne $true) {
			New-Item "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" -force -ea SilentlyContinue | Out-Null
		}
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32' -Name '(default)' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		RefreshIconCache
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Modern) {
		Write-Host "   $($lang.ModernMenu)"
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		RefreshIconCache
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Take ownership to the right-click menu
	.取得所有权到右键菜单
#>
Function TakeOwnership
{
	param
	(
		[switch]$Remove,
		[switch]$Add
	)

	Write-Host "   $($lang.TakeOwnership)"
	if ($Remove) {
		Write-Host "   $($lang.Delete)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Drive\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Add) {
		Write-Host "   $($lang.AddTo)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'AppliesTo' -Value "NOT (System.ItemPathDisplay:=\""$($env:SystemDrive)\Users\"" OR System.ItemPathDisplay:=\""$($env:SystemDrive)\ProgramData\"" OR System.ItemPathDisplay:=\""$($env:systemroot)\"" OR System.ItemPathDisplay:=\""$($env:systemroot)\System32\"" OR System.ItemPathDisplay:=\""$($env:SystemDrive)\Program Files\"" OR System.ItemPathDisplay:=\""$($env:SystemDrive)\Program Files (x86)\"")" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" /r && icacls "%1" /grant *S-1-3-4:F /t /c /l /q & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" /r && icacls "%1" /grant *S-1-3-4:F /t /c /l /q & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership' -Name "MUIVerb" -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command' -Name '(default)' -Value '"%1" %*' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value '"%1" %*' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		RefreshIconCache
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Always Show Copy Path Context Menu in Windows 10
	.在 Windows 10 中始终显示复制路径上下文菜单
#>
Function CopyPath
{
	param
	(
		[switch]$Remove,
		[switch]$Add
	)

	Write-Host "   $($lang.CopyPath)"
	if ($Remove) {
		Write-Host "   $($lang.Delete)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Add) {
		Write-Host "   $($lang.AddTo)".PadRight(22) -NoNewline
		if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath") -ne $true) {
			New-Item "HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath" -force -ea SilentlyContinue | Out-Null
		}
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name '(default)' -Value 'Copy &as path' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name 'MUIVerb' -Value '@shell32.dll,-30329' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name 'Icon' -Value 'imageres.dll,-5302' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name 'InvokeCommandOnSelection' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name 'VerbHandler' -Value '{f3d06e7c-1e45-4a26-847e-f9fcdee59be0}' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name 'VerbName' -Value 'copyaspath' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Windows 11 TPM 2.0 Check
	.Windows 11 TPM 2.0 检查
#>
Function Win11TPM
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.TPMCheck)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\LabConfig" -Name 'BypassCPUCheck' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\LabConfig" -Name 'BypassStorageCheck' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\LabConfig" -Name 'BypassRAMCheck' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\LabConfig" -Name 'BypassTPMCheck' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\LabConfig" -Name 'BypassSecureBootCheck' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\MoSetup" -Name 'AllowUpgradesWithUnsupportedTPMOrCPU' -Force -ErrorAction SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Close)".PadRight(22) -NoNewline
		if((Test-Path -LiteralPath "HKLM:\SYSTEM\Setup\LabConfig") -ne $true) {  New-Item "HKLM:\SYSTEM\Setup\LabConfig" -force -ea SilentlyContinue | Out-Null }
		if((Test-Path -LiteralPath "HKLM:\SYSTEM\Setup\MoSetup") -ne $true) {  New-Item "HKLM:\SYSTEM\Setup\MoSetup" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\LabConfig' -Name 'BypassCPUCheck' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\LabConfig' -Name 'BypassStorageCheck' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\LabConfig' -Name 'BypassRAMCheck' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\LabConfig' -Name 'BypassTPMCheck' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\LabConfig' -Name 'BypassSecureBootCheck' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\MoSetup' -Name 'AllowUpgradesWithUnsupportedTPMOrCPU' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Keep space
	.保留空间
#>
Function KeepSpace
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.KeepSpace)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		DISM.exe /Online /Set-ReservedStorageState /State:Enabled | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Close)".PadRight(22) -NoNewline
		DISM.exe /Online /Set-ReservedStorageState /State:Disabled | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Hibernation
	.休眠
#>
Function Hibernation
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Hibernation)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Start-Process 'powercfg.exe' -ArgumentList '/h on' -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Close)".PadRight(22) -NoNewline
		Start-Process 'powercfg.exe' -Verb runAs -ArgumentList '/h off' -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Power supply solution optimized after "high performance"
	.电源方案为“高性能”后优化
#>
Function PowerSupply
{
	param
	(
		[switch]$Restore,
		[switch]$Optimize
	)

	Write-Host "   $($lang.PowerSupply)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		powercfg -restoredefaultschemes
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Optimize) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
		powercfg -change -monitor-timeout-ac 0
		powercfg -change -monitor-timeout-dc 0
		powercfg -change -disk-timeout-ac 0
		powercfg -change -disk-timeout-dc 5
		powercfg -change -standby-timeout-ac 0
		powercfg -change -standby-timeout-dc 60
		powercfg -change -hibernate-timeout-ac 0
		powercfg -change -hibernate-timeout-dc 300
		powercfg /SETACVALUEINDEX 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
		powercfg /SETDCVALUEINDEX 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	."This app is preventing shutdown or restart" screen
	."此应用正在阻止关机或重新启动" 屏幕
#>
Function AppRestartScreen
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.AppRestartScreen)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'MenuShowDelay' -Value '400' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'WaitToKillAppTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'HungAppTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'AutoEndTasks' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'LowLevelHooksTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'WaitToKillServiceTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name 'AutoEndTasks' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name 'LowLevelHooksTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name 'WaitToKillServiceTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'MenuShowDelay' -Value '0' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'WaitToKillAppTimeout' -Value '5000' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'HungAppTimeout' -Value '4000' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'LowLevelHooksTimeout' -Value 4096 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'WaitToKillServiceTimeout' -Value 8192 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'LowLevelHooksTimeout' -Value 4096 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'WaitToKillServiceTimeout' -Value 8192 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Shortcut small arrow and suffix
	.快捷方式小箭头和后缀
#>
Function ShortcutArrow
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ShortcutArrow)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\IE.AssocFile.URL' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\InternetShortcut' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\lnkfile' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
		Remove-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Force -ea SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name link -Force -ErrorAction SilentlyContinue
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Delete)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Value "$($env:systemroot)\system32\imageres.dll,197" -PropertyType String -Force -ea SilentlyContinue | out-null
		Remove-Item -Path "$($env:USERPROFILE)\AppData\Local\iconcache.db" -ErrorAction SilentlyContinue
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'link' -Value ([byte[]](0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.NumLock key will light up automatically after power on
	.NumLock 键开机后自动亮起
#>
Function Numlock
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Numlock)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -Path "Registry::HKEY_USERS\.DEFAULT\Control Panel\Keyboard" -Name InitialKeyboardIndicators -PropertyType String -Value 2147483650 -Force -ErrorAction SilentlyContinue | Out-Null
		Add-Type -AssemblyName System.Windows.Forms
		If (-not ([System.Windows.Forms.Control]::IsKeyLocked('NumLock'))) {
			$wsh = New-Object -ComObject WScript.Shell
			$wsh.SendKeys('{NUMLOCK}')
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -Path "Registry::HKEY_USERS\.DEFAULT\Control Panel\Keyboard" -Name InitialKeyboardIndicators -PropertyType String -Value 2147483648 -Force -ErrorAction SilentlyContinue | Out-Null
		Add-Type -AssemblyName System.Windows.Forms
		If ([System.Windows.Forms.Control]::IsKeyLocked('NumLock')) {
			$wsh = New-Object -ComObject WScript.Shell
			$wsh.SendKeys('{NUMLOCK}')
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Show file name extensions
	.显示文件扩展名
#>
Function ExplorerOpenTo
{
	param
	(
		[switch]$ThisPC,
		[switch]$QuickAccess
	)

	if ($ThisPC) {
		Write-Host "   $($lang.ExplorerTo -f $($lang.ExplorerToThisPC))"
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "LaunchTo" -PropertyType DWord -Value 2 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($QuickAccess) {
		Write-Host "   $($lang.ExplorerTo -f $($lang.ExplorerToQuickAccess))"
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "LaunchTo" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Aero Shake Shake to the lowest function
	.Aero Shake 摇一摇降到最低功能
#>
Function AeroShake
{
	param
	(
		[switch]$AllUser,
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.AeroShake)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name 'DisallowShaking' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

		if ($AllUser) {
			Remove-ItemProperty -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "NoWindowMinimizingShortcuts" -ErrorAction SilentlyContinue | Out-Null
			Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "NoWindowMinimizingShortcuts" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name 'DisallowShaking' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

		if ($AllUser) {
			New-ItemProperty -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "NoWindowMinimizingShortcuts" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
			New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "NoWindowMinimizingShortcuts" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Show file name extensions
	.显示文件扩展名
#>
Function FileExtensions
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	Write-Host "   $($lang.FileExtensions)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideFileExt -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideFileExt -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Search bar: display search icon
	.搜索栏：显示搜索图标
#>
Function SearchBox
{
	param
	(
		[switch]$Hide,
		[switch]$SearchIcon,
		[switch]$SearchBox
	)

	Write-Host "   $($lang.SearchBox)"
	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($SearchIcon) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($SearchBox) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.User Account Control (UAC): Never notify me
	.用户账户控制 (UAC)：从不通知我
#>
Function UACNever
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UAC)"
	if ($Enable) {
		Write-Host "   $($lang.UACNever)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 5 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.File transfer dialog: brief information, detailed information
	.文件传输对话框：简略信息、详细信息
#>
Function FileTransferDialog
{
	param
	(
		[switch]$Detailed,
		[switch]$Simple
	)

	Write-Host "   $($lang.FileTransfer)"
	if ($Detailed) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager" -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager -Name EnthusiastMode -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Simple) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Smart Screen for Microsoft Store apps
	.适用于 Microsoft Store 应用的 Smart Screen
#>
Function SmartScreenApps
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.SmartScreenApps)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Type String -Value "RequireAdmin"
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" -Name "EnableWebContentEvaluation" -ErrorAction SilentlyContinue
	
		Get-ChildItem -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\*edge*" -Name -ErrorAction SilentlyContinue | ForEach-Object {
			if (Test-Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -PathType Container) {
				Remove-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -ErrorAction SilentlyContinue | Out-Null
				Remove-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "PreventOverride" -ErrorAction SilentlyContinue | Out-Null
			}
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Type String -Value "Off"
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" -Name "EnableWebContentEvaluation" -Type DWord -Value 0
	
		Get-ChildItem -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\*edge*" -Name -ErrorAction SilentlyContinue | ForEach-Object {
			if (Test-Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -PathType Container) {
				Set-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -Type DWord -Value 0 | Out-Null
				Set-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "PreventOverride" -Type DWord -Value 0 | Out-Null
			}
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Smart Screen for Microsoft Store apps
	.适用于 Microsoft Store 应用的 Smart Screen
#>
Function SmartScreenSafe
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.SmartScreenSafe)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments -Name SaveZoneInformation -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if (-not (Test-Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments))
		{
			New-Item -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments -Force -ErrorAction SilentlyContinue | Out-Null
		}
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments -Name SaveZoneInformation -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Easy access keyboard stuff
	.轻松访问键盘的东西
#>
Function EasyAccessKeyboard
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.EasyAccessKeyboard)"
	if ($Enable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\StickyKeys" "Flags" "510" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\Keyboard Response" "Flags" "126" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\ToggleKeys" "Flags" "62" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\StickyKeys" "Flags" "506" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\Keyboard Response" "Flags" "122" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\ToggleKeys" "Flags" "58" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Automatic maintenance plan
	.自动维护计划
#>
Function Maintain
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Maintain)"
	if ($Enable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" -Name "MaintenanceDisabled" -ErrorAction SilentlyContinue
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance' -Name 'MaintenanceDisabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Customer experience improvement plan
	.客户体验改善计划
#>
Function Experience
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Experience)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows" -Name "CEIPEnable" -ErrorAction SilentlyContinue
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows' -Name 'CEIPEnable' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Common file type safety warnings
	.常见文件类型安全警告
#>
Function SafetyWarnings
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.SafetyWarnings)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations") -ne $true) { New-Item "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'LowRiskFileTypes' -Value '.exe;.reg;.msi;.bat;.cmd;.com;.vbs;.hta;.scr;.pif;.js;' -PropertyType String -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
} 

<#
	.QOS service
	.QOS 服务
#>
Function QOS
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.QOS)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\nvspbind")\nvspbind.exe" -ArgumentList "/e ""*"" ms_pacer" -Wait -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\nvspbind")\nvspbind.exe" -ArgumentList "/d ""*"" ms_pacer" -Wait -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Network tuning function
	.网络调优功能
#>
Function NetworkTuning
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.NetworkTuning)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		netsh interface tcp set global autotuninglevel=normal | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		netsh interface tcp set global autotuninglevel=disabled | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.ECN function
	.ECN 功能
#>
Function ECN
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ECN)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		netsh int tcp set global ecn=enabled | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		netsh int tcp set global ecn=disable | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Windows error recovery
	.Windows 错误恢复
#>
Function ErrorRecovery
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ErrorRecovery)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /set {default} bootstatuspolicy DisplayAllFailures | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} bootstatuspolicy ignoreallfailures | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.DEP and PAE
	.DEP 和 PAE
#>
Function DEPPAE
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.DEP)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /deletevalue `{current`} pae 
		bcdedit /set `{current`} nx OptIn
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} nx AlwaysOff
		bcdedit /set `{current`} pae ForceDisable
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Automatic repair function after power failure
	.断电后自动修复功能
#>
Function PowerFailure
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PowerFailure)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} Recoveryenabled Yes | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} Recoveryenabled No | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Certain scheduled tasks
	.某些计划任务
#>
Function ScheduledTasks
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	$tasks = @(
		<#
			.Windows base scheduled tasks
		#>
		"\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319"
		"\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319 64"
		"\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319 64 Critical"
		"\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319 Critical"
#		"\Microsoft\Windows\Active Directory Rights Management Services Client\AD RMS Rights Policy Template Management (Automated)"
#		"\Microsoft\Windows\Active Directory Rights Management Services Client\AD RMS Rights Policy Template Management (Manual)"
#		"\Microsoft\Windows\AppID\EDP Policy Manager"
#		"\Microsoft\Windows\AppID\PolicyConverter"
		"\Microsoft\Windows\AppID\SmartScreenSpecific"
#		"\Microsoft\Windows\AppID\VerifiedPublisherCertStoreCheck"
		"\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser"
		"\Microsoft\Windows\Application Experience\ProgramDataUpdater"
#		"\Microsoft\Windows\Application Experience\StartupAppTask"
#		"\Microsoft\Windows\ApplicationData\CleanupTemporaryState"
#		"\Microsoft\Windows\ApplicationData\DsSvcCleanup"		
#		"\Microsoft\Windows\AppxDeploymentClient\Pre-staged app cleanup"
		"\Microsoft\Windows\Autochk\Proxy"
#		"\Microsoft\Windows\Bluetooth\UninstallDeviceTask"
#		"\Microsoft\Windows\CertificateServicesClient\AikCertEnrollTask"
#		"\Microsoft\Windows\CertificateServicesClient\KeyPreGenTask"
#		"\Microsoft\Windows\CertificateServicesClient\SystemTask"
#		"\Microsoft\Windows\CertificateServicesClient\UserTask"
#		"\Microsoft\Windows\CertificateServicesClient\UserTask-Roam"
#		"\Microsoft\Windows\Chkdsk\ProactiveScan"
#		"\Microsoft\Windows\Clip\License Validation"
		"\Microsoft\Windows\CloudExperienceHost\CreateObjectTask"
		"\Microsoft\Windows\Customer Experience Improvement Program\Consolidator"
		"\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask"
		"\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip"
#		"\Microsoft\Windows\Data Integrity Scan\Data Integrity Scan"
#		"\Microsoft\Windows\Data Integrity Scan\Data Integrity Scan for Crash Recovery"
#		"\Microsoft\Windows\Defrag\ScheduledDefrag"
#		"\Microsoft\Windows\Diagnosis\Scheduled"
#		"\Microsoft\Windows\DiskCleanup\SilentCleanup"
		"\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"
#		"\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticResolver"
#		"\Microsoft\Windows\DiskFootprint\Diagnostics"
		"\Microsoft\Windows\Feedback\Siuf\DmClient"
#		"\Microsoft\Windows\File Classification Infrastructure\Property Definition Sync"
#		"\Microsoft\Windows\FileHistory\File History (maintenance mode)"
#		"\Microsoft\Windows\LanguageComponentsInstaller\Installation"
#		"\Microsoft\Windows\LanguageComponentsInstaller\Uninstallation"
#		"\Microsoft\Windows\Location\Notifications"
#		"\Microsoft\Windows\Location\WindowsActionDialog"
#		"\Microsoft\Windows\Maintenance\WinSAT"
#		"\Microsoft\Windows\Maps\MapsToastTask"
#		"\Microsoft\Windows\Maps\MapsUpdateTask"
#		"\Microsoft\Windows\MemoryDiagnostic\ProcessMemoryDiagnosticEvents"
#		"\Microsoft\Windows\MemoryDiagnostic\RunFullMemoryDiagnostic"
		"\Microsoft\Windows\Mobile Broadband Accounts\MNO Metadata Parser"
#		"\Microsoft\Windows\MUI\LPRemove"
#		"\Microsoft\Windows\Multimedia\SystemSoundsService"
#		"\Microsoft\Windows\NetCfg\BindingWorkItemQueueHandler"
#		"\Microsoft\Windows\NetTrace\GatherNetworkInfo"
#		"\Microsoft\Windows\Offline Files\Background Synchronization"
#		"\Microsoft\Windows\Offline Files\Logon Synchronization"
#		"\Microsoft\Windows\PI\Secure-Boot-Update"
#		"\Microsoft\Windows\PI\Sqm-Tasks"
#		"\Microsoft\Windows\Plug and Play\Device Install Group Policy"
#		"\Microsoft\Windows\Plug and Play\Device Install Reboot Required"
#		"\Microsoft\Windows\Plug and Play\Plug and Play Cleanup"
#		"\Microsoft\Windows\Plug and Play\Sysprep Generalize Drivers"
#		"\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem"
#		"\Microsoft\Windows\Ras\MobilityManager"
#		"\Microsoft\Windows\RecoveryEnvironment\VerifyWinRE"
#		"\Microsoft\Windows\Registry\RegIdleBackup"
#		"\Microsoft\Windows\RemoteAssistance\RemoteAssistanceTask"
#		"\Microsoft\Windows\RemovalTools\MRT_HB"
#		"\Microsoft\Windows\Servicing\StartComponentCleanup"
#		"\Microsoft\Windows\SettingSync\NetworkStateChangeTask"
#		"\Microsoft\Windows\Shell\CreateObjectTask"
#		"\Microsoft\Windows\Shell\FamilySafetyMonitor"
#		"\Microsoft\Windows\Shell\FamilySafetyRefresh"
#		"\Microsoft\Windows\Shell\IndexerAutomaticMaintenance"
#		"\Microsoft\Windows\SoftwareProtectionPlatform\SvcRestartTask"
#		"\Microsoft\Windows\SoftwareProtectionPlatform\SvcRestartTaskLogon"
#		"\Microsoft\Windows\SoftwareProtectionPlatform\SvcRestartTaskNetwork"
#		"\Microsoft\Windows\SpacePort\SpaceAgentTask"
#		"\Microsoft\Windows\Sysmain\HybridDriveCachePrepopulate"
#		"\Microsoft\Windows\Sysmain\HybridDriveCacheRebalance"
#		"\Microsoft\Windows\Sysmain\ResPriStaticDbSync"
#		"\Microsoft\Windows\Sysmain\WsSwapAssessmentTask"
#		"\Microsoft\Windows\SystemRestore\SR"
#		"\Microsoft\Windows\Task Manager\Interactive"
#		"\Microsoft\Windows\TextServicesFramework\MsCtfMonitor"
#		"\Microsoft\Windows\Time Synchronization\ForceSynchronizeTime"
#		"\Microsoft\Windows\Time Synchronization\SynchronizeTime"
#		"\Microsoft\Windows\Time Zone\SynchronizeTimeZone"
#		"\Microsoft\Windows\TPM\Tpm-HASCertRetr"
#		"\Microsoft\Windows\TPM\Tpm-Maintenance"
#		"\Microsoft\Windows\UpdateOrchestrator\Maintenance Install"
#		"\Microsoft\Windows\UpdateOrchestrator\Policy Install"
#		"\Microsoft\Windows\UpdateOrchestrator\Reboot"
#		"\Microsoft\Windows\UpdateOrchestrator\Resume On Boot"
#		"\Microsoft\Windows\UpdateOrchestrator\Schedule Scan"
#		"\Microsoft\Windows\UpdateOrchestrator\USO_UxBroker_Display"
#		"\Microsoft\Windows\UpdateOrchestrator\USO_UxBroker_ReadyToReboot"
#		"\Microsoft\Windows\UPnP\UPnPHostConfig"
#		"\Microsoft\Windows\User Profile Service\HiveUploadTask"
#		"\Microsoft\Windows\WCM\WiFiTask"
#		"\Microsoft\Windows\WDI\ResolutionHost"
		"\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance"
		"\Microsoft\Windows\Windows Defender\Windows Defender Cleanup"
		"\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan"
		"\Microsoft\Windows\Windows Defender\Windows Defender Verification"
		"\Microsoft\Windows\Windows Error Reporting\QueueReporting"
#		"\Microsoft\Windows\Windows Filtering Platform\BfeOnServiceStartTypeChange"
#		"\Microsoft\Windows\Windows Media Sharing\UpdateLibrary"
#		"\Microsoft\Windows\WindowsColorSystem\Calibration Loader"
#		"\Microsoft\Windows\WindowsUpdate\Automatic App Update"
#		"\Microsoft\Windows\WindowsUpdate\Scheduled Start"
#		"\Microsoft\Windows\WindowsUpdate\sih"
#		"\Microsoft\Windows\WindowsUpdate\sihboot"
#		"\Microsoft\Windows\Wininet\CacheTask"
#		"\Microsoft\Windows\WOF\WIM-Hash-Management"
#		"\Microsoft\Windows\WOF\WIM-Hash-Validation"
#		"\Microsoft\Windows\Work Folders\Work Folders Logon Synchronization"
#		"\Microsoft\Windows\Work Folders\Work Folders Maintenance Work"
#		"\Microsoft\Windows\Workplace Join\Automatic-Device-Join"
#		"\Microsoft\Windows\WS\License Validation"
#		"\Microsoft\Windows\WS\WSTask"

		<#
			.Scheduled tasks which cannot be disabled
		#>
#		"\Microsoft\Windows\Device Setup\Metadata Refresh"
#		"\Microsoft\Windows\SettingSync\BackgroundUploadTask"
	)

	Write-Host "   $($lang.ScheduledTasks)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		foreach ($task in $tasks) {
			$parts = $task.split('\')
			$name = $parts[-1]
			$path = $parts[0..($parts.length-2)] -join '\'
		
			Enable-ScheduledTask -TaskName "$name" -TaskPath "$path" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Red
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline

		foreach ($task in $tasks) {
			$parts = $task.split('\')
			$name = $parts[-1]
			$path = $parts[0..($parts.length-2)] -join '\'
		
			Disable-ScheduledTask -TaskName "$name" -TaskPath "$path" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Automatic download and installation of Windows updates
	.自动下载和安装 Windows 更新
#>
Function UpdateAutoDownload
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UpdateAutoDownload)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "NoAutoUpdate" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "AUOptions" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "AUOptions" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "ScheduledInstallDay" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "ScheduledInstallTime" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'NoAutoUpdate' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'AUOptions' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'ScheduledInstallDay' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'ScheduledInstallTime' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Disable seeding of updates to other computers via Group Policies
	.通过组策略禁用对其他计算机的更新种子
#>
Function UpdatePolicies
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UpdatePolicies)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" -Name "DODownloadMode" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" -Name 'DODownloadMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}
}

<#
	.Automatic driver update
	.自动驱动程序更新
#>
Function UpdateAutoDrive
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UpdateAutoDrive)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" -Name 'SearchOrderConfig' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" -Name 'SearchOrderConfig' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}
}

<#
	.Windows Update: 'Updates are available' message
	.Windows 更新：有可用更新消息
#>
Function UpdateAreAvailable
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UpdateAreAvailable)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Start-Process "takeown" -ArgumentList "/F $env:WinDIR\System32\MusNotification.exe" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotification.exe /remove:d Everyone" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotification.exe /grant Everyone:F" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotification.exe /setowner ""NT SERVICE\TrustedInstaller""" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotification.exe /remove:g Everyone" -WindowStyle Hidden

		Start-Process "takeown" -ArgumentList "/F $env:WinDIR\System32\MusNotificationUx.exe" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotificationUx.exe /remove:d Everyone" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotificationUx.exe /grant Everyone:F" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotificationUx.exe /setowner ""NT SERVICE\TrustedInstaller""" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotificationUx.exe /remove:g Everyone" -WindowStyle Hidden
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Start-Process "takeown" -ArgumentList "/F $env:WinDIR\System32\MusNotification.exe" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotification.exe /deny Everyone:(X)" -WindowStyle Hidden
		Start-Process "takeown" -ArgumentList "/F $env:WinDIR\System32\MusNotificationUx.exe" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotificationUx.exe /deny Everyone:(X)" -WindowStyle Hidden
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.It is forbidden to send voice, ink and typing samples to MS (so Cortana can learn to recognize you)
	.向 MS 发送语音、墨迹和打字样本 ( 因此 Cortana 可以学习识别您 )
#>
Function PrivacyVoiceTyping
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyVoiceTyping)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Personalization\Settings" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Personalization\Settings" "AcceptedPrivacyPolicy" "1" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Personalization\Settings" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Personalization\Settings" "AcceptedPrivacyPolicy" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Send contacts to MS ( so Cortana can compare speech etc samples )
	.向 MS 发送联系人 ( 因此 Cortana 可以比较语音等样本 )
#>
Function PrivacyContactsSpeech
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyContactsSpeech)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore" "HarvestContacts" "1" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore" "HarvestContacts" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.让网站通过访问我的语言列表来提供本地相关内容
	.Let websites provide locally relevant content by accessing my language list
#>
Function PrivacyLanguageOptOut
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyLanguageOptOut)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Control Panel\International\User Profile" -Name "HttpAcceptLanguageOptOut" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Control Panel\International\User Profile" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Control Panel\International\User Profile" "HttpAcceptLanguageOptOut" 0 -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Apps use my advertising ID for experiencess across apps
	.让应用使用我的广告 ID 进行跨应用体验
#>
Function PrivacyAds
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyAds)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo" -Name "Enabled" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo" "Enabled" 0 -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Locaton aware printing (changes default based on connected network)
	.位置感知打印 ( 根据连接的网络更改默认值 )
#>
Function PrivacyLocatonAware
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyLocatonAware)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\Printers\Defaults" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Input\TIPC" -Name "Enabled" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Printers\Defaults" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Printers\Defaults" "NetID" "{00000000-0000-0000-0000-000000000000}" -ErrorAction SilentlyContinue | Out-Null

		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Input\TIPC" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Input\TIPC" "Enabled" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Synchronisation of settings
	.设置同步
#>
Function PrivacySetSync
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	$groups = @(
		"Accessibility"
		"AppSync"
		"BrowserSettings"
		"Credentials"
		"DesktopTheme"
		"Language"
		"PackageState"
		"Personalization"
		"StartLayout"
		"Windows"
	)

	Write-Host "   $($lang.PrivacySetSync)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "BackupPolicy" 0x3c -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "DeviceMetadataUploaded" 0 -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "PriorLogons" 1 -ErrorAction SilentlyContinue | Out-Null
		foreach ($group in $groups) {
			New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\$group" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
			Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\$group" "Enabled" "1" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "BackupPolicy" 0x3c -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "DeviceMetadataUploaded" 0 -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "PriorLogons" 1 -ErrorAction SilentlyContinue | Out-Null
		foreach ($group in $groups) {
			New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\$group" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
			Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\$group" "Enabled" "0" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Personalization of inking and typing
	.隐私：墨迹书写和打字个性化
#>
Function PrivacyInkingTyping
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyInkingTyping)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" "RestrictImplicitInkCollection" "0" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" "RestrictImplicitTextCollection" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" "RestrictImplicitInkCollection" "1" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" "RestrictImplicitTextCollection" "1" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Share information with unpaired devices
	.隐私：与未配对设备共享信息
#>
Function PrivacyShareUnpairedDevices
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyShareUnpairedDevices)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\LooselyCoupled" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\LooselyCoupled" "Type" "LooselyCoupled" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\LooselyCoupled" "Value" "Deny" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\LooselyCoupled" "InitialAppValue" "Unspecified" -ErrorAction SilentlyContinue | Out-Null
		foreach ($key in (Get-ChildItem "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global")) {
		    if ($key.PSChildName -EQ "LooselyCoupled") {
		        continue
		    }
		    Set-ItemProperty -Path ("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\" + $key.PSChildName) "Type" "InterfaceClass" -ErrorAction SilentlyContinue | Out-Null
		    Set-ItemProperty -Path ("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\" + $key.PSChildName) "Value" "Deny" -ErrorAction SilentlyContinue | Out-Null
		    Set-ItemProperty -Path ("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\" + $key.PSChildName) "InitialAppValue" "Unspecified" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Windows Hello Biometrics
	.隐私：Windows Hello 生物识别
#>
Function PrivacyBiometrics
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyLocationSensor)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Biometrics" -Name "Enabled" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Policies\Microsoft\Biometrics" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Biometrics" "Enabled" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Compatibility Telemetry
	.隐私：兼容性遥测
#>
Function PrivacyCompatibleTelemetry
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyCompatibleTelemetry)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\CompatTelRunner.exe" -Name "Debugger" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\CompatTelRunner.exe" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\CompatTelRunner.exe" "Debugger" "%windir%\system32\taskkill.exe" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Diagnostic data
	.隐私：诊断数据
#>
Function PrivacyDiagnosticData
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyDiagnosticData)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" "TailoredExperiencesWithDiagnosticDataEnabled" "2" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" "TailoredExperiencesWithDiagnosticDataEnabled" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Tailored experiences
	.隐私：量身定制的体验
#>
Function PrivacyTailoredExperiences
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.TailoredExperiences)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" "TailoredExperiencesWithDiagnosticDataEnabled" "2" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" "TailoredExperiencesWithDiagnosticDataEnabled" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Feedback notifications
	.隐私：反馈通知
#>
Function PrivacyFeedbackNotifications
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyFeedbackNotifications)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Siuf\Rules" -Name "NumberOfSIUFInPeriod" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Siuf\Rules" -Name "PeriodInNanoSeconds" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Siuf\Rules" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Siuf\Rules" "NumberOfSIUFInPeriod" "0" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Siuf\Rules" "PeriodInNanoSeconds" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Location tracking
	.隐私：位置跟踪
#>
Function PrivacyLocationTracking
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyLocationTracking)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" "Value" "Allow" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" "Value" "Deny" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Location sensor
	.隐私：位置传感器
#>
Function PrivacyLocationSensor
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyLocationSensor)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}" "SensorPermissionState" "1" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}" "SensorPermissionState" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Connected User Experiences and Telemetry
	.隐私：互联用户体验和遥测
#>
Function PrivacyExperiencesTelemetry
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ExperiencesTelemetry)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Policies\Microsoft\Windows\DataCollection" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Windows\DataCollection" "AllowTelemetry" "3" -ErrorAction SilentlyContinue | Out-Null
		Get-Service -Name "DiagTrack" | Set-Service -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
		Start-Service "DiagTrack" -ErrorAction SilentlyContinue | Out-Null
		Get-Service -Name "dmwappushservice" | Set-Service -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
		Start-Service "dmwappushservice" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Policies\Microsoft\Windows\DataCollection" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Windows\DataCollection" "AllowTelemetry" "0" -ErrorAction SilentlyContinue | Out-Null
		Get-Service -Name "DiagTrack" | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
		Stop-Service "DiagTrack" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null
		Get-Service -Name "dmwappushservice" | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
		Stop-Service "dmwappushservice" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}



<#
	.Privacy: Background access of default apps
	.隐私：默认应用的后台访问
#>
Function PrivacyBackgroundAccess
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyBackgroundAccess)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		foreach ($key in (Get-ChildItem "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications")) {
			Remove-ItemProperty -Path ("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications\" + $key.PSChildName) -Name 'Disabled' -Force -ErrorAction SilentlyContinue | out-null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		foreach ($key in (Get-ChildItem "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications")) {
			Set-ItemProperty -Path ("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications\" + $key.PSChildName) "Disabled" 1 -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Submit Windows Defender survey results to MS
	.隐私：向 MS 提交 Windows Defender 调查结果
#>
Function PrivacyDefenderSurvey
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyDefenderSurvey)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		TakeownRegistry("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Spynet")
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet" "SpyNetReporting" 2 -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet" "SubmitSamplesConsent" 1 -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		TakeownRegistry("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Spynet")
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet" "SpyNetReporting" 0 -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet" "SubmitSamplesConsent" 0 -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Timeline time
	.隐私：时间轴时间
#>
Function TimelineTime
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.TimelineTime)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Privacy: Collect activity history
	.隐私：收集活动历史记录
#>
Function CollectActivity
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.CollectActivity)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'PublishUserActivities' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'PublishUserActivities' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.IE automatically detects settings
	.IE 自动检测设置
#>
Function AutoDetect
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.IEAutoSet)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoDetect' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoDetect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.IE Setting proxy does not take effect
	.IE 设置代理不生效
#>
Function IEProxy
{
	Write-Host "   $($lang.IEProxy)"
	Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
	"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections [1 7 17]" | Out-File -FilePath "$env:TEMP\ie_proxy.ini" -Encoding ASCII
	Start-Process "regini" -ArgumentList "$env:TEMP\ie_proxy.ini" -WindowStyle Minimized
	Remove-Item -Path "$env:TEMP\ie_proxy.ini" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Merge taskbar buttons: never
	.合并任务栏按钮：从不
#>
Function MergeTaskbarNever
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.MergeTaskbarNever)"
	if ($Enable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarGlomLevel' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name TaskbarGlomLevel -Force -ErrorAction SilentlyContinue
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Notification area: always show all icons
	.通知区域：始终显示所有图标
#>
Function NotificationAlways
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.NotificationAlways)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'EnableAutoTray' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name EnableAutoTray -Force -ErrorAction SilentlyContinue
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Open "Show all folders" in the navigation pane
	.在导航窗格中打开“显示所有文件夹”
#>
Function NavShowAll
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.NavShowAll)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'NavPaneExpandToCurrentFolder' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "NavPaneExpandToCurrentFolder" -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Hide the Cortana button on the taskbar
	.在任务栏上隐藏 Cortana 按钮
#>
Function Cortana
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Cortana)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "ShowCortanaButton" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Hide the Task View button on the taskbar
	.在任务栏上隐藏 任务视图 按钮
#>
Function TaskView
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	Write-Host "   $($lang.TaskView)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "ShowTaskViewButton" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "ShowTaskViewButton" -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Hide recently used files in Quick access
	.在快速访问中隐藏最近使用的文件
#>
Function QuickAccessFiles
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	Write-Host "   $($lang.QuickAccessFiles)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowRecent" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowRecent" -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Show frequently used folders in Quick access
	.在快速访问中显示常用文件夹
#>
Function QuickAccessFolders
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	Write-Host "   $($lang.QuickAccessFolders)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowFrequent" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowFrequent" -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "$env:appdata\Microsoft\Windows\Recent\*.*"
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Memory compression
	.内存压缩
#>
Function MemoryCompression
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.MemoryCompression)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Enable-MMAgent -mc
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Disable-MMAgent -mc
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Pre-fetch pre-launch
	.预取预启动
#>
Function Prelaunch
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Prelaunch)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Enable-MMAgent -ApplicationPreLaunch
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Disable-MMAgent -ApplicationPreLaunch
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.SSD
#>
Function SSD
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	Write-Host "   $($lang.OptSSD)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		fsutil behavior set DisableLastAccess 2 | Out-Null
		fsutil behavior set EncryptPagingFile 0 | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		fsutil behavior set DisableLastAccess 1 | Out-Null
		fsutil behavior set EncryptPagingFile 0 | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Program Compatibility Assistant
	.程序兼容性助手
#>
Function Compatibility
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Compatibility)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' -Name 'DisablePCA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Visual animation effect
	.视觉动画效果
#>
Function AnimationEffects 
{
	param
	(
		[switch]$Restore,
		[switch]$Optimize
	)

	Write-Host "   $($lang.AnimationEffects)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'EnableAeroPeek' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'AlwaysHibernateThumbnails' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "TurnOffSPIAnimations" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" -Name "VisualFXSetting" -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewAlphaSelect' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewShadow' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'IconsOnly' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop\WindowMetrics' -Name 'MinAnimate' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'UserPreferencesMask' -Value ([byte[]](0x9e,0x1e,0x07,0x80,0x12,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'DragFullWindows' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'FontSmoothing' -Value '2' -PropertyType String -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Red
	}

	if ($Optimize) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM") -ne $true) { New-Item "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM' -Name 'DisallowAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'EnableAeroPeek' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'AlwaysHibernateThumbnails' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'TurnOffSPIAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -Name 'VisualFXSetting' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarAnimations' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewAlphaSelect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewShadow' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'IconsOnly' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop\WindowMetrics' -Name 'MinAnimate' -Value '0' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'UserPreferencesMask' -Value ([byte[]](0x9e,0x1e,0x07,0x80,0x12,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'DragFullWindows' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'FontSmoothing' -Value '2' -PropertyType String -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.Disk Defragmentation Plan
	.磁盘碎片整理计划
#>
Function Defragmentation
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Defragmentation)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Enable-ScheduledTask -TaskPath "\Microsoft\Windows\Defrag\" -TaskName "ScheduledDefrag" | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Disable-ScheduledTask -TaskPath "\Microsoft\Windows\Defrag\" -TaskName "ScheduledDefrag" | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Photo preview
	.照片预览
#>
Function PhotoPreview
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PhotoPreview)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.jpg") -ne $true) { New-Item "HKCU:\Software\Classes\.jpg" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.jpeg") -ne $true) { New-Item "HKCU:\Software\Classes\.jpeg" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.gif") -ne $true) { New-Item "HKCU:\Software\Classes\.gif" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.png") -ne $true) { New-Item "HKCU:\Software\Classes\.png" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.bmp") -ne $true) { New-Item "HKCU:\Software\Classes\.bmp" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.tiff") -ne $true) { New-Item "HKCU:\Software\Classes\.tiff" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.ico") -ne $true) { New-Item "HKCU:\Software\Classes\.ico" -force -ea SilentlyContinue }
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.jpg' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.jpeg' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.gif' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.png' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.bmp' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.tiff' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.ico' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\Software\Classes\.jpg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.jpeg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.gif" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.png" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.bmp" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.tiff" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.ico" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Reduce the number of processors using RAM
	.降低 RAM 使用处理器数量
#>
Function RAM
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.RAM)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'SvcHostSplitThresholdInKB' -Value 3670016 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'WaitToKillServiceTimeout' -Value '5000' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'NetworkThrottlingIndex' -Value 10 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'SystemResponsiveness' -Value 20 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' -Name 'SearchOrderConfig' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name 'HiberbootEnabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Remove-ItemProperty -Name "PowerThrottlingOff" -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_Enabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_FSEBehaviorMode' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_AutoGameModeDefaultProfile' -Value ([byte[]](0x02,0x00,0x01,0x00,0x00,0x00,0xc4,0x20,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_GameModeRelatedProcesses' -Value ([byte[]](0x01,0x00,0x01,0x00,0x01,0x00,0x67,0x00,0x61,0x00,0x6d,0x00,0x65,0x00,0x70,0x00,0x61,0x00,0x6e,0x00,0x65,0x00,0x6c,0x00,0x2e,0x00,0x65,0x00,0x78,0x00,0x65,0x00,0x00,0x00,0xc9,0x00,0x4e,0x95,0x67,0x77,0xb0,0xeb,0x1e,0x03,0xd8,0xf1,0x1e,0x03,0x1e,0x00,0x00,0x00,0xb0,0xeb,0x1e,0x03,0x1e,0x00,0x00,0x00,0x0f,0x00,0x00,0x00,0x2c,0xea,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_HonorUserFSEBehaviorMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_DXGIHonorFSEWindowsCompatible' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_EFSEFeatureFlags' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name 'HibernateEnabledDefault' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\943c8cb6-6f93-4227-ad87-e9a3feec08d1' -Name 'Attributes' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'SvcHostSplitThresholdInKB' -Value 67108864 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'WaitToKillServiceTimeout' -Value '2000' -PropertyType String -Force -ea SilentlyContinue | out-null
		if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -force -ea SilentlyContinue }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'NetworkThrottlingIndex' -Value -1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'SystemResponsiveness' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' -Name 'SearchOrderConfig' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name 'HiberbootEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		if((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling") -ne $true) {  New-Item "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' -Name 'PowerThrottlingOff' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		if((Test-Path -LiteralPath "HKCU:\System\GameConfigStore") -ne $true) {  New-Item "HKCU:\System\GameConfigStore" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_Enabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_FSEBehaviorMode' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_AutoGameModeDefaultProfile' -Value ([byte[]](0x01,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_GameModeRelatedProcesses' -Value ([byte[]](0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_HonorUserFSEBehaviorMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_DXGIHonorFSEWindowsCompatible' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_EFSEFeatureFlags' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name 'HibernateEnabledDefault' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\943c8cb6-6f93-4227-ad87-e9a3feec08d1' -Name 'Attributes' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Storage Sense
	.存储感知
#>
Function StorageSense
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.StorageSense)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if (-not (Test-Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy))
		{
			New-Item -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		}
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -Name 01 -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if (-not (Test-Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy))
		{
			New-Item -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		}
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -Name 01 -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Delivery Optimization
	.传递优化
#>
Function Delivery
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Delivery)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -Path Registry::HKEY_USERS\S-1-5-20\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings -Name DownloadMode -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -Path Registry::HKEY_USERS\S-1-5-20\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings -Name DownloadMode -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Maximum password usage time is unlimited
	.密码最长使用时间为无限
#>
Function PwdUnlimited
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PwdUnlimited)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		net accounts /maxpwage:42 | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		net accounts /maxpwage:UNLIMITED | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Gamebar
#>
Function Gamebar
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Gamebar)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name AppCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name AudioCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name CursorCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name MicrophoneCaptureEnabled -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AppCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AudioCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'CursorCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'MicrophoneCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Game Mode
	.Game Mode
#>
Function GameMode
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.GameMode)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name CursorCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name MicrophoneCaptureEnabled -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\GameBar' -Name 'AutoGameModeEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\GameBar' -Name 'AllowAutoGameMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Game DVR and Game Bar
	.游戏 DVR 和游戏栏
#>
Function GameDVRAndBar
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.GameDVRAndBar)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Name AllowgameDVR -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Name 'AllowgameDVR' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	."Windows protects your PC" dialog
	."Windows 保护了您的 PC" 对话框
#>
Function Protected
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Protected)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments") -ne $true) { New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Add 15 file selection limit to hide context menu items
	.增加 15 个文件选择限制以隐藏上下文菜单项
#>
Function MultipleIncrease
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.MultipleIncrease)"
	if ($Enable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer" -Name MultipleInvokePromptMinimum -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'MultipleInvokePromptMinimum' -Value 999 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Autoplay
	.自动播放
#>
Function Autoplay
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Autoplay)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -Name "DisableAutoplay" -Type DWord -Value 0
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -Name "DisableAutoplay" -Type DWord -Value 1
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Run all drives automatically
	.自动运行所有驱动器
#>
Function Autorun
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Autorun)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer")) {
			New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" | Out-Null
		}
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun" -Type DWord -Value 255
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Error report
	.错误报告
#>
Function ErrorReporting
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ErrorReporting)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "Disabled" -ErrorAction SilentlyContinue

		Set-Service -Name "WerSvc" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
		Start-Service "WerSvc" -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "Disabled" -Type DWord -Value 1

		Set-Service -Name "WerSvc" -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
		Stop-Service "WerSvc" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.F8 boot menu option
	.F8 启动菜单选项
#>
Function F8BootMenu
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.F8BootMenu)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} bootmenupolicy Legacy | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} bootmenupolicy Standard | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Sent to
	.发送到
#>
Function SendTo
{
	Write-Host "   $($lang.SendTo)"
	Write-Host "   $($lang.Clean)".PadRight(22) -NoNewline
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\Mail Recipient.MAPIMail" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\邮件收件人.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\Fax Recipient.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\传真收件人.lnk" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.System logs
	.系统日志
#>
Function CleanSystemLog
{
	Write-Host "   $($lang.Logs)"
	Write-Host "   $($lang.Clean)".PadRight(22) -NoNewline
	Get-EventLog -LogName * | ForEach-Object { Clear-EventLog $_.Log }
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.WinSxS slimming
	.WinSxS 瘦身
#>
Function CleanSxS
{
	Write-Host "   $($lang.SxS)"
	Write-Host "   $($lang.Clean)".PadRight(22) -NoNewline
	Dism /Online /Cleanup-Image /StartComponentCleanup
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Notification Center
	.通知中心
#>
Function NotificationCenter
{
	param
	(
		[switch]$Restore,
		[switch]$Full,
		[switch]$Part
	)

	$Notifications = @(
#		"windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel" # Settings
		"microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowslive.calendar"    # Calendar
		"microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowslive.mail"        # Mail
		"Microsoft.MicrosoftEdge_8wekyb3d8bbwe!MicrosoftEdge"                                 # Edge
		"Microsoft.Windows.Cortana_cw5n1h2txyewy!CortanaUI"                                   # Cortana
		"Windows.SystemToast.AudioTroubleshooter"                                             # Audio
		"Windows.SystemToast.Suggested"                                                       # Suggested
		"Microsoft.WindowsStore_8wekyb3d8bbwe!App"                                            # Store
		"Windows.SystemToast.SecurityAndMaintenance"                                          # Security and Maintenance
		"Windows.SystemToast.WiFiNetworkManager"                                              # Wireless
		"Windows.SystemToast.HelloFace"                                                       # Windows Hello
		"Windows.SystemToast.RasToastNotifier"                                                # VPN
		"Windows.System.Continuum"                                                            # Tablet
		"Microsoft.BingNews_8wekyb3d8bbwe!AppexNews"                                          # News
		"Windows.SystemToast.BdeUnlock"                                                       # Bitlocker
		"Windows.SystemToast.BackgroundAccess"                                                # Battery Saver
		"Windows.Defender.SecurityCenter"                                                     # Security Center
		"Microsoft.Windows.Photos_8wekyb3d8bbwe!App"                                          # Photos
		"Microsoft.SkyDrive.Desktop"                                                          # OneDrive
#		"Windows.SystemToast.AutoPlay"                                                        # Autoplay
	)

	Write-Host "   $($lang.Notification)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\TrayNotify" -Name "PastIconsStream" -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\TrayNotify" -Name "IconStreams" -ErrorAction SilentlyContinue
		
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" -Name "ToastEnabled" -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -Name "DisableEnhancedNotifications" -ErrorAction SilentlyContinue
		Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		
		foreach ($Name in $Notifications) {
			New-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -Name Enabled -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		}
	
		netsh firewall set notifications mode=enable profile=all | Out-Null
		netsh firewall set opmode exceptions=enable | Out-Null
	}

	if ($Full) {
		Write-Host "   $($lang.Full)".PadRight(22) -NoNewline
		If (-not (Test-Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer")) {
			New-Item -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" | Out-Null
		}
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" -Name "ToastEnabled" -Type DWord -Value 0
	}

	if ($Part) {
		Write-Host "   $($lang.Part)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications' -Name 'DisableEnhancedNotifications' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableSoftLanding' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

		foreach ($Name in $Notifications)
		{
			if ((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name") -ne $true) {
				New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -force -ea SilentlyContinue | Out-Null
			}

			New-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -Name Enabled -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		}

		# 关闭 防火墙通知
		New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	RestartExplorer

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.System disk paging size
	.系统盘分页大小
#>
Function PagingSize
{
	param
	(
		[switch]$Enable,
		[switch]$Disable,
		[string]$size
	)

	Write-Host "   $($lang.PagingSize)"
	if ($Enable) {
		Write-Host "   $($lang.Setting) $($size)G".PadRight(22) -NoNewline
		switch ($size)
		{
			8 {
				New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("$($env:SystemDrive)\pagefile.sys 8192 8192") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
			}
			16 {
				New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("$($env:SystemDrive)\pagefile.sys 16384 16384") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
			}
		}
	}

	if ($Disable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("?:\pagefile.sys") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Enable 3389 remote desktop
	.启用 3389 远程桌面
#>
Function RemoteDesktop {
	Write-Host "   $($lang.StRemote)"
	Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\TermService") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Services\TermService" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services\TermService' -Name 'Start' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\MpsSvc") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Services\MpsSvc" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services\MpsSvc' -Name 'Start' -Value 4 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Stop-Service "MpsSvc" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	netsh advfirewall firewall add rule name="Open Port 3389" dir=in action=allow protocol=TCP localport=3389 | Out-Null
	Start-Service "TermService" -ErrorAction SilentlyContinue | Out-Null

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Turn on SMB file sharing
	.打开 SMB 文件共享
#>
Function SMBFileShare {
	Write-Host "   $($lang.StSMB)"
	Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
	<#
		.Add 'firewall rules'
		.添加 '防火墙规则'
	#>
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 137" dir=in action=allow protocol=UDP localport=137 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 137" dir=out action=allow protocol=UDP localport=137 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 138" dir=in action=allow protocol=UDP localport=138 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 138" dir=out action=allow protocol=UDP localport=138 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 139" dir=in action=allow protocol=TCP localport=139 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 139" dir=out action=allow protocol=TCP localport=139 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 445" dir=in action=allow protocol=TCP localport=445 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 445" dir=out action=allow protocol=TCP localport=445 | Out-Null

	<#
		.Enable 'Guest User'
		.启用 'Guest 用户'
	#>
	Net User Guest /Active:yes | Out-Null

	<#
		.Set the group policy 'Deny guest users in this computer from accessing the network'
		.设置组策略 '拒绝从网络访问此计算机中的 Guest 用户'
	#>
	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'forceguest' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet001\Control\Lsa") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet001\Control\Lsa" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet001\Control\Lsa' -Name 'forceguest' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	<#
		.Group Policy 'Guests Only-Authenticate local users as guests'
		.组策略 '仅来宾 - 对本地用户进行身份验证，其身份为来宾'
	#>
	Remove-Item -Path "$($env:TEMP)\share.inf" -ErrorAction SilentlyContinue
@"
[Version] 
signature="`$CHICAGO$" 
Revision=1 

[Privilege Rights] 
SeDenyNetworkLogonRight = 
"@ | Out-File -FilePath "$($env:TEMP)\share.inf" -Encoding Ascii
	secedit /configure /db "$($env:TEMP)\share.sdb" /cfg "$($env:TEMP)\share.inf"
	Remove-Item -Path "$($env:TEMP)\share.inf" -ErrorAction SilentlyContinue
	Remove-Item -Path "$($env:TEMP)\share.sdb" -ErrorAction SilentlyContinue

	<#
		.Disable the 'Psec Policy Agent (IP security policy) service'
		.禁用 'Psec Policy Agent（IP安全策略）服务'
	#>
	Set-Service -Name "PolicyAgent" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
	Stop-Service "PolicyAgent" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	<#
		.Disable the 'Server (Shared Service)'
		.禁用 'Server（共享服务）'
	#>
	Set-Service -Name "ShareAccess" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
	Stop-Service "ShareAccess" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	<#
		.Enable 'Computer Browser (browsing service)'
		.启用 'Computer Browser（浏览服务）'
	#>
	Set-Service -Name "Browser" -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
	Start-Service "Browser" -ErrorAction SilentlyContinue | Out-Null

	<#
		.Disable the 'MpsSvc Service'
		.禁用 'MpsSvc 服务'
	#>
	Set-Service -Name "MpsSvc" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
	Stop-Service "MpsSvc" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	<#
		.Enable 'LanmanServer service'
		.启用 'LanmanServer 服务'
	#>
	Set-Service -Name "LanmanServer" -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
	Start-Service "LanmanServer" -ErrorAction SilentlyContinue | Out-Null
	gpupdate /force | out-null

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Remove Desktop from This PC
	.从这台电脑上删除桌面
#>
Function ThisPCDesktop
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationDesktop))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
        Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Remove Documents from This PC
	.从这台电脑上删除文档
#>
Function ThisPCDocument
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationDocuments))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A8CDFF1C-4878-43be-B5FD-F8091C1C60D0}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A8CDFF1C-4878-43be-B5FD-F8091C1C60D0}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A8CDFF1C-4878-43be-B5FD-F8091C1C60D0}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A8CDFF1C-4878-43be-B5FD-F8091C1C60D0}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.Remove Downloads from This PC
	.从这台 PC 中删除下载
#>
Function ThisPCDownload
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationDownloads))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{374DE290-123F-4565-9164-39C4925E467B}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{374DE290-123F-4565-9164-39C4925E467B}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{374DE290-123F-4565-9164-39C4925E467B}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{374DE290-123F-4565-9164-39C4925E467B}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Remove Music from This PC
	.从这台电脑中删除音乐
#>
Function ThisPCMusic
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationMusic))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{1CF1260C-4DD0-4ebb-811F-33C572699FDE}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{1CF1260C-4DD0-4ebb-811F-33C572699FDE}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{1CF1260C-4DD0-4ebb-811F-33C572699FDE}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{1CF1260C-4DD0-4ebb-811F-33C572699FDE}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Remove Pictures from This PC
	.从这台电脑中删除图片
#>
Function ThisPCPicture
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationPictures))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3ADD1653-EB32-4cb0-BBD7-DFA0ABB5ACCA}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3ADD1653-EB32-4cb0-BBD7-DFA0ABB5ACCA}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3ADD1653-EB32-4cb0-BBD7-DFA0ABB5ACCA}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3ADD1653-EB32-4cb0-BBD7-DFA0ABB5ACCA}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Remove Videos from This PC
	.从这台 PC 中删除视频
#>
Function ThisPCVideo
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationVideos))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A0953C92-50DC-43bf-BE83-3742FED03C9C}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A0953C92-50DC-43bf-BE83-3742FED03C9C}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A0953C92-50DC-43bf-BE83-3742FED03C9C}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A0953C92-50DC-43bf-BE83-3742FED03C9C}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Remove Videos from This PC
	.从这台 PC 中删除视频
#>
Function ThisPC3D
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.Location3D))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.All icons in the taskbar
	.任务栏所有图标
#>
Function ResetTaskBar
{
	Write-Host "   $($lang.Reset) $($lang.TaskBar)" -ForegroundColor Green
	Write-Host "   - $($lang.Delete) $($lang.TaskBar)"
	Remove-Item -Path "$env:AppData\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\*.*"
	Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	if (Test-Path "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\syspin")\syspin.exe" -PathType Leaf) {
		Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\syspin")\syspin.exe" -WindowStyle Hidden -ArgumentList """$($env:systemroot)\explorer.exe"" ""5386""" -Wait
	}
	RestartExplorer

	Write-Host "   - $($lang.ResetExplorer)`n"
}


<#
	.Rearrange the desktop icons by name
	.重新按名称排列桌面图标
#>
Function ResetDesktop
{
	$ResetDesktopReg = @(
		'HKCU:\Software\Microsoft\Windows\Shell\BagMRU'
		'HKCU:\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Microsoft\Windows\ShellNoRoam\Bags'
		'HKCU:\Software\Microsoft\Windows\ShellNoRoam\BagMRU'
		'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
		'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
	)

	Write-Host "   $($lang.ResetDesk)" -ForegroundColor Green
	Write-Host "   - $($lang.ResetFolder)"
	foreach ($item in $ResetDesktopReg) {
		Remove-Item -Path $item -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	RestartExplorer

	Write-Host "   - $($lang.ResetExplorer)`n"
	RefreshIconCache
}


<#
	.Refresh icon cache
	.刷新图标缓存
#>
Function RefreshIconCache
{
	$code = @'
	private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
	private const int WM_SETTINGCHANGE = 0x1a;
	private const int SMTO_ABORTIFHUNG = 0x0002;

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
private static extern IntPtr SendMessageTimeout ( IntPtr hWnd, int Msg, IntPtr wParam, string lParam, uint fuFlags, uint uTimeout, IntPtr lpdwResult );

[System.Runtime.InteropServices.DllImport("Shell32.dll")] 
private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

public static void Refresh() {
	SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);
	SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);
}
'@

	Add-Type -MemberDefinition $code -Namespace MyWinAPI -Name Explorer
	[MyWinAPI.Explorer]::Refresh()
}

Export-ModuleMember -Function * -Alias *