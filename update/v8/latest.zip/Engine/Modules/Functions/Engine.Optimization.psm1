﻿<#
 .Synopsis
  Optimize the system

 .Description
  Optimize the system Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Optimize the system user interface
	.优化系统用户界面
#>
Function Optimization
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title "$($lang.Optimize) $($lang.System)"
	Write-Host "   $($lang.Optimize) $($lang.System)`n   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIOptOSClick = {
		if ($GUIOptOS.Checked) {
			$GUIOptOSPanel.Enabled = $True
		} else {
			$GUIOptOSPanel.Enabled = $False
		}
	}
	$GUIPrivateClick = {
		if ($GUIPrivate.Checked) {
			$GUIPrivatePanel.Enabled = $True
		} else {
			$GUIPrivatePanel.Enabled = $False
		}
	}
	$GUIOptNotificationClick = {
		if ($GUIOptNotification.Checked) {
			$GUIOptNotificationPanel.Enabled = $True
		} else {
			$GUIOptNotificationPanel.Enabled = $False
		}
	}
	$GUIOptPagingSizeClick = {
		if ($GUIOptPagingSize.Checked) {
			$GUIOptPagingSizePanel.Enabled = $True
		} else {
			$GUIOptPagingSizePanel.Enabled = $False
		}
	}
	$GUIOptOtherClick = {
		if ($GUIOptOther.Checked) {
			$GUIOptOtherPanel.Enabled = $True
		} else {
			$GUIOptOtherPanel.Enabled = $False
		}
	}
	$GUIOptClearClick = {
		if ($GUIOptClear.Checked) {
			$GUIOptClearPanel.Enabled = $True
		} else {
			$GUIOptClearPanel.Enabled = $False
		}
	}
	$GUIOptCanelClick = { 
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIOpt.Close()
	}
	$GUIOptRestoreClick = {
		$GUIOpt.Hide()
		if ($GUIOptOS.Enabled) {
			if ($GUIOptOS.Checked) {
				if ($GUIOptAddOwnership.Checked) { TakeOwnership -Remove }
				if ($GUIOptKeepSpace.Checked) { KeepSpace -Enable }
				if ($GUIOptHibernation.Checked) { Hibernation -Enable }
				if ($GUIOptPowerSupply.Checked) { PowerSupply -Restore }
				if ($GUIOptAppRestartScreen.Checked) { AppRestartScreen -Enable }
				if ($GUIOptShortcutArrow.Checked) { ShortcutArrow -Enable }
				if ($GUIOptNumLock.Checked) { Numlock -Disable }
				if ($GUIOptFileExtensions.Checked) { FileExtensions -Hide }
				if ($GUIOptSearchBox.Checked) {
					SearchBox -SearchBox
					RestartExplorer
				}
				if ($GUIOptUAC.Checked)  { UACNever -Enable }
				if ($GUIOptFileTransfer.Checked) { FileTransferDialog -Simple }
				if ($GUIOptSmartScreenApps.Checked) { SmartScreenApps -Enable }
				if ($GUIOptSmartScreenSafe.Checked) { SmartScreenSafe -Enable }
				if ($GUIOptMaintain.Checked) { Maintain -Enable }
				if ($GUIOptExperience.Checked) { Experience -Enable }
				if ($GUIOptDefragmentation.Checked) { Defragmentation -Enable }
				if ($GUIOptCompatibility.Checked) { Compatibility -Enable }
				if ($GUIOptAnimationEffects.Checked) { AnimationEffects -Restore }
				if ($GUIOptSafetyWarnings.Checked) { SafetyWarnings -Enable }
				if ($GUIOptQOS.Checked) { QOS -Enable }
				if ($GUIOptNetworkTuning.Checked) { NetworkTuning -Enable }
				if ($GUIOptECN.Checked) { ECN -Enable }
				if ($GUIOptErrorRecovery.Checked) { ErrorRecovery -Enable }
				if ($GUIOptDEP.Checked) { DEPPAE -Enable }
				if ($GUIOptPowerFailure.Checked) { PowerFailure -Enable }
				if ($GUIOptIEAutoSet.Checked) { AutoDetect -Enable }
				if ($GUIOptScheduledTasks.Checked) { ScheduledTasks -Restore }
				if ($GUIOptMergeTaskbarNever.Checked) { MergeTaskbarNever -Disable }
				if ($GUIOptNotificationAlways.Checked) { NotificationAlways -Disable }
				if ($GUIOptNavShowAll.Checked) { NavShowAll -Disable }
				if ($GUIOptCortana.Checked) {
					Cortana -Enable
					RestartExplorer
				}
				if ($GUIOptTaskView.Checked) { TaskView -Show }
				if ($GUIOptPwdUnlimited.Checked) { PwdUnlimited -Enable }
				if ($GUIOptRAM.Checked) { RAM -Enable }
				if ($GUIOptStorageSense.Checked) { StorageSense -Enable }
				if ($GUIOptDelivery.Checked) { Delivery -Enable }
				if ($GUIOptPhotoPreview.Checked) { PhotoPreview -Disable }
				if ($GUIOptQuickAccessFiles.Checked) { QuickAccessFiles -Show }
				if ($GUIOptQuickAccessFolders.Checked) { QuickAccessFolders -Show }
				if ($GUIOptGamebar.Checked) { Gamebar -Enable }
				if ($GUIOptGameMode.Checked) { GameMode -Enable }
				if ($GUIOptProtected.Checked) { Protected -Enable }
				if ($GUIOptMultipleIncrease.Checked) { MultipleIncrease -Enable }
				if ($GUIOptAutoplay.Checked) { Autoplay -Enable }
				if ($GUIOptAutorun.Checked) { Autorun -Enable }
				if ($GUIOptErrorReporting.Checked) { ErrorReporting -Enable }
				if ($GUIOptF8BootMenu.Checked) { F8BootMenu -Enable }
				if ($GUIOptSSD.Checked) { SSD -Enable }
				if ($GUIOptMemoryCompression.Checked) { MemoryCompression -Enable }
				if ($GUIOptPrelaunch.Checked) { Prelaunch -Enable }
				if ($GUIOptUser.Checked) { OptUser -Restore }
				if ($GUIOptUpdate.Checked) { OptUpdate -Restore }
			}
		}

		<#
			.隐私类
		#>
		if ($GUIPrivate.Enabled) {
			if ($GUIPrivate.Checked) {
				if ($GUIOptFixPrivacy.Checked) { FixPrivacy -Restore }
				if ($GUIOptTimelineTime.Checked) { TimelineTime -Enable }
				if ($GUIOptCollectActivity.Checked) { CollectActivity -Enable }
			}
		}

		<#
			.系统盘分页大小
		#>
		if ($GUIOptPagingSize.Enabled) {
			if ($GUIOptPagingSize.Checked) {
				PagingSize -Disable
			}
		}

		<#
			.通知中心
		#>
		if ($GUIOptNotification.Enabled) {
			if ($GUIOptNotification.Checked) {
				NotificationCenter -Restore
			}
		}

		if ($GUIOptTaskBar.Checked) { ResetTaskBar }
		if ($GUIOptResetDesk.Checked) { ResetDesktop }
		gpupdate /force | out-null
		$GUIOpt.Close()
	}
	$GUIOptOKClick = {
		$GUIOpt.Hide()

		if ($GUIOptOS.Enabled) {
			if ($GUIOptOS.Checked) {
				if ($GUIOptAddOwnership.Checked) {
					TakeOwnership -Remove
					TakeOwnership -Add
				}
				if ($GUIOptKeepSpace.Checked) { KeepSpace -Disable }
				if ($GUIOptHibernation.Checked) { Hibernation -Disable }
				if ($GUIOptPowerSupply.Checked) { PowerSupply -Optimize }
				if ($GUIOptAppRestartScreen.Checked) { AppRestartScreen -Disable }
				if ($GUIOptShortcutArrow.Checked) { ShortcutArrow -Disable }
				if ($GUIOptNumLock.Checked) { Numlock -Enable }
				if ($GUIOptFileExtensions.Checked) { FileExtensions -Show }
				if ($GUIOptSearchBox.Checked) {
					SearchBox -SearchIcon
					RestartExplorer
				}
				if ($GUIOptUAC.Checked) { UACNever -Disable }
				if ($GUIOptFileTransfer.Checked) { FileTransferDialog -Detailed }
				if ($GUIOptSmartScreenApps.Checked) { SmartScreenApps -Disable }
				if ($GUIOptSmartScreenSafe.Checked) { SmartScreenSafe -Disable }
				if ($GUIOptMaintain.Checked) { Maintain -Disable }
				if ($GUIOptExperience.Checked) { Experience -Disable }
				if ($GUIOptDefragmentation.Checked) { Defragmentation -Disable }
				if ($GUIOptCompatibility.Checked) { Compatibility -Disable }
				if ($GUIOptAnimationEffects.Checked) { AnimationEffects -Optimize }
				if ($GUIOptSafetyWarnings.Checked) { SafetyWarnings -Disable }
				if ($GUIOptQOS.Checked) { QOS -Disable }
				if ($GUIOptNetworkTuning.Checked) { NetworkTuning -Disable }
				if ($GUIOptECN.Checked) { ECN -Disable }
				if ($GUIOptErrorRecovery.Checked) { ErrorRecovery -Disable }
				if ($GUIOptDEP.Checked) { DEPPAE -Disable }
				if ($GUIOptPowerFailure.Checked) { PowerFailure -Disable }
				if ($GUIOptIEAutoSet.Checked) { AutoDetect -Disable }
				if ($GUIOptIEProxy.Checked) { IEProxy }
				if ($GUIOptScheduledTasks.Checked) { ScheduledTasks -Disable }
				if ($GUIOptMergeTaskbarNever.Checked) { MergeTaskbarNever -Enable }
				if ($GUIOptNotificationAlways.Checked) { NotificationAlways -Enable }
				if ($GUIOptNavShowAll.Checked) { NavShowAll -Enable }
				if ($GUIOptCortana.Checked) {
					Cortana -Disable
					RestartExplorer
				}
				if ($GUIOptTaskView.Checked) { TaskView -Hide }
				if ($GUIOptPwdUnlimited.Checked) { PwdUnlimited -Disable }
				if ($GUIOptRAM.Checked) { RAM -Disable }
				if ($GUIOptStorageSense.Checked) { StorageSense -Disable }
				if ($GUIOptDelivery.Checked) { Delivery -Disable }
				if ($GUIOptPhotoPreview.Checked) { PhotoPreview -Enable }
				if ($GUIOptQuickAccessFiles.Checked) { QuickAccessFiles -Hide }
				if ($GUIOptQuickAccessFolders.Checked) { QuickAccessFolders -Hide }
				if ($GUIOptGamebar.Checked) { Gamebar -Disable }
				if ($GUIOptGameMode.Checked) { GameMode -Disable }
				if ($GUIOptProtected.Checked) { Protected -Disable }
				if ($GUIOptMultipleIncrease.Checked) { MultipleIncrease -Disable }
				if ($GUIOptAutoplay.Checked) { Autoplay -Disable }
				if ($GUIOptAutorun.Checked) { Autorun -Disable }
				if ($GUIOptErrorReporting.Checked) { ErrorReporting -Disable }
				if ($GUIOptF8BootMenu.Checked) { F8BootMenu -Disable }
				if ($GUIOptSSD.Checked) { SSD -Disable }
				if ($GUIOptMemoryCompression.Checked) { MemoryCompression -Disable }
				if ($GUIOptPrelaunch.Checked) { Prelaunch -Disable }
				if ($GUIOptUser.Checked) { OptUser -Disable }
				if ($GUIOptUpdate.Checked) { OptUpdate -Disable }
			}
		}

		<#
			.隐私类
		#>
		if ($GUIPrivate.Enabled) {
			if ($GUIPrivate.Checked) {
				if ($GUIOptFixPrivacy.Checked) { FixPrivacy -Disable }
				if ($GUIOptTimelineTime.Checked) { TimelineTime -Disable }
				if ($GUIOptCollectActivity.Checked) { CollectActivity -Disable }
			}
		}

		<#
			.通知中心
		#>
		if ($GUIOptNotification.Enabled) {
			if ($GUIOptNotification.Checked) {
				if ($GUIOptNotificationFull.Checked) {
					NotificationCenter -Restore
					NotificationCenter -Full
				}
				if ($GUIOptNotificationPart.Checked) {
					NotificationCenter -Restore
					NotificationCenter -Part
				}
			}
		}

		<#
			.系统盘分页大小
		#>
		if ($GUIOptPagingSize.Enabled) {
			if ($GUIOptPagingSize.Checked) {
				if ($GUIOptPagingSizeLow.Checked) { PagingSize -Enable -size 8 }
				if ($GUIOptPagingSizeHigh.Checked) { PagingSize -Enable -size 16 }
			}
		}

		<#
			.其它类
		#>
		if ($GUIOptOther.Enabled) {
			if ($GUIOptOther.Checked) {
				if ($GUIOptRDS.Checked) { RemoteDesktop }
				if ($GUIOptSMB.Checked) { SMBFileShare }
			}
		}

		<#
			.清理类
		#>
		if ($GUIOptClear.Enabled) {
			if ($GUIOptClear.Checked) {
				if ($GUIOptSendTo.Checked) { SendTo }
				if ($GUIOptCleanSystemLog.Checked) { CleanSystemLog }
				if ($GUIOptCleanSxS.Checked) { CleanSxS }
			}
		}

		if ($GUIOptTaskBar.Checked) { ResetTaskBar }
		if ($GUIOptResetDesk.Checked) { ResetDesktop }

		gpupdate /force | out-null
		$GUIOpt.Close()
	}
	$GUIOpt            = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 600
		Width          = 980
		Text           = "$($lang.Optimize) $($lang.System)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}

	<#
		.通知中心
	#>
	$GUIOptNotification = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Notification)"
		Location       = '505,6'
		ForeColor      = "#008000"
		Checked        = $True
		add_click      = $GUIOptNotificationClick
	}
	$GUIOptNotificationPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 56
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 0
		Location       = '510,30'
	}
	$GUIOptNotificationFull = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Close) $($lang.Notification) ( $($lang.Full) )"
	}
	$GUIOptNotificationPart = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Close) $($lang.Notification) ( $($lang.Part) )"
		Checked        = $true
	}

	<#
		.系统盘分页大小
	#>
	$GUIOptPagingSize  = New-Object System.Windows.Forms.CheckBox -Property @{
		autoSize       = $true
		Text           = "$($lang.PagingSize) ( $($lang.Restart) )"
		Location       = '505,100'
		ForeColor      = "#008000"
		Checked        = $True
		add_Click      = $GUIOptPagingSizeClick
	}
	$GUIOptPagingSizePanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 56
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 0
		Location       = '510,123'
	}
	$GUIOptPagingSizeLow = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Setting) $($lang.PagingSize) (8G)"
		Checked        = $true
	}
	$GUIOptPagingSizeHigh = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Setting) $($lang.PagingSize) (16G)"
	}

	<#
		.其它类
	#>
	$GUIOptOther       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Related)"
		Location       = '505,195'
		Checked        = $True
		add_Click      = $GUIOptOtherClick
	}
	$GUIOptOtherPanel  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 56
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 0
		Location       = '510,220'
	}
	$GUIOptRDS         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = $($lang.StRemote)
	}
	$GUIOptSMB         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = $($lang.StSMB)
	}
	$GUIOptSMBTips     = New-Object System.Windows.Forms.Label -Property @{
		Height         = 36
		Width          = 415
		Text           = $lang.StSMBTips
		Padding        = "15,0,15,0"
	}

	<#
		.清理类
	#>
	$GUIOptClear       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Cleanup)"
		Location       = '505,295'
		Checked        = $True
		add_Click      = $GUIOptClearClick
	}
	$GUIOptClearPanel  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 56
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 0
		Location       = '510,320'
	}
	$GUIOptSendTo      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = $($lang.SendTo)
		Checked        = $true
	}
	$GUIOptCleanSystemLog = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = $($lang.Logs)
		Checked        = $true
	}
	$GUIOptCleanSxS    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = $($lang.SxS)
	}

	<#
		.优化类
	#>
	$GUIOptOS          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Optimize)"
		Location       = '10,6'
		Checked        = $True
		add_click      = $GUIOptOSClick
	}
	$GUIOptOSPanel     = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 375
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 0
		Location       = '16,30'
	}
	$GUIOptAddOwnership = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.AddTo) $($lang.AddOwnership)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptKeepSpace   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Close) $($lang.KeepSpace)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptHibernation = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Close) $($lang.Hibernation)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPowerSupply = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Setting) $($lang.PowerSupply)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptAppRestartScreen = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.AppRestartScreen)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptShortcutArrow = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Delete) $($lang.ShortcutArrow)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptNumLock     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Setting) $($lang.NumLock)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptFileExtensions = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.FileExtensions)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptSearchBox   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Setting) $($lang.SearchBox)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptUAC         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Setting) $($lang.UAC)$($lang.UACNever)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptFileTransfer = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Setting) $($lang.FileTransfer)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptSmartScreenApps = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.SmartScreenApps)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptSmartScreenSafe = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.SmartScreenSafe)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptMaintain    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Close) $($lang.Maintain)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptExperience  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Close) $($lang.Experience)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptDefragmentation = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Defragmentation)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptCompatibility = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Close) $($lang.Compatibility)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptAnimationEffects = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Optimize) $($lang.AnimationEffects)"
		Checked        = $true
	}
	$GUIOptSafetyWarnings = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.SafetyWarnings)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptQOS         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.QOS)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptNetworkTuning = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Optimize) $($lang.NetworkTuning)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptECN         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.ECN)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptErrorRecovery = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Close) $($lang.ErrorRecovery)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptDEP         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.DEP) ( $($lang.Restart) )"
		ForeColor      = "#008000"
	}
	$GUIOptPowerFailure = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Close) $($lang.PowerFailure)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptIEAutoSet   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.IEAutoSet)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptIEProxy     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Restore) $($lang.IEProxy)"
	}
	$GUIOptScheduledTasks = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.ScheduledTasks)"
		Checked        = $true
	}
	$GUIOptMergeTaskbarNever = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Setting) $($lang.MergeTaskbarNever)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptNotificationAlways = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Setting) $($lang.NotificationAlways)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptNavShowAll  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.NavShowAll)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptCortana     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = $lang.Cortana
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptTaskView    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = $lang.TaskView
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPwdUnlimited = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Setting) $($lang.PwdUnlimited)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptRAM         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.RAM)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptStorageSense = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.StorageSense)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptDelivery    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Delivery)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPhotoPreview = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Enable) $($lang.PhotoPreview)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptQuickAccessFiles = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.QuickAccessFiles)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptQuickAccessFolders = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.QuickAccessFolders)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptGamebar     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Gamebar)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptGameMode    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.GameMode)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptProtected   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Protected)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptMultipleIncrease = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.MultipleIncrease)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptAutoplay    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Autoplay)"
		ForeColor      = "#008000"
	}
	$GUIOptAutorun     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Autorun)"
		ForeColor      = "#008000"
	}
	$GUIOptErrorReporting = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.ErrorReporting)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptF8BootMenu  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.F8BootMenu)"
		ForeColor      = "#008000"
	}
	$GUIOptSSD         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Optimize) $($lang.OptSSD)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptMemoryCompression = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.MemoryCompression)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptPrelaunch   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Disable) $($lang.Prelaunch)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptUser        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Optimize) $($lang.OptUser)"
		Checked        = $true
	}
	$GUIOptUpdate      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 32
		Width          = 415
		Text           = "$($lang.Optimize) $($lang.OptUpdate)"
		Checked        = $true
	}
	
	<#
		.隐私类
	#>
	$GUIPrivate        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 390
		Text           = "$($lang.FixPrivacy)"
		Location       = '10,425'
		Checked        = $True
		add_click      = $GUIPrivateClick
	}
	$GUIPrivatePanel   = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 105
		Width          = 440
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 0
		Location       = '16,450'
	}
	$GUIOptFixPrivacy  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 415
		Text           = "$($lang.Optimize) $($lang.FixPrivacy)"
		Checked        = $true
	}
	$GUIOptTimelineTime = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 415
		Text           = "$($lang.Disable) $($lang.TimelineTime)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIOptCollectActivity = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 415
		Text           = "$($lang.Disable) $($lang.CollectActivity)"
		Checked        = $true
		ForeColor      = "#008000"
	}

	$GUIOptSortName    = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 395
		Text           = $lang.AdvOption
		Location       = '505,400'
	}
	$GUIOptTaskBar     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = "$($lang.Reset) $($lang.TaskBar)"
		Location       = '525,423'
	}
	$GUIOptResetDesk   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 415
		Text           = $lang.ResetDesk
		Location       = '525,450'
	}
	$GUIOptTips        = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 415
		Text           = $lang.OptimizationTips
		Location       = '505,488'
	}
	$GUIOptReset       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "505,515"
		Height         = 36
		Width          = 145
		add_Click      = $GUIOptRestoreClick
		Text           = $lang.Restore
	}
	$GUIOptOK          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "655,515"
		Height         = 36
		Width          = 145
		add_Click      = $GUIOptOKClick
		Text           = $lang.OK
	}
	$GUIOptCanel       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "806,515"
		Height         = 36
		Width          = 145
		add_Click      = $GUIOptCanelClick
		Text           = $lang.Cancel
	}

	$GUIOpt.controls.AddRange((
		$GUIOptOS,
		$GUIOptOSPanel,
		$GUIPrivate,
		$GUIPrivatePanel,
		$GUIOptNotification,
		$GUIOptNotificationPanel,
		$GUIOptPagingSize,
		$GUIOptPagingSizePanel,
		$GUIOptOther,
		$GUIOptOtherPanel,
		$GUIOptClear,
		$GUIOptClearPanel,
		$GUIOptSortName,
		$GUIOptTaskBar,
		$GUIOptResetDesk,
		$GUIOptTips,
		$GUIOptReset,
		$GUIOptOK,
		$GUIOptCanel
	))

	<#
		.通知中心
	#>
	$GUIOptNotificationPanel.controls.AddRange((
		$GUIOptNotificationFull,
		$GUIOptNotificationPart
	))

	$GUIOptClearPanel.controls.AddRange((
		$GUIOptSendTo,
		$GUIOptCleanSystemLog,
		$GUIOptCleanSxS
	))

	$GUIOptOtherPanel.controls.AddRange((
		$GUIOptRDS,
		$GUIOptSMB,
		$GUIOptSMBTips
	))

	$GUIOptOSPanel.controls.AddRange((
		$GUIOptAddOwnership,
		$GUIOptKeepSpace,
		$GUIOptHibernation,
		$GUIOptPowerSupply,
		$GUIOptAppRestartScreen,
		$GUIOptShortcutArrow,
		$GUIOptNumLock,
		$GUIOptFileExtensions,
		$GUIOptSearchBox,
		$GUIOptUAC,
		$GUIOptFileTransfer,
		$GUIOptSmartScreenApps,
		$GUIOptSmartScreenSafe,
		$GUIOptMaintain,
		$GUIOptExperience,
		$GUIOptDefragmentation,
		$GUIOptCompatibility,
		$GUIOptAnimationEffects,
		$GUIOptSafetyWarnings,
		$GUIOptQOS,
		$GUIOptNetworkTuning,
		$GUIOptECN,
		$GUIOptErrorRecovery,
		$GUIOptDEP,
		$GUIOptPowerFailure,
		$GUIOptIEAutoSet,
		$GUIOptIEProxy,
		$GUIOptScheduledTasks,
		$GUIOptMergeTaskbarNever,
		$GUIOptNotificationAlways,
		$GUIOptNavShowAll,
		$GUIOptCortana,
		$GUIOptTaskView,
		$GUIOptPwdUnlimited,
		$GUIOptRAM,
		$GUIOptStorageSense,
		$GUIOptDelivery,
		$GUIOptPhotoPreview,
		$GUIOptQuickAccessFiles,
		$GUIOptQuickAccessFolders,
		$GUIOptGamebar,
		$GUIOptGameMode,
		$GUIOptProtected,
		$GUIOptMultipleIncrease,
		$GUIOptAutoplay,
		$GUIOptAutorun,
		$GUIOptErrorReporting,
		$GUIOptF8BootMenu,
		$GUIOptSSD,
		$GUIOptMemoryCompression,
		$GUIOptPrelaunch,
		$GUIOptUser,
		$GUIOptUpdate
	))

	$GUIOptPagingSizePanel.controls.AddRange((
		$GUIOptPagingSizeLow,
		$GUIOptPagingSizeHigh
	))

	<#
		.添加：隐私类
	#>
	$GUIPrivatePanel.controls.AddRange((
		$GUIOptFixPrivacy,
		$GUIOptTimelineTime,
		$GUIOptCollectActivity
	))

	<#
		.右键菜单：优化类
	#>
	$GUIOptMenuAllSelClick = {
		$GUIOptOSPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true }
		}
	}
	$GUIOptMenuAllClearClick = {
		$GUIOptOSPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false }
		}
	}
	$GUIOptMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptMenu.Items.Add($lang.AllSel).add_Click($GUIOptMenuAllSelClick)
	$GUIOptMenu.Items.Add($lang.AllClear).add_Click($GUIOptMenuAllClearClick)
	$GUIOptOSPanel.ContextMenuStrip = $GUIOptMenu

	<#
		.右键菜单：隐私设置
	#>
	$GUIOptPriavteMenuAllSelClick = {
		$GUIPrivatePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true }
		}
	}
	$GUIOptPriavteMenuAllClearClick = {
		$GUIPrivatePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false }
		}
	}
	$GUIOptPriavteMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptPriavteMenu.Items.Add($lang.AllSel).add_Click($GUIOptPriavteMenuAllSelClick)
	$GUIOptPriavteMenu.Items.Add($lang.AllClear).add_Click($GUIOptPriavteMenuAllClearClick)
	$GUIPrivatePanel.ContextMenuStrip = $GUIOptPriavteMenu

	<#
		.右键菜单：其它
	#>
	$GUIOptOtherMenuAllSelClick = {
		$GUIOptOtherPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true }
		}
	}
	$GUIOptOtherMenuAllClearClick = {
		$GUIOptOtherPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false }
		}
	}
	$GUIOptOtherMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptOtherMenu.Items.Add($lang.AllSel).add_Click($GUIOptOtherMenuAllSelClick)
	$GUIOptOtherMenu.Items.Add($lang.AllClear).add_Click($GUIOptOtherMenuAllClearClick)
	$GUIOptOtherPanel.ContextMenuStrip = $GUIOptOtherMenu

	<#
		.右键菜单：清理
	#>
	$GUIOptCleanMenuAllSelClick = {
		$GUIOptClearPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true }
		}
	}
	$GUIOptCleanMenuAllClearClick = {
		$GUIOptClearPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false }
		}
	}
	$GUIOptCleanMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptCleanMenu.Items.Add($lang.AllSel).add_Click($GUIOptCleanMenuAllSelClick)
	$GUIOptCleanMenu.Items.Add($lang.AllClear).add_Click($GUIOptCleanMenuAllClearClick)
	$GUIOptClearPanel.ContextMenuStrip = $GUIOptCleanMenu


	$NoSelectPowerSupply = @(8, 9, 10, 11, 14)
	Get-CimInstance -ClassName Win32_SystemEnclosure | ForEach-Object {
		if ($NoSelectPowerSupply -contains $_.SecurityStatus) {
			$GUIOptHibernation.Checked = $False
			$GUIOptPowerSupply.Checked = $False
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIOpt.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIOpt.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$GUIOpt.FormBorderStyle = 'Fixed3D'
	$GUIOpt.ShowDialog() | Out-Null

	if ( -not ($Force)) {
		ToMainpage -wait 2
	}
}

Export-ModuleMember -Function * -Alias *