﻿<#
 .Synopsis
  Optimize the system

 .Description
  Optimize the system Feature Modules
#>

<#
	.Optimize the system user interface
	.优化系统用户界面
#>
Function Optimization
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title "$($lang.Optimize) $($lang.System)"
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIOptMenuAllSelClick = {
		$GUIOptPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $true }
		}
		$GUIOptNotificationPart.Checked = $True
		$GUIOptPagingSize.Checked = $True
	}
	$GUIOptMenuAllClearClick = {
		$GUIOptPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) { $_.Checked = $false }
		}
		$GUIOptNotificationNo.Checked = $True
		$GUIOptPagingSizeNo.Checked = $True
	}
	$GUIOptCanelClick = { 
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIOpt.Close()
	}
	$GUIOptRestoreClick = {
		$GUIOpt.Hide()
		if ($GUIOptAddOwnership.Checked) { DisableTakeOwnership }
		if ($GUIOptHibernation.Checked) { EnableHibernation }
		if ($GUIOptPowerSupply.Checked) { RestorePowerSupply }
		if ($GUIOptAppRestartScreen.Checked) { EnableAppRestartScreen }
		if ($GUIOptShortcutArrow.Checked) { RestoreArrow }
		if ($GUIOptNumLock.Checked) { DisableNumlock }
		if ($GUIOptSearchBox.Checked) {
			SetSearchBox -Type "Box"
			Stop-Process -ProcessName explorer -ErrorAction SilentlyContinue
		}
		if ($GUIOptUAC.Checked) { SetUACDefault }
		if ($GUIOptSmartScreen.Checked) { EnableSmartScreen }
		if ($GUIOptMaintain.Checked) { EnableMaintain }
		if ($GUIOptExperience.Checked) { RestoreExperience }
		if ($GUIOptDefragmentation.Checked) { EnableDefragmentation }
		if ($GUIOptCompatibility.Checked) { EnableCompatibility }
		if ($GUIOptAnimationEffects.Checked) { RestoreAnimationEffects }
		if ($GUIOptSafetyWarnings.Checked) { DisableSafetyWarnings }
		if ($GUIOptQOS.Checked) { EnableQOS }
		if ($GUIOptNetworkTuning.Checked) { EnableNetworkTuning }
		if ($GUIOptECN.Checked) { EnableECN }
		if ($GUIOptErrorRecovery.Checked) { EnableErrorRecovery }
		if ($GUIOptDEP.Checked) { RestoreDEPPAE }
		if ($GUIOptPowerFailure.Checked) { EnablePowerFailure }
		if ($GUIOptIEAutoSet.Checked) { EnableAutoDetect }
		if ($GUIOptScheduledTasks.Checked) { RestoreScheduledTasks }
		if ($GUIOptMergeTaskbarNever.Checked) { DefaultMergeTaskbarNever }
		if ($GUIOptNotificationAlways.Checked) { DefaultNotificationAlways }
		if ($GUIOptNavShowAll.Checked) { RestoreNavShowAll }
		if ($GUIOptCortana.Checked) {
			RestoreCortana
			Stop-Process -ProcessName explorer -ErrorAction SilentlyContinue
		}
		if ($GUIOptPwdUnlimited.Checked) { RestorePwdUnlimited }
		if ($GUIOptRAM.Checked) { RestoreRAM }
		if ($GUIOptPhotoPreview.Checked) { DisablePhotoPreview }
		if ($GUIOptQuickAccess.Checked) { ShowRecentShortcuts }
		if ($GUIOptGamebar.Checked) { EnableGamebar }
		if ($GUIOptGameMode.Checked) { EnableGameMode }
		if ($GUIOptProtected.Checked) { RestoreProtected }
		if ($GUIOptMultipleIncrease.Checked) { RestoreMultipleIncrease }
		if ($GUIOptAutoplay.Checked) { EnableAutoplay }
		if ($GUIOptAutorun.Checked) { EnableAutorun }
		if ($GUIOptErrorReporting.Checked) { EnableErrorReporting }
		if ($GUIOptF8BootMenu.Checked) { EnableF8BootMenu }
		if ($GUIOptSSD.Checked) { DefaultOptSSD }
		if ($GUIOptMemoryCompression.Checked) { EnableMemoryCompression }
		if ($GUIOptPrelaunch.Checked) { EnablePrelaunch }
		if ($GUIOptUser.Checked) { RestoreOptUser }
		if ($GUIOptUpdate.Checked) { RestoreOptUpdate }
		if ($GUIOptFixPrivacy.Checked) { RestoreFixPrivacy }
		if ($GUIOptTimelineTime.Checked) { EnableTimelineTime }
		if ($GUIOptCollectActivity.Checked) { EnableCollectActivity }
		if ($GUIOptNotificationFull.Checked) { RestoreActionCenter }
		if ($GUIOptNotificationPart.Checked) { RestoreActionCenterPart }
		if ($GUIOptPagingSize.Checked) { RestorePagingSize }
		if ($GUIOptPagingSizeHigh.Checked) { RestorePagingSize }
		if ($GUIOptTaskBar.Checked) { ResetTaskBar }
		if ($GUIOptResetDesk.Checked) { ResetDesktop }
		gpupdate /force | out-null
		$GUIOpt.Close()
	}
	$GUIOptOKClick = {
		$GUIOpt.Hide()
		if ($GUIOptAddOwnership.Checked) {
			DisableTakeOwnership
			EnableTakeOwnership
		}
		if ($GUIOptHibernation.Checked) { DisableHibernation }
		if ($GUIOptPowerSupply.Checked) { SetPowerSupply }
		if ($GUIOptAppRestartScreen.Checked) { DisableAppRestartScreen }
		if ($GUIOptShortcutArrow.Checked) { DisableArrow }
		if ($GUIOptNumLock.Checked) { EnableNumlock }
		if ($GUIOptSearchBox.Checked) {
			SetSearchBox -Type "icon"
			Stop-Process -ProcessName explorer -ErrorAction SilentlyContinue
		}
		if ($GUIOptUAC.Checked) { SetUACNever }
		if ($GUIOptSmartScreen.Checked) { DisableSmartScreen }
		if ($GUIOptMaintain.Checked) { DisableMaintain }
		if ($GUIOptExperience.Checked) { SetExperience }
		if ($GUIOptDefragmentation.Checked) { DisableDefragmentation }
		if ($GUIOptCompatibility.Checked) { DisableCompatibility }
		if ($GUIOptAnimationEffects.Checked) { OptAnimationEffects }
		if ($GUIOptSafetyWarnings.Checked) { EnableSafetyWarnings }
		if ($GUIOptQOS.Checked) { DisableQOS }
		if ($GUIOptNetworkTuning.Checked) { DisableNetworkTuning }
		if ($GUIOptECN.Checked) { DisableECN }
		if ($GUIOptErrorRecovery.Checked) { DisableErrorRecovery }
		if ($GUIOptDEP.Checked) { DisableDEPPAE }
		if ($GUIOptPowerFailure.Checked) { DisablePowerFailure }
		if ($GUIOptIEAutoSet.Checked) { DisableAutoDetect }
		if ($GUIOptIEProxy.Checked) { IEProxy }
		if ($GUIOptScheduledTasks.Checked) { DisableScheduledTasks }
		if ($GUIOptMergeTaskbarNever.Checked) { SetMergeTaskbarNever }
		if ($GUIOptNotificationAlways.Checked) { SetNotificationAlways }
		if ($GUIOptNavShowAll.Checked) { SetNavShowAll }
		if ($GUIOptCortana.Checked) {
			SetCortana
			Stop-Process -ProcessName explorer -ErrorAction SilentlyContinue
		}
		if ($GUIOptPwdUnlimited.Checked) { SetPwdUnlimited }
		if ($GUIOptRAM.Checked) { SetRAM }
		if ($GUIOptPhotoPreview.Checked) { EnablePhotoPreview }
		if ($GUIOptQuickAccess.Checked) { HideRecentShortcuts }
		if ($GUIOptGamebar.Checked) { DisableGamebar }
		if ($GUIOptGameMode.Checked) { DisableGameMode }
		if ($GUIOptProtected.Checked) { DisableProtected }
		if ($GUIOptMultipleIncrease.Checked) { DisableMultipleIncrease }
		if ($GUIOptAutoplay.Checked) { DisableAutoplay }
		if ($GUIOptAutorun.Checked) { DisableAutorun }
		if ($GUIOptErrorReporting.Checked) { DisableErrorReporting }
		if ($GUIOptF8BootMenu.Checked) { DisableF8BootMenu }
		if ($GUIOptSSD.Checked) { OptSSD }
		if ($GUIOptMemoryCompression.Checked) { DisableMemoryCompression }
		if ($GUIOptPrelaunch.Checked) { DisablePrelaunch }
		if ($GUIOptUser.Checked) { DisableOptUser }
		if ($GUIOptUpdate.Checked) { DisableOptUpdate }
		if ($GUIOptFixPrivacy.Checked) { DisableFixPrivacy }
		if ($GUIOptTimelineTime.Checked) { DisableTimelineTime }
		if ($GUIOptCollectActivity.Checked) { DisableCollectActivity }
		if ($GUIOptSendTo.Checked) { SendTo }
		if ($GUIOptCleanSystemLog.Checked) { CleanSystemLog }
		if ($GUIOptCleanSxS.Checked) { CleanSxS }
		if ($GUIOptNotificationFull.Checked) { DisableActionCenter }
		if ($GUIOptNotificationPart.Checked) { DisableActionCenterPart }
		if ($GUIOptPagingSize.Checked) { PagingSize -size 8 }
		if ($GUIOptPagingSizeHigh.Checked) { PagingSize -size 16 }
		if ($GUIOptTaskBar.Checked) { ResetTaskBar }
		if ($GUIOptResetDesk.Checked) { ResetDesktop }

		gpupdate /force | out-null
		$GUIOpt.Close()
	}

	$GUIOpt            = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 568
		Width          = 450
		Text           = "$($lang.Optimize) $($lang.System)"
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUIOptPanel       = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 468
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = 8
		Dock           = 1
	}
	$GUIOptAddOwnership = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.AddTo) $($lang.AddOwnership)"
		Checked        = $true
	}
	$GUIOptHibernation = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Close) $($lang.Hibernation)"
		Checked        = $true
	}
	$GUIOptPowerSupply = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Setting) $($lang.PowerSupply)"
		Checked        = $true
	}
	$GUIOptAppRestartScreen = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.AppRestartScreen)"
		Checked        = $true
	}
	$GUIOptShortcutArrow = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Delete) $($lang.ShortcutArrow)"
		Checked        = $true
	}
	$GUIOptNumLock     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Setting) $($lang.NumLock)"
		Checked        = $true
	}
	$GUIOptSearchBox   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Setting) $($lang.SearchBox)"
		Checked        = $true
	}
	$GUIOptUAC         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Setting) $($lang.UAC)$($lang.UACNever)"
		Checked        = $true
	}
	$GUIOptSmartScreen = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.SmartScreen)"
		Checked        = $true
	}
	$GUIOptMaintain    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Close) $($lang.Maintain)"
		Checked        = $true
	}
	$GUIOptExperience  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Close) $($lang.Experience)"
		Checked        = $true
	}
	$GUIOptDefragmentation = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Defragmentation)"
		Checked        = $true
	}
	$GUIOptCompatibility = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Close) $($lang.Compatibility)"
		Checked        = $true
	}
	$GUIOptAnimationEffects = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.AnimationEffects)"
		Checked        = $true
	}
	$GUIOptSafetyWarnings = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.SafetyWarnings)"
		Checked        = $true
	}
	$GUIOptQOS         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.QOS)"
		Checked        = $true
	}
	$GUIOptNetworkTuning = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.NetworkTuning)"
		Checked        = $true
	}
	$GUIOptECN         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.ECN)"
		Checked        = $true
	}
	$GUIOptErrorRecovery = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Close) $($lang.ErrorRecovery)"
		Checked        = $true
	}
	$GUIOptDEP         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.DEP) ( $($lang.Restart) )"
	}
	$GUIOptPowerFailure = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Close) $($lang.PowerFailure)"
		Checked        = $true
	}
	$GUIOptIEAutoSet   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.IEAutoSet)"
		Checked        = $true
	}
	$GUIOptIEProxy     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Restore) $($lang.IEProxy)"
	}
	$GUIOptScheduledTasks = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.ScheduledTasks)"
		Checked        = $true
	}
	$GUIOptMergeTaskbarNever = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Setting) $($lang.MergeTaskbarNever)"
		Checked        = $true
	}
	$GUIOptNotificationAlways = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Setting) $($lang.NotificationAlways)"
		Checked        = $true
	}
	$GUIOptNavShowAll  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Setting) $($lang.NavShowAll)"
		Checked        = $true
	}
	$GUIOptCortana     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = $lang.Cortana
		Checked        = $true
	}
	$GUIOptPwdUnlimited = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Setting) $($lang.PwdUnlimited)"
		Checked        = $true
	}
	$GUIOptRAM         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.RAM)"
		Checked        = $true
	}
	$GUIOptPhotoPreview = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Enable) $($lang.PhotoPreview)"
		Checked        = $true
	}
	$GUIOptQuickAccess = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.QuickAccess)"
		Checked        = $true
	}
	$GUIOptGamebar     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Gamebar)"
		Checked        = $true
	}
	$GUIOptGameMode    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.GameMode)"
		Checked        = $true
	}
	$GUIOptProtected   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Protected)"
		Checked        = $true
	}
	$GUIOptMultipleIncrease = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Enable) $($lang.MultipleIncrease)"
		Checked        = $true
	}
	$GUIOptAutoplay    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Autoplay)"
	}
	$GUIOptAutorun     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Autorun)"
	}
	$GUIOptErrorReporting = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.ErrorReporting)"
		Checked        = $true
	}
	$GUIOptF8BootMenu  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.F8BootMenu)"
	}
	$GUIOptSSD         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.OptSSD)"
		Checked        = $true
	}
	$GUIOptMemoryCompression = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.MemoryCompression)"
		Checked        = $true
	}
	$GUIOptPrelaunch   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.Prelaunch)"
		Checked        = $true
	}
	$GUIOptUser        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.OptUser)"
		Checked        = $true
	}
	$GUIOptUpdate      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.OptUpdate)"
		Checked        = $true
	}
	$GUIOptFixPrivacy  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Optimize) $($lang.FixPrivacy)"
		Checked        = $true
	}
	$GUIOptTimelineTime = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.TimelineTime) ( $($lang.Restart) )"
		Checked        = $true
	}
	$GUIOptCollectActivity = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Disable) $($lang.CollectActivity) ( $($lang.Restart) )"
		Checked        = $true
	}
	$GUIOptSendTo      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Clean) $($lang.SendTo)"
		Checked        = $true
	}
	$GUIOptCleanSystemLog = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Clean) $($lang.Logs)"
		Checked        = $true
	}
	$GUIOptCleanSxS    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Clean) $($lang.SxS)"
	}
	$GUIOptGroupNotification = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		Height         = 118
		Width          = 405
		autoSizeMode   = 1
		Padding        = 14
	}
	$GUIOptNotificationTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 405
		Text           = "$($lang.Notification)"
	}
	$GUIOptNotificationNo = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = $lang.NotSet
	}
	$GUIOptNotificationFull = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = "$($lang.Close) $($lang.Notification) $($lang.Full)"
	}
	$GUIOptNotificationPart = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = "$($lang.Close) $($lang.Notification) $($lang.Part)"
		Checked        = $true
	}
	$GUIOptGroupPagingSize = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		BorderStyle    = 0
		Height         = 118
		Width          = 405
		autoSizeMode   = 1
		Padding        = 14
	}
	$GUIOptPagingSizeTitle = New-Object System.Windows.Forms.Label -Property @{
		autoSize       = $true
		Text           = "$($lang.PagingSize) ( $($lang.Restart) )"
	}
	$GUIOptPagingSizeNo = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = $lang.NotSet
	}
	$GUIOptPagingSize  = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = "$($lang.Setting) $($lang.PagingSize) (8G)"
		Checked        = $true
	}
	$GUIOptPagingSizeHigh = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 405
		Text           = "$($lang.Setting) $($lang.PagingSize) (16G)"
	}
	$GUIOptTaskBar     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Reset) $($lang.TaskBar)"
	}
	$GUIOptResetDesk   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = $lang.ResetDesk
	}
	$GUIOptReset       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "10,482"
		Height         = 36
		Width          = 133
		add_Click      = $GUIOptRestoreClick
		Text           = $lang.Restore
	}
	$GUIOptOK          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "148,482"
		Height         = 36
		Width          = 133
		add_Click      = $GUIOptOKClick
		Text           = $lang.OK
	}
	$GUIOptCanel       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "286,482"
		Height         = 36
		Width          = 133
		add_Click      = $GUIOptCanelClick
		Text           = $lang.Cancel
	}

	$GUIOpt.controls.AddRange((
		$GUIOptPanel,
		$GUIOptReset,
		$GUIOptOK,
		$GUIOptCanel
	))
	$GUIOptPanel.controls.AddRange((
		$GUIOptAddOwnership,
		$GUIOptHibernation,
		$GUIOptPowerSupply,
		$GUIOptAppRestartScreen,
		$GUIOptShortcutArrow,
		$GUIOptNumLock,
		$GUIOptSearchBox,
		$GUIOptUAC,
		$GUIOptSmartScreen,
		$GUIOptMaintain,
		$GUIOptExperience,
		$GUIOptDefragmentation,
		$GUIOptCompatibility,
		$GUIOptAnimationEffects,
		$GUIOptSafetyWarnings,
		$GUIOptQOS,
		$GUIOptNetworkTuning,
		$GUIOptECN,
		$GUIOptErrorRecovery,
		$GUIOptDEP,
		$GUIOptPowerFailure,
		$GUIOptIEAutoSet,
		$GUIOptIEProxy,
		$GUIOptScheduledTasks,
		$GUIOptMergeTaskbarNever,
		$GUIOptNotificationAlways,
		$GUIOptNavShowAll,
		$GUIOptCortana,
		$GUIOptPwdUnlimited,
		$GUIOptRAM,
		$GUIOptPhotoPreview,
		$GUIOptQuickAccess,
		$GUIOptGamebar,
		$GUIOptGameMode,
		$GUIOptProtected,
		$GUIOptMultipleIncrease,
		$GUIOptAutoplay,
		$GUIOptAutorun,
		$GUIOptErrorReporting,
		$GUIOptF8BootMenu,
		$GUIOptSSD,
		$GUIOptMemoryCompression,
		$GUIOptPrelaunch,
		$GUIOptUser,
		$GUIOptUpdate,
		$GUIOptFixPrivacy,
		$GUIOptTimelineTime,
		$GUIOptCollectActivity,
		$GUIOptSendTo,
		$GUIOptCleanSystemLog,
		$GUIOptCleanSxS,
		$GUIOptGroupNotification,
		$GUIOptGroupPagingSize,
		$GUIOptTaskBar,
		$GUIOptResetDesk
	))

	$GUIOptGroupNotification.controls.AddRange((
		$GUIOptNotificationTitle,
		$GUIOptNotificationNo,
		$GUIOptNotificationFull,
		$GUIOptNotificationPart
	))

	$GUIOptGroupPagingSize.controls.AddRange((
		$GUIOptPagingSizeTitle,
		$GUIOptPagingSizeNo,
		$GUIOptPagingSize,
		$GUIOptPagingSizeHigh
	))

	$GUIOptMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOptMenu.Items.Add($lang.AllSel).add_Click($GUIOptMenuAllSelClick)
	$GUIOptMenu.Items.Add($lang.AllClear).add_Click($GUIOptMenuAllClearClick)
	$GUIOpt.ContextMenuStrip = $GUIOptMenu

	$NoSelectPowerSupply = @(8, 9, 10, 11, 14)
	Get-CimInstance -ClassName Win32_SystemEnclosure | ForEach-Object {
		if ($NoSelectPowerSupply -contains $_.SecurityStatus) {
			$GUIOptPowerSupply.Checked = $False
		}
	}

	$GUIOpt.FormBorderStyle = 'Fixed3D'
	$GUIOpt.ShowDialog() | Out-Null

	if ( -not ($Force)) {
		ToMainpage -wait 2
	}
}

Export-ModuleMember -Function "Optimization"