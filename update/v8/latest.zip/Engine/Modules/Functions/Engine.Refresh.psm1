﻿<#
 .Synopsis
  Refresh

 .Description
  Refresh Feature Modules
#>

<#
	.Refresh the user interface
	.刷新用户界面
#>
Function Refresh
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.RefreshLang)

	If ($Force) {
		RefreshStart
	} else {
		Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------
   1. $($lang.DelOldShortcut)
   2. $($lang.VerifyShortcut)`n"

		Write-Host "   $($lang.RefreshYN)" -ForegroundColor Green
		$caption = $lang.RefreshConfirm
		$message = "$($lang.Continue) (Y)`n$($lang.Cancel) (N)"
		$choices = @("&Yes","&No")
		$choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription]
		$choices | ForEach-Object { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))}
		$prompt = $Host.ui.PromptForChoice($caption, $message, $choicedesc, 0)
		Switch ($prompt)
		{
			0 {
				RefreshStart
				ToMainpage -wait 6
			}
			1 {
				ToMainpage -wait 2
			}
		}
	}
}


<#
	.Start processing refresh task
	.开始处理刷新任务
#>
Function RefreshStart
{
	<#
		.Obtain deployment conditions: 1. Clean up the entire solution; clean up the main engine after running. Set the mark after being satisfied: $True
		.获取部署条件：1、清理整个解决方案；运行后清理主引擎。满足后设置标记为：$True
	#>
	$FlagsPreProcess = $Flase
	if ((Test-Path -path "$PSScriptRoot\..\..\Deploy\ClearSolutions" -PathType Leaf) -or
		(Test-Path -path "$PSScriptRoot\..\..\Deploy\ClearEngine" -PathType Leaf))
	{
		$FlagsPreProcess = $True
	}

	<#
		.Get the required application software path
		.获取所需的应用软件路径
	#>
	$Shortcut = "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\Shortcut")\Shortcut.exe"
	$syspin   = "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\syspin")\syspin.exe"
	$DeskEdit = "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\DeskEdit")\DeskEdit.exe"

	Write-Host "   $($lang.AddTo) $($lang.DeskIcon)"
	$StartMenu = "$env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs\$($Global:UniqueID)'s Solutions"
	if (Test-Path $syspin -PathType Leaf) {
		Start-Process -FilePath $syspin -ArgumentList """$StartMenu\- $($lang.Mainpage) -.lnk"" ""51394""" -Wait -WindowStyle Hidden
		Start-Process -FilePath $syspin -ArgumentList """$StartMenu\- Solutions Toolbox -.lnk"" ""51394""" -Wait -WindowStyle Hidden
		Start-Process -FilePath $syspin -ArgumentList """$StartMenu\- 解决方案工具箱 -.lnk"" ""51394""" -Wait -WindowStyle Hidden
	}
	Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\Bundled Solutions.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:SystemDrive\Users\Public\Desktop\附赠解决方案.lnk" -ErrorAction SilentlyContinue

	<#
		.Clean up old connections
		.清理旧连接
	#>
	$CleanOldLNK = @(
		"*.lnk"
		"00\*.lnk"
		"10\*.lnk"
		"30\*.lnk"
		"40\*.lnk"
		"50\*.lnk"
		"60\*.lnk"
		"70\*.lnk"
	)

	foreach ($item in $CleanOldLNK) {
		Remove-Item -Path "$Global:UniqueMainFolder\$item" -ErrorAction SilentlyContinue
	}

	<#
		.Clean up old connections
		.清理旧文件
	#>
	RemoveTree -Path $StartMenu
	CheckCatalog -chkpath $StartMenu

	$FlagFolder00 = "$PSScriptRoot\..\..\..\00"
	$FlagFolder10 = "$PSScriptRoot\..\..\..\10"
	$FlagFolder20 = "$PSScriptRoot\..\..\..\20"
	$FlagFolder30 = "$PSScriptRoot\..\..\..\30"
	$FlagFolder40 = "$PSScriptRoot\..\..\..\40"
	$FlagFolder50 = "$PSScriptRoot\..\..\..\50"
	$FlagFolder60 = "$PSScriptRoot\..\..\..\60"
	$FlagFolder70 = "$PSScriptRoot\..\..\..\70"

	<#
		.Pre-configuration processing
		.预配置处理
	#>
	if ($FlagsPreProcess) {
		Start-Process -FilePath $Shortcut -ArgumentList "/f:""$env:SystemDrive\Users\Public\Desktop\$($lang.MainHisName).lnk"" /a:c /t:""$($Global:UniqueMainFolder)""" -WindowStyle Hidden
		Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\- $($lang.Location) -.lnk"" /a:c /t:""$($Global:UniqueMainFolder)""" -WindowStyle Hidden
	} else {
		Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($Global:UniqueMainFolder)"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($Global:UniqueID)'s Solutions"""
		Start-Process -FilePath $Shortcut -ArgumentList "/f:""$env:SystemDrive\Users\Public\Desktop\$($lang.MainHisName).lnk"" /a:c /t:""$($Global:UniqueMainFolder)"" /i:""$($Global:UniqueMainFolder)\Engine\icons\Engine.Gift.ico""" -WindowStyle Hidden
		Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\- $($lang.Location) -.lnk"" /a:c /t:""$($Global:UniqueMainFolder)"" /i:""$($Global:UniqueMainFolder)\Engine\icons\Engine.Gift.ico""" -WindowStyle Hidden

		if (Test-Path -Path "$($UniqueMainFolder)\Engine\Engine.ps1") {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\- $($lang.Mainpage) -.lnk"" /a:c /t:""powershell"" /p:""-Command \""Start-Process 'Powershell.exe' -Argument '-File \""$($Global:UniqueMainFolder)\Engine\Engine.ps1\""' -Verb RunAs"" /i:""$($Global:UniqueMainFolder)\Engine\icons\MainPanel.ico""" -WindowStyle Hidden -Wait
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$FlagFolder00\- $($lang.InstlOffice -f "WPS") -.lnk"" /a:c /t:""powershell"" /p:""-Command \""Start-Process 'Powershell.exe' -Argument '-File \""$($Global:UniqueMainFolder)\Engine\Engine.ps1\"" -Functions \\\""WPS -Quit\\\""' -Verb RunAs"" /i:""$($Global:UniqueMainFolder)\Engine\icons\run.ico""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\- $($lang.Mainpage) -.lnk"" /a:c /t:""powershell"" /p:""-Command \""Start-Process 'Powershell.exe' -Argument '-File \""$($Global:UniqueMainFolder)\Engine\Engine.ps1\""' -Verb RunAs"" /i:""$($Global:UniqueMainFolder)\Engine\icons\MainPanel.ico""" -WindowStyle Hidden
			if (Test-Path $syspin -PathType Leaf) {
				Start-Process -FilePath $syspin -ArgumentList """$StartMenu\- $($lang.Mainpage) -.lnk"" ""51201""" -Wait -WindowStyle Hidden
			}
		}
		if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\$($Global:IUniqueIDsLang)\Instl.ps1") {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$FlagFolder00\- $($lang.EditAndInstl) -.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\Engine\Modules\$($Global:IsLang)\instl.ps1""" -WindowStyle Hidden
		} else {
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\en-US\Instl.ps1") {
				Start-Process -FilePath $Shortcut -ArgumentList "/f:""$FlagFolder00\- $($lang.EditAndInstl) -.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\Engine\Modules\en-US\instl.ps1""" -WindowStyle Hidden
			}
		}
	}

	if (Test-Path $FlagFolder00 -PathType Container) {
		if ($FlagsPreProcess) {
			RemoveTree -Path $FlagFolder00
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$FlagFolder00"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.InstlPacker)"""

			if (Test-Path -Path "$FlagFolder00\OInstall\OInstall.$($Global:IsLang).exe" ) {
				Start-Process -FilePath $Shortcut -ArgumentList "/f:""$FlagFolder00\- $($lang.InstlOffice -f "Microsoft") -.lnk"" /a:c /t:""$FlagFolder00\OInstall\OInstall.$($Global:IsLang).exe"" /w:""$FlagFolder00\OInstall"" /i:""$FlagFolder00\OInstall\OInstall.$($Global:IsLang).exe""" -WindowStyle Hidden
			} else {
				if (Test-Path -Path "FlagFolder00\00\OInstall\OInstall.en-US.exe") {
					Start-Process -FilePath $Shortcut -ArgumentList "/f:""$FlagFolder00\- $($lang.InstlOffice -f "Microsoft") -.lnk"" /a:c /t:""$FlagFolder00\OInstall\OInstall.en-US.exe"" /w:""$FlagFolder00\OInstall"" /i:""$FlagFolder00\OInstall\OInstall.en-US.exe""" -WindowStyle Hidden
				}
			}
		}
	}

	if (Test-Path $FlagFolder10 -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.BakRestore)"
		if ($FlagsPreProcess) {
			Move-Item $FlagFolder10 "$($UniqueMainFolder)\$($lang.BakRestore)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.BakRestore)
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$FlagFolder10"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.BakRestore)"""
			$NewFolderName = "10"
		}

		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\Ghost\Ghost.exe") {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Symantec Ghost.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Ghost\Ghost.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Ghost"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Ghost\Ghost.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.BakRestore)\Symantec Ghost.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Ghost\Ghost.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Ghost"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Ghost\Ghost.exe""" -WindowStyle Hidden
		}
		if (Test-Path -Path "$($UniqueMainFolder)\$($NewFolderName)\GhostExp\GhostExp.exe") {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Symantec Ghost Explorer.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostExp\GhostExp.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostExp"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostExp\GhostExp.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.BakRestore)\Symantec Ghost Explorer.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostExp\GhostExp.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostExp"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostExp\GhostExp.exe""" -WindowStyle Hidden
		}
		if (Test-Path -Path "$($UniqueMainFolder)\$($NewFolderName)\GhostSrv\GhostSrv.exe") {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Symantec GhostCast Server.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostSrv\GhostSrv.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostSrv"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostSrv\GhostSrv.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.BakRestore)\Symantec GhostCast Server.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostSrv\GhostSrv.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostSrv"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\GhostSrv\GhostSrv.exe""" -WindowStyle Hidden
		}
		if (Test-Path -Path "$($UniqueMainFolder)\$($NewFolderName)\Tftpd\tftpd.exe" ) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Tftpd.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Tftpd\tftpd.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Tftpd"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Tftpd\tftpd.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.BakRestore)\Tftpd.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Tftpd\tftpd.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Tftpd"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Tftpd\tftpd.exe""" -WindowStyle Hidden
		}
	}

	if (Test-Path $FlagFolder20 -PathType Container) {
		if ($FlagsPreProcess) {
			Move-Item $FlagFolder20 "$($UniqueMainFolder)\$($lang.ActivationKit)" -Force -ErrorAction SilentlyContinue
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$FlagFolder20"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.ActivationKit)"""
		}
	}

	if (Test-Path $FlagFolder30 -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.MostUsedSoftware)"
		if ($FlagsPreProcess) {
			Move-Item $FlagFolder30 "$($UniqueMainFolder)\$($lang.MostUsedSoftware)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.MostUsedSoftware)
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$FlagFolder30"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.MostUsedSoftware)"""
			$NewFolderName = "30"
		}
		
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\AdvancedIPScanner" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Advanced IP Scanner.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\AdvancedIPScanner\advanced_ip_scanner.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\AdvancedIPScanner"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\AdvancedIPScanner\advanced_ip_scanner.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Advanced IP Scanner.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\AdvancedIPScanner\advanced_ip_scanner.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\AdvancedIPScanner"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\AdvancedIPScanner\advanced_ip_scanner.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\VLC" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\VLC media player.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\VLC\vlc.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\VLC"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\VLC\vlc.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\VLC media player.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\VLC\vlc.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\VLC"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\VLC\vlc.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\360DrvMgr" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.DrvMgr).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\360DrvMgr\360DrvMgr.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\360DrvMgr"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\360DrvMgr\360DrvMgr.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\$($lang.DrvMgr).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\360DrvMgr\360DrvMgr.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\360DrvMgr"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\360DrvMgr\360DrvMgr.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\DriverTalent" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Driver Updater.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverTalent\Driver Talent.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverTalent"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverTalent\Driver Talent.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Driver Updater.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverTalent\Driver Talent.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverTalent"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverTalent\Driver Talent.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\DriverGenius" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.DriverGenius).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverGenius\DriverGenius.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverGenius"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverGenius\DriverGenius.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\$($lang.DriverGenius).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverGenius\DriverGenius.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverGenius"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverGenius\DriverGenius.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\DiskGenius" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\DiskGenius.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DiskGenius\Diskgenius.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DiskGenius"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DiskGenius\Diskgenius.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\DiskGenius.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DiskGenius\Diskgenius.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DiskGenius"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DiskGenius\Diskgenius.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\WinNTSetup" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinNTSetup.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinNTSetup\WinNTSetup.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinNTSetup"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinNTSetup\WinNTSetup.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\WinNTSetup.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinNTSetup\WinNTSetup.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinNTSetup"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinNTSetup\WinNTSetup.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\rufus" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Rufus.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\rufus\rufus.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\rufus"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\rufus\rufus.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Rufus.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\rufus\rufus.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\rufus"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\rufus\rufus.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\FastCopy" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\FastCopy.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\FastCopy\FastCopy.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\FastCopy"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\FastCopy\FastCopy.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\FastCopy.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\FastCopy\FastCopy.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\FastCopy"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\FastCopy\FastCopy.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\DnsJumper" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\DNS Jumper.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DnsJumper\DnsJumper.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DnsJumper"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DnsJumper\DnsJumper.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\DNS Jumper.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DnsJumper\DnsJumper.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DnsJumper"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DnsJumper\DnsJumper.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\EasyBCD" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\EasyBCD.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\EasyBCD\EasyBCD.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\EasyBCD"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\EasyBCD\EasyBCD.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\EasyBCD.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\EasyBCD\EasyBCD.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\EasyBCD"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\EasyBCD\EasyBCD.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\RegeditX" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegEditX.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegeditX\RegEditX.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegeditX"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegeditX\RegEditX.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\RegEditX.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegeditX\RegEditX.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegeditX"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegeditX\RegEditX.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\RegShot" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegShot.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegShot\Regshot.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegShot"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegShot\Regshot.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\RegShot.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegShot\Regshot.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegShot"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\RegShot\Regshot.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\Beyond Compare" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Beyond Compare.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Beyond Compare\BCompare.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Beyond Compare"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Beyond Compare\BComparePortable.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Beyond Compare.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Beyond Compare\BCompare.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Beyond Compare"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Beyond Compare\BComparePortable.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\WipeFile" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\WipeFile.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\WipeFile\WipeFile.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\WipeFile"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\WipeFile\WipeFile.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\WipeFile.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\WipeFile\WipeFile.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\WipeFile"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\WipeFile\WipeFile.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\Everything" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Everything.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Everything\Everything.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Everything"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Everything\Everything.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Everything.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Everything\Everything.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Everything"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Everything\Everything.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\SDCardFormatter" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\SD Card Formatter.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\SDCardFormatter\SDCardFormatter.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\SDCardFormatter"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\SDCardFormatter\SDCardFormatter.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\SD Card Formatter.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\SDCardFormatter\SDCardFormatter.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\SDCardFormatter"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\SDCardFormatter\SDCardFormatter.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\TopMost" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\TopMost.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TopMost\TopMost.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TopMost"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TopMost\TopMost.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\TopMost.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TopMost\TopMost.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TopMost"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TopMost\TopMost.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\geek" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Geek Uninstaller.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\geek\geek.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\geek"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\geek\geek.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.MostUsedSoftware)\Geek Uninstaller.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\geek\geek.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\geek"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\geek\geek.exe""" -WindowStyle Hidden
		}
	}

	if (Test-Path $FlagFolder40 -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.HardwareDetection)"
		if ($FlagsPreProcess) {
			Move-Item $FlagFolder40 "$($UniqueMainFolder)\$($lang.HardwareDetection)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.HardwareDetection)
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$FlagFolder40"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.HardwareDetection)"""
			$NewFolderName = "40"
		}

		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\AIDA64" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\AIDA64.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\AIDA64\aida64.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\AIDA64"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\AIDA64\aida64.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\AIDA64.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\AIDA64\aida64.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\AIDA64"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\AIDA64\aida64.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\ASSSDBenchmark" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\AS SSD Benchmark.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\ASSSDBenchmark\ASSSDBenchmark.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\ASSSDBenchmark"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\ASSSDBenchmark\ASSSDBenchmark.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\AS SSD Benchmark.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\ASSSDBenchmark\ASSSDBenchmark.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\ASSSDBenchmark"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\ASSSDBenchmark\ASSSDBenchmark.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\CPU-Z" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\CPU-Z.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\CPU-Z\cpu-z.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\CPU-Z"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\CPU-Z\cpu-z.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\CPU-Z.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\CPU-Z\cpu-z.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\CPU-Z"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\CPU-Z\cpu-z.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\FurMark" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\FurMark.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\FurMark\FurMark.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\FurMark"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\FurMark\FurMark.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\FurMark.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\FurMark\FurMark.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\FurMark"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\FurMark\FurMark.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\GPUShark" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPUShark.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPUShark\GPUShark.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPUShark"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPUShark\GPUShark.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\GPUShark.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPUShark\GPUShark.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPUShark"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPUShark\GPUShark.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\GPU-Z" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPU-Z.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPU-Z\GPU-Z.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPU-Z"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPU-Z\GPU-Z.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\GPU-Z.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPU-Z\GPU-Z.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPU-Z"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\GPU-Z\GPU-Z.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\HDDScan" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDDScan.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDDScan\HDDScan.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDDScan"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDDScan\HDDScan.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\HDDScan.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDDScan\HDDScan.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDDScan"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDDScan\HDDScan.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\Hard Disk Sentinel" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Hard Disk Sentinel.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Hard Disk Sentinel\HDSentinel.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Hard Disk Sentinel"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Hard Disk Sentinel\HDSentinel.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\Hard Disk Sentinel.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Hard Disk Sentinel\HDSentinel.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Hard Disk Sentinel"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Hard Disk Sentinel\HDSentinel.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\HDSpeed" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDSpeed.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDSpeed\HDSpeed.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDSpeed"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDSpeed\HDSpeed.ico"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\HDSpeed.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDSpeed\HDSpeed.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDSpeed"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\HDSpeed\HDSpeed.ico"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\MaxxMEM2" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\MaxxMEM2.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\MaxxMEM2\MaxxMEM2.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\MaxxMEM2"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\MaxxMEM2\MaxxMEM2.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\MaxxMEM2.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\MaxxMEM2\MaxxMEM2.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\MaxxMEM2"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\MaxxMEM2\MaxxMEM2.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\TxBENCH" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\TxBENCH.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TxBENCH\TxBENCH.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TxBENCH"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TxBENCH\TxBENCH.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\TxBENCH.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TxBENCH\TxBENCH.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TxBENCH"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TxBENCH\TxBENCH.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\Victoria" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Victoria.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Victoria\Victoria.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Victoria"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Victoria\Victoria.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\Victoria.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Victoria\Victoria.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Victoria"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Victoria\Victoria.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path -path "$($UniqueMainFolder)\$($NewFolderName)\MemTest\MemTest64.exe") {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest64.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\MemTest64.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\MemTest64.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\MemTest64.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\MemTest64.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\MemTest64.exe""" -WindowStyle Hidden
		}
		if (Test-Path -path "$($UniqueMainFolder)\$($NewFolderName)\MemTest\MTPclassic.exe") {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\memTestPro Classic.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\MTPclassic.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\MTPclassic.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\memTestPro Classic.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\MTPclassic.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\MTPclassic.exe""" -WindowStyle Hidden
		}
		if (Test-Path -path "$($UniqueMainFolder)\$($NewFolderName)\MemTest\memTestPro.exe") {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\memTestPro.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\memTestPro.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\memTestPro.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.HardwareDetection)\memTestPro.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\memTestPro.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\MemTest\memTestPro.exe""" -WindowStyle Hidden
		}
	}

	if (Test-Path $FlagFolder50 -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.Debugging)"
		if ($FlagsPreProcess) {
			Move-Item $FlagFolder50 "$($UniqueMainFolder)\$($lang.Debugging)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.Debugging)
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$FlagFolder50"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.Debugging)"""
			$NewFolderName = "50"
		}

		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\AutoRuns" -PathType Container) {
			if (Test-Path "$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns\AutoRuns.exe" -PathType Leaf) {
				Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns\AutoRuns.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns\AutoRuns.exe""" -WindowStyle Hidden
				Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\AutoRuns.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns\AutoRuns.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns\AutoRuns.exe""" -WindowStyle Hidden
			}
			if (Test-Path "$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns\Autoruns64a.exe" -PathType Leaf) {
				Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns\Autoruns64a.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns\Autoruns64a.exe""" -WindowStyle Hidden
				Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\AutoRuns.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns\Autoruns64a.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\AutoRuns\Autoruns64a.exe""" -WindowStyle Hidden
			}
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\DbgView" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\DbgView.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DbgView\Dbgview.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DbgView"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DbgView\Dbgview.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\DbgView.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DbgView\Dbgview.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DbgView"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DbgView\Dbgview.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\DriverView" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverView.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverView\DriverView.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverView"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverView\DriverView.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\DriverView.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverView\DriverView.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverView"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\DriverView\DriverView.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\FullEventLogView" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\FullEventLogView.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\FullEventLogView\FullEventLogView.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\FullEventLogView"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\FullEventLogView\FullEventLogView.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\FullEventLogView.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\FullEventLogView\FullEventLogView.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\FullEventLogView"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\FullEventLogView\FullEventLogView.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\ProcessExplorer" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Process Explorer.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessExplorer\ProcessExplorer.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessExplorer"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessExplorer\ProcessExplorer.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\Process Explorer.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessExplorer\ProcessExplorer.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessExplorer"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessExplorer\ProcessExplorer.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\ProcessMonitor" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Process Monitor.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessMonitor\Procmon.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessMonitor"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessMonitor\Procmon.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\Process Monitor.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessMonitor\Procmon.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessMonitor"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\ProcessMonitor\Procmon.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\PUTTY" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\PUTTY.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\PUTTY\putty.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\PUTTY"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\PUTTY\putty.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\PUTTY.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\PUTTY\putty.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\PUTTY"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\PUTTY\putty.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\TCPView" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\TCPView.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TCPView\Tcpview.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TCPView"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TCPView\Tcpview.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.Debugging)\TCPView.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TCPView\Tcpview.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TCPView"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TCPView\Tcpview.exe""" -WindowStyle Hidden
		}
	}

	if (Test-Path $FlagFolder60 -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.SetupTool)"
		if ($FlagsPreProcess) {
			Move-Item $FlagFolder60 "$($UniqueMainFolder)\$($lang.SetupTool)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.SetupTool)

			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\G.bat") { Copy-Item -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\G.bat" -Destination "$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StRemote).bat"  -Force -ErrorAction SilentlyContinue }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\H.bat") { Copy-Item -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\H.bat" -Destination "$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StPwd).bat"     -Force -ErrorAction SilentlyContinue }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\I.bat") { Copy-Item -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\I.bat" -Destination "$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StSMB).bat"     -Force -ErrorAction SilentlyContinue }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\J.bat") { Copy-Item -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\J.bat" -Destination "$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StSafe).bat"    -Force -ErrorAction SilentlyContinue }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\N.bat") { Copy-Item -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\N.bat" -Destination "$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StDelHide).bat" -Force -ErrorAction SilentlyContinue }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\P.bat") { Copy-Item -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\P.bat" -Destination "$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StSelAdv).bat"  -Force -ErrorAction SilentlyContinue }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\Q.bat") { Copy-Item -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\60\Q.bat" -Destination "$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StPS).bat"      -Force -ErrorAction SilentlyContinue }
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$FlagFolder60"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.SetupTool)"""
			$NewFolderName = "60"
			
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\G.bat") { Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StRemote).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\G.bat"" /i:""$($Global:UniqueMainFolder)\Engine\icons\run.ico""" -WindowStyle Hidden }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\H.bat") { Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StPwd).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\H.bat"" /i:""$($Global:UniqueMainFolder)\Engine\icons\run.ico""" -WindowStyle Hidden }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\I.bat") { Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StSMB).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\I.bat"" /i:""$($Global:UniqueMainFolder)\Engine\icons\run.ico""" -WindowStyle Hidden }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\J.bat") { Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StSafe).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\J.bat"" /i:""$($Global:UniqueMainFolder)\Engine\icons\run.ico""" -WindowStyle Hidden }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\N.bat") { Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StDelHide).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\N.bat"" /i:""$($Global:UniqueMainFolder)\Engine\icons\run.ico""" -WindowStyle Hidden }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\P.bat") { Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StSelAdv).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\P.bat"" /i:""$($Global:UniqueMainFolder)\Engine\icons\run.ico""" -WindowStyle Hidden }
			if (Test-Path -Path "$($UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\Q.bat") { Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\$($lang.StPS).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\Engine\Modules\langpacks\$($Global:IsLang)\$($NewFolderName)\Q.bat"" /i:""$($Global:UniqueMainFolder)\Engine\icons\run.ico""" -WindowStyle Hidden }
		}

		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\dControl" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\- $($lang.DefenderControl) -.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\dControl\dControl.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\dControl"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\dControl\dControl.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.SetupTool)\$($lang.DefenderControl).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\dControl\dControl.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\dControl"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\dControl\dControl.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\Wub" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\- $($lang.Wub) -.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Wub\Wub.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Wub"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Wub\Wub.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.SetupTool)\$($lang.Wub).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Wub\Wub.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Wub"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Wub\Wub.exe"" /R:7""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\fab" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\- $($lang.Fab) -.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\fab\Fab.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\fab"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\fab\Fab.exe"" /R:7""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.SetupTool)\$($lang.Fab).lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\fab\Fab.bat"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\fab"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\fab\Fab.exe"" /R:7""" -WindowStyle Hidden
		}
	}

	if (Test-Path $FlagFolder70 -PathType Container) {
		CheckCatalog -chkpath "$StartMenu\$($lang.RemoteTool)"
		if ($FlagsPreProcess) {
			Move-Item $FlagFolder70 "$($UniqueMainFolder)\$($lang.RemoteTool)" -Force -ErrorAction SilentlyContinue
			$NewFolderName = $($lang.RemoteTool)
		} else {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$FlagFolder70"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($lang.RemoteTool)"""
			$NewFolderName = "70"
		}

		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\AnyDesk" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\AnyDesk.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\AnyDesk\AnyDesk.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\AnyDesk"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\AnyDesk\AnyDesk.exe" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\AnyDesk.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\AnyDesk\AnyDesk.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\AnyDesk"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\AnyDesk\AnyDesk.exe" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\Radmin" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\Radmin.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Radmin\Radmin.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Radmin"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Radmin\Radmin.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\Radmin.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\Radmin\Radmin.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\Radmin"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\Radmin\Radmin.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\TeamViewer" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\TeamViewer.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TeamViewer\TeamViewer.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TeamViewer"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TeamViewer\TeamViewer.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\TeamViewer.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TeamViewer\TeamViewer.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TeamViewer"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TeamViewer\TeamViewer.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\TTVnc" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTC.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc\TTClient.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc\TTClient.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\TTC.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc\TTClient.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc\TTClient.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\TTVnc" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTS.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc\TTServer.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc\TTServer.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\TTS.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc\TTServer.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\TTVnc\TTServer.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\VNCView" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\VNC Viewer.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\VNCView\VNCView.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\VNCView"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\VNCView\VNCView.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\VNC Viewer.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\VNCView\VNCView.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\VNCView"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\VNCView\VNCView.exe""" -WindowStyle Hidden
		}
		if (Test-Path "$($UniqueMainFolder)\$($NewFolderName)\WinBox" -PathType Container) {
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinBox.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinBox\winbox.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinBox"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinBox\winbox.exe""" -WindowStyle Hidden
			Start-Process -FilePath $Shortcut -ArgumentList "/f:""$StartMenu\$($lang.RemoteTool)\WinBox.lnk"" /a:c /t:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinBox\winbox.exe"" /w:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinBox"" /i:""$($Global:UniqueMainFolder)\$($NewFolderName)\WinBox\winbox.exe""" -WindowStyle Hidden
		}
	}

	Wait-Process -Name "Shortcut" -ErrorAction SilentlyContinue
}

Export-ModuleMember -Function "Refresh"
Export-ModuleMember -Function "RefreshStart"