﻿<#
 .Synopsis
  System software

 .Description
  System software Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.System software user interface
	.系统软件用户界面
#>
Function SystemSoftware
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.ComesWith)
	Write-Host "   $($lang.ComesWith)`n   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUISSUpdateClick = {
		if ($GUISSUpdate.Checked) {
			$GUISSUpdateDA.Enabled = $True
			$GUISSUpdateGP.Enabled = $True
			$GUISSUpdateDrive.Enabled = $True
			$GUISSUpdateAvailable.Enabled = $True
			$GUISSUpdateTPMUpdate.Enabled = $True
		} else {
			$GUISSUpdateDA.Enabled = $False
			$GUISSUpdateGP.Enabled = $False
			$GUISSUpdateDrive.Enabled = $False
			$GUISSUpdateAvailable.Enabled = $False
			$GUISSUpdateTPMUpdate.Enabled = $False
		}
	}
	$GUISSDefenderClick = {
		if ($GUISSDefender.Checked) {
			$GUISSDefenderLoginAccount.Enabled = $True
			$GUISSDefenderEdgeFilter.Enabled = $True
		} else {
			$GUISSDefenderLoginAccount.Enabled = $False
			$GUISSDefenderEdgeFilter.Enabled = $False
		}
	}
	$GUISSCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUISS.Close()
	}
	$GUISSResetClick = {
		$GUISS.Hide()
		if ($GUISSUpdate.Checked) {
			InstallProcess -appname "$($lang.Enable) $($lang.WubTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50\Wub" -pwd "" -url "https://www.sordum.org/files/download/windows-update-blocker/Wub.zip" -urlAMD64 "" -urlarm64 "" -filename "Wub*" -param "/E" -Before "1:Wub:ini" -After ""
		}

		if ($GUISSUpdateDA.Enabled) {
			if ($GUISSUpdateDA.Checked) {
				UpdateAutoDownload -Enable
			}
		}

		if ($GUISSUpdateWelcomeExperience.Enabled) {
			if ($GUISSUpdateWelcomeExperience.Checked) {
				WelcomeExperience -Show
			}
		}

		if ($GUISSUpdateFirstLogonAnimation.Enabled) {
			if ($GUISSUpdateFirstLogonAnimation.Checked) {
				FirstLogonAnimation -Disable
			}
		}

		if ($GUISSUpdateGP.Enabled) {
			if ($GUISSUpdateGP.Checked) {
				UpdatePolicies -Enable
			}
		}

		if ($GUISSUpdateDrive.Enabled) {
			if ($GUISSUpdateDrive.Checked) {
				UpdateAutoDrive -Enable
			}
		}

		if ($GUISSUpdateAvailable.Enabled) {
			if ($GUISSUpdateAvailable.Checked) {
				UpdateAreAvailable -Enable
			}
		}
	
		if ($GUISSUpdateTPMUpdate.Enabled) {
			if ($GUISSUpdateTPMUpdate.Checked) {
				Win11TPMUpdate -Restore
			}
		}

		if ($GUISSDefender.Checked) {
			InstallProcess -appname "$($lang.Enable) $($lang.DefenderControlTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50\dControl" -pwd "sordum" -url "https://www.sordum.org/files/download/d-control/dControl.zip" -urlAMD64 "" -urlarm64 "" -filename "dfControl*" -param "" -Before "1:dfControl:ini" -After ""
		}

		if ($GUISSDefenderLoginAccount.Enabled) {
			if ($GUISSDefenderLoginAccount.Checked) {
				DismissMSAccount -Enable
			}
		}

		if ($GUISSDefenderEdgeFilter.Enabled) {
			if ($GUISSDefenderEdgeFilter.Checked) {
				DismissSmartScreenFilter -Enable
			}
		}

		if ($GUISSFirewall.Checked) {
			InstallProcess -appname "$($lang.Enable) $($lang.FabTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50\Fab" -pwd "" -url "https://www.sordum.org/files/download/firewall-app-blocker/fab.zip" -urlAMD64 "" -urlarm64 "" -filename "fab*" -param "/S 0" -Before "1:Fab:ini" -After ""
		}
		WaitEnd
		$GUISS.Close()
	}
	$GUISSOKClick = {
		$GUISS.Hide()
		if ($GUISSUpdate.Checked) {
			InstallProcess -appname "$($lang.Close) $($lang.WubTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50\Wub" -pwd "" -url "https://www.sordum.org/files/download/windows-update-blocker/Wub.zip" -urlAMD64 "" -urlarm64 "" -filename "Wub*" -param "/D /P" -Before "1:Wub:ini" -After ""
		}

		if ($GUISSUpdateDA.Enabled) {
			if ($GUISSUpdateDA.Checked) {
				UpdateAutoDownload -Disable
			}
		}

		if ($GUISSUpdateWelcomeExperience.Enabled) {
			if ($GUISSUpdateWelcomeExperience.Checked) {
				WelcomeExperience -Hide
			}
		}

		if ($GUISSUpdateGP.Enabled) {
			if ($GUISSUpdateGP.Checked) {
				UpdatePolicies -Disable
			}
		}

		if ($GUISSUpdateDrive.Enabled) {
			if ($GUISSUpdateDrive.Checked) {
				UpdateAutoDrive -Disable
			}
		}

		if ($GUISSUpdateAvailable.Enabled) {
			if ($GUISSUpdateAvailable.Checked) {
				UpdateAreAvailable -Disable
			}
		}

		if ($GUISSUpdateTPMUpdate.Enabled) {
			if ($GUISSUpdateTPMUpdate.Checked) {
				Win11TPMUpdate -Disable
			}
		}

		if ($GUISSDefender.Checked) {
			InstallProcess -appname "$($lang.Close) $($lang.DefenderControlTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50\dControl" -pwd "sordum" -url "https://www.sordum.org/files/download/d-control/dControl.zip" -urlAMD64 "" -urlarm64 "" -filename "dfControl*" -param "" -Before "1:dfControl:ini" -After ""
		}

		if ($GUISSDefenderLoginAccount.Enabled) {
			if ($GUISSDefenderLoginAccount.Checked) {
				DismissMSAccount -Disable
			}
		}

		if ($GUISSDefenderEdgeFilter.Enabled) {
			if ($GUISSDefenderEdgeFilter.Checked) {
				DismissSmartScreenFilter -Disable
			}
		}

		if ($GUISSFirewall.Checked) {
			InstallProcess -appname "$($lang.Close) $($lang.FabTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50\Fab" -pwd "" -url "https://www.sordum.org/files/download/firewall-app-blocker/fab.zip" -urlAMD64 "" -urlarm64 "" -filename "fab*" -param "/S 3" -Before "1:Fab:ini" -After ""
		}

		if ($GUISSOneDrive.Checked) { DelOneDrive }
		if ($GUISSEdge.Checked) { DelEdge }
		WaitEnd
		$GUISS.Close()
	}
	$GUISS             = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 550
		Text           = $lang.ComesWith
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUISSPanel        = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 515
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 1
		Location       = "0,0"
	}

	<#
		.Windows Update
	#>
	$GUISSUpdate       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 495
		Text           = "$($lang.Close) $($lang.WubTips)"
		ForeColor      = "#008000"
		Location       = "8,5"
		add_Click      = $GUISSUpdateClick
		Checked        = $true
	}
	$GUISSUpdateDA     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 470
		Text           = "$($lang.Disable) $($lang.UpdateAutoDownload)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateWelcomeExperience = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 470
		Text           = "$($lang.Hide) $($lang.UpdateWelcomeExperience)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateFirstLogonAnimation = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 470
		Text           = "$($lang.Disable) $($lang.UpdateFirstLogonAnimation)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateGP     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 470
		Text           = "$($lang.Disable) $($lang.UpdatePolicies)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateDrive  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 470
		Text           = "$($lang.Disable) $($lang.UpdateAutoDrive)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateAvailable = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 470
		Text           = "$($lang.Disable) $($lang.UpdateAreAvailable)"
		ForeColor      = "#008000"
		Checked        = $true
		Padding        = "18,0,0,0"
	}
	$GUISSUpdateTPMUpdate = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 470
		Text           = "$($lang.Disable) $($lang.TPMUpdate)"
		Checked        = $true
		ForeColor      = "#008000"
		Padding        = "18,0,0,0"
	}
	$GUISSDefender     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 36
		Width          = 495
		Text           = "$($lang.Close) $($lang.DefenderControlTips)"
		ForeColor      = "#008000"
		Padding        = "0,8,0,0"
		Checked        = $true
		add_Click      = $GUISSDefenderClick
	}
	$GUISSDefenderLoginAccount = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 460
		Text           = "$($lang.Disable) $($lang.DefenderLoginAccount)"
		ForeColor      = "#008000"
		Padding        = "18,0,0,0"
		add_Click      = $GUISSUpdateClick
		Checked        = $true
	}
	$GUISSDefenderEdgeFilter = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 40
		Width          = 460
		Text           = "$($lang.Disable) $($lang.DefenderEdgeFilter)"
		ForeColor      = "#008000"
		Padding        = "18,0,0,0"
		add_Click      = $GUISSUpdateClick
		Checked        = $true
	}
	$GUISSFirewall     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 36
		Width          = 495
		Text           = "$($lang.Close) $($lang.FabTips)"
		ForeColor      = "#008000"
		Padding        = "0,8,0,0"
		Checked        = $true
	}
	$GUISSOneDrive     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 495
		Text           = "$($lang.Delete) OneDrive"
	}
	$GUISSEdge         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 26
		Width          = 495
		Text           = "$($lang.Delete) Edge"
	}

	$GUISSErrorMsg     = New-Object system.Windows.Forms.Label -Property @{
		Location       = "10,530"
		Height         = 22
		Width          = 512
		Text           = $lang.OptimizationTips
	}
	$GUISSReset        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,555"
		Height         = 36
		Width          = 515
		add_Click      = $GUISSResetClick
		Text           = $lang.Restore
	}
	$GUISSOK           = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,595"
		Height         = 36
		Width          = 515
		add_Click      = $GUISSOKClick
		Text           = $lang.OK
	}
	$GUISSCanel        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,635"
		Height         = 36
		Width          = 515
		add_Click      = $GUISSCanelClick
		Text           = $lang.Cancel
	}
	$GUISS.controls.AddRange((
		$GUISSPanel,
		$GUISSErrorMsg,
		$GUISSReset,
		$GUISSOK,
		$GUISSCanel
	))

	$GUISSPanel.controls.AddRange((
		$GUISSUpdate,
		$GUISSUpdateDA,
		$GUISSUpdateWelcomeExperience,
		$GUISSUpdateFirstLogonAnimation,
		$GUISSUpdateGP,
		$GUISSUpdateDrive,
		$GUISSUpdateAvailable
	))

	if (IsWin11) {
		$GUISSPanel.controls.AddRange((
			$GUISSUpdateTPMUpdate
		))
	}

	$GUISSPanel.controls.AddRange((
		$GUISSDefender,
		$GUISSDefenderLoginAccount,
		$GUISSDefenderEdgeFilter,
		$GUISSFirewall,
		$GUISSOneDrive,
		$GUISSEdge
	))

	$GUISSMenuAllSelClick = {
		$GUISSPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUISSMenuAllClearClick = {
		$GUISSPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUISSMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUISSMenu.Items.Add($lang.AllSel).add_Click($GUISSMenuAllSelClick)
	$GUISSMenu.Items.Add($lang.AllClear).add_Click($GUISSMenuAllClearClick)
	$GUISSPanel.ContextMenuStrip = $GUISSMenu

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUISS.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUISS.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$GUISS.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$GUISS.FormBorderStyle = 'Fixed3D'
	$GUISS.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

<#
	.Delete One Drive
	.删除 One Drive
#>
Function DelOneDrive
{
	Write-Host "   $($lang.Delete) OneDrive" -ForegroundColor Green

#	Write-Output "Kill OneDrive process"
	Stop-Process -ProcessName OneDrive -force -ErrorAction SilentlyContinue  | Out-Null
	Stop-Process -ProcessName OneDriveSetup -force -ErrorAction SilentlyContinue | Out-Null
	Stop-Process -ProcessName explorer -force -ErrorAction SilentlyContinue | Out-Null

#	Write-Output "Remove OneDrive"
	if (Test-Path "$($env:systemroot)\System32\OneDriveSetup.exe") {
	    & "$($env:systemroot)\System32\OneDriveSetup.exe" /uninstall
	}
	if (Test-Path "$($env:systemroot)\SysWOW64\OneDriveSetup.exe") {
	    & "$($env:systemroot)\SysWOW64\OneDriveSetup.exe" /uninstall
	}

	Write-Output "Removing OneDrive leftovers"
	Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "$($env:USERPROFILE)\OneDrive" | Out-Null
	Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "$($env:localappdata)\Microsoft\OneDrive" | Out-Null
	Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "$($env:programdata)\Microsoft OneDrive" | Out-Null
	Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "$($env:SystemDrive)\OneDriveTemp" | Out-Null

	# check if directory is empty before removing:
	If ((Get-ChildItem "$($env:USERPROFILE)\OneDrive" -Recurse -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0) {
	    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "$($env:USERPROFILE)\OneDrive" | Out-Null
	}

#	Write-Output "Disable OneDrive via Group Policies"
	New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\OneDrive" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\OneDrive" "DisableFileSyncNGSC" 1 -ErrorAction SilentlyContinue | Out-Null

#	Write-Output "Remove Onedrive from explorer sidebar"
	New-PSDrive -PSProvider "Registry" -Root "HKEY_CLASSES_ROOT" -Name "HKCR" -ErrorAction SilentlyContinue | Out-Null
	New-Item -Path "HKCR:\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
	Set-ItemProperty -Path "HKCR:\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" "System.IsPinnedToNameSpaceTree" 0 -ErrorAction SilentlyContinue | Out-Null
	New-Item -Path "HKCR:\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
	Set-ItemProperty -Path "HKCR:\Wow6432Node\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" "System.IsPinnedToNameSpaceTree" 0 -ErrorAction SilentlyContinue | Out-Null
	Remove-PSDrive "HKCR" -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" -Force -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Wow6432Node\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" -Force -ErrorAction SilentlyContinue | Out-Null
	Remove-ItemProperty -Path "HKLM:\defuser\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name OneDriveSetup -Force -ErrorAction SilentlyContinue | Out-Null

	# Thank you Matthew Israelsson
#	Write-Output "Removing run hook for new users"
	reg load "hku\Default" "$($env:systemroot)\Users\Default\NTUSER.DAT" | Out-Null
	reg delete "HKEY_USERS\Default\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "OneDriveSetup" /f | Out-Null
	reg unload "hku\Default" | Out-Null

#	Write-Output "Removing startmenu entry"
	Remove-Item -Force -ErrorAction SilentlyContinue "$($env:USERPROFILE)\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk" | Out-Null
	Remove-Item -Force -ErrorAction SilentlyContinue "$($env:systemroot)\ServiceProfiles\NetworkService\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk" | Out-Null
	Remove-Item -Force -ErrorAction SilentlyContinue "$($env:systemroot)\ServiceProfiles\LocalService\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk" | Out-Null

#	Write-Output "Removing scheduled task"
	Get-ScheduledTask -TaskPath '\' -TaskName 'OneDrive*' -ea SilentlyContinue | Unregister-ScheduledTask -Confirm:$false -ErrorAction SilentlyContinue | Out-Null

#	Write-Output "Restarting explorer"
	RestartExplorer

#	Write-Output "Waiting for explorer to complete loading"
	Start-Sleep 5

	<#
		Removing additional OneDrive leftovers
	#>
	foreach ($item in (Get-ChildItem "$env:WinDir\WinSxS\*onedrive*" -ErrorAction SilentlyContinue)) {
		TakeownFolder $item.FullName
		Remove-Item -Recurse -Force $item.FullName -ErrorAction SilentlyContinue | Out-Null
	}

	Start-Process "takeown" -ArgumentList "/F $env:WinDIR\System32\OneDriveSetup.exe" -WindowStyle Hidden
	Start-Process "takeown" -ArgumentList "/F $env:WinDIR\System32\OneDriveSetup.exe" -WindowStyle Hidden
	Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\OneDriveSetup.exe /Grant System:(F)" -WindowStyle Hidden
	Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\OneDriveSetup.exe /Grant Administrator:(F)" -WindowStyle Hidden
	Start-Process "icacls" -ArgumentList "$env:WinDIR\SysWOW64\OneDriveSetup.exe /Grant System:(F)" -WindowStyle Hidden
	Start-Process "icacls" -ArgumentList "$env:WinDIR\SysWOW64\OneDriveSetup.exe /Grant Administrator:(F)" -WindowStyle Hidden

	Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "$($env:systemroot)\SysWOW64\OneDriveSetup.exe" | Out-Null
	Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "$($env:systemroot)\System32\OneDriveSetup.exe" | Out-Null
}

<#
	.Delete Edge browser
	.删除 Edge 浏览器
#>
Function DelEdge
{
	Write-Host "   $($lang.Delete) Edge" -ForegroundColor Green
	$softiwt = "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO")\install_wim_tweak.exe"
	if (Test-Path $softiwt -PathType Leaf ) {
		Start-Process $softiwt -ArgumentList "/o" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/o /c Microsoft-Windows-Internet-Browser-Package /r" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/o /c Microsoft.MicrosoftEdgeDevToolsClient /r" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/o /c Microsoft.MicrosoftEdgeDevToolsClient_1000.20226.1000.0_neutral_neutral_8wekyb3d8bbwe /r" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/h /o" -Wait -WindowStyle Minimized
	}

	Get-ChildItem -Path "${env:ProgramFiles(x86)}\Microsoft\Edge\Application" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
		$filename = "$($_.FullName)\Installer\setup.exe"
		$param = "--uninstall --force-uninstall --system-level"

		if (Test-Path $filename -PathType Leaf) {
			Write-Host "`n   EDGE has been installed, execute the delete command:"
			Start-Process -FilePath $filename -ArgumentList $param -Wait
			Write-Host "`n   Finish deleting..."
		}
	}

	$apps = @(
		"*edge*"
	)

	foreach ($app in $apps) {
		Write-Host "   Trying to remove $app"

		Get-AppxPackage -Name $app | Remove-AppxPackage -ErrorAction SilentlyContinue | Out-Null
		Get-AppxPackage -Name $app -AllUsers | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue | Out-Null

		Get-AppXProvisionedPackage -Online -ErrorAction SilentlyContinue | Out-Null | Where-Object DisplayName -EQ $app | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Out-Null
	}

	# Force removing Edge apps
	$needles = @(
		"*edge*"
	)

	foreach ($needle in $needles) {
		write-host "   Trying to remove all packages containing $needle"
		$pkgs = (Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages" |
			Where-Object Name -Like "*$needle*" -ErrorAction SilentlyContinue)

		foreach ($pkg in $pkgs) {
			$pkgname = $pkg.Name.split('\')[-1]

			Takeown-Registry($pkg.Name)
			Takeown-Registry($pkg.Name + "\Owners")

			Set-ItemProperty -Path ("HKLM:" + $pkg.Name.Substring(18)) -Name Visibility -Value 1 -ErrorAction SilentlyContinue | Out-Null
			New-ItemProperty -Path ("HKLM:" + $pkg.Name.Substring(18)) -Name DefVis -PropertyType DWord -Value 2 -ErrorAction SilentlyContinue | Out-Null
			Remove-Item      -Path ("HKLM:" + $pkg.Name.Substring(18) + "\Owners") -ErrorAction SilentlyContinue | Out-Null

			dism.exe /Online /Remove-Package /PackageName:$pkgname /NoRestart
		}
	}

	# Removing additional Edge leftovers
#	foreach ($item in (Get-ChildItem "$env:WinDir\SystemApps\*edge*" -ErrorAction SilentlyContinue | Out-Null)) {
#	    TakeownFolder $item.FullName
#	    Remove-Item -Recurse -Force $item.FullName -ErrorAction SilentlyContinue | Out-Null
#	}
#	foreach ($item in (Get-ChildItem "$env:WinDir\WinSxS\*edge*" -ErrorAction SilentlyContinue | Out-Null)) {
#	    TakeownFolder $item.FullName
#	    Remove-Item -Recurse -Force $item.FullName -ErrorAction SilentlyContinue | Out-Null
#	}
#	foreach ($item in (Get-ChildItem "$env:WinDir\WinSxS\Manifests\*edge*" -ErrorAction SilentlyContinue | Out-Null)) {
#	    TakeownFolder $item.FullName
#	    Remove-Item -Recurse -Force $item.FullName -ErrorAction SilentlyContinue | Out-Null
#	}
	foreach ($item in (Get-ChildItem "$env:WinDir\WinSxS\FileMaps\*edge*" -ErrorAction SilentlyContinue | Out-Null)) {
		TakeownFolder $item.FullName
		Remove-Item -Recurse -Force $item.FullName -ErrorAction SilentlyContinue | Out-Null
	}
	foreach ($item in (Get-ChildItem "$env:WinDir\System32\*edge*" -ErrorAction SilentlyContinue | Out-Null)) {
		TakeownFolder $item.FullName
		Remove-Item -Recurse -Force $item.FullName -ErrorAction SilentlyContinue | Out-Null
	}
	foreach ($item in (Get-ChildItem "$env:WinDir\temp\*edge*" -ErrorAction SilentlyContinue | Out-Null)) {
		TakeownFolder $item.FullName
		Remove-Item -Recurse -Force $item.FullName -ErrorAction SilentlyContinue | Out-Null
	}
	foreach ($item in (Get-ChildItem "$($env:localappdata)\temp\*edge*" -ErrorAction SilentlyContinue | Out-Null)) {
		TakeownFolder $item.FullName
		Remove-Item -Recurse -Force $item.FullName -ErrorAction SilentlyContinue | Out-Null
	}
	foreach ($item in (Get-ChildItem "$($env:programdata)\Microsoft\Windows\AppRepository\*edge*" -ErrorAction SilentlyContinue | Out-Null)) {
		TakeownFolder $item.FullName
		Remove-Item -Recurse -Force $item.FullName -ErrorAction SilentlyContinue | Out-Null
	}
	foreach ($item in (Get-ChildItem "$env:WinDir\Prefetch\*edge*" -ErrorAction SilentlyContinue | Out-Null)) {
		TakeownFolder $item.FullName
		Remove-Item -Recurse -Force $item.FullName -ErrorAction SilentlyContinue | Out-Null
	}

	Remove-Item -Path "$($env:localappdata)\Microsoft\Edge" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "$($env:localappdata)\Microsoft\Windows\Safety" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "$($env:programdata)\Microsoft\EdgeUpdate" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
}

Enum Status
{
	Enable
	Disable
}

Enum Mode
{
	Wait
	Fast
	Queue
}

Enum Action
{
	Install
	NoInst
	To
	Unzip
}

Export-ModuleMember -Function * -Alias *