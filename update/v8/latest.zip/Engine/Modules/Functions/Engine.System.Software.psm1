﻿<#
 .Synopsis
  System software

 .Description
  System software Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.System software user interface
	.系统软件用户界面
#>
Function SystemSoftware
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.ComesWith)
	Write-Host "   $($lang.PlanTask)
   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUISSMenuAllSelClick = {
		$GUISSPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $true }
		}
	}
	$GUISSMenuAllClearClick = {
		$GUISSPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]){ $_.Checked = $false }
		}
	}
	$GUISSCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUISS.Close()
	}
	$GUISSResetClick = {
		$GUISS.Hide()
		if ($GUISSDefender.Checked) {
			InstallProcess -appname "$($lang.Enable) $($lang.DefenderControlTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50" -pwd "sordum" -url "https://www.sordum.org/files/download/d-control/dControl.zip" -urlAMD64 "" -urlarm64 "" -filename "dControl*" -param "/E" -method "1:dControl:ini"
		}

		if ($GUISSFirewall.Checked) {
			InstallProcess -appname "$($lang.Enable) $($lang.FabTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50" -pwd "" -url "https://www.sordum.org/files/download/firewall-app-blocker/fab.zip" -urlAMD64 "" -urlarm64 "" -filename "fab*" -param "/S 0" -method "1:Fab:ini"
		}

		if ($GUISSUpdate.Checked) {
			InstallProcess -appname "$($lang.Enable) $($lang.WubTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50" -pwd "" -url "https://www.sordum.org/files/download/windows-update-blocker/Wub.zip" -urlAMD64 "" -urlarm64 "" -filename "Wub*" -param "/E" -method "1:Wub:ini"
		}
		WaitEnd
		$GUISS.Close()
	}
	$GUISSOKClick = {
		$GUISS.Hide()
		if ($GUISSDefender.Checked) {
			InstallProcess -appname "$($lang.Close) $($lang.DefenderControlTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50" -pwd "sordum" -url "https://www.sordum.org/files/download/d-control/dControl.zip" -urlAMD64 "" -urlarm64 "" -filename "dControl*" -param "/D" -method "1:dControl:ini"
		}

		if ($GUISSFirewall.Checked) {
			InstallProcess -appname "$($lang.Close) $($lang.FabTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50" -pwd "" -url "https://www.sordum.org/files/download/firewall-app-blocker/fab.zip" -urlAMD64 "" -urlarm64 "" -filename "fab*" -param "/S 3" -method "1:Fab:ini"
		}

		if ($GUISSUpdate.Checked) {
			InstallProcess -appname "$($lang.Close) $($lang.WubTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $env:SystemDrive -structure "$($Global:UniqueID)\50" -pwd "" -url "https://www.sordum.org/files/download/windows-update-blocker/Wub.zip" -urlAMD64 "" -urlarm64 "" -filename "Wub*" -param "/D /P" -method "1:Wub:ini"
		}

		if ($GUISSOneDrive.Checked) { DelOneDrive }
		if ($GUISSEdge.Checked) { DelEdge }
		if ($GUISSTaskBar.Checked) { ResetTaskBar }
		if ($GUISSResetDesk.Checked) { ResetDesktop }
		WaitEnd
		$GUISS.Close()
	}
	$GUISS             = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 600
		Width          = 450
		Text           = $lang.ComesWith
		TopMost        = $True
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUISSPanel        = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 475
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 1
	}
	$GUISSDefender     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Close) $($lang.DefenderControlTips)"
		ForeColor      = "#008000"
		Checked        = $true
	}
	$GUISSFirewall     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Close) $($lang.FabTips)"
		ForeColor      = "#008000"
		Checked        = $true
	}
	$GUISSUpdate       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Close) $($lang.WubTips)"
		ForeColor      = "#008000"
		Checked        = $true
	}
	$GUISSOneDrive     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Delete) OneDrive"
		Checked        = $true
	}
	$GUISSEdge         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Delete) Edge"
	}
	$GUISSTaskBar      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = "$($lang.Reset) $($lang.TaskBar)"
	}
	$GUISSResetDesk    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 405
		Text           = $lang.ResetDesk
	}
	$GUISSErrorMsg     = New-Object system.Windows.Forms.Label -Property @{
		Location       = "10,490"
		Height         = 22
		Width          = 405
		Text           = $lang.OptimizationTips
	}
	$GUISSReset        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "10,515"
		Height         = 36
		Width          = 133
		add_Click      = $GUISSResetClick
		Text           = $lang.Enable
	}
	$GUISSOK           = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "148,515"
		Height         = 36
		Width          = 133
		add_Click      = $GUISSOKClick
		Text           = $lang.OK
	}
	$GUISSCanel        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "286,515"
		Height         = 36
		Width          = 133
		add_Click      = $GUISSCanelClick
		Text           = $lang.Cancel
	}
	$GUISS.controls.AddRange((
		$GUISSPanel,
		$GUISSErrorMsg,
		$GUISSReset,
		$GUISSOK,
		$GUISSCanel
	))

	$GUISSPanel.controls.AddRange((
		$GUISSDefender,
		$GUISSFirewall,
		$GUISSUpdate,
		$GUISSOneDrive,
		$GUISSEdge,
		$GUISSTaskBar,
		$GUISSResetDesk
	))

	$GUISSMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUISSMenu.Items.Add($lang.AllSel).add_Click($GUISSMenuAllSelClick)
	$GUISSMenu.Items.Add($lang.AllClear).add_Click($GUISSMenuAllClearClick)
	$GUISS.ContextMenuStrip = $GUISSMenu

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUISS.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUISS.Font = New-Object System.Drawing.Font("Arial", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	$GUISS.FormBorderStyle = 'Fixed3D'
	$GUISS.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

<#
	.Delete One Drive
	.删除 One Drive
#>
Function DelOneDrive
{
	Write-Host "   $($lang.Delete) OneDrive" -ForegroundColor Green
	$removeonedrive = "$PSScriptRoot\..\..\AIO\Opt\scripts\remove-onedrive.ps1"
	if (Test-Path $removeonedrive -PathType Leaf ) {
		Start-Process "powershell" -ArgumentList "-file $($removeonedrive)" -WindowStyle Minimized
	}
}

<#
	.Delete Edge browser
	.删除 Edge 浏览器
#>
Function DelEdge
{
	Write-Host "   $($lang.Delete) Edge" -ForegroundColor Green
	$softiwt = "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO")\install_wim_tweak.exe"
	if (Test-Path $softiwt -PathType Leaf ) {
		Start-Process $softiwt -ArgumentList "/o" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/o /c Microsoft-Windows-Internet-Browser-Package /r" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/o /c Microsoft.MicrosoftEdgeDevToolsClient /r" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/o /c Microsoft.MicrosoftEdgeDevToolsClient_1000.20226.1000.0_neutral_neutral_8wekyb3d8bbwe /r" -Wait -WindowStyle Minimized
		Start-Process $softiwt -ArgumentList "/h /o" -Wait -WindowStyle Minimized
	}
	$latestedge = "$PSScriptRoot\..\..\AIO\Opt\scripts\latest.uninstall.edge.ps1"
	if (Test-Path $latestedge -PathType Leaf ) {
		Start-Process "powershell" -ArgumentList "-file $latestedge" -Wait -WindowStyle Minimized
	}
}

Enum Status
{
	Enable
	Disable
}

Enum Mode
{
	Wait
	Fast
	Queue
}

Enum Action
{
	Install
	NoInst
	To
	Unzip
}

Export-ModuleMember -Function * -Alias *