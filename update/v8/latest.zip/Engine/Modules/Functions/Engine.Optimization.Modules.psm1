﻿Function DisableTakeOwnership
{
	Write-Host "   $($lang.Delete) $($lang.AddOwnership)"
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Drive\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableTakeOwnership
{
	Write-Host "   $($lang.AddTo) $($lang.AddOwnership)"
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'AppliesTo' -Value "NOT (System.ItemPathDisplay:=\""$env:SystemDrive\Users\"" OR System.ItemPathDisplay:=\""$env:SystemDrive\ProgramData\"" OR System.ItemPathDisplay:=\""$env:SystemRoot\"" OR System.ItemPathDisplay:=\""$env:SystemRoot\System32\"" OR System.ItemPathDisplay:=\""$env:SystemDrive\Program Files\"" OR System.ItemPathDisplay:=\""$env:SystemDrive\Program Files (x86)\"")" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" /r && icacls "%1" /grant *S-1-3-4:F /t /c /l /q & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" /r && icacls "%1" /grant *S-1-3-4:F /t /c /l /q & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership' -Name "MUIVerb" -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command' -Name '(default)' -Value '"%1" %*' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value '"%1" %*' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	RefreshIconCache
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableHibernation
{
	Write-Host "   $($lang.Close) $($lang.Hibernation)"
	Start-Process 'powercfg.exe' -Verb runAs -ArgumentList '/h off' -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableHibernation
{
	Write-Host "   $($lang.Enable) $($lang.Hibernation)"
	Start-Process 'powercfg.exe' -ArgumentList '/h on' -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SetPowerSupply
{
	Write-Host "   $($lang.Setting) $($lang.PowerSupply)"
	powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
	powercfg -change -monitor-timeout-ac 0
	powercfg -change -monitor-timeout-dc 0
	powercfg -change -disk-timeout-ac 0
	powercfg -change -disk-timeout-dc 5
	powercfg -change -standby-timeout-ac 0
	powercfg -change -standby-timeout-dc 60
	powercfg -change -hibernate-timeout-ac 0
	powercfg -change -hibernate-timeout-dc 300
	powercfg /SETACVALUEINDEX 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
	powercfg /SETDCVALUEINDEX 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestorePowerSupply
{
	Write-Host "   $($lang.Restore) $($lang.PowerSupply)"
	powercfg -restoredefaultschemes
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableAppRestartScreen
{
	Write-Host "   $($lang.Enable) $($lang.AppRestartScreen)"
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'WaitToKillServiceTimeout' -Value '5000' -PropertyType String -Force -ea SilentlyContinue | out-null
	Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name WaitToKillAppTimeout -Force -ErrorAction SilentlyContinue | out-null
	Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name HungAppTimeout -Force -ErrorAction SilentlyContinue | out-null
	Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name AutoEndTasks -Force -ErrorAction SilentlyContinue | out-null
	Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name AutoEndTasks -Force -ErrorAction SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableAppRestartScreen
{
	Write-Host "   $($lang.Disable) $($lang.AppRestartScreen)"
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'WaitToKillServiceTimeout' -Value '0' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'WaitToKillAppTimeout' -Value '4000' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'HungAppTimeout' -Value '5000' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableArrow
{
	Write-Host "   $($lang.Delete) $($lang.ShortcutArrow)"
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Value "$env:SystemRoot\system32\imageres.dll,197" -PropertyType String -Force -ea SilentlyContinue | out-null
	Remove-Item -Path "$env:USERPROFILE\AppData\Local\iconcache.db" -ErrorAction SilentlyContinue
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'link' -Value ([byte[]](0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreArrow
{
	Write-Host "   $($lang.Restore) $($lang.ShortcutArrow)"
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\IE.AssocFile.URL' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\InternetShortcut' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\lnkfile' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
	Remove-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Force -ea SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name link -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableNumlock
{
	Write-Host "   $($lang.Setting) $($lang.Numlock)"
	If (-not (Test-Path "HKU:")) {
		New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS | Out-Null
	}
	Set-ItemProperty -Path "HKU:\.DEFAULT\Control Panel\Keyboard" -Name "InitialKeyboardIndicators" -Type DWord -Value 2147483650 -ErrorAction SilentlyContinue
	Add-Type -AssemblyName System.Windows.Forms
	If (-not ([System.Windows.Forms.Control]::IsKeyLocked('NumLock'))) {
		$wsh = New-Object -ComObject WScript.Shell
		$wsh.SendKeys('{NUMLOCK}')
	}
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableNumlock
{
	Write-Host "   $($lang.Cancel) $($lang.Numlock)"
	If (-not(Test-Path "HKU:")) {
		New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS | Out-Null
	}
	Set-ItemProperty -Path "HKU:\.DEFAULT\Control Panel\Keyboard" -Name "InitialKeyboardIndicators" -Type DWord -Value 2147483648 -ErrorAction SilentlyContinue
	Add-Type -AssemblyName System.Windows.Forms
	If ([System.Windows.Forms.Control]::IsKeyLocked('NumLock')) {
		$wsh = New-Object -ComObject WScript.Shell
		$wsh.SendKeys('{NUMLOCK}')
	}
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SetSearchBox
{
	param
	(
		[string]$Type
	)

	switch ($Type) {
		"icon" {
			New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		}
		"Box" {
			New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		}
	}
}

Function SetUACNever
{
	Write-Host "   $($lang.Setting) $($lang.UAC)$($lang.UACNever)"
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SetUACDefault
{
	Write-Host "   $($lang.Restore) $($lang.UAC)$($lang.UACNever)"
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 5 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableSmartScreen
{
	Write-Host "   $($lang.Disable) $($lang.SmartScreen)"
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Type String -Value "Off"
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" -Name "EnableWebContentEvaluation" -Type DWord -Value 0

	Get-ChildItem -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\*edge*" -Name -ErrorAction SilentlyContinue | ForEach-Object {
		if (Test-Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -PathType Container) {
			Set-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -Type DWord -Value 0 | Out-Null
			Set-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "PreventOverride" -Type DWord -Value 0 | Out-Null
		}
	}
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableSmartScreen
{
	Write-Host "   $($lang.Enable) $($lang.SmartScreen)"
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Type String -Value "RequireAdmin"
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" -Name "EnableWebContentEvaluation" -ErrorAction SilentlyContinue

	Get-ChildItem -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\*edge*" -Name -ErrorAction SilentlyContinue | ForEach-Object {
		if (Test-Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -PathType Container) {
			Remove-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -ErrorAction SilentlyContinue | Out-Null
			Remove-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "PreventOverride" -ErrorAction SilentlyContinue | Out-Null
		}
	}
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableMaintain
{
	Write-Host "   $($lang.Disable) $($lang.Maintain)"
	Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" -Name "MaintenanceDisabled" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableMaintain
{
	Write-Host "   $($lang.Enable) $($lang.Maintain)"
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance' -Name 'MaintenanceDisabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SetExperience
{
	Write-Host "   $($lang.Disable) $($lang.Experience)"
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows' -Name 'CEIPEnable' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreExperience
{
	Write-Host "   $($lang.Restore) $($lang.Experience)"
	Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows" -Name "CEIPEnable" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableSafetyWarnings
{
	Write-Host "   $($lang.Disable) $($lang.SafetyWarnings)"
	Remove-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableSafetyWarnings
{
	Write-Host "   $($lang.Enable) $($lang.SafetyWarnings)"
	if ((Test-Path -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations") -ne $true) { New-Item "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'LowRiskFileTypes' -Value '.exe;.reg;.msi;.bat;.cmd;.com;.vbs;.hta;.scr;.pif;.js;' -PropertyType String -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableQOS
{
	Write-Host "   $($lang.Disable) $($lang.QOS)"
	Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\nvspbind")\nvspbind.exe" -ArgumentList "/d ""*"" ms_pacer" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableQOS
{
	Write-Host "   $($lang.Enable) $($lang.QOS)"
	Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\nvspbind")\nvspbind.exe" -ArgumentList "/e ""*"" ms_pacer" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableNetworkTuning
{
	Write-Host "   $($lang.Disable) $($lang.NetworkTuning)"
	netsh interface tcp set global autotuninglevel=disabled | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableNetworkTuning
{
	Write-Host "   $($lang.Enable) $($lang.NetworkTuning)"
	netsh interface tcp set global autotuninglevel=normal | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableECN
{
	Write-Host "   $($lang.Disable) $($lang.ECN)"
	netsh int tcp set global ecn=disable | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableECN
{
	Write-Host "   $($lang.Enable) $($lang.ECN)"
	netsh int tcp set global ecn=enabled | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableErrorRecovery
{
	Write-Host "   $($lang.Disable) $($lang.ErrorRecovery)"
	bcdedit /set `{current`} bootstatuspolicy ignoreallfailures | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableErrorRecovery
{
	Write-Host "   $($lang.Enable) $($lang.ErrorRecovery)"
	bcdedit /set {default} bootstatuspolicy DisplayAllFailures | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableDEPPAE
{
	Write-Host "   $($lang.Disable) $($lang.DEP)"
	bcdedit /set `{current`} nx AlwaysOff
	bcdedit /set `{current`} pae ForceDisable
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreDEPPAE
{
	Write-Host "   $($lang.Enable) $($lang.DEP)"
	bcdedit /deletevalue `{current`} pae 
	bcdedit /set `{current`} nx OptIn
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisablePowerFailure
{
	Write-Host "   $($lang.Disable) $($lang.PowerFailure)"
	bcdedit /set `{current`} Recoveryenabled No | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnablePowerFailure
{
	Write-Host "   $($lang.Enable) $($lang.PowerFailure)"
	bcdedit /set `{current`} Recoveryenabled Yes | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableScheduledTasks
{
	Write-Host "   $($lang.Disable) $($lang.ScheduledTasks)"
	Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\..\AIO\Opt\utils\disable-scheduled-tasks.ps1""" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreScheduledTasks
{
	Write-Host "   $($lang.Restore) $($lang.ScheduledTasks)"
	Write-Host "   - $($lang.NotSupport)" -ForegroundColor Red
}

Function DisableOptUser
{
	Write-Host "   $($lang.Disable) $($lang.OptUser)"
	Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\..\AIO\Opt\scripts\optimize-user-interface.ps1""" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreOptUser
{
	Write-Host "   $($lang.Restore) $($lang.OptUser)"
	Write-Host "   - $($lang.NotSupport)" -ForegroundColor Red
}

Function DisableOptUpdate
{
	Write-Host "   $($lang.Optimize) $($lang.OptUpdate)"
	Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\..\AIO\Opt\scripts\optimize-windows-update.ps1""" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreOptUpdate
{
	Write-Host "   $($lang.Restore) $($lang.OptUpdate)"
	Write-Host "   - $($lang.NotSupport)" -ForegroundColor Red
}

Function DisableFixPrivacy
{
	Write-Host "   $($lang.Optimize) $($lang.FixPrivacy)"
	Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\..\AIO\Opt\scripts\fix-privacy-settings.ps1""" -Wait -WindowStyle Minimized
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreFixPrivacy
{
	Write-Host "   $($lang.Restore) $($lang.FixPrivacy)"
	Write-Host "   - $($lang.NotSupport)" -ForegroundColor Red
}

Function DisableTimelineTime
{
	Write-Host "   $($lang.Disable) $($lang.TimelineTime)"
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableTimelineTime
{
	Write-Host "   $($lang.Enable) $($lang.TimelineTime)"
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableCollectActivity
{
	Write-Host "   $($lang.Disable) $($lang.CollectActivity)"
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'PublishUserActivities' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableCollectActivity
{
	Write-Host "   $($lang.Enable) $($lang.CollectActivity)"
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'PublishUserActivities' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableAutoDetect
{
	Write-Host "   $($lang.Disable) $($lang.IEAutoSet)"
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoDetect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableAutoDetect
{
	Write-Host "   $($lang.Enable) $($lang.IEAutoSet)"
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoDetect' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function IEProxy
{
	Write-Host "   $($lang.Restore) $($lang.IEProxy)"
	"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections [1 7 17]" | Out-File -FilePath "$env:TEMP\ie_proxy.ini" -Encoding ASCII
	Start-Process "regini" -ArgumentList "$env:TEMP\ie_proxy.ini" -WindowStyle Minimized
	Remove-Item -Path "$env:TEMP\ie_proxy.ini" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SetMergeTaskbarNever
{
	Write-Host "   $($lang.Setting) $($lang.MergeTaskbarNever)"
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarGlomLevel' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DefaultMergeTaskbarNever
{
	Write-Host "   $($lang.Restore) $($lang.MergeTaskbarNever)"
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name TaskbarGlomLevel -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SetNotificationAlways
{
	Write-Host "   $($lang.Setting) $($lang.NotificationAlways)"
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'EnableAutoTray' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DefaultNotificationAlways
{
	Write-Host "   $($lang.Restore) $($lang.NotificationAlways)"
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name EnableAutoTray -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SetNavShowAll
{
	Write-Host "   $($lang.Setting) $($lang.NavShowAll)"
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'NavPaneExpandToCurrentFolder' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreNavShowAll
{
	Write-Host "   $($lang.Restore) $($lang.NavShowAll)"
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "NavPaneExpandToCurrentFolder" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SetCortana
{
	Write-Host "   $($lang.Setting) $($lang.Cortana)"
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreCortana
{
	Write-Host "   $($lang.Restore) $($lang.Cortana)"
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "ShowCortanaButton" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function HideRecentShortcuts
{
	Write-Host "   $($lang.Disable) $($lang.QuickAccess)"
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowRecent" -Type DWord -Value 0
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowFrequent" -Type DWord -Value 0
	Remove-Item -Path "$env:appdata\Microsoft\Windows\Recent\*.*"
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function ShowRecentShortcuts
{
	Write-Host "   $($lang.Enable) $($lang.QuickAccess)"
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowRecent" -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowFrequent" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableMemoryCompression
{
	Write-Host "   $($lang.Disable) $($lang.MemoryCompression)"
	Disable-MMAgent -mc
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableMemoryCompression
{
	Write-Host "   $($lang.Enable) $($lang.MemoryCompression)"
	Enable-MMAgent -mc
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisablePrelaunch
{
	Write-Host "   $($lang.Disable) $($lang.Prelaunch)"
	Disable-MMAgent -ApplicationPreLaunch
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnablePrelaunch
{
	Write-Host "   $($lang.Enable) $($lang.Prelaunch)"
	Enable-MMAgent -ApplicationPreLaunch
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function OptSSD
{
	Write-Host "   $($lang.Optimize) $($lang.OptSSD)"
	fsutil behavior set DisableLastAccess 1 | Out-Null
	fsutil behavior set EncryptPagingFile 0 | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DefaultOptSSD
{
	Write-Host "   $($lang.Restore) $($lang.OptSSD)"
	fsutil behavior set DisableLastAccess 2 | Out-Null
	fsutil behavior set EncryptPagingFile 0 | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableCompatibility
{
	Write-Host "   $($lang.Disable) $($lang.Compatibility)"
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' -Name 'DisablePCA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableCompatibility
{
	Write-Host "   $($lang.Restore) $($lang.Compatibility)"
	Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function OptAnimationEffects
{
	Write-Host "   $($lang.Optimize) $($lang.AnimationEffects)"
	if ((Test-Path -LiteralPath "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM") -ne $true) { New-Item "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM' -Name 'DisallowAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'EnableAeroPeek' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'AlwaysHibernateThumbnails' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'TurnOffSPIAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -Name 'VisualFXSetting' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarAnimations' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewAlphaSelect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewShadow' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'IconsOnly' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop\WindowMetrics' -Name 'MinAnimate' -Value '0' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'UserPreferencesMask' -Value ([byte[]](0x9e,0x1e,0x07,0x80,0x12,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'DragFullWindows' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'FontSmoothing' -Value '2' -PropertyType String -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreAnimationEffects
{
	Write-Host "   $($lang.Restore) $($lang.AnimationEffects)"
	Write-Host "   - $($lang.NotSupport)" -ForegroundColor Red
}

Function DisableDefragmentation
{
	Write-Host "   $($lang.Disable) $($lang.Defragmentation)"
	Disable-ScheduledTask -TaskPath "\Microsoft\Windows\Defrag\" -TaskName "ScheduledDefrag" | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableDefragmentation
{
	Write-Host "   $($lang.Enable) $($lang.Defragmentation)"
	Enable-ScheduledTask -TaskPath "\Microsoft\Windows\Defrag\" -TaskName "ScheduledDefrag" | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisablePhotoPreview
{
	Write-Host "   $($lang.Disable) $($lang.PhotoPreview)"
	Remove-Item -Path "HKCU:\Software\Classes\.jpg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.jpeg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.gif" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.png" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.bmp" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.tiff" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Classes\.ico" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnablePhotoPreview
{
	Write-Host "   $($lang.Enable) $($lang.PhotoPreview)"
	if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.jpg") -ne $true) { New-Item "HKCU:\Software\Classes\.jpg" -force -ea SilentlyContinue }
	if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.jpeg") -ne $true) { New-Item "HKCU:\Software\Classes\.jpeg" -force -ea SilentlyContinue }
	if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.gif") -ne $true) { New-Item "HKCU:\Software\Classes\.gif" -force -ea SilentlyContinue }
	if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.png") -ne $true) { New-Item "HKCU:\Software\Classes\.png" -force -ea SilentlyContinue }
	if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.bmp") -ne $true) { New-Item "HKCU:\Software\Classes\.bmp" -force -ea SilentlyContinue }
	if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.tiff") -ne $true) { New-Item "HKCU:\Software\Classes\.tiff" -force -ea SilentlyContinue }
	if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.ico") -ne $true) { New-Item "HKCU:\Software\Classes\.ico" -force -ea SilentlyContinue }
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.jpg' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.jpeg' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.gif' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.png' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.bmp' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.tiff' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.ico' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SetRAM
{
	Write-Host "   $($lang.Setting) $($lang.RAM)"
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'SvcHostSplitThresholdInKB' -Value 67108864 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreRAM
{
	Write-Host "   $($lang.Restore) $($lang.RAM)"
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'SvcHostSplitThresholdInKB' -Value 3670016 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SetPwdUnlimited
{
	Write-Host "   $($lang.Setting) $($lang.PwdUnlimited)"
	net accounts /maxpwage:UNLIMITED | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestorePwdUnlimited
{
	Write-Host "   $($lang.Restore) $($lang.PwdUnlimited)"
	net accounts /maxpwage:42 | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableGamebar
{
	Write-Host "   $($lang.Disable) $($lang.Gamebar)"
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AppCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AudioCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'CursorCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'MicrophoneCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableGamebar
{
	Write-Host "   $($lang.Enable) $($lang.Gamebar)"
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name AppCaptureEnabled -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name AudioCaptureEnabled -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name CursorCaptureEnabled -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name MicrophoneCaptureEnabled -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableGameMode
{
	Write-Host "   $($lang.Disable) $($lang.GameMode)"
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\GameBar' -Name 'AutoGameModeEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\GameBar' -Name 'AllowAutoGameMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableGameMode
{
	Write-Host "   $($lang.Enable) $($lang.GameMode)"
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name CursorCaptureEnabled -Force -ErrorAction SilentlyContinue
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name MicrophoneCaptureEnabled -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableProtected
{
	Write-Host "   $($lang.Disable) $($lang.Protected)"
	if ((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments") -ne $true) { New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments" -force -ea SilentlyContinue | Out-Null }
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreProtected
{
	Write-Host "   $($lang.Enable) $($lang.Protected)"
	Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableMultipleIncrease
{
	Write-Host "   $($lang.Disable) $($lang.MultipleIncrease)"
	New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'MultipleInvokePromptMinimum' -Value 999 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreMultipleIncrease
{
	Write-Host "   $($lang.Enable) $($lang.MultipleIncrease)"
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer" -Name MultipleInvokePromptMinimum -Force -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableAutoplay
{
	Write-Host "   $($lang.Disable) $($lang.Autoplay)"
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -Name "DisableAutoplay" -Type DWord -Value 1
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableAutoplay
{
	Write-Host "   $($lang.Enable) $($lang.Autoplay)"
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -Name "DisableAutoplay" -Type DWord -Value 0
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableAutorun
{
	Write-Host "   $($lang.Disable) $($lang.Autorun)"
	If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer")) {
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" | Out-Null
	}
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun" -Type DWord -Value 255
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableAutorun
{
	Write-Host "   $($lang.Enable) $($lang.Autorun)"
	Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableErrorReporting
{
	Write-Host "   $($lang.Disable) $($lang.ErrorReporting)"
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "Disabled" -Type DWord -Value 1
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableErrorReporting
{
	Write-Host "   $($lang.Enable) $($lang.ErrorReporting)"
	Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "Disabled" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableF8BootMenu
{
	Write-Host "   $($lang.Disable) $($lang.F8BootMenu)"
	bcdedit /set `{current`} bootmenupolicy Standard | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function EnableF8BootMenu
{
	Write-Host "   $($lang.Enable) $($lang.F8BootMenu)"
	bcdedit /set `{current`} bootmenupolicy Legacy | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function SendTo
{
	Write-Host "   $($lang.Clean) $($lang.SendTo)"
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\Mail Recipient.MAPIMail" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\邮件收件人.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\Fax Recipient.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\传真收件人.lnk" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function CleanSystemLog
{
	Write-Host "   $($lang.Clean) $($lang.Logs)"
	Get-EventLog -LogName * | ForEach-Object { Clear-EventLog $_.Log }
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function CleanSxS
{
	Write-Host "   $($lang.Clean) $($lang.SxS)"
	Dism /Online /Cleanup-Image /AnalyzeComponentstore
	Dism /Online /Cleanup-Image /StartComponentCleanup /ResetBase
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


$Notifications = @(
#	"windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel" # Settings
	"microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowslive.calendar"    # Calendar
	"microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowslive.mail"        # Mail
	"Microsoft.MicrosoftEdge_8wekyb3d8bbwe!MicrosoftEdge" # Edge
	"Microsoft.Windows.Cortana_cw5n1h2txyewy!CortanaUI"   # Cortana
	"Windows.SystemToast.AudioTroubleshooter"    # Audio
	"Windows.SystemToast.Suggested"              # Suggested
	"Microsoft.WindowsStore_8wekyb3d8bbwe!App"   # Store
	"Windows.SystemToast.SecurityAndMaintenance" # Security and Maintenance
	"Windows.SystemToast.WiFiNetworkManager"     # Wireless
	"Windows.SystemToast.HelloFace"              # Windows Hello
	"Windows.SystemToast.RasToastNotifier"       # VPN
	"Windows.System.Continuum"                   # Tablet
	"Microsoft.BingNews_8wekyb3d8bbwe!AppexNews" # News
	"Windows.SystemToast.BdeUnlock"              # Bitlocker
	"Windows.SystemToast.BackgroundAccess"       # Battery Saver
	"Windows.Defender.SecurityCenter"            # Security Center
	"Microsoft.Windows.Photos_8wekyb3d8bbwe!App" # Photos
	"Microsoft.SkyDrive.Desktop"                 # OneDrive
	#"Windows.SystemToast.AutoPlay"              # Autoplay
)

Function DisableActionCenter
{
	Write-Host "   $($lang.Disable) $($lang.Notification) $($lang.Full)"
	If (-not (Test-Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer")) {
		New-Item -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" | Out-Null
	}
	Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" -Name "ToastEnabled" -Type DWord -Value 0
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreActionCenter
{
	Write-Host "   $($lang.Enable) $($lang.Notification) $($lang.Full)"
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" -Name "ToastEnabled" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function DisableActionCenterPart
{
	Write-Host "   $($lang.Disable) $($lang.Notification) $($lang.Part)"
	if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -force -ea SilentlyContinue | Out-Null }
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications' -Name 'DisableEnhancedNotifications' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

	New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Force -ErrorAction SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableSoftLanding' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

	foreach ($Name in $Notifications)
	{
		if ((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name") -ne $true) {
			New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -force -ea SilentlyContinue | Out-Null
		}

		New-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -Name Enabled -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	# 关闭 防火墙通知
	New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestoreActionCenterPart
{
	Write-Host "   $($lang.Restore) $($lang.Notification) $($lang.Part)"
	Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	
	foreach ($Name in $Notifications) {
		New-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -Name Enabled -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	netsh firewall set notifications mode=enable profile=all | Out-Null
	netsh firewall set opmode exceptions=enable | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


Function PagingSize
{
	param
	(
		[string]$size
	)
	Write-Host "   $($lang.Setting) $($lang.PagingSize) $($size)G"
	switch ($size)
	{
		8 { New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("$env:SystemDrive\pagefile.sys 8192 8192") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null }
		16 { New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("$env:SystemDrive\pagefile.sys 16384 16384") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null }
	}
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestorePagingSize
{
	Write-Host "   $($lang.Restore) $($lang.PagingSize)"
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("?:\pagefile.sys") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

Function RestorePoint
{
	Enable-ComputerRestore -drive $env:SystemDrive -ErrorAction SilentlyContinue
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name 'SystemRestorePointCreationFrequency' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Checkpoint-Computer -description "$($Global:UniqueID)" -restorepointtype "Modify_Settings" -ErrorAction SilentlyContinue
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name 'SystemRestorePointCreationFrequency' -Value 1440 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Disable-ComputerRestore -Drive $env:SystemDrive -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


$ResetDesktopReg = @(
	'HKCU:\Software\Microsoft\Windows\Shell\BagMRU'
	'HKCU:\Software\Microsoft\Windows\Shell\Bags'
	'HKCU:\Software\Microsoft\Windows\ShellNoRoam\Bags'
	'HKCU:\Software\Microsoft\Windows\ShellNoRoam\BagMRU'
	'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
	'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags'
	'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\Bags'
	'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
)

Function ResetTaskBar
{
	Write-Host "   $($lang.Reset) $($lang.TaskBar)" -ForegroundColor Green
	Write-Host "   - $($lang.Delete) $($lang.TaskBar)"
	Remove-Item -Path "$env:AppData\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\*.*"
	Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	if (Test-Path "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\syspin")\syspin.exe" -PathType Leaf) {
		Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\syspin")\syspin.exe" -WindowStyle Hidden -ArgumentList """$env:SystemRoot\explorer.exe"" ""5386""" -Wait
	}
	Write-Host "   - $($lang.ResetExplorer)`n"
	Stop-Process -ProcessName explorer -ErrorAction SilentlyContinue
}

Function ResetDesktop
{
	Write-Host "   $($lang.ResetDesk)" -ForegroundColor Green
	Write-Host "   - $($lang.ResetFolder)"
	foreach ($item in $ResetDesktopReg) {
		Remove-Item -Path $item -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.ResetExplorer)`n"
	Stop-Process -ProcessName explorer -ErrorAction SilentlyContinue
	RefreshIconCache
}

Function RefreshIconCache
{
	$code = @'
	private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
	private const int WM_SETTINGCHANGE = 0x1a;
	private const int SMTO_ABORTIFHUNG = 0x0002;

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
private static extern IntPtr SendMessageTimeout ( IntPtr hWnd, int Msg, IntPtr wParam, string lParam, uint fuFlags, uint uTimeout, IntPtr lpdwResult );

[System.Runtime.InteropServices.DllImport("Shell32.dll")] 
private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

public static void Refresh() {
	SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);
	SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);
}
'@

	Add-Type -MemberDefinition $code -Namespace MyWinAPI -Name Explorer
	[MyWinAPI.Explorer]::Refresh()
}

Export-ModuleMember -Function "DisableTakeOwnership"
Export-ModuleMember -Function "EnableTakeOwnership"
Export-ModuleMember -Function "DisableHibernation"
Export-ModuleMember -Function "EnableHibernation"
Export-ModuleMember -Function "SetPowerSupply"
Export-ModuleMember -Function "RestorePowerSupply"
Export-ModuleMember -Function "EnableAppRestartScreen"
Export-ModuleMember -Function "DisableAppRestartScreen"
Export-ModuleMember -Function "DisableArrow"
Export-ModuleMember -Function "RestoreArrow"
Export-ModuleMember -Function "EnableNumlock"
Export-ModuleMember -Function "DisableNumlock"
Export-ModuleMember -Function "SetSearchBox"
Export-ModuleMember -Function "SetUACNever"
Export-ModuleMember -Function "SetUACDefault"
Export-ModuleMember -Function "DisableSmartScreen"
Export-ModuleMember -Function "EnableSmartScreen"
Export-ModuleMember -Function "EnableMaintain"
Export-ModuleMember -Function "DisableMaintain"
Export-ModuleMember -Function "SetExperience"
Export-ModuleMember -Function "RestoreExperience"
Export-ModuleMember -Function "DisableSafetyWarnings"
Export-ModuleMember -Function "EnableSafetyWarnings"
Export-ModuleMember -Function "DisableQOS"
Export-ModuleMember -Function "EnableQOS"
Export-ModuleMember -Function "DisableNetworkTuning"
Export-ModuleMember -Function "EnableNetworkTuning"
Export-ModuleMember -Function "DisableECN"
Export-ModuleMember -Function "EnableECN"
Export-ModuleMember -Function "DisableErrorRecovery"
Export-ModuleMember -Function "EnableErrorRecovery"
Export-ModuleMember -Function "DisableDEPPAE"
Export-ModuleMember -Function "RestoreDEPPAE"
Export-ModuleMember -Function "DisablePowerFailure"
Export-ModuleMember -Function "EnablePowerFailure"
Export-ModuleMember -Function "DisableScheduledTasks"
Export-ModuleMember -Function "RestoreScheduledTasks"
Export-ModuleMember -Function "DisableOptUser"
Export-ModuleMember -Function "RestoreOptUser"
Export-ModuleMember -Function "DisableOptUpdate"
Export-ModuleMember -Function "RestoreOptUpdate"
Export-ModuleMember -Function "DisableFixPrivacy"
Export-ModuleMember -Function "RestoreFixPrivacy"
Export-ModuleMember -Function "DisableTimelineTime"
Export-ModuleMember -Function "EnableTimelineTime"
Export-ModuleMember -Function "DisableCollectActivity"
Export-ModuleMember -Function "EnableCollectActivity"
Export-ModuleMember -Function "DisableAutoDetect"
Export-ModuleMember -Function "EnableAutoDetect"
Export-ModuleMember -Function "IEProxy"
Export-ModuleMember -Function "SetMergeTaskbarNever"
Export-ModuleMember -Function "DefaultMergeTaskbarNever"
Export-ModuleMember -Function "SetNotificationAlways"
Export-ModuleMember -Function "DefaultNotificationAlways"
Export-ModuleMember -Function "SetNavShowAll"
Export-ModuleMember -Function "RestoreNavShowAll"
Export-ModuleMember -Function "SetCortana"
Export-ModuleMember -Function "RestoreCortana"
Export-ModuleMember -Function "HideRecentShortcuts"
Export-ModuleMember -Function "ShowRecentShortcuts"
Export-ModuleMember -Function "DisableMemoryCompression"
Export-ModuleMember -Function "EnableMemoryCompression"
Export-ModuleMember -Function "DisablePrelaunch"
Export-ModuleMember -Function "EnablePrelaunch"
Export-ModuleMember -Function "OptSSD"
Export-ModuleMember -Function "DefaultOptSSD"
Export-ModuleMember -Function "DisableCompatibility"
Export-ModuleMember -Function "EnableCompatibility"
Export-ModuleMember -Function "OptAnimationEffects"
Export-ModuleMember -Function "RestoreAnimationEffects"
Export-ModuleMember -Function "DisableDefragmentation"
Export-ModuleMember -Function "EnableDefragmentation"
Export-ModuleMember -Function "DisablePhotoPreview"
Export-ModuleMember -Function "EnablePhotoPreview"
Export-ModuleMember -Function "SetRAM"
Export-ModuleMember -Function "RestoreRAM"
Export-ModuleMember -Function "SetPwdUnlimited"
Export-ModuleMember -Function "RestorePwdUnlimited"
Export-ModuleMember -Function "DisableGamebar"
Export-ModuleMember -Function "EnableGamebar"
Export-ModuleMember -Function "DisableGameMode"
Export-ModuleMember -Function "EnableGameMode"
Export-ModuleMember -Function "DisableProtected"
Export-ModuleMember -Function "RestoreProtected"
Export-ModuleMember -Function "DisableMultipleIncrease"
Export-ModuleMember -Function "RestoreMultipleIncrease"
Export-ModuleMember -Function "DisableAutoplay"
Export-ModuleMember -Function "EnableAutoplay"
Export-ModuleMember -Function "DisableAutorun"
Export-ModuleMember -Function "EnableAutorun"
Export-ModuleMember -Function "DisableErrorReporting"
Export-ModuleMember -Function "EnableErrorReporting"
Export-ModuleMember -Function "DisableF8BootMenu"
Export-ModuleMember -Function "EnableF8BootMenu"
Export-ModuleMember -Function "SendTo"
Export-ModuleMember -Function "CleanSystemLog"
Export-ModuleMember -Function "CleanSxS"
Export-ModuleMember -Function "DisableActionCenter"
Export-ModuleMember -Function "RestoreActionCenter"
Export-ModuleMember -Function "DisableActionCenterPart"
Export-ModuleMember -Function "RestoreActionCenterPart"
Export-ModuleMember -Function "PagingSize"
Export-ModuleMember -Function "RestorePagingSize"
Export-ModuleMember -Function "RestorePoint"
Export-ModuleMember -Function "ResetTaskBar"
Export-ModuleMember -Function "ResetDesktop"
Export-ModuleMember -Function "RefreshIconCache"