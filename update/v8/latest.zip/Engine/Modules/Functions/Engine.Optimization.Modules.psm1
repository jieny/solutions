﻿<#
 .Synopsis
  Optimize Modules

 .Description
  Optimize Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Take ownership to the right-click menu
	.取得所有权到右键菜单
#>
Function TakeOwnership
{
	param
	(
		[switch]$Remove,
		[switch]$Add
	)

	Write-Host "   $($lang.AddOwnership)"
	if ($Remove) {
		Write-Host "   $($lang.Delete)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Drive\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Add) {
		Write-Host "   $($lang.AddTo)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'AppliesTo' -Value "NOT (System.ItemPathDisplay:=\""$env:SystemDrive\Users\"" OR System.ItemPathDisplay:=\""$env:SystemDrive\ProgramData\"" OR System.ItemPathDisplay:=\""$env:SystemRoot\"" OR System.ItemPathDisplay:=\""$env:SystemRoot\System32\"" OR System.ItemPathDisplay:=\""$env:SystemDrive\Program Files\"" OR System.ItemPathDisplay:=\""$env:SystemDrive\Program Files (x86)\"")" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" /r && icacls "%1" /grant *S-1-3-4:F /t /c /l /q & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" /r && icacls "%1" /grant *S-1-3-4:F /t /c /l /q & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership' -Name "MUIVerb" -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command' -Name '(default)' -Value '"%1" %*' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value '"%1" %*' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		RefreshIconCache
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Keep space
	.保留空间
#>
Function KeepSpace
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.KeepSpace)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		DISM.exe /Online /Set-ReservedStorageState /State:Enabled | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Close)".PadRight(22) -NoNewline
		DISM.exe /Online /Set-ReservedStorageState /State:Disabled | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Hibernation
	.休眠
#>
Function Hibernation
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Hibernation)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Start-Process 'powercfg.exe' -ArgumentList '/h on' -WindowStyle Minimized
	}

	if ($Disable) {
		Write-Host "   $($lang.Close)".PadRight(22) -NoNewline
		Start-Process 'powercfg.exe' -Verb runAs -ArgumentList '/h off' -WindowStyle Minimized
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Power supply solution optimized after "high performance"
	.电源方案为“高性能”后优化
#>
Function PowerSupply
{
	param
	(
		[switch]$Restore,
		[switch]$Optimize
	)

	Write-Host "   $($lang.PowerSupply)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		powercfg -restoredefaultschemes
	}

	if ($Optimize) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
		powercfg -change -monitor-timeout-ac 0
		powercfg -change -monitor-timeout-dc 0
		powercfg -change -disk-timeout-ac 0
		powercfg -change -disk-timeout-dc 5
		powercfg -change -standby-timeout-ac 0
		powercfg -change -standby-timeout-dc 60
		powercfg -change -hibernate-timeout-ac 0
		powercfg -change -hibernate-timeout-dc 300
		powercfg /SETACVALUEINDEX 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
		powercfg /SETDCVALUEINDEX 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	."This app is preventing shutdown or restart" screen
	."此应用正在阻止关机或重新启动" 屏幕
#>
Function AppRestartScreen
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.AppRestartScreen)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'MenuShowDelay' -Value '400' -PropertyType String -Force -ea SilentlyContinue;
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'WaitToKillAppTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'HungAppTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'AutoEndTasks' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'LowLevelHooksTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'WaitToKillServiceTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name 'AutoEndTasks' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name 'LowLevelHooksTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name 'WaitToKillServiceTimeout' -Force -ErrorAction SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'MenuShowDelay' -Value '0' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'WaitToKillAppTimeout' -Value '5000' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'HungAppTimeout' -Value '4000' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'LowLevelHooksTimeout' -Value 4096 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'WaitToKillServiceTimeout' -Value 8192 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'LowLevelHooksTimeout' -Value 4096 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'WaitToKillServiceTimeout' -Value 8192 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Shortcut small arrow and suffix
	.快捷方式小箭头和后缀
#>
Function ShortcutArrow
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ShortcutArrow)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\IE.AssocFile.URL' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\InternetShortcut' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\lnkfile' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
		Remove-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Force -ea SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name link -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Delete)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Value "$env:SystemRoot\system32\imageres.dll,197" -PropertyType String -Force -ea SilentlyContinue | out-null
		Remove-Item -Path "$env:USERPROFILE\AppData\Local\iconcache.db" -ErrorAction SilentlyContinue
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'link' -Value ([byte[]](0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.NumLock key will light up automatically after power on
	.NumLock 键开机后自动亮起
#>
Function Numlock
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Numlock)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		If (-not (Test-Path "HKU:")) {
			New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS | Out-Null
		}
		Set-ItemProperty -Path "HKU:\.DEFAULT\Control Panel\Keyboard" -Name "InitialKeyboardIndicators" -Type DWord -Value 2147483650 -ErrorAction SilentlyContinue
		Add-Type -AssemblyName System.Windows.Forms
		If (-not ([System.Windows.Forms.Control]::IsKeyLocked('NumLock'))) {
			$wsh = New-Object -ComObject WScript.Shell
			$wsh.SendKeys('{NUMLOCK}')
		}
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		If (-not(Test-Path "HKU:")) {
			New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS | Out-Null
		}
		Set-ItemProperty -Path "HKU:\.DEFAULT\Control Panel\Keyboard" -Name "InitialKeyboardIndicators" -Type DWord -Value 2147483648 -ErrorAction SilentlyContinue
		Add-Type -AssemblyName System.Windows.Forms
		If ([System.Windows.Forms.Control]::IsKeyLocked('NumLock')) {
			$wsh = New-Object -ComObject WScript.Shell
			$wsh.SendKeys('{NUMLOCK}')
		}
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Search bar: display search icon
	.搜索栏：显示搜索图标
#>
Function SearchBox
{
	param
	(
		[string]$Type
	)

	Write-Host "   $($lang.SearchBox)"
	switch ($Type) {
		"icon" {
			Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
			New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		}
		"Box" {
			Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
			New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		}
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.User Account Control (UAC): Never notify me
	.用户账户控制 (UAC)：从不通知我
#>
Function UACNever
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UAC)"
	if ($Enable) {
		Write-Host "   $($lang.UACNever)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 5 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Smart Screen for Microsoft Store apps
	.适用于 Microsoft Store 应用的 Smart Screen
#>
Function SmartScreen
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.SmartScreen)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Type String -Value "RequireAdmin"
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" -Name "EnableWebContentEvaluation" -ErrorAction SilentlyContinue
	
		Get-ChildItem -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\*edge*" -Name -ErrorAction SilentlyContinue | ForEach-Object {
			if (Test-Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -PathType Container) {
				Remove-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -ErrorAction SilentlyContinue | Out-Null
				Remove-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "PreventOverride" -ErrorAction SilentlyContinue | Out-Null
			}
		}
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Type String -Value "Off"
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" -Name "EnableWebContentEvaluation" -Type DWord -Value 0
	
		Get-ChildItem -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\*edge*" -Name -ErrorAction SilentlyContinue | ForEach-Object {
			if (Test-Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -PathType Container) {
				Set-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -Type DWord -Value 0 | Out-Null
				Set-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "PreventOverride" -Type DWord -Value 0 | Out-Null
			}
		}
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Automatic maintenance plan
	.自动维护计划
#>
Function Maintain
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Maintain)"
	if ($Enable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" -Name "MaintenanceDisabled" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance' -Name 'MaintenanceDisabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Customer experience improvement plan
	.客户体验改善计划
#>
Function Experience
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Experience)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows" -Name "CEIPEnable" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows' -Name 'CEIPEnable' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Common file type safety warnings
	.常见文件类型安全警告
#>
Function SafetyWarnings
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.SafetyWarnings)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations") -ne $true) { New-Item "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'LowRiskFileTypes' -Value '.exe;.reg;.msi;.bat;.cmd;.com;.vbs;.hta;.scr;.pif;.js;' -PropertyType String -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
} 

<#
	.QOS service
	.QOS 服务
#>
Function QOS
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.QOS)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\nvspbind")\nvspbind.exe" -ArgumentList "/e ""*"" ms_pacer" -Wait -WindowStyle Minimized
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\nvspbind")\nvspbind.exe" -ArgumentList "/d ""*"" ms_pacer" -Wait -WindowStyle Minimized
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Network tuning function
	.网络调优功能
#>
Function NetworkTuning
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.NetworkTuning)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		netsh interface tcp set global autotuninglevel=normal | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		netsh interface tcp set global autotuninglevel=disabled | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.ECN function
	.ECN 功能
#>
Function ECN
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ECN)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		netsh int tcp set global ecn=enabled | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		netsh int tcp set global ecn=disable | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Windows error recovery
	.Windows 错误恢复
#>
Function ErrorRecovery
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ErrorRecovery)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /set {default} bootstatuspolicy DisplayAllFailures | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} bootstatuspolicy ignoreallfailures | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.DEP and PAE
	.DEP 和 PAE
#>
Function DEPPAE
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.DEP)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /deletevalue `{current`} pae 
		bcdedit /set `{current`} nx OptIn
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} nx AlwaysOff
		bcdedit /set `{current`} pae ForceDisable
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Automatic repair function after power failure
	.断电后自动修复功能
#>
Function PowerFailure
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PowerFailure)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} Recoveryenabled Yes | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} Recoveryenabled No | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Certain scheduled tasks
	.某些计划任务
#>
Function ScheduledTasks
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	Write-Host "   $($lang.ScheduledTasks)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Write-Host "   - $($lang.NotSupport)`n" -ForegroundColor Red
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\..\AIO\Opt\utils\disable-scheduled-tasks.ps1""" -Wait -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.UI user interface
	.UI 用户界面
#>
Function OptUser
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	Write-Host "   $($lang.OptUser)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Write-Host "   - $($lang.NotSupport)`n" -ForegroundColor Red
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\..\AIO\Opt\scripts\optimize-user-interface.ps1""" -Wait -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Windows updates
	.Windows 更新
#>
Function OptUpdate
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	Write-Host "   $($lang.OptUpdate)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Write-Host "   - $($lang.NotSupport)`n" -ForegroundColor Red
	}

	if ($Disable) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\..\AIO\Opt\scripts\optimize-windows-update.ps1""" -Wait -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy settings
	.隐私设置
#>
Function FixPrivacy
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	Write-Host "   $($lang.FixPrivacy)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Write-Host "   - $($lang.NotSupport)`n" -ForegroundColor Red
	}

	if ($Disable) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		Start-Process powershell -ArgumentList "-file ""$PSScriptRoot\..\..\AIO\Opt\scripts\fix-privacy-settings.ps1""" -Wait -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Timeline time
	.隐私：时间轴时间
#>
Function TimelineTime
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.TimelineTime)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Privacy: Collect activity history
	.隐私：收集活动历史记录
#>
Function CollectActivity
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.CollectActivity)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'PublishUserActivities' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'PublishUserActivities' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.IE automatically detects settings
	.IE 自动检测设置
#>
Function AutoDetect
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.IEAutoSet)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoDetect' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoDetect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.IE Setting proxy does not take effect
	.IE 设置代理不生效
#>
Function IEProxy
{
	Write-Host "   $($lang.IEProxy)"
	Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
	"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections [1 7 17]" | Out-File -FilePath "$env:TEMP\ie_proxy.ini" -Encoding ASCII
	Start-Process "regini" -ArgumentList "$env:TEMP\ie_proxy.ini" -WindowStyle Minimized
	Remove-Item -Path "$env:TEMP\ie_proxy.ini" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Merge taskbar buttons: never
	.合并任务栏按钮：从不
#>
Function MergeTaskbarNever
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.MergeTaskbarNever)"
	if ($Enable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarGlomLevel' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name TaskbarGlomLevel -Force -ErrorAction SilentlyContinue
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Notification area: always show all icons
	.通知区域：始终显示所有图标
#>
Function NotificationAlways
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.NotificationAlways)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'EnableAutoTray' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name EnableAutoTray -Force -ErrorAction SilentlyContinue
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Open "Show all folders" in the navigation pane
	.在导航窗格中打开“显示所有文件夹”
#>
Function NavShowAll
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.NavShowAll)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'NavPaneExpandToCurrentFolder' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "NavPaneExpandToCurrentFolder" -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Hide the Cortana button on the taskbar
	.在任务栏上隐藏 Cortana 按钮
#>
Function Cortana
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Cortana)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "ShowCortanaButton" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	."Quick Access" shows recently used and frequently used
	."快速访问" 中显示最近使用的文件和显示常用文件夹
#>
Function RecentShortcuts
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.QuickAccess)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowRecent" -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowFrequent" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowRecent" -Type DWord -Value 0
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowFrequent" -Type DWord -Value 0
		Remove-Item -Path "$env:appdata\Microsoft\Windows\Recent\*.*"
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Memory compression
	.内存压缩
#>
Function MemoryCompression
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.MemoryCompression)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Enable-MMAgent -mc
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Disable-MMAgent -mc
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Pre-fetch pre-launch
	.预取预启动
#>
Function Prelaunch
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Prelaunch)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Enable-MMAgent -ApplicationPreLaunch
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Disable-MMAgent -ApplicationPreLaunch
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.SSD
#>
Function SSD
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	Write-Host "   $($lang.OptSSD)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		fsutil behavior set DisableLastAccess 2 | Out-Null
		fsutil behavior set EncryptPagingFile 0 | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		fsutil behavior set DisableLastAccess 1 | Out-Null
		fsutil behavior set EncryptPagingFile 0 | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Program Compatibility Assistant
	.程序兼容性助手
#>
Function Compatibility
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Compatibility)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' -Name 'DisablePCA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Visual animation effect
	.视觉动画效果
#>
Function AnimationEffects 
{
	param
	(
		[switch]$Restore,
		[switch]$Optimize
	)

	Write-Host "   $($lang.AnimationEffects)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Write-Host "   - $($lang.NotSupport)`n" -ForegroundColor Red
	}

	if ($Optimize) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM") -ne $true) { New-Item "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM' -Name 'DisallowAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'EnableAeroPeek' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'AlwaysHibernateThumbnails' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'TurnOffSPIAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -Name 'VisualFXSetting' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarAnimations' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewAlphaSelect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewShadow' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'IconsOnly' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop\WindowMetrics' -Name 'MinAnimate' -Value '0' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'UserPreferencesMask' -Value ([byte[]](0x9e,0x1e,0x07,0x80,0x12,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'DragFullWindows' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'FontSmoothing' -Value '2' -PropertyType String -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.Disk Defragmentation Plan
	.磁盘碎片整理计划
#>
Function Defragmentation
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Defragmentation)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Enable-ScheduledTask -TaskPath "\Microsoft\Windows\Defrag\" -TaskName "ScheduledDefrag" | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Disable-ScheduledTask -TaskPath "\Microsoft\Windows\Defrag\" -TaskName "ScheduledDefrag" | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Photo preview
	.照片预览
#>
Function PhotoPreview
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PhotoPreview)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.jpg") -ne $true) { New-Item "HKCU:\Software\Classes\.jpg" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.jpeg") -ne $true) { New-Item "HKCU:\Software\Classes\.jpeg" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.gif") -ne $true) { New-Item "HKCU:\Software\Classes\.gif" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.png") -ne $true) { New-Item "HKCU:\Software\Classes\.png" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.bmp") -ne $true) { New-Item "HKCU:\Software\Classes\.bmp" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.tiff") -ne $true) { New-Item "HKCU:\Software\Classes\.tiff" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.ico") -ne $true) { New-Item "HKCU:\Software\Classes\.ico" -force -ea SilentlyContinue }
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.jpg' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.jpeg' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.gif' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.png' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.bmp' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.tiff' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.ico' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\Software\Classes\.jpg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.jpeg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.gif" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.png" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.bmp" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.tiff" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.ico" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Reduce the number of processors using RAM
	.降低 RAM 使用处理器数量
#>
Function RAM
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.RAM)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'SvcHostSplitThresholdInKB' -Value 3670016 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'WaitToKillServiceTimeout' -Value '5000' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'NetworkThrottlingIndex' -Value 10 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'SystemResponsiveness' -Value 20 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' -Name 'SearchOrderConfig' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name 'HiberbootEnabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Remove-ItemProperty -Name "PowerThrottlingOff" -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_Enabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_FSEBehaviorMode' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_AutoGameModeDefaultProfile' -Value ([byte[]](0x02,0x00,0x01,0x00,0x00,0x00,0xc4,0x20,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_GameModeRelatedProcesses' -Value ([byte[]](0x01,0x00,0x01,0x00,0x01,0x00,0x67,0x00,0x61,0x00,0x6d,0x00,0x65,0x00,0x70,0x00,0x61,0x00,0x6e,0x00,0x65,0x00,0x6c,0x00,0x2e,0x00,0x65,0x00,0x78,0x00,0x65,0x00,0x00,0x00,0xc9,0x00,0x4e,0x95,0x67,0x77,0xb0,0xeb,0x1e,0x03,0xd8,0xf1,0x1e,0x03,0x1e,0x00,0x00,0x00,0xb0,0xeb,0x1e,0x03,0x1e,0x00,0x00,0x00,0x0f,0x00,0x00,0x00,0x2c,0xea,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_HonorUserFSEBehaviorMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_DXGIHonorFSEWindowsCompatible' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_EFSEFeatureFlags' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name 'HibernateEnabledDefault' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue;
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\943c8cb6-6f93-4227-ad87-e9a3feec08d1' -Name 'Attributes' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'SvcHostSplitThresholdInKB' -Value 67108864 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'WaitToKillServiceTimeout' -Value '2000' -PropertyType String -Force -ea SilentlyContinue | out-null
		if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -force -ea SilentlyContinue }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'NetworkThrottlingIndex' -Value -1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'SystemResponsiveness' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' -Name 'SearchOrderConfig' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name 'HiberbootEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		if((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling") -ne $true) {  New-Item "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' -Name 'PowerThrottlingOff' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		if((Test-Path -LiteralPath "HKCU:\System\GameConfigStore") -ne $true) {  New-Item "HKCU:\System\GameConfigStore" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_Enabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_FSEBehaviorMode' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_AutoGameModeDefaultProfile' -Value ([byte[]](0x01,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_GameModeRelatedProcesses' -Value ([byte[]](0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_HonorUserFSEBehaviorMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_DXGIHonorFSEWindowsCompatible' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_EFSEFeatureFlags' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name 'HibernateEnabledDefault' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\943c8cb6-6f93-4227-ad87-e9a3feec08d1' -Name 'Attributes' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Maximum password usage time is unlimited
	.密码最长使用时间为无限
#>
Function PwdUnlimited
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PwdUnlimited)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		net accounts /maxpwage:42 | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		net accounts /maxpwage:UNLIMITED | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Gamebar
#>
Function Gamebar
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Gamebar)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name AppCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name AudioCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name CursorCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name MicrophoneCaptureEnabled -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AppCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AudioCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'CursorCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'MicrophoneCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Game Mode
	.Game Mode
#>
Function GameMode
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.GameMode)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name CursorCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name MicrophoneCaptureEnabled -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\GameBar' -Name 'AutoGameModeEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\GameBar' -Name 'AllowAutoGameMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	."Windows protects your PC" dialog
	."Windows 保护了您的 PC" 对话框
#>
Function Protected
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Protected)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments") -ne $true) { New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Add 15 file selection limit to hide context menu items
	.增加 15 个文件选择限制以隐藏上下文菜单项
#>
Function MultipleIncrease
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.MultipleIncrease)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer" -Name MultipleInvokePromptMinimum -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'MultipleInvokePromptMinimum' -Value 999 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Autoplay
	.自动播放
#>
Function Autoplay
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Autoplay)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -Name "DisableAutoplay" -Type DWord -Value 0
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -Name "DisableAutoplay" -Type DWord -Value 1
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Run all drives automatically
	.自动运行所有驱动器
#>
Function Autorun
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Autorun)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer")) {
			New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" | Out-Null
		}
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun" -Type DWord -Value 255
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Error report
	.错误报告
#>
Function ErrorReporting
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ErrorReporting)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "Disabled" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "Disabled" -Type DWord -Value 1
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.F8 boot menu option
	.F8 启动菜单选项
#>
Function F8BootMenu
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.F8BootMenu)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} bootmenupolicy Legacy | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} bootmenupolicy Standard | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Sent to
	.发送到
#>
Function SendTo
{
	Write-Host "   $($lang.SendTo)"
	Write-Host "   $($lang.Clean)".PadRight(22) -NoNewline
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\Mail Recipient.MAPIMail" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\邮件收件人.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\Fax Recipient.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\传真收件人.lnk" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.System logs
	.系统日志
#>
Function CleanSystemLog
{
	Write-Host "   $($lang.Logs)"
	Write-Host "   $($lang.Clean)".PadRight(22) -NoNewline
	Get-EventLog -LogName * | ForEach-Object { Clear-EventLog $_.Log }
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.WinSxS slimming
	.WinSxS 瘦身
#>
Function CleanSxS
{
	Write-Host "   $($lang.SxS)"
	Write-Host "   $($lang.Clean)".PadRight(22) -NoNewline
	Dism /Online /Cleanup-Image /StartComponentCleanup
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Notification Center
	.通知中心
#>
Function NotificationCenter
{
	param
	(
		[switch]$Restore,
		[switch]$Full,
		[switch]$Part
	)

	$Notifications = @(
#		"windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel" # Settings
		"microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowslive.calendar"    # Calendar
		"microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowslive.mail"        # Mail
		"Microsoft.MicrosoftEdge_8wekyb3d8bbwe!MicrosoftEdge"                                 # Edge
		"Microsoft.Windows.Cortana_cw5n1h2txyewy!CortanaUI"                                   # Cortana
		"Windows.SystemToast.AudioTroubleshooter"                                             # Audio
		"Windows.SystemToast.Suggested"                                                       # Suggested
		"Microsoft.WindowsStore_8wekyb3d8bbwe!App"                                            # Store
		"Windows.SystemToast.SecurityAndMaintenance"                                          # Security and Maintenance
		"Windows.SystemToast.WiFiNetworkManager"                                              # Wireless
		"Windows.SystemToast.HelloFace"                                                       # Windows Hello
		"Windows.SystemToast.RasToastNotifier"                                                # VPN
		"Windows.System.Continuum"                                                            # Tablet
		"Microsoft.BingNews_8wekyb3d8bbwe!AppexNews"                                          # News
		"Windows.SystemToast.BdeUnlock"                                                       # Bitlocker
		"Windows.SystemToast.BackgroundAccess"                                                # Battery Saver
		"Windows.Defender.SecurityCenter"                                                     # Security Center
		"Microsoft.Windows.Photos_8wekyb3d8bbwe!App"                                          # Photos
		"Microsoft.SkyDrive.Desktop"                                                          # OneDrive
#		"Windows.SystemToast.AutoPlay"                                                        # Autoplay
	)

	Write-Host "   $($lang.Notification)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\TrayNotify" -Name "PastIconsStream" -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\TrayNotify" -Name "IconStreams" -ErrorAction SilentlyContinue
		
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" -Name "ToastEnabled" -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -Name "DisableEnhancedNotifications" -ErrorAction SilentlyContinue
		Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		
		foreach ($Name in $Notifications) {
			New-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -Name Enabled -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		}
	
		netsh firewall set notifications mode=enable profile=all | Out-Null
		netsh firewall set opmode exceptions=enable | Out-Null
	}

	if ($Full) {
		Write-Host "   $($lang.Disable) $($lang.Full)".PadRight(22) -NoNewline
		If (-not (Test-Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer")) {
			New-Item -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" | Out-Null
		}
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" -Name "ToastEnabled" -Type DWord -Value 0
	}

	if ($Part) {
		Write-Host "   $($lang.Disable) $($lang.Part)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications' -Name 'DisableEnhancedNotifications' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableSoftLanding' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

		foreach ($Name in $Notifications)
		{
			if ((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name") -ne $true) {
				New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -force -ea SilentlyContinue | Out-Null
			}

			New-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -Name Enabled -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		}

		# 关闭 防火墙通知
		New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	RestartExplorer

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.System disk paging size
	.系统盘分页大小
#>
Function PagingSize
{
	param
	(
		[switch]$Enable,
		[switch]$Disable,
		[string]$size
	)

	Write-Host "   $($lang.PagingSize)"
	if ($Enable) {
		Write-Host "   $($lang.Setting) $($size)G".PadRight(22) -NoNewline
		switch ($size)
		{
			8 {
				New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("$env:SystemDrive\pagefile.sys 8192 8192") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
			}
			16 {
				New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("$env:SystemDrive\pagefile.sys 16384 16384") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
			}
		}
	}

	if ($Disable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("?:\pagefile.sys") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Enable 3389 remote desktop
	.启用 3389 远程桌面
#>
Function RemoteDesktop {
	Write-Host "   $($lang.StRemote)"
	Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\TermService") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Services\TermService" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services\TermService' -Name 'Start' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\MpsSvc") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Services\MpsSvc" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services\MpsSvc' -Name 'Start' -Value 4 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Stop-Service "MpsSvc" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	netsh advfirewall firewall add rule name="Open Port 3389" dir=in action=allow protocol=TCP localport=3389 | Out-Null
	Start-Service "TermService" -ErrorAction SilentlyContinue | Out-Null

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Turn on SMB file sharing
	.打开 SMB 文件共享
#>
Function SMBFileShare {
	Write-Host "   $($lang.StSMB)"
	Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
	<#
		.Add 'firewall rules'
		.添加 '防火墙规则'
	#>
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 137" dir=in action=allow protocol=UDP localport=137 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 137" dir=out action=allow protocol=UDP localport=137 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 138" dir=in action=allow protocol=UDP localport=138 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 138" dir=out action=allow protocol=UDP localport=138 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 139" dir=in action=allow protocol=TCP localport=139 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 139" dir=out action=allow protocol=TCP localport=139 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 445" dir=in action=allow protocol=TCP localport=445 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 445" dir=out action=allow protocol=TCP localport=445 | Out-Null

	<#
		.Enable 'Guest User'
		.启用 'Guest 用户'
	#>
	Net User Guest /Active:yes | Out-Null

	<#
		.Set the group policy 'Deny guest users in this computer from accessing the network'
		.设置组策略 '拒绝从网络访问此计算机中的 Guest 用户'
	#>
	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'forceguest' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet001\Control\Lsa") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet001\Control\Lsa" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet001\Control\Lsa' -Name 'forceguest' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	<#
		.Group Policy 'Guests Only-Authenticate local users as guests'
		.组策略 '仅来宾 - 对本地用户进行身份验证，其身份为来宾'
	#>
	Remove-Item -Path "$($env:TEMP)\share.inf" -ErrorAction SilentlyContinue
@"
[Version] 
signature="`$CHICAGO$" 
Revision=1 

[Privilege Rights] 
SeDenyNetworkLogonRight = 
"@ | Out-File -FilePath "$($env:TEMP)\share.inf" -Encoding Ascii
	secedit /configure /db "$($env:TEMP)\share.sdb" /cfg "$($env:TEMP)\share.inf"
	Remove-Item -Path "$($env:TEMP)\share.inf" -ErrorAction SilentlyContinue
	Remove-Item -Path "$($env:TEMP)\share.sdb" -ErrorAction SilentlyContinue

	<#
		.Disable the 'Psec Policy Agent (IP security policy) service'
		.禁用 'Psec Policy Agent（IP安全策略）服务'
	#>
	Set-Service -Name "PolicyAgent" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
	Stop-Service "PolicyAgent" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	<#
		.Disable the 'Server (Shared Service)'
		.禁用 'Server（共享服务）'
	#>
	Set-Service -Name "ShareAccess" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
	Stop-Service "ShareAccess" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	<#
		.Enable 'Computer Browser (browsing service)'
		.启用 'Computer Browser（浏览服务）'
	#>
	Set-Service -Name "Browser" -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
	Start-Service "Browser" -ErrorAction SilentlyContinue | Out-Null

	<#
		.Disable the 'MpsSvc Service'
		.禁用 'MpsSvc 服务'
	#>
	Set-Service -Name "MpsSvc" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
	Stop-Service "MpsSvc" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	<#
		.Enable 'LanmanServer service'
		.启用 'LanmanServer 服务'
	#>
	Set-Service -Name "LanmanServer" -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
	Start-Service "LanmanServer" -ErrorAction SilentlyContinue | Out-Null
	gpupdate /force | out-null

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Create a system restore
	.创建系统还原
#>
Function RestorePoint
{
	Enable-ComputerRestore -drive $env:SystemDrive -ErrorAction SilentlyContinue
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name 'SystemRestorePointCreationFrequency' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Checkpoint-Computer -description "$($Global:UniqueID)" -restorepointtype "Modify_Settings" -ErrorAction SilentlyContinue
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name 'SystemRestorePointCreationFrequency' -Value 1440 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Disable-ComputerRestore -Drive $env:SystemDrive -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.All icons in the taskbar
	.任务栏所有图标
#>
Function ResetTaskBar
{
	Write-Host "   $($lang.Reset) $($lang.TaskBar)" -ForegroundColor Green
	Write-Host "   - $($lang.Delete) $($lang.TaskBar)"
	Remove-Item -Path "$env:AppData\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\*.*"
	Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	if (Test-Path "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\syspin")\syspin.exe" -PathType Leaf) {
		Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\syspin")\syspin.exe" -WindowStyle Hidden -ArgumentList """$env:SystemRoot\explorer.exe"" ""5386""" -Wait
	}
	RestartExplorer

	Write-Host "   - $($lang.ResetExplorer)`n"
}


<#
	.Rearrange the desktop icons by name
	.重新按名称排列桌面图标
#>
Function ResetDesktop
{
	$ResetDesktopReg = @(
		'HKCU:\Software\Microsoft\Windows\Shell\BagMRU'
		'HKCU:\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Microsoft\Windows\ShellNoRoam\Bags'
		'HKCU:\Software\Microsoft\Windows\ShellNoRoam\BagMRU'
		'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
		'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
	)

	Write-Host "   $($lang.ResetDesk)" -ForegroundColor Green
	Write-Host "   - $($lang.ResetFolder)"
	foreach ($item in $ResetDesktopReg) {
		Remove-Item -Path $item -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	RestartExplorer

	Write-Host "   - $($lang.ResetExplorer)`n"
	RefreshIconCache
}


<#
	.Refresh icon cache
	.刷新图标缓存
#>
Function RefreshIconCache
{
	$code = @'
	private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
	private const int WM_SETTINGCHANGE = 0x1a;
	private const int SMTO_ABORTIFHUNG = 0x0002;

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
private static extern IntPtr SendMessageTimeout ( IntPtr hWnd, int Msg, IntPtr wParam, string lParam, uint fuFlags, uint uTimeout, IntPtr lpdwResult );

[System.Runtime.InteropServices.DllImport("Shell32.dll")] 
private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

public static void Refresh() {
	SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);
	SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);
}
'@

	Add-Type -MemberDefinition $code -Namespace MyWinAPI -Name Explorer
	[MyWinAPI.Explorer]::Refresh()
}

Export-ModuleMember -Function * -Alias *