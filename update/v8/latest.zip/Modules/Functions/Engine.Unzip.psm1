﻿<#
	.Unzip the compressed package
	.解压压缩包
#>
Function Unzip_Compressed_Package
{
	<#
		.Extracting passwords
		.解压：密码
	#>
	$UnpackPasswordFiles = @(
		,("dControl*",  "dControl",           "sordum")
	)

	for ($i=0; $i -lt $UnpackPasswordFiles.Count; $i++) {
		Get-ChildItem –Path "$($PSScriptRoot)\..\..\..\" -filter "$($UnpackPasswordFiles[$i][1]).zip" –Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
			$SaveToName = [IO.Path]::GetDirectoryName($_.FullName)

			if ($UnpackPasswordFiles[$i][2] -eq "sordum") {
				Add-MpPreference -ExclusionPath "$SaveToName" -ErrorAction SilentlyContinue | Out-Null
			}

			Archive -Password $($UnpackPasswordFiles[$i][2]) -filename $_.FullName -to $SaveToName
			Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue
			Remove-Item -Path "$($_.FullName).sha256" -ErrorAction SilentlyContinue
		}
	}

	Get-ChildItem –Path "$($PSScriptRoot)\..\..\..\" -filter "*.zip" –Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
		$SaveToName = [IO.Path]::GetDirectoryName($_.FullName)
		Archive -filename $_.FullName -to $SaveToName
		Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue
		Remove-Item -Path "$($_.FullName).sha256" -ErrorAction SilentlyContinue
	}
	Write-Host ""
}