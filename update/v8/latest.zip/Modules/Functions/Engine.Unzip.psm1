﻿<#
	.Unzip the compressed package
	.解压压缩包
#>
Function Unzip_Compressed_Package
{
	<#
		.Extracting passwords
		.解压：密码
	#>
	$UnpackPasswordFiles = @(
		("HEU*",       "HEU_KMS_Activator",  "HEU"),
		("dControl*",  "dControl",           "sordum")
	)

	foreach ($item in $UnpackPasswordFiles) {
		Get-ChildItem –Path "$($PSScriptRoot)\..\..\..\" -filter "$($item[1]).zip" –Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
			$SaveToName = [IO.Path]::GetDirectoryName($_.FullName)

			if ($item[2] -eq "HEU") {
				Get-ChildItem –Path "$($PSScriptRoot)\..\..\..\" -filter "$($item[0]).exe" –Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					Add-MpPreference -ExclusionPath $_.FullName -ErrorAction SilentlyContinue | Out-Null
				}
				Add-MpPreference -ExclusionPath "$($env:systemroot)\System32\SECOPatcher.dll" -ErrorAction SilentlyContinue | Out-Null
			}

			if ($item[2] -eq "sordum") {
				Add-MpPreference -ExclusionPath "$SaveToName" -ErrorAction SilentlyContinue | Out-Null
			}

			Write-host "   * $($_.FullName)"
			Write-Host "     $($lang.Unpacking)".PadRight(28) -NoNewline
			Archive -Password $($item[2]) -filename $_.FullName -to $SaveToName
	
			Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue
			Remove-Item -Path "$($_.FullName).sha256" -ErrorAction SilentlyContinue
		}
	}

	Get-ChildItem –Path "$($PSScriptRoot)\..\..\..\" -filter "*.zip" –Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
		$SaveToName = [IO.Path]::GetDirectoryName($_.FullName)

		Write-host "   * $($_.FullName)"
		Write-Host "     $($lang.Unpacking)".PadRight(28) -NoNewline
		Archive -filename $_.FullName -to $SaveToName

		Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue
		Remove-Item -Path "$($_.FullName).sha256" -ErrorAction SilentlyContinue
	}
	Write-Host ""
}