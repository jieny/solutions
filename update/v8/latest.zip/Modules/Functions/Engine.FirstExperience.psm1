﻿<#
 .Synopsis
  FirstExperience

 .Description
  FirstExperience Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Register user interface
	.注册用户界面
#>
Function FirstExperience
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.FirstExperience)
	Write-Host "   $($lang.FirstExperience)`n   ---------------------------------------------------"

	if ($Force) {
		if (Test-Path -Path "$($PSScriptRoot)\..\..\Deploy\DoNotUpdate" -PathType Leaf) {
			Write-Host "   - $($lang.UpdateSkipUpdateCheck)"
		} else {
			Write-Host "   - $($lang.ForceUpdate)"
			Update -Auto -Force -IsProcess
		}

		FirstExperienceProcess
	} else {
		FirstExperienceGUI
	}
}

Function FirstExperienceGUI
{
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIFEVolumePanelClick = {
		if ($GUIFEVolume.Checked) {
			$GUIFEVolumePanel.Enabled = $True
		} else {
			$GUIFEVolumePanel.Enabled = $False
		}
	}
	$GUIFEDeskMenuClick = {
		if ($GUIFEDeskMenu.Checked) {
			$GUIFEDeskMenuShift.Enabled = $True
		} else {
			$GUIFEDeskMenuShift.Enabled = $False
		}
	}
	$GUIFECanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIFE.Close()
	}
	$GUIFEOKClick = {
		$GUIFE.Hide()
		if ($GUIFEVolume.Enabled) {
			if ($GUIFEVolume.Checked) {
				if ($GUIFEVolumeDefault.Checked) {
					SystemDiskLabel -VolumeName "OS"
				}
				if ($GUIFEVolumeSync.Checked) {
					SystemDiskLabel -VolumeName $Global:UniqueID
				}
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
			}
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFEDeskMenu.Enabled) {
			if ($GUIFEDeskMenu.Checked) {
				PersonaliseDeskMenu -Del
				if ($GUIFEDeskMenuShift.Checked) {
					PersonaliseDeskMenu -Add -Hide
				} else {
					PersonaliseDeskMenu -Add
				}
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			} else {
				PersonaliseDeskMenu -Del
				Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
			}
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.ExcludeDefenders)"
		if ($GUIFEDefenders.Checked) {
			ExclusionFirewall
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFELangAndKeyboard.Checked) {
			LanguageSetting
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.SettingLangAndKeyboard)"
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFEUtf8.Checked) {
			UseBetaUTF8 -Enable
		} else {
			Write-Host "   $($lang.SettingUTF8)"
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFELocale.Checked) {
			RegionCode -Force
		} else {
			Write-Host "   $($lang.SettingLocale)"
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFEFixMainFolder.Checked) {
			FixMainFolder
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.FDPermissions)"
		if ($GUIFEFDPermissions.Checked) {
			Permissions
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.Shortcut)"
		if ($GUIFEShortcut.Checked) {
			ShortcutProcess
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFEDeployCleanup.Checked) {
			RemoveTree -Path "$($PSScriptRoot)\..\..\Deploy"
		}

		if ($GUIFEReboot.Checked) {
			Restart-Computer -Force
		}
		$GUIFE.Close()
	}
	$GUIFE             = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 550
		Text           = $lang.FirstExperience
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}
	$GUIFEPanel        = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 520
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
		Dock           = 1
		Location       = "10,5"
	}
	$GUIFEVolume       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 490
		Text           = $lang.SelectVolumename
		Checked        = $True
		add_Click      = $GUIFEVolumePanelClick
	}
	$GUIFEVolumePanel  = New-Object system.Windows.Forms.Panel -Property @{
		Height         = 50
		Width          = 485
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
	}
	$GUIFEVolumeDefault = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 300
		Text           = "OS"
		Location       = '16,0'
		Checked        = $True
	}
	$GUIFEVolumeSync   = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 300
		Text           = $($Global:UniqueID)
		Location       = '16,25'
	}
	$GUIFEDeskMenu     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.DesktopMenu
		Checked        = $True
		add_Click      = $GUIFEDeskMenuClick
	}
	$GUIFEDeskMenuShift = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 380
		Text           = $lang.DesktopMenuShift
	}
	$GUIFEDefenders    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.ExcludeDefenders
		Checked        = $True
	}
	$GUIFELangAndKeyboard = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.SettingLangAndKeyboard
		Checked        = $True
	}
	$GUIFEUtf8         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.SettingUTF8
	}
	$GUIFEUtf8Tips     = New-Object System.Windows.Forms.Label -Property @{
		Height         = 26
		Width          = 370
		Text           = $lang.SettingUTF8Tips
		Padding        = "16,0,8,0"
	}
	$GUIFELocale       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = "$($lang.SettingLocale) ( $((Get-Culture).Name) )"
	}
	$GUIFELocaleTips     = New-Object System.Windows.Forms.Label -Property @{
		Height         = 26
		Width          = 370
		Text           = $lang.SettingLocaleTips
		Padding        = "16,0,8,0"
	}
	$GUIFEFixMainFolder = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = "$($lang.FixMainFolder -f $($Global:UniqueID))"
		Checked        = $True
	}
	$GUIFEFDPermissions = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.FDPermissions
		Checked        = $True
	}
	$GUIFEShortcut     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.Shortcut
		Checked        = $True
	}
	$GUIFEDeployCleanup = New-Object System.Windows.Forms.Checkbox -Property @{
		Height         = 30
		Width          = 505
		Text           = $lang.DeployCleanup
		Location       = "12,538"
		Checked        = $True
	}
	$GUIFEReboot       = New-Object System.Windows.Forms.Checkbox -Property @{
		Height         = 30
		Width          = 505
		Text           = $lang.Reboot
		Location       = "12,565"
	}
	$GUIFEOK           = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,595"
		Height         = 36
		Width          = 515
		add_Click      = $GUIFEOKClick
		Text           = $lang.OK
	}
	$GUIFECanel        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,635"
		Height         = 36
		Width          = 515
		add_Click      = $GUIFECanelClick
		Text           = $lang.Cancel
	}
	$GUIFE.controls.AddRange((
		$GUIFEPanel,
		$GUIFEDeployCleanup,
		$GUIFEReboot,
		$GUIFEOK,
		$GUIFECanel
	))
	$GUIFEPanel.controls.AddRange((
		$GUIFEVolume,
		$GUIFEVolumePanel,
		$GUIFEDeskMenu,
		$GUIFEDeskMenuShift,
		$GUIFEDefenders,
		$GUIFELangAndKeyboard,
		$GUIFEUtf8,
		$GUIFEUtf8Tips,
		$GUIFELocale,
		$GUIFELocaleTips,
		$GUIFEFixMainFolder,
		$GUIFEFDPermissions,
		$GUIFEShortcut
	))
	$GUIFEVolumePanel.controls.AddRange((
		$GUIFEVolumeDefault,
		$GUIFEVolumeSync
	))
 
	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIFE.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIFE.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$GUIFE.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$GUIFE.FormBorderStyle = 'Fixed3D'
	$GUIFE.ShowDialog() | Out-Null
}

<#
	.Prerequisite deployment
	.先决部署
#>
Function FirstExperienceProcess
{
	<#
		.According to the official requirements of Microsoft, add the strategy: Prevent Windows 10 from automatically deleting unused language packs
		.按照微软官方要求，添加策略：防止 Windows 10 自动删除未使用的语言包
	#>
	Disable-ScheduledTask -TaskPath "\Microsoft\Windows\AppxDeploymentClient\" -TaskName "Pre-staged app cleanup" -ErrorAction SilentlyContinue | Out-Null

	<#
		.Prevent cleanup of unused language packs
		.阻止清理未使用的语言包
	#>
	If (-not (Test-Path "HKLM:\Software\Policies\Microsoft\Control Panel\International")) { New-Item -Path "HKLM:\Software\Policies\Microsoft\Control Panel\International" -Force | Out-Null }
	Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Control Panel\International" -Name "BlockCleanupOfUnusedPreinstalledLangPacks" -Type DWord -Value 1 -ErrorAction SilentlyContinue | Out-Null
	Disable-ScheduledTask -TaskPath "\Microsoft\Windows\MUI\" -TaskName "LPRemove" -ErrorAction SilentlyContinue | Out-Null

	<#
		.Block cleanup of unused Language Feature On Demand packages
		.阻止清理未使用的 Language Feature On Demand 包
	#>
	If (-not (Test-Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\TextInput")) { New-Item -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\TextInput" -Force | Out-Null }
	Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\TextInput" -Name "AllowLanguageFeaturesUninstall" -Type DWord -Value 0 -ErrorAction SilentlyContinue | Out-Null
	Disable-ScheduledTask -TaskPath "\Microsoft\Windows\LanguageComponentsInstaller" -TaskName "Uninstallation" -ErrorAction SilentlyContinue | Out-Null

	<#
		.After using the $OEM$ mode to add files, the default is read-only. Change all files to: Normal.
		.使用 $OEM$ 模式添加文件后默认为只读，更改所有文件为：正常。
	#>
	Get-ChildItem "$($PSScriptRoot)\..\..\..\" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.Attributes="Normal" }
	if (Test-Path -Path "$($env:SystemDrive)\Users\Public\Desktop\Office" -PathType Container) {
		Get-ChildItem "$($env:SystemDrive)\Users\Public\Desktop\Office" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.Attributes="Normal" }
	}

	<#
		.Close the pop-up after entering the system for the first time: Network Location Wizard
		.关闭第一次进入系统后弹出：网络位置向导
	#>
	Write-Host "`n   $($lang.Disable) $($lang.NetworkLocationWizard)"
	New-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Network\NewNetworkWindowOff" -Force -ErrorAction SilentlyContinue | Out-Null

	<#
		.Change system disk volume label
		.更改系统盘卷标
	#>
	if (Test-Path "$($PSScriptRoot)\..\..\Deploy\SyncVolumeName" -PathType Leaf) {
		SystemDiskLabel -VolumeName $Global:UniqueID
	} else {
		SystemDiskLabel -VolumeName "OS"
	}

	<#
		.Add exclusion to firewall
		.向防火墙添加排除
	#>
	if (Test-Path "$($PSScriptRoot)\..\..\Deploy\ExcludeDefender" -PathType Leaf) {
		ExclusionFirewall
	}

	<#
	 	.Desktop right-click menu
		.桌面右键菜单
	#>
	if (Test-Path "$($PSScriptRoot)\..\..\Deploy\DesktopMenu" -PathType Leaf) {
		PersonaliseDeskMenu -Del

		if (Test-Path "$($PSScriptRoot)\..\..\Deploy\DesktopMenuShift" -PathType Leaf) {
			PersonaliseDeskMenu -Add -Hide
		} else {
			PersonaliseDeskMenu -Add
		}
	} else {
		PersonaliseDeskMenu -Del
	}

	<#
		.Set system language, keyboard, etc.
		.设置系统语言、键盘等
	#>
	LanguageSetting

	<#
		.Refresh icon cache
		.刷新图标缓存
	#>
	RefreshIconCache

	<#
		.Set folder and file permissions
		.设置文件夹、文件权限
	#>
	Permissions

	<#
		.Install fonts
		.安装字体
	#>
	InstallFontsProcess

	<#
		.Unzip the compressed package
		.解压压缩包
	#>
	UnzipThePackage

	<#
		.After completing the prerequisite deployment, determine whether to restart the computer
		.完成先决条件部署后，判断是否重启计算机
	#>
	if (Test-Path -Path "$($PSScriptRoot)\..\..\Deploy\PrerequisitesReboot" -PathType Leaf) {
		Write-Host "   $($lang.Reboot)"
		$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
		if (-not (Test-Path $regPath)) {
			New-Item -Path $regPath -Force -ErrorAction SilentlyContinue | Out-Null
		}

		$regValue = "cmd /c start /min """" powershell -Command ""Start-Process 'Powershell' -Argument '-ExecutionPolicy ByPass -File ""$((Convert-Path -Path "$($PSScriptRoot)\..\..\Engine.ps1" -ErrorAction SilentlyContinue))"" -Functions \""FirstDeployment -Quit\""' -WindowStyle Minimized -Verb RunAs"""
		New-ItemProperty -Path $regPath -Name "$($Global:UniqueID)" -Value $regValue -PropertyType STRING -Force | Out-Null

		Restart-Computer -Force
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	} else {
		FirstDeployment
	}
}


<#
	.First Deployment
	.首次部署
#>
Function FirstDeployment
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.FirstDeployment)
	Write-Host "   $($lang.FirstDeployment)`n   ---------------------------------------------------"

	<#
		.Prerequisite deployment rules
		.先决部署规则
	#>
	$Global:MarkRebootComputer = $False
	$FlagsClearSolutionsRule = $False

	if ($Reboot) {
		$Global:MarkRebootComputer = $True
	}
	if (Test-Path -Path "$($PSScriptRoot)\..\..\Deploy\FirstExperienceReboot" -PathType Leaf) {
		$Global:MarkRebootComputer = $True
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\Deploy\ClearSolutions" -PathType Leaf) {
		$FlagsClearSolutionsRule = $True
	}
	if (Test-Path -Path "$($PSScriptRoot)\..\..\Deploy\ClearEngine" -PathType Leaf) {
		$FlagsClearSolutionsRule = $True
	}

	<#
		.Pop up the main interface
		.弹出主界面
	#>
	Write-Host "`n   $($lang.FirstDeploymentPopup)"
	if ($FlagsClearSolutionsRule) {
		Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
	} else {
		if (Test-Path "$($PSScriptRoot)\..\..\Deploy\PopupEngine" -PathType Leaf) {
			Write-Host "   $($lang.Operable)`n" -ForegroundColor Green
			Start-Process powershell -ArgumentList "-file $((Convert-Path -Path "$($PSScriptRoot)\..\..\Engine.ps1" -ErrorAction SilentlyContinue))"
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}
	}

	<#
		.Create Shortcut
		.创建快捷方式
	#>
	ShortcutProcess

	<#
		.Allow the first pre-experience, as planned
		.允许首次预体验，按计划
	#>
	Write-Host "`n   $($lang.FirstExpFinishOnDemand)"
	if (Test-Path "$($PSScriptRoot)\..\..\Deploy\FirstPreExperience" -PathType Leaf)
	{
		Write-Host "   $($lang.Operable)" -ForegroundColor Green

		<#
			.Create a restore point
			.创建还原点
		#>
#		RestorePointCreate

		<#
			.Change user directory
			.更改用户目录
		#>
#		SetKnownFolderPath -KnownFolder 'Desktop'   -NewFolder "D:\Yi\Desktop"
#		SetKnownFolderPath -KnownFolder 'Documents' -NewFolder "D:\Yi\Documents"
#		SetKnownFolderPath -KnownFolder 'Downloads' -NewFolder "D:\Yi\Downloads"
#		SetKnownFolderPath -KnownFolder 'Music'     -NewFolder "D:\Yi\Music"
#		SetKnownFolderPath -KnownFolder 'Pictures'  -NewFolder "D:\Yi\Pictures"
#		SetKnownFolderPath -KnownFolder 'Videos'    -NewFolder "D:\Yi\Videos"

		<#
			.Activation Kit
			.激活工具
		#>
		InstallProcess -appname $ActivateApp[0][0] -status "Enable" -act $ActivateApp[0][2] -mode $ActivateApp[0][3] -todisk $ActivateApp[0][4] -structure $ActivateApp[0][5] -pwd $ActivateApp[0][6] -url $ActivateApp[0][7] -urlAMD64 $ActivateApp[0][8] -urlarm64 $ActivateApp[0][9] -filename $ActivateApp[0][10] -param $ActivateApp[0][11] -Before $ActivateApp[0][12] -After $ActivateApp[0][13]

		<#
			.Desktop icons
			.桌面图标
		#>
		DesktopICONThisPC -AllUsers           # 此电脑              | This computer
#		DesktopICONRecycleBin -AllUsers       # 回收站              | Recycle Bin
		DesktopICONUser -AllUsers             # 用户                | User
#		DesktopICONControlPanel -AllUsers     # 控制面板            | Control Panel
#		DesktopICONNetwork -AllUsers          # 网络                | Network
#		DesktopICONGodMode                    # 上帝模式            | God Mode
#		DesktopICONIE -AllUsers               # Internet Explorer
		ResetDesktop                          # 重新排列桌面图标     | Rearrange desktop icons

		<#
			.优化电源前判断计算机类型
			.Determine the computer type before optimizing the power supply
		#>
		$NoSelectPowerSupply = @(8, 9, 10, 11, 14)
		Get-CimInstance -ClassName Win32_SystemEnclosure | ForEach-Object {
			if ($NoSelectPowerSupply -notcontains $_.SecurityStatus) {
				Hibernation -Disable            # Disable, Enable             | $lang.Hibernation
				PowerSupply -Optimize           # Optimize, Restore           | $lang.PowerSupply
			}
		}

		<#
			.优化系统
			.Optimize the system
		#>
		if (IsWin11) {
			Win11TPMSetup
			Win11TPMUpdate
		}
		KeepSpace -Disable              # Disable, Enable             | $lang.KeepSpace
		AppRestartScreen -Disable       # Disable, Enable             | $lang.AppRestartScreen
		Numlock -Enable                 # Disable, Enable             | $lang.Numlock
		UACNever -Disable               # Disable, Enable             | $lang.UAC $lang.UACNever
		SmartScreenApps -Disable        # Disable, Enable             | $lang.SmartScreenApps
		SmartScreenSafe -Disable        # Disable, Enable             | $lang.SmartScreenSafe
		EasyAccessKeyboard -Disable     # Disable, Enable             | $lang.EasyAccessKeyboard
		Maintain -Disable               # Disable, Enable             | $lang.Maintain
		Experience -Disable             # Disable, Enable             | $lang.Experience
		Defragmentation -Disable        # Disable, Enable             | $lang.Defragmentation
		Compatibility -Disable          # Disable, Enable             | $lang.Compatibility
		AnimationEffects -Optimize      # Optimize, Restore           | $lang.AnimationEffects
		ErrorRecovery -Disable          # Disable, Enable             | $lang.ErrorRecovery
#		DEPPAE -Disable                 # Disable, Enable             | $lang.DEP
		PowerFailure -Disable           # Disable, Enable             | $lang.PowerFailure
		ScheduledTasks -Disable         # Disable, Restore            | $lang.ScheduledTasks
		PwdUnlimited -Disable           # Disable, Enable             | $lang.PwdUnlimited
		RAM -Disable                    # Disable, Enable             | $lang.RAM
		StorageSense -Disable           # Disable, Enable             | $lang.StorageSense
		Delivery -Disable               # Disable, Enable             | $lang.Delivery
		PhotoPreview -Enable            # Disable, Enable             | $lang.PhotoPreview
		Protected -Disable              # Disable, Enable             | $lang.Protected
		ErrorReporting -Disable         # Disable, Enable             | $lang.ErrorReporting
#		F8BootMenu -Disable             # Disable, Enable             | $lang.F8BootMenu
		SSD -Disable                    # Disable, Enable             | $lang.OptSSD
		MemoryCompression -Disable      # Disable, Enable             | $lang.MemoryCompression
		Prelaunch -Disable              # Disable, Enable             | $lang.Prelaunch

		<#
			.网络优化
		#>
#		IEProxy                             # Disable, Enable             | $lang.IEProxy
		AutoDetect -Disable                 # Disable, Enable             | $lang.IEAutoSet
#		NetworkDiscovery -Disable           # Disable, Enable             | $lang.NetworkDiscovery
#		NetworkAdaptersSavePower -Disable   # Disable, Enable             | $lang.NetworkAdaptersPM
#		IPv6Component -Disable              # Disable, Enable             | $lang.IPv6Component
		QOS -Disable                        # Disable, Enable             | $lang.QOS
		NetworkTuning -Disable              # Disable, Enable             | $lang.NetworkTuning
		ECN -Disable                        # Disable, Enable             | $lang.ECN

		<#
			.Resource manager
			.资源管理器
		#>
#		SeparateProcess -Disable        # Disable, Enable             | $lang.SeparateProcess
#		RestartApps -Disable            # Disable, Enable             | $lang.RestartApps
#		CheckBoxes -Disable             # Disable, Enable             | $lang.CheckBoxes
#		ThumbnailCache -Disable         # Disable, Enable             | $lang.ThumbnailCache
		ExplorerOpenTo -ThisPC          # Disable, Enable             | $lang.ExplorerToThisPC
		AeroShake -Disable -AllUser     # Disable, Enable             | $lang.AeroShake
		FileExtensions -Show            # Show, Hide                  | $lang.FileExtensions
		SafetyWarnings -Disable         # Disable, Enable             | $lang.SafetyWarnings
		FileTransferDialog -Detailed    # Detailed, Simple            | $lang.FileTransfer
		NavShowAll -Enable              # Disable, Enable             | $lang.NavShowAll
#		Autoplay -Disable               # Disable, Enable             | $lang.Autoplay
#		Autorun -Disable                # Disable, Enable             | $lang.Autorun
		QuickAccessFiles -Hide          # Show, Hide                  | $lang.QuickAccessFiles
		QuickAccessFolders -Hide        # Show, Hide                  | $lang.QuickAccessFolders
		ShortcutArrow -Disable          # Disable, Enable             | $lang.ShortcutArrow

		ThisPCDesktop -Disable          # Disable, Enable             | $lang.LocationDesktop
		ThisPCDocument -Disable         # Disable, Enable             | $lang.LocationDocuments
		ThisPCDownload -Disable         # Disable, Enable             | $lang.LocationDownloads
		ThisPCMusic -Disable            # Disable, Enable             | $lang.LocationMusic
		ThisPCPicture -Disable          # Disable, Enable             | $lang.LocationPictures
		ThisPCVideo -Disable            # Disable, Enable             | $lang.LocationVideos
		if (-not (IsWin11)) {
			ThisPC3D -Disable           # Disable, Enable             | $lang.Location3D
		}

		<#
			.Right click menu
			.右键菜单
		#>
		if (IsWin11) {
			Win11ContextMenu -Modern    # Modern, Classic             | $lang.ClassicMenu
		}
		TakeOwnership -Remove           # Del $lang.AddOwnership
		TakeOwnership -Add              # Add $lang.AddOwnership
		MultipleIncrease -Disable       # Disable, Enable             | $lang.MultipleIncrease
		CopyPath -Add                   # Remove, Add                 | $lang.CopyPath

		<#
			.Start menu and taskbar
			.开始菜单和任务栏
		#>
		if (IsWin11) {
#			TaskbarAlignment -Leaf      # Leaf, Center                | $lang.TaskbarAlignment
			TaskbarWidgets -Hide        # Show, Hide                  | $lang.TaskbarWidgets
		}
		TeamsAutostarting -Disable      # Disable, Enable             | $lang.TeamsAutostarting
		TeamsTaskbarChat -Hide          # Show, Hide                  | $lang.TeamsTaskbarChat
		BingSearch -Disable             # Disable, Enable             | $lang.BingSearch
		TaskbarSuggestedContent -Hide   # Show, Hide                  | $lang.TaskbarSuggestedContent
		SuggestionsDevice -Disable      # Disable, Enable             | $lang.SuggestionsDevice
		SearchBox -SearchIcon           # Hide, SearchIcon, SearchBox | $lang.SearchBox
		MergeTaskbarNever -Enable       # Disable, Enable             | $lang.MergeTaskbarNever
		NotificationAlways -Enable      # Disable, Enable             | $lang.NotificationAlways
		Cortana -Disable                # Disable, Enable             | $lang.Cortana
		TaskView -Hide                  # Show, Hide                  | $lang.TaskView

		<#
			.Game Bar
		#>
		XboxGameBar -Disable            # Disable, Enable             | $lang.XboxGameBar
		XboxGameBarTips -Disable        # Disable, Enable             | $lang.XboxGameBarTips
		XboxGameMode -Disable           # Disable, Enable             | $lang.XboxGameMode
		XboxGameDVR -Disable            # Disable, Restore            | $lang.XboxGameDVR

		<#
			.Privacy
			.隐私
		#>
		PrivacyVoiceTyping -Disable             # Disable, Enable     | $lang.PrivacyVoiceTyping
		PrivacyContactsSpeech -Disable          # Disable, Enable     | $lang.PrivacyContactsSpeech
		PrivacyLanguageOptOut -Disable          # Disable, Enable     | $lang.PrivacyLanguageOptOut
		PrivacyAds -Disable                     # Disable, Enable     | $lang.PrivacyAds
		PrivacyLocatonAware -Disable            # Disable, Enable     | $lang.PrivacyLocatonAware
		PrivacySetSync -Disable                 # Disable, Enable     | $lang.PrivacySetSync
		PrivacyInkingTyping -Disable            # Disable, Enable     | $lang.PrivacyInkingTyping
		PrivacyShareUnpairedDevices -Disable    # Disable, Enable     | $lang.PrivacyShareUnpairedDevices
		PrivacyLocationSensor -Disable          # Disable, Enable     | $lang.PrivacyLocationSensor
		PrivacyBiometrics -Disable              # Disable, Enable     | $lang.PrivacyBiometrics
		PrivacyCompatibleTelemetry -Disable     # Disable, Enable     | $lang.PrivacyCompatibleTelemetry
		PrivacyDiagnosticData -Disable          # Disable, Enable     | $lang.PrivacyDiagnosticData
		PrivacyTailoredExperiences -Disable     # Disable, Enable     | $lang.TailoredExperiences
		PrivacyFeedbackNotifications -Disable   # Disable, Enable     | $lang.PrivacyFeedbackNotifications
		PrivacyLocationTracking -Disable        # Disable, Enable     | $lang.PrivacyLocationTracking
		PrivacyExperiencesTelemetry -Disable    # Disable, Enable     | $lang.ExperiencesTelemetry
		PrivacyBackgroundAccess -Disable        # Disable, Enable     | $lang.PrivacyBackgroundAccess
		if (-not (IsWin11)) {
			TimelineTime -Disable              # Disable, Enable     | $lang.TimelineTime
			CollectActivity -Disable           # Disable, Enable     | $lang.CollectActivity
		}

		<#
			.Paging size
			.分页大小
		#>
		PagingSize -Enable -size 8              # 8, 16               | $lang.PagingSize 8G and 16G

		<#
			.Notification Center
			.通知中心
		#>
		NotificationCenter -Part                # Full, Part, Restore | $lang.Notification $lang.Full

		<#
			.Other
			.其它
		#>
#		RemoteDesktop                   # $lang.StRemote
#		SMBFileShare                    # $lang.StSMB

		<#
			.Clean
			.清理
		#>
		SendTo                          # $lang.SendTo
		CleanSystemLog                  # $lang.Logs
		DiskCleanup                     # $lang.DiskCleanup
#		CleanSxS                        # $lang.SxS

		<#
			.Optimize service
			.优化服务
		#>
		$PreServices = @(
#			"Spooler"
			"DPS"
			"WdiSystemHost"
			"WdiServiceHost"
			"diagnosticshub.standardcollector.service"
			"dmwappushservice"
			"lfsvc"
			"MapsBroker"
			"NetTcpPortSharing"
			"RemoteAccess"
			"RemoteRegistry"
			"SharedAccess"
			"TrkWks"
			"WbioSrvc"
			"WlanSvc"
			"WMPNetworkSvc"
			"WSearch"
			"XblAuthManager"
			"XblGameSave"
			"XboxNetApiSvc"
		)

		foreach ($item in $PreServices) {
			Write-Host "   $($lang.Close) $item"
			Get-Service -Name $item | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
			Stop-Service $item -Force -NoWait -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		}

		<#
			.Turn off Microsoft Defender Antivirus
			.关闭 Microsoft Defender 防病毒
		#>
#		InstallProcess -appname "$($lang.Close) $($lang.DefenderControlTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $PSScriptRoot -structure "..\..\..\20\dControl" -pwd "sordum" -url "https://www.sordum.org/files/download/d-control/dControl.zip" -urlAMD64 "" -urlarm64 "" -filename "dfControl*" -param "" -Before "" -After ""


		<#
			.Turn off Microsoft Defender firewall
			.关闭 Microsoft Defender 防火墙
		#>
#		InstallProcess -appname "$($lang.Close) $($lang.FabTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $PSScriptRoot -structure "..\..\..\20" -pwd "" -url "https://www.sordum.org/files/download/firewall-app-blocker/fab.zip" -urlAMD64 "" -urlarm64 "" -filename "fab*" -param "/S 3" -Before "" -After ""

		<#
			.Turn off Windows Update
			.关闭 Windows 更新
		#>
#		InstallProcess -appname "$($lang.Close) $($lang.WubTips)" -status "Enable" -act "Install" -mode "Fast" -todisk $PSScriptRoot -structure "..\..\..\20" -pwd "" -url "https://www.sordum.org/files/download/windows-update-blocker/Wub.zip" -urlAMD64 "" -urlarm64 "" -filename "Wub*" -param "/D /P" -Before "" -After ""
#		UpdateAutoDownload -Disable
#		UpdatePolicies -Disable
#		UpdateAutoDrive -Disable
#		UpdateAreAvailable -Disable
#		Win11TPM -Disable

		<#
			.Delete OneDrive
			.删除 OneDrive
		#>
#		OneDriveRemove         # Remove OneDrive

		<#
			.Delete Edge
			.删除 Edge
		#>
#		DelEdge             # Remove Edge

		<#
			.Delete UWP app
			.删除 UWP 应用
		#>
		[Windows.Management.Deployment.PackageManager, Windows.Web, ContentType = WindowsRuntime]::new().FindPackages() | Select-Object -ExpandProperty Id -Property DisplayName | Where-Object -FilterScript {
			($_.Name -in (Get-AppxPackage -PackageTypeFilter Bundle -AllUsers).Name) -and ($null -ne $_.DisplayName)} | ForEach-Object {
			if (($AppsUncheck + $AppsExcluded) -Contains $_.Name) {
			} else {
				Write-Host "   $($_.Name)"
				Write-host "   $($lang.Delete)".PadRight(22) -NoNewline
				Get-AppXProvisionedPackage -Online | Where-Object DisplayName -Like "$($_.Name)" | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction SilentlyContinue | Out-Null
				Get-AppxPackage -Name "$($_.Name)" | Remove-AppxPackage | Out-Null
				Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
			}
		}
		Write-Host ""

		<#
			.Install prerequisite software
			.安装必备软件
		#>
		for ($i=0; $i -lt $Global:PrerequisiteApp.Count; $i++) {
			InstallProcess -appname $Global:PrerequisiteApp[$i][0] -status $Global:PrerequisiteApp[$i][1] -act $Global:PrerequisiteApp[$i][2] -mode $Global:PrerequisiteApp[$i][3] -todisk $Global:PrerequisiteApp[$i][4] -structure $Global:PrerequisiteApp[$i][5] -pwd $Global:PrerequisiteApp[$i][6] -url $Global:PrerequisiteApp[$i][7] -urlAMD64 $Global:PrerequisiteApp[$i][8] -urlarm64 $Global:PrerequisiteApp[$i][9] -filename $Global:PrerequisiteApp[$i][10] -param $Global:PrerequisiteApp[$i][11] -Before $Global:PrerequisiteApp[$i][12] -After $Global:PrerequisiteApp[$i][13]
		}

		<#
			.Install common software
			.安装常用软件
		#>
#		MostUsedSoftware -Force        # $lang.MostUsedSoftware

		<#
			.Wait for the queue to finish
			.等待队列运行结束
		#>
		WaitEnd
	} else {
		Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
	}

	Write-Host "`n   $($lang.FirstDeployment)"
	DeployGuide

	<#
		.Search for Bat and PS1
		.搜索 Bat、PS1
	#>
	write-host "`n   $($lang.DiskSearch)"

	<#
		.Search for local deployment: Bat
		.搜索本地部署：Bat
	#>
	Get-ChildItem –Path "$($PSScriptRoot)\..\..\Deploy\bat" -Filter "*.bat" -ErrorAction SilentlyContinue | foreach-Object {
		write-host	"   - $($lang.DiskSearchFind -f $($_.Fullname))`n" -ForegroundColor Green
		Start-Process -FilePath "$($_.Fullname)"  -wait -WindowStyle Minimized
	}

	<#
		.Search for local deployment: ps1
		.搜索本地部署：ps1
	#>
	Get-ChildItem –Path "$($PSScriptRoot)\..\..\Deploy\ps1" -Filter "*.ps1" -ErrorAction SilentlyContinue | foreach-Object {
		write-host	"   - $($lang.DiskSearchFind -f $($_.Fullname))`n" -ForegroundColor Green
		Start-Process "powershell" -ArgumentList "-ExecutionPolicy ByPass -file ""$($_.Fullname)""" -Wait -WindowStyle Minimized
	}

	<#
		.Full plan, search by rule: Bat
		.全盘计划，按规则搜索：Bat
	#>
	$SearchBatFile = @(
		"$($Global:UniqueID).bat"
		"$($Global:UniqueID)\$($Global:UniqueID).bat"
	)
	foreach ($item in $SearchBatFile) {
		Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
			$TempFilePath = Join-Path -Path "$($_.Root)" -ChildPath "$($item)" -ErrorAction SilentlyContinue

			Write-Host "   - $($TempFilePath)"
			if (Test-Path $TempFilePath -PathType Leaf) {
				write-host	"   - $($lang.DiskSearchFind -f $($TempFilePath))`n" -ForegroundColor Gray
				Start-Process -FilePath "$($TempFilePath)"  -wait -WindowStyle Minimized
			}
		}
	}

	<#
		.Full plan, search by rule: ps1
		.全盘计划，按规则搜索：ps1
	#>
	$SearchPSFile = @(
		"$($Global:UniqueID).ps1"
		"$($Global:UniqueID)\$($Global:UniqueID).ps1"
	)
	foreach ($item in $SearchPSFile) {
		Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
			$TempFilePath = Join-Path -Path "$($_.Root)" -ChildPath "$($item)" -ErrorAction SilentlyContinue

			Write-Host "   - $TempFilePath"
			if (Test-Path $TempFilePath -PathType Leaf) {
				write-host	"   - $($lang.DiskSearchFind -f $($TempFilePath))`n" -ForegroundColor Gray
				Start-Process "powershell" -ArgumentList "-ExecutionPolicy ByPass -file ""$TempFilePath""" -Wait -WindowStyle Minimized
			}
		}
	}

	<#
		.Recovery PowerShell strategy
		.恢复 PowerShell 策略
	#>
	if (Test-Path -Path "$($PSScriptRoot)\..\..\Deploy\ResetExecutionPolicy" -PathType Leaf) {
		Set-ExecutionPolicy -ExecutionPolicy Restricted -Force -ErrorAction SilentlyContinue
	}

	<#
		.Clean up the solution
		.清理解决方案
	#>
	if (Test-Path -Path "$($PSScriptRoot)\..\..\Deploy\ClearSolutions" -PathType Leaf) {
		Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
		RemoveTree -Path "$($Global:UniqueMainFolder)"

		<#
			.In order to prevent the solution from being unable to be cleaned up, the next time you log in, execute it again
			.为了防止无法清理解决方案，下次登录时，再次执行
		#>
		Write-Host "   $($lang.NextDelete)`n" -ForegroundColor Green
		$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
		$regKey = "Clear $($Global:UniqueID) Folder"
		$regValue = "cmd.exe /c rd /s /q ""$($Global:UniqueMainFolder)"""
		if (Test-Path $regPath) {
			New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
		} else {
			New-Item -Path $regPath -Force | Out-Null
			New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
		}
	}

	<#
		.Clean up the main engine
		.清理主引擎
	#>
	if (Test-Path -Path "$($PSScriptRoot)\..\..\Deploy\ClearEngine" -PathType Leaf) {
		Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
		RemoveTree -Path "$($Global:MainFolder)"
	}

	<#
		.Clean up deployment configuration
		.清理部署配置
	#>
	RemoveTree -Path "$($PSScriptRoot)\..\..\Deploy"

	if ($Global:MarkRebootComputer) {
		<#
			.Reboot Computer
			.重启计算机
		#>
		Restart-Computer -Force
	}
}

<#
	.Change system disk volume label
	.更改系统盘卷标
#>
Function SystemDiskLabel
{
	param
	(
		[string]$VolumeName
	)

	Write-Host "`n   $($lang.VolumeLabel -f $VolumeName)"
	(New-Object -ComObject "Shell.Application").NameSpace($env:SystemDrive).Self.Name = $VolumeName
}

<#
	.Add exclusion to firewall
	.向防火墙添加排除
#>
Function ExclusionFirewall
{
	$ExcludeMpPreference = @(
		"$($PSScriptRoot)\..\..\.."
	)

	Write-Host "`n   $($lang.AddTo) $($lang.Exclude)"
	foreach ($item in $ExcludeMpPreference) {
		Write-Host "   * $item"
		Add-MpPreference -ExclusionPath (Convert-Path -Path $item -ErrorAction SilentlyContinue) -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

Function FixMainFolder
{
	Write-Host "`n   $($lang.FixMainFolder -f $($Global:UniqueID))`n"
	$DeskEdit = "$(GetArchitecturePacker -Path "$($PSScriptRoot)\..\..\AIO\DeskEdit")\DeskEdit.exe"
	if (Test-Path $DeskEdit -PathType Leaf) {
		$IconPath = Convert-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -ErrorAction SilentlyContinue
		Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($Global:UniqueMainFolder)"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($Global:UniqueID)'s Solutions"""

		if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($Global:UniqueMainFolder)"" /S=.ShellClassInfo /L=IconResource=""$($IconPath),0"""
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	} else {
		Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
	}
}

Export-ModuleMember -Function * -Alias *