﻿<#
	.Register user interface
	.注册用户界面
#>
Function FirstExperience
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.FirstExperience)
	Write-Host "   $($lang.FirstExperience)`n   ---------------------------------------------------"

	if ($Force) {
		if (Deploy_Sync -Mark "AutoUpdate") {
			Write-Host "   - $($lang.ForceUpdate)"
			Update -Auto -Force -IsProcess
		} else {
			Write-Host "   - $($lang.UpdateSkipUpdateCheck)"
		}

		FirstExperience_Process
	} else {
		FirstExperience_Setting_UI
	}
}

Function FirstExperience_Setting_UI
{
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIFEVolumePanelClick = {
		if ($GUIFEVolume.Checked) {
			$GUIFEVolumePanel.Enabled = $True
		} else {
			$GUIFEVolumePanel.Enabled = $False
		}
	}
	$GUIFEDeskMenuClick = {
		if ($GUIFEDeskMenu.Checked) {
			$GUIFEDeskMenuShift.Enabled = $True
		} else {
			$GUIFEDeskMenuShift.Enabled = $False
		}
	}
	$GUIFECanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIFE.Close()
	}
	$GUIFEOKClick = {
		$GUIFE.Hide()
		if ($GUIFEVolume.Enabled) {
			if ($GUIFEVolume.Checked) {
				if ($GUIFEVolumeDefault.Checked) {
					System_Disk_Label -VolumeName "OS"
				}
				if ($GUIFEVolumeSync.Checked) {
					System_Disk_Label -VolumeName $Global:UniqueID
				}
				Write-Host "   $($lang.Done)`n" -ForegroundColor Green
			} else {
				Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
			}
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFEDeskMenu.Enabled) {
			if ($GUIFEDeskMenu.Checked) {
				Personalise_Menu -Del
				if ($GUIFEDeskMenuShift.Checked) {
					Personalise_Menu -Add -Hide
				} else {
					Personalise_Menu -Add
				}
				Write-Host "   $($lang.Done)`n" -ForegroundColor Green
			} else {
				Personalise_Menu -Del
				Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
			}
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.ExcludeDefenders)"
		if ($GUIFEDefenders.Checked) {
			Firewall_Exclusion
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFELangAndKeyboard.Checked) {
			Language_Setting
			Write-Host "   $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.SettingLangAndKeyboard)"
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFEUtf8.Checked) {
			Language_Use_UTF8 -Enabled
		} else {
			Write-Host "   $($lang.SettingUTF8)"
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFELocale.Checked) {
			Language_Region_Setting -Force
		} else {
			Write-Host "   $($lang.SettingLocale)"
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFEFixMainFolder.Checked) {
			Repair_Home_Directory
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.FDPermissions)"
		if ($GUIFEFDPermissions.Checked) {
			Permissions
			Write-Host "   $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		write-host "   $($lang.Shortcut)"
		if ($GUIFEShortcut.Checked) {
			Shortcut_Process
			Write-Host "   $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}

		if ($GUIFEDeployCleanup.Checked) {
			Remove_Tree -Path "$($PSScriptRoot)\..\..\Deploy"
		}

		if ($GUIFEReboot.Checked) {
			Restart-Computer -Force
		}
		$GUIFE.Close()
	}
	$GUIFE             = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 550
		Text           = $lang.FirstExperience
		StartPosition  = "CenterScreen"
		MaximizeBox    = $False
		MinimizeBox    = $False
		ControlBox     = $False
		BackColor      = "#ffffff"
	}
	$GUIFEPanel        = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 520
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
		Dock           = 1
		Location       = "10,5"
	}
	$GUIFEVolume       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 490
		Text           = $lang.SelectVolumename
		Checked        = $True
		add_Click      = $GUIFEVolumePanelClick
	}
	$GUIFEVolumePanel  = New-Object system.Windows.Forms.Panel -Property @{
		Height         = 50
		Width          = 485
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $True
		Padding        = "8,0,8,0"
	}
	$GUIFEVolumeDefault = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 300
		Text           = "OS"
		Location       = '16,0'
		Checked        = $True
	}
	$GUIFEVolumeSync   = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 300
		Text           = $($Global:UniqueID)
		Location       = '16,25'
	}
	$GUIFEDeskMenu     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.DesktopMenu
		Checked        = $True
		add_Click      = $GUIFEDeskMenuClick
	}
	$GUIFEDeskMenuShift = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 380
		Text           = $lang.DesktopMenuShift
	}
	$GUIFEDefenders    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.ExcludeDefenders
		Checked        = $True
	}
	$GUIFELangAndKeyboard = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.SettingLangAndKeyboard
		Checked        = $True
	}
	$GUIFEUtf8         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.SettingUTF8
	}
	$GUIFEUtf8Tips     = New-Object System.Windows.Forms.Label -Property @{
		Height         = 26
		Width          = 370
		Text           = $lang.SettingUTF8Tips
		Padding        = "16,0,8,0"
	}
	$GUIFELocale       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = "$($lang.SettingLocale) ( $((Get-Culture).Name) )"
	}
	$GUIFELocaleTips   = New-Object System.Windows.Forms.Label -Property @{
		Height         = 26
		Width          = 370
		Text           = $lang.SettingLocaleTips
		Padding        = "16,0,8,0"
	}
	$GUIFEFixMainFolder = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = "$($lang.FixMainFolder -f $($Global:UniqueID))"
		Checked        = $True
	}
	$GUIFEFDPermissions = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.FDPermissions
		Checked        = $True
	}
	$GUIFEShortcut     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 490
		Text           = $lang.Shortcut
		Checked        = $True
	}
	$GUIFEDeployCleanup = New-Object System.Windows.Forms.Checkbox -Property @{
		Height         = 30
		Width          = 505
		Text           = $lang.DeployCleanup
		Location       = "12,538"
		Checked        = $True
	}
	$GUIFEReboot       = New-Object System.Windows.Forms.Checkbox -Property @{
		Height         = 30
		Width          = 505
		Text           = $lang.Reboot
		Location       = "12,565"
	}
	$GUIFEOK           = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,595"
		Height         = 36
		Width          = 515
		add_Click      = $GUIFEOKClick
		Text           = $lang.OK
	}
	$GUIFECanel        = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,635"
		Height         = 36
		Width          = 515
		add_Click      = $GUIFECanelClick
		Text           = $lang.Cancel
	}
	$GUIFE.controls.AddRange((
		$GUIFEPanel,
		$GUIFEDeployCleanup,
		$GUIFEReboot,
		$GUIFEOK,
		$GUIFECanel
	))
	$GUIFEPanel.controls.AddRange((
		$GUIFEVolume,
		$GUIFEVolumePanel,
		$GUIFEDeskMenu,
		$GUIFEDeskMenuShift,
		$GUIFEDefenders,
		$GUIFELangAndKeyboard,
		$GUIFEUtf8,
		$GUIFEUtf8Tips,
		$GUIFELocale,
		$GUIFELocaleTips,
		$GUIFEFixMainFolder,
		$GUIFEFDPermissions,
		$GUIFEShortcut
	))
	$GUIFEVolumePanel.controls.AddRange((
		$GUIFEVolumeDefault,
		$GUIFEVolumeSync
	))
 
	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIFE.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIFE.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$GUIFE.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$GUIFE.FormBorderStyle = 'Fixed3D'
	$GUIFE.ShowDialog() | Out-Null
}

<#
	.Prerequisite deployment
	.先决部署
#>
Function FirstExperience_Process
{
	<#
		.Refresh all known languages installed
		.刷新已安装的所有已知语言
	#>
	Language_Known_Available

	<#
		.Determine whether all languages currently installed are multilingual versions, and add known policies to multilingual versions
		.获取已安装所有语言是否是多语版，多语版则添加已知策略
	#>
	if ($Global:AvailableLanguages.count -gt 0) {
		Write-Host "   $($lang.LangMul) ( $($Global:AvailableLanguages.count) )"
		<#
			.According to the official requirements of Microsoft, add the strategy: Prevent Windows 10 from automatically deleting unused language packs
			.按照微软官方要求，添加策略：防止 Windows 10 自动删除未使用的语言包
		#>
		Disable-ScheduledTask -TaskPath "\Microsoft\Windows\AppxDeploymentClient\" -TaskName "Pre-staged app cleanup" -ErrorAction SilentlyContinue | Out-Null

		<#
			.Prevent cleanup of unused language packs
			.阻止清理未使用的语言包
		#>
		If (-not (Test-Path "HKLM:\Software\Policies\Microsoft\Control Panel\International")) { New-Item -Path "HKLM:\Software\Policies\Microsoft\Control Panel\International" -Force | Out-Null }
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Control Panel\International" -Name "BlockCleanupOfUnusedPreinstalledLangPacks" -Type DWord -Value 1 -ErrorAction SilentlyContinue | Out-Null
		Disable-ScheduledTask -TaskPath "\Microsoft\Windows\MUI\" -TaskName "LPRemove" -ErrorAction SilentlyContinue | Out-Null

		<#
			.Block cleanup of unused Language Feature On Demand packages
			.阻止清理未使用的 Language Feature On Demand 包
		#>
		If (-not (Test-Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\TextInput")) { New-Item -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\TextInput" -Force | Out-Null }
		Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\TextInput" -Name "AllowLanguageFeaturesUninstall" -Type DWord -Value 0 -ErrorAction SilentlyContinue | Out-Null
		Disable-ScheduledTask -TaskPath "\Microsoft\Windows\LanguageComponentsInstaller" -TaskName "Uninstallation" -ErrorAction SilentlyContinue | Out-Null
	} else {
		Write-Host "   $($lang.LangSingle)"
	}

	<#
		.After using the $OEM$ mode to add files, the default is read-only. Change all files to: Normal.
		.使用 $OEM$ 模式添加文件后默认为只读，更改所有文件为：正常。
	#>
	Get-ChildItem "$($PSScriptRoot)\..\..\..\" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.Attributes="Normal" }
	if (Test-Path -Path "$($env:SystemDrive)\Users\Public\Desktop\Office" -PathType Container) {
		Get-ChildItem "$($env:SystemDrive)\Users\Public\Desktop\Office" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.Attributes="Normal" }
	}

	<#
		.Close the pop-up after entering the system for the first time: Network Location Wizard
		.关闭第一次进入系统后弹出：网络位置向导
	#>
	Write-Host "`n   $($lang.Disable) $($lang.NetworkLocationWizard)"
	New-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Network\NewNetworkWindowOff" -Force -ErrorAction SilentlyContinue | Out-Null

	<#
		.Change system disk volume label
		.更改系统盘卷标
	#>
	if (Deploy_Sync -Mark "SyncVolumeName") {
		System_Disk_Label -VolumeName $Global:UniqueID
	} else {
		System_Disk_Label -VolumeName "OS"
	}

	<#
		.Add exclusion to firewall
		.向防火墙添加排除
	#>
	if (Deploy_Sync -Mark "ExcludeDefender") {
		Firewall_Exclusion
	}

	<#
	 	.Desktop right-click menu
		.桌面右键菜单
	#>
	if (Deploy_Sync -Mark "DesktopMenu") {
		Personalise_Menu -Del

		if (Deploy_Sync -Mark "DesktopMenuShift") {
			Personalise_Menu -Add -Hide
		} else {
			Personalise_Menu -Add
		}
	} else {
		Personalise_Menu -Del
	}

	<#
		.Set system language, keyboard, etc.
		.设置系统语言、键盘等
	#>
	Language_Setting

	<#
		.Refresh icon cache
		.刷新图标缓存
	#>
	RefreshIconCache

	<#
		.Set folder and file permissions
		.设置文件夹、文件权限
	#>
	Permissions

	<#
		.Install fonts
		.安装字体
	#>
	Install_Fonts_Process

	<#
		.Unzip the compressed package
		.解压压缩包
	#>
	Unzip_Compressed_Package

	<#
		.After completing the prerequisite deployment, determine whether to restart the computer
		.完成先决条件部署后，判断是否重启计算机
	#>
	Write-Host "   $($lang.Reboot)"
	if (Deploy_Sync -Mark "PrerequisitesReboot") {
		Write-Host "   $($lang.Operable)".PadRight(28) -NoNewline
		$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
		if (-not (Test-Path $regPath)) {
			New-Item -Path $regPath -Force -ErrorAction SilentlyContinue | Out-Null
		}

		$regValue = "cmd /c start /min """" powershell -Command ""Start-Process 'Powershell' -Argument '-ExecutionPolicy ByPass -File ""$((Convert-Path -Path "$($PSScriptRoot)\..\..\Engine.ps1" -ErrorAction SilentlyContinue))"" -Functions \""FirstExperience_Deploy -Quit\""' -WindowStyle Minimized -Verb RunAs"""
		New-ItemProperty -Path $regPath -Name "$($Global:UniqueID)" -Value $regValue -PropertyType STRING -Force | Out-Null

		Restart-Computer -Force
		Write-Host "   $($lang.Done)`n" -ForegroundColor Green
	} else {
		Write-Host "   $($lang.Inoperable)"
		FirstExperience_Deploy
	}
}


<#
	.First Deployment
	.首次部署
#>
Function FirstExperience_Deploy
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title $($lang.FirstDeployment)
	Write-Host "   $($lang.FirstDeployment)`n   ---------------------------------------------------"

	<#
		.Prerequisite deployment rules
		.先决部署规则
	#>
	$Global:MarkRebootComputer = $False
	$FlagsClearSolutionsRule = $False

	if ($Reboot) {
		$Global:MarkRebootComputer = $True
	}
	if (Deploy_Sync -Mark "FirstExperienceReboot") {
		$Global:MarkRebootComputer = $True
	}

	if (Deploy_Sync -Mark "ClearSolutions") {
		$FlagsClearSolutionsRule = $True
	}
	if (Deploy_Sync -Mark "ClearEngine") {
		$FlagsClearSolutionsRule = $True
	}

	<#
		.Pop up the main interface
		.弹出主界面
	#>
	Write-Host "`n   $($lang.FirstDeploymentPopup)"
	if ($FlagsClearSolutionsRule) {
		Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
	} else {
		if (Deploy_Sync -Mark "PopupEngine") {
			Write-Host "   $($lang.Operable)`n" -ForegroundColor Green
			Start-Process powershell -ArgumentList "-file $((Convert-Path -Path "$($PSScriptRoot)\..\..\Engine.ps1" -ErrorAction SilentlyContinue))"
		} else {
			Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
		}
	}

	<#
		.Create Shortcut
		.创建快捷方式
	#>
	Shortcut_Process

	<#
		.Allow the first pre-experience, as planned
		.允许首次预体验，按计划
	#>
	Write-Host "`n   $($lang.FirstExpFinishOnDemand)"
	if (Deploy_Sync -Mark "FirstPreExperience")
	{
		Write-Host "   $($lang.Operable)" -ForegroundColor Green

		<#
			.Create a restore point
			.创建还原点
		#>
#		Restore_Point_Create

		<#
			.Change user directory
			.更改用户目录
		#>
#		Change_Location_Set_Path -KnownFolder 'Desktop'   -NewFolder "D:\Yi\Desktop"
#		Change_Location_Set_Path -KnownFolder 'Documents' -NewFolder "D:\Yi\Documents"
#		Change_Location_Set_Path -KnownFolder 'Downloads' -NewFolder "D:\Yi\Downloads"
#		Change_Location_Set_Path -KnownFolder 'Music'     -NewFolder "D:\Yi\Music"
#		Change_Location_Set_Path -KnownFolder 'Pictures'  -NewFolder "D:\Yi\Pictures"
#		Change_Location_Set_Path -KnownFolder 'Videos'    -NewFolder "D:\Yi\Videos"

		<#
			.Activation Kit
			.激活工具
		#>
		Install_Process -appname $Global:ActivateApp[0][0] -status "Enabled" -act $Global:ActivateApp[0][2] -mode $Global:ActivateApp[0][3] -todisk $Global:ActivateApp[0][4] -structure $Global:ActivateApp[0][5] -pwd $Global:ActivateApp[0][6] -url $Global:ActivateApp[0][7] -urlAMD64 $Global:ActivateApp[0][8] -urlarm64 $Global:ActivateApp[0][9] -filename $Global:ActivateApp[0][10] -param $Global:ActivateApp[0][11] -Before $Global:ActivateApp[0][12] -After $Global:ActivateApp[0][13]

		<#
			.Desktop icons
			.桌面图标
		#>
		Desktop_ICON_ThisPC -AllUsers           # 此电脑              | This computer
#		Desktop_ICON_Recycle_Bin -AllUsers      # 回收站              | Recycle Bin
		Desktop_ICON_User -AllUsers             # 用户                | User
#		Desktop_ICON_Control_Panel -AllUsers    # 控制面板            | Control Panel
#		Desktop_ICON_Network -AllUsers          # 网络                | Network
#		Desktop_ICON_God_Mode                   # 上帝模式            | God Mode
#		Desktop_ICON_IE -AllUsers               # Internet Explorer
		Desktop_Reset_Reorganize                # 重新排列桌面图标     | Rearrange desktop icons

		<#
			.优化电源前判断计算机类型
			.Determine the computer type before optimizing the power supply
		#>
		$NoSelectPowerSupply = @(8, 9, 10, 11, 14)
		Get-CimInstance -ClassName Win32_SystemEnclosure | ForEach-Object {
			if ($NoSelectPowerSupply -notcontains $_.SecurityStatus) {
				Hibernation -Disable            # Disable, Enabled            | $lang.Hibernation
				Power_Supply -Optimize          # Optimize, Restore           | $lang.PowerSupply
			}
		}

		<#
			.优化系统
			.Optimize the system
		#>
		if (IsWin11) {
			Win11_TPM_Setup
			Win11_TPM_Update
		}
		Keep_Space -Disable             # Disable, Enabled             | $lang.KeepSpace
		App_Restart_Screen -Disable     # Disable, Enabled             | $lang.AppRestartScreen
		Numlock -Enabled                # Disable, Enabled             | $lang.Numlock
		UAC_Never -Disable              # Disable, Enabled             | $lang.UAC $lang.UACNever
		Smart_Screen_Apps -Disable      # Disable, Enabled             | $lang.SmartScreenApps
		Smart_Screen_Safe -Disable      # Disable, Enabled             | $lang.SmartScreenSafe
		Easy_Access_Keyboard -Disable   # Disable, Enabled             | $lang.EasyAccessKeyboard
		Maintain -Disable               # Disable, Enabled             | $lang.Maintain
		Experience -Disable             # Disable, Enabled             | $lang.Experience
		Defragmentation -Disable        # Disable, Enabled             | $lang.Defragmentation
		Compatibility -Disable          # Disable, Enabled             | $lang.Compatibility
		Animation_Effects -Optimize     # Optimize, Restore            | $lang.AnimationEffects
		Error_Recovery -Disable         # Disable, Enabled             | $lang.ErrorRecovery
#		DEPPAE -Disable                 # Disable, Enabled             | $lang.DEP
		Power_Failure -Disable          # Disable, Enabled             | $lang.PowerFailure
		Scheduled_Tasks -Disable        # Disable, Restore             | $lang.ScheduledTasks
		Password_Unlimited -Disable     # Disable, Enabled             | $lang.PwdUnlimited
		RAM -Disable                    # Disable, Enabled             | $lang.RAM
		Storage_Sense -Disable          # Disable, Enabled             | $lang.StorageSense
		Delivery -Disable               # Disable, Enabled             | $lang.Delivery
		Photo_Preview -Enabled          # Disable, Enabled             | $lang.PhotoPreview
		Protected -Disable              # Disable, Enabled             | $lang.Protected
		Error_Reporting -Disable        # Disable, Enabled             | $lang.ErrorReporting
#		F8_Boot_Menu -Disable           # Disable, Enabled             | $lang.F8BootMenu
		SSD -Disable                    # Disable, Enabled             | $lang.OptSSD
		Memory_Compression -Disable     # Disable, Enabled             | $lang.MemoryCompression
		Prelaunch -Disable              # Disable, Enabled             | $lang.Prelaunch

		<#
			.网络优化
		#>
#		IEProxy                               # Disable, Enabled             | $lang.IEProxy
		Auto_Detect -Disable                  # Disable, Enabled             | $lang.IEAutoSet
#		Network_Discovery -Disable            # Disable, Enabled             | $lang.NetworkDiscovery
#		Network_Adapters_Save_Power -Disable  # Disable, Enabled             | $lang.NetworkAdaptersPM
#		IPv6_Component -Disable               # Disable, Enabled             | $lang.IPv6Component
		QOS -Disable                          # Disable, Enabled             | $lang.QOS
		Network_Tuning -Disable               # Disable, Enabled             | $lang.NetworkTuning
		ECN -Disable                          # Disable, Enabled             | $lang.ECN

		<#
			.Resource manager
			.资源管理器
		#>
#		Separate_Process -Disable       # Disable, Enabled             | $lang.SeparateProcess
#		Restart_Apps -Disable           # Disable, Enabled             | $lang.RestartApps
#		Check_Boxes -Disable            # Disable, Enabled             | $lang.CheckBoxes
#		Thumbnail_Cache -Disable        # Disable, Enabled             | $lang.ThumbnailCache
		Explorer_Open_To -ThisPC        # Disable, Enabled             | $lang.ExplorerToThisPC
		Aero_Shake -Disable -AllUser    # Disable, Enabled             | $lang.AeroShake
		File_Extensions -Show           # Show, Hide                   | $lang.FileExtensions
		Safety_Warnings -Disable        # Disable, Enabled             | $lang.SafetyWarnings
		File_Transfer_Dialog -Detailed  # Detailed, Simple             | $lang.FileTransfer
		Nav_Show_All -Enabled            # Disable, Enabled            | $lang.NavShowAll
#		Autoplay -Disable               # Disable, Enabled             | $lang.Autoplay
#		Autorun -Disable                # Disable, Enabled             | $lang.Autorun
		Quick_Access_Files -Hide        # Show, Hide                   | $lang.QuickAccessFiles
		Quick_Access_Folders -Hide      # Show, Hide                   | $lang.QuickAccessFolders
		Shortcut_Arrow -Disable         # Disable, Enabled             | $lang.ShortcutArrow

		Desktop_Icon_ThisPC -Disable    # Disable, Enabled             | $lang.LocationDesktop
		Desktop_Icon_Document -Disable  # Disable, Enabled             | $lang.LocationDocuments
		Desktop_Icon_Download -Disable  # Disable, Enabled             | $lang.LocationDownloads
		Desktop_Icon_Music -Disable     # Disable, Enabled             | $lang.LocationMusic
		Desktop_Icon_Picture -Disable   # Disable, Enabled             | $lang.LocationPictures
		Desktop_Icon_Video -Disable     # Disable, Enabled             | $lang.LocationVideos
		if (-not (IsWin11)) {
			Desktop_Icon_3D -Disable    # Disable, Enabled             | $lang.Location3D
		}

		<#
			.Right click menu
			.右键菜单
		#>
		if (IsWin11) {
			Win11_Context_Menu -Modern        # Modern, Classic             | $lang.ClassicMenu
		}
		Take_Ownership -Remove                # Del $lang.AddOwnership
		Take_Ownership -Add                   # Add $lang.AddOwnership
		File_Selection_Restrictions -Disable  # Disable, Enabled             | $lang.MultipleIncrease
		Copy_Path -Add                        # Remove, Add                 | $lang.CopyPath

		<#
			.Start menu and taskbar
			.开始菜单和任务栏
		#>
		if (IsWin11) {
#			Taskbar_Alignment -Leaf         # Leaf, Center                | $lang.TaskbarAlignment
			Taskbar_Widgets -Hide           # Show, Hide                  | $lang.TaskbarWidgets
		}
		Teams_Autostarting -Disable         # Disable, Enabled             | $lang.TeamsAutostarting
		Teams_Taskbar_Chat -Hide            # Show, Hide                  | $lang.TeamsTaskbarChat
		Bing_Search -Disable                # Disable, Enabled             | $lang.BingSearch
		Taskbar_Suggested_Content -Hide     # Show, Hide                  | $lang.TaskbarSuggestedContent
		Suggestions_Device -Disable         # Disable, Enabled             | $lang.SuggestionsDevice
		Search_Box -SearchIcon              # Hide, SearchIcon, SearchBox | $lang.SearchBox
		Merge_Taskbar_Never -Enabled         # Disable, Enabled             | $lang.MergeTaskbarNever
		Notification_Center_Always -Enabled  # Disable, Enabled             | $lang.NotificationAlways
		Cortana -Disable                    # Disable, Enabled             | $lang.Cortana
		Task_View -Hide                     # Show, Hide                  | $lang.TaskView

		<#
			.Game Bar
		#>
		XboxGameBar -Disable            # Disable, Enabled             | $lang.XboxGameBar
		XboxGameBarTips -Disable        # Disable, Enabled             | $lang.XboxGameBarTips
		XboxGameMode -Disable           # Disable, Enabled             | $lang.XboxGameMode
		XboxGameDVR -Disable            # Disable, Restore            | $lang.XboxGameDVR

		<#
			.Privacy
			.隐私
		#>
		Privacy_Voice_Typing -Disable            # Disable, Enabled     | $lang.PrivacyVoiceTyping
		Privacy_Contacts_Speech -Disable         # Disable, Enabled     | $lang.PrivacyContactsSpeech
		Privacy_Language_Opt_Out -Disable        # Disable, Enabled     | $lang.PrivacyLanguageOptOut
		Privacy_Ads -Disable                     # Disable, Enabled     | $lang.PrivacyAds
		Privacy_Locaton_Aware -Disable           # Disable, Enabled     | $lang.PrivacyLocatonAware
		Privacy_Set_Sync -Disable                # Disable, Enabled     | $lang.PrivacySetSync
		Privacy_Inking_Typing -Disable           # Disable, Enabled     | $lang.PrivacyInkingTyping
		Privacy_Share_Unpaired_Devices -Disable  # Disable, Enabled     | $lang.PrivacyShareUnpairedDevices
		Privacy_Location_Sensor -Disable         # Disable, Enabled     | $lang.PrivacyLocationSensor
		Privacy_Biometrics -Disable              # Disable, Enabled     | $lang.PrivacyBiometrics
		Privacy_Compatible_Telemetry -Disable    # Disable, Enabled     | $lang.PrivacyCompatibleTelemetry
		Privacy_Diagnostic_Data -Disable         # Disable, Enabled     | $lang.PrivacyDiagnosticData
		Privacy_Tailored_Experiences -Disable    # Disable, Enabled     | $lang.TailoredExperiences
		Privacy_Feedback_Notifications -Disable  # Disable, Enabled     | $lang.PrivacyFeedbackNotifications
		Privacy_Location_Tracking -Disable       # Disable, Enabled     | $lang.PrivacyLocationTracking
		Privacy_Experiences_Telemetry -Disable   # Disable, Enabled     | $lang.ExperiencesTelemetry
		Privacy_Background_Access -Disable       # Disable, Enabled     | $lang.PrivacyBackgroundAccess
		if (-not (IsWin11)) {
			Timeline_Time -Disable               # Disable, Enabled     | $lang.TimelineTime
			Collect_Activity -Disable            # Disable, Enabled     | $lang.CollectActivity
		}

		<#
			.Paging size
			.分页大小
		#>
		System_Disk_Page_Size -Enabled -size 8   # 8, 16  | $lang.PagingSize 8G and 16G

		<#
			.Notification Center
			.通知中心
		#>
		Notification_Center -Part       # Full, Part, Restore | $lang.Notification $lang.Full

		<#
			.Other
			.其它
		#>
#		Remote_Desktop                  # $lang.StRemote
#		SMB_File_Share                  # $lang.StSMB

		<#
			.Clean
			.清理
		#>
		Send_To                         # $lang.SendTo
		Cleanup_System_Log              # $lang.Logs
		Cleanup_Disk                    # $lang.DiskCleanup
#		Cleanup_SxS                     # $lang.SxS

		<#
			.Optimize service
			.优化服务
		#>
		$PreServices = @(
#			"Spooler"
			"DPS"
			"WdiSystemHost"
			"WdiServiceHost"
			"diagnosticshub.standardcollector.service"
			"dmwappushservice"
			"lfsvc"
			"MapsBroker"
			"NetTcpPortSharing"
			"RemoteAccess"
			"RemoteRegistry"
			"SharedAccess"
			"TrkWks"
			"WbioSrvc"
			"WlanSvc"
			"WMPNetworkSvc"
			"WSearch"
			"XblAuthManager"
			"XblGameSave"
			"XboxNetApiSvc"
		)

		foreach ($item in $PreServices) {
			Write-Host "   $($lang.Close) $item"
			Get-Service -Name $item | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
			Stop-Service $item -Force -NoWait -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   $($lang.Done)`n" -ForegroundColor Green
		}

		<#
			.Turn off Microsoft Defender Antivirus
			.关闭 Microsoft Defender 防病毒
		#>
#		Install_Process -appname "$($lang.Close) $($lang.DefenderControlTips)" -status "Enabled" -act "Install" -mode "Fast" -todisk $PSScriptRoot -structure "..\..\..\20\dControl" -pwd "sordum" -url "https://www.sordum.org/files/download/d-control/dControl.zip" -urlAMD64 "" -urlarm64 "" -filename "dfControl*" -param "" -Before "" -After ""


		<#
			.Turn off Microsoft Defender firewall
			.关闭 Microsoft Defender 防火墙
		#>
#		Install_Process -appname "$($lang.Close) $($lang.FabTips)" -status "Enabled" -act "Install" -mode "Fast" -todisk $PSScriptRoot -structure "..\..\..\20" -pwd "" -url "https://www.sordum.org/files/download/firewall-app-blocker/fab.zip" -urlAMD64 "" -urlarm64 "" -filename "fab*" -param "/S 3" -Before "" -After ""

		<#
			.Turn off Windows Update
			.关闭 Windows 更新
		#>
#		Install_Process -appname "$($lang.Close) $($lang.WubTips)" -status "Enabled" -act "Install" -mode "Fast" -todisk $PSScriptRoot -structure "..\..\..\20" -pwd "" -url "https://www.sordum.org/files/download/windows-update-blocker/Wub.zip" -urlAMD64 "" -urlarm64 "" -filename "Wub*" -param "/D /P" -Before "" -After ""
#		Update_Auto_Download -Disable
#		Update_Policies -Disable
#		Update_Auto_Drive -Disable
#		Update_Are_Available -Disable
#		Win11TPM -Disable

		<#
			.Delete OneDrive
			.删除 OneDrive
		#>
#		OneDrive_Del        # Remove OneDrive

		<#
			.Delete Edge
			.删除 Edge
		#>
#		Edge_Del             # Remove Edge

		<#
			.Delete UWP app
			.删除 UWP 应用
		#>
		[Windows.Management.Deployment.PackageManager, Windows.Web, ContentType = WindowsRuntime]::new().FindPackages() | Select-Object -ExpandProperty Id -Property DisplayName | Where-Object -FilterScript {
			($_.Name -in (Get-AppxPackage -PackageTypeFilter Bundle -AllUsers).Name) -and ($null -ne $_.DisplayName)} | ForEach-Object {
			if (($AppsUncheck + $AppsExcluded) -Contains $_.Name) {
			} else {
				Write-Host "   $($_.Name)"
				Write-host "   $($lang.Delete)".PadRight(22) -NoNewline
				Get-AppXProvisionedPackage -Online | Where-Object DisplayName -Like "$($_.Name)" | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction SilentlyContinue | Out-Null
				Get-AppxPackage -Name "$($_.Name)" | Remove-AppxPackage | Out-Null
				Write-Host "$($lang.Done)`n" -ForegroundColor Green
			}
		}
		Write-Host ""

		<#
			.Install prerequisite software
			.安装必备软件
		#>
		for ($i=0; $i -lt $Global:PrerequisiteApp.Count; $i++) {
			Install_Process -appname $Global:PrerequisiteApp[$i][0] -status $Global:PrerequisiteApp[$i][1] -act $Global:PrerequisiteApp[$i][2] -mode $Global:PrerequisiteApp[$i][3] -todisk $Global:PrerequisiteApp[$i][4] -structure $Global:PrerequisiteApp[$i][5] -pwd $Global:PrerequisiteApp[$i][6] -url $Global:PrerequisiteApp[$i][7] -urlAMD64 $Global:PrerequisiteApp[$i][8] -urlarm64 $Global:PrerequisiteApp[$i][9] -filename $Global:PrerequisiteApp[$i][10] -param $Global:PrerequisiteApp[$i][11] -Before $Global:PrerequisiteApp[$i][12] -After $Global:PrerequisiteApp[$i][13]
		}

		<#
			.Install common software
			.安装常用软件
		#>
#		Most_Used_Software -Force        # $lang.MostUsedSoftware

		<#
			.Wait for the queue to finish
			.等待队列运行结束
		#>
		Wait_Process_End
	} else {
		Write-Host "   $($lang.Inoperable)" -ForegroundColor Red
	}

	Write-Host "`n   $($lang.FirstDeployment)"
	Deploy_Guide

	<#
		.Search for Bat and PS1
		.搜索 Bat、PS1
	#>
	write-host "`n   $($lang.DiskSearch)"

	<#
		.Search for local deployment: Bat
		.搜索本地部署：Bat
	#>
	Get-ChildItem –Path "$($PSScriptRoot)\..\..\Deploy\bat" -Filter "*.bat" -ErrorAction SilentlyContinue | foreach-Object {
		write-host	"   - $($lang.DiskSearchFind -f $($_.Fullname))`n" -ForegroundColor Green
		Start-Process -FilePath "$($_.Fullname)"  -wait -WindowStyle Minimized
	}

	<#
		.Search for local deployment: ps1
		.搜索本地部署：ps1
	#>
	Get-ChildItem –Path "$($PSScriptRoot)\..\..\Deploy\ps1" -Filter "*.ps1" -ErrorAction SilentlyContinue | foreach-Object {
		write-host	"   - $($lang.DiskSearchFind -f $($_.Fullname))`n" -ForegroundColor Green
		Start-Process "powershell" -ArgumentList "-ExecutionPolicy ByPass -file ""$($_.Fullname)""" -Wait -WindowStyle Minimized
	}

	<#
		.Full plan, search by rule: Bat
		.全盘计划，按规则搜索：Bat
	#>
	$SearchBatFile = @(
		"$($Global:UniqueID).bat"
		"$($Global:UniqueID)\$($Global:UniqueID).bat"
		"$($Global:UniqueID)\Deploy\Bat\$($Global:UniqueID).bat"
	)
	foreach ($item in $SearchBatFile) {
		Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
			$TempFilePath = Join-Path -Path "$($_.Root)" -ChildPath "$($item)" -ErrorAction SilentlyContinue

			Write-Host "   - $($TempFilePath)"
			if (Test-Path $TempFilePath -PathType Leaf) {
				write-host	"   - $($lang.DiskSearchFind -f $($TempFilePath))`n" -ForegroundColor Gray
				Start-Process -FilePath "$($TempFilePath)" -wait -WindowStyle Minimized
			}
		}
	}

	<#
		.Full plan, search by rule: ps1
		.全盘计划，按规则搜索：ps1
	#>
	$SearchPSFile = @(
		"$($Global:UniqueID).ps1"
		"$($Global:UniqueID)\$($Global:UniqueID).ps1"
		"$($Global:UniqueID)\Deploy\PS\$($Global:UniqueID).bat"
	)
	foreach ($item in $SearchPSFile) {
		Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
			$TempFilePath = Join-Path -Path "$($_.Root)" -ChildPath "$($item)" -ErrorAction SilentlyContinue

			Write-Host "   - $TempFilePath"
			if (Test-Path $TempFilePath -PathType Leaf) {
				write-host	"   - $($lang.DiskSearchFind -f $($TempFilePath))`n" -ForegroundColor Gray
				Start-Process "powershell" -ArgumentList "-ExecutionPolicy ByPass -file ""$TempFilePath""" -Wait -WindowStyle Minimized
			}
		}
	}

	<#
		.Recovery PowerShell strategy
		.恢复 PowerShell 策略
	#>
	if (Deploy_Sync -Mark "ResetExecutionPolicy") {
		Set-ExecutionPolicy -ExecutionPolicy Restricted -Force -ErrorAction SilentlyContinue
	}

	<#
		.Clean up the solution
		.清理解决方案
	#>
	if (Deploy_Sync -Mark "ClearSolutions") {
		Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
		Remove_Tree -Path "$($Global:UniqueMainFolder)"

		<#
			.In order to prevent the solution from being unable to be cleaned up, the next time you log in, execute it again
			.为了防止无法清理解决方案，下次登录时，再次执行
		#>
		Write-Host "   $($lang.NextDelete)`n" -ForegroundColor Green
		$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
		$regKey = "Clear $($Global:UniqueID) Folder"
		$regValue = "cmd.exe /c rd /s /q ""$($Global:UniqueMainFolder)"""
		if (Test-Path $regPath) {
			New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
		} else {
			New-Item -Path $regPath -Force | Out-Null
			New-ItemProperty -Path $regPath -Name $regKey -Value $regValue -PropertyType STRING -Force | Out-Null
		}
	}

	<#
		.Clean up the main engine
		.清理主引擎
	#>
	if (Deploy_Sync -Mark "ClearEngine") {
		Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
		Remove_Tree -Path "$($Global:MainFolder)"
	}

	<#
		.Clean up deployment configuration
		.清理部署配置
	#>
	Remove_Tree -Path "$($PSScriptRoot)\..\..\Deploy"

	if ($Global:MarkRebootComputer) {
		<#
			.Reboot Computer
			.重启计算机
		#>
		Restart-Computer -Force
	}
}

<#
	.Change system disk volume label
	.更改系统盘卷标
#>
Function System_Disk_Label
{
	param
	(
		[string]$VolumeName
	)

	Write-Host "`n   $($lang.VolumeLabel -f $VolumeName)"
	(New-Object -ComObject "Shell.Application").NameSpace($env:SystemDrive).Self.Name = $VolumeName
}

<#
	.Add exclusion to firewall
	.向防火墙添加排除
#>
Function Firewall_Exclusion
{
	$ExcludeMpPreference = @(
		(Convert-Path -Path "$($PSScriptRoot)\..\..\.." -ErrorAction SilentlyContinue)
	)

	Write-Host "`n   $($lang.AddTo) $($lang.Exclude)"
	foreach ($item in $ExcludeMpPreference) {
		Write-Host "   * $($item)"
		Add-MpPreference -ExclusionPath (Convert-Path -Path $item -ErrorAction SilentlyContinue) -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   $($lang.Done)`n" -ForegroundColor Green
	}
}

Function Repair_Home_Directory
{
	Write-Host "`n   $($lang.FixMainFolder -f $($Global:UniqueID))`n"
	$DeskEdit = "$(Get_Arch_Path -Path "$($PSScriptRoot)\..\..\AIO\DeskEdit")\DeskEdit.exe"
	if (Test-Path $DeskEdit -PathType Leaf) {
		Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($Global:UniqueMainFolder)"" /S=.ShellClassInfo /L=LocalizedResourceName=""$($Global:UniqueID)'s Solutions""" -wait

		$IconPath = Convert-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -ErrorAction SilentlyContinue
		if (Test-Path -Path $IconPath -PathType Leaf) {
			Start-Process -FilePath $DeskEdit -ArgumentList "/F=""$($Global:UniqueMainFolder)"" /S=.ShellClassInfo /L=IconResource=""$($IconPath),0"""
		}
		Write-Host "   $($lang.Done)`n" -ForegroundColor Green
	} else {
		Write-Host "   $($lang.Inoperable)`n" -ForegroundColor Red
	}
}