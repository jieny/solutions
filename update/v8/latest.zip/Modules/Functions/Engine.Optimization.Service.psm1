﻿<#
 .Synopsis
  Optimize service

 .Description
  Optimize service Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Optimize service
	.优化服务
#>
$Services = @(
	"Spooler"
	"DPS"
	"WdiSystemHost"
	"WdiServiceHost"
	"diagnosticshub.standardcollector.service"
	"dmwappushservice"
	"lfsvc"
	"MapsBroker"
	"NetTcpPortSharing"
	"RemoteAccess"
	"RemoteRegistry"
	"SharedAccess"
	"TrkWks"
	"WbioSrvc"
	"WlanSvc"
	"WMPNetworkSvc"
	"WSearch"
	"XblAuthManager"
	"XblGameSave"
	"XboxNetApiSvc"
)

<#
	.Optimize the service user interface
	.优化服务用户界面
#>
Function OptimizationService
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title "$($lang.Optimize) $($lang.Service)"
	Write-Host "   $($lang.Optimize) $($lang.Service)`n   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIServerCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIServer.Close()
	}
	$GUIServerRestoreClick = {
		$GUIServer.Hide()
		$GUIServerPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Checked) {
					Write-Host "   $($_.Text)"
					Write-Host "   - $($lang.SettingTo -f $($lang.Auto))" -ForegroundColor Green
					Get-Service -Name $_.Tag | Set-Service -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
					if ($GUIServerStatus.Checked) {
						Write-Host "   - $($lang.Enable)" -ForegroundColor Green
						Start-Service $_.Tag -ErrorAction SilentlyContinue | Out-Null
					}
					Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
				}
			}
		}
		$GUIServer.Close()
	}
	$GUIServerOKClick = {
		$GUIServer.Hide()
		$GUIServerPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Checked) {
					Write-Host "   $($_.Text)"
					Write-Host "   - $($lang.SettingTo -f $($lang.Disable))" -ForegroundColor Green
					Get-Service -Name $_.Tag | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
					if ($GUIServerStatus.Checked) {
						Write-Host "   - $($lang.Close)" -ForegroundColor Green
						Stop-Service $_.Tag -Force -NoWait -ErrorAction SilentlyContinue | Out-Null
					}
					Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
				}
			}
		}
		$GUIServer.Close()
	}
	$GUIServer         = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 550
		Text           = "$($lang.Optimize) $($lang.Service)"
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false 
		BackColor      = "#ffffff"
	}
	$GUIServerPanel    = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 510
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 1
	}
	$GUIServerStatus   = New-Object System.Windows.Forms.CheckBox -Property @{
		UseVisualStyleBackColor = $True
		Location       = "11,520"
		Height         = 36
		Width          = 480
		Text           = $lang.Status
		Checked        = $true
	}
	$GUIServerReset    = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,555"
		Height         = 36
		Width          = 515
		add_Click      = $GUIServerRestoreClick
		Text           = $lang.Enable
	}
	$GUIServerOK       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,595"
		Height         = 36
		Width          = 515
		add_Click      = $GUIServerOKClick
		Text           = $lang.Disable
	}
	$GUIServerCanel    = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,635"
		Height         = 36
		Width          = 515
		add_Click      = $GUIServerCanelClick
		Text           = $lang.Cancel
	}
	$GUIServer.controls.AddRange((
		$GUIServerPanel,
		$GUIServerStatus,
		$GUIServerReset,
		$GUIServerOK,
		$GUIServerCanel
	))

	$ServiceUncheck = @(
		"Spooler"
		"WbioSrvc"
		"WlanSvc"
		"WSearch"
	)

	for ($i=0; $i -lt $Services.Count; $i++) {
		$CheckBox   = New-Object System.Windows.Forms.CheckBox -Property @{
			Height  = 28
			Width   = 495
			Text    = $($lang.$($Services[$i]))
			Tag     = $Services[$i]
			Checked = $true
		}

		if ($ServiceUncheck -Contains $Services[$i]) {
			$CheckBox.Checked = $false
		}
		$GUIServerPanel.controls.AddRange($CheckBox)
	}

	$GUIServerAllSelClick = {
		$GUIServerPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIServerAllClearClick = {
		$GUIServerPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIServerMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIServerMenu.Items.Add($lang.AllSel).add_Click($GUIServerAllSelClick)
	$GUIServerMenu.Items.Add($lang.AllClear).add_Click($GUIServerAllClearClick)
	$GUIServer.ContextMenuStrip = $GUIServerMenu

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIServer.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIServer.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$GUIServer.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$GUIServer.FormBorderStyle = 'Fixed3D'
	$GUIServer.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

Export-ModuleMember -Function * -Alias *