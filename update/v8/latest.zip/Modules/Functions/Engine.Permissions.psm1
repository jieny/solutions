﻿<#
	.Get all the directories under the directory and hide them
	.获取目录下的所有目录，并隐藏
#>
$GroupFolderHide = @(
	"20"
	"30"
	"40"
	"50"
	"60"
)

<#
	.Only hide the directory, not under the directory
	.只隐藏目录，不含目录下的
#>
$GroupFile = @(
	"Engine"
)

<#
	.Hidden files
	.隐藏文件
#>
$GroupFileAuthority = @(
	"Modules\langpacks\en-US\instl.ps1"
	"Modules\langpacks\zh-CN\instl.ps1"
	"Modules\langpacks\zh-TW\instl.ps1"
	"Modules\langpacks\ja-JP\instl.ps1"
	"Modules\langpacks\ko-KR\instl.ps1"
	"Modules\langpacks\de-DE\instl.ps1"
)

<#
	.Handling hidden tasks
	.处理隐藏任务
#>
Function Permissions
{
	Write-Host "`n   $($lang.Authority)`n"
	foreach ($item in $GroupFolderHide) {
		Get-ChildItem "$PSScriptRoot\..\..\..\$item" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
			Set-ItemProperty -Path $_.FullName -Name Attributes -Value Hidden -ErrorAction SilentlyContinue
		}
	}

	foreach ($item in $GroupFile) {
		Set-ItemProperty -Path "$PSScriptRoot\..\..\..\$item" -Name Attributes -Value Hidden -ErrorAction SilentlyContinue
	}

	foreach ($item in $GroupFileAuthority) {
		Set-ItemProperty -Path "$PSScriptRoot\..\..\..\$item" -Name Attributes -Value "ReadOnly" -ErrorAction SilentlyContinue
	}
}