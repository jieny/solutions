﻿<#
	.LOGO
#>
Function Logo
{
	param
	(
		$Title
	)
	Clear-Host
	$Host.UI.RawUI.WindowTitle = "$($Global:UniqueID)'s Solutions | $($Title)"
	Write-Host "`n   Author: $($Global:UniqueID) ( $($Global:AuthorURL) )

   From: $($Global:UniqueID)'s Solutions
   buildstring: $((Get-Module -Name Engine).Version.ToString()).bs_release.220201-1208`n"
}

<#
	.主界面
	.Main interface
#>
Function Mainpage
{
	Logo -Title $($lang.Mainname)
	Write-Host "   $($lang.Mainname)`n   ---------------------------------------------------"

	write-host "   1. $($lang.Update)
   2. $($lang.FirstExperience)
   3. $($lang.RestorePoint)
   4. $($lang.Delete) $($lang.Mainname)" -ForegroundColor Green

	write-host  "`n   [*] A. $($lang.Oneclick) BCDEFGHIJ"

	Get-Command -CommandType Function | ForEach-Object {
		if ($_ -like "Activate") {
			Write-Host "       B. $($lang.ActivationKit)"
		}
	}

	write-host  "       C. $($lang.LocationUserFolder)
       D. $($lang.DeskIcon)
       E. $($lang.Optimize) $($lang.System)
       F. $($lang.Optimize) $($lang.Service)
       G. $($lang.Instl) $($lang.Necessary)
       H. $($lang.Instl) $($lang.MostUsedSoftware)
       I. $($lang.Delete) $($lang.ComesWith)
       J. $($lang.Delete) $($lang.UninstallUWP)


   L. $($lang.SwitchLanguage)
   R. $($lang.RefreshModules)
   Q. $($lang.Exit)`n"

	$select = Read-Host "   $($lang.Choose)"
	switch ($select)
	{
		"1" {
			Update
			ToMainpage -wait 2
		}
		"2" {
			FirstExperience
			ToMainpage -wait 2
		}
		"3" {
			Restore_Point_Create_UI
			ToMainpage -wait 2
		}
		"4" {
			Uninstall
			ToMainpage -wait 2
		}
		"a" {
			if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Engine" -Name "RestorePointPrompt" -ErrorAction SilentlyContinue) {
				$GetRestorePointPrompt = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Engine" -Name "RestorePointPrompt"
				switch ($GetRestorePointPrompt) {
					"False" { Restore_Point_Create_UI }
				}
			} else {
				Restore_Point_Create_UI
			}

			Get-Command -CommandType Function | ForEach-Object {
				if ($_ -like "Activate") {
					Invoke-Expression -Command "Activate -Force"
				}
			}

			Change_Location -Force
			Desktop -Force
			Optimization_System_UI -Force
			Optimization_Service_UI -Force
			Prerequisite -Force
			System_Software_UI -Force
			UWP_Uninstall -Force
			Most_Used_Software -Force
			Wait_Process_End
			ToMainpage -wait 4
		}
		"b" {
			Get-Command -CommandType Function | ForEach-Object {
				if ($_ -like "Activate") {
					Invoke-Expression -Command Activate
				}
			}
		}
		"c" { Change_Location }
		"d" { Desktop }
		"e" { Optimization_System_UI }
		"f" { Optimization_Service_UI }
		"g" { Prerequisite }
		"h" { Most_Used_Software }
		"i" { System_Software_UI }
		"j" { UWP_Uninstall }
		"l" {
			Language -Reset
			Mainpage
		}
		"r" {
			Modules_Refresh
		}
		"q" {
			Modules_Import
			exit
		}
		default { Mainpage }
	}
}

<#
	.返回到主界面
	.Return to the main interface
#>
Function ToMainpage
{
	param
	(
		[int]$wait
	)

	if ($Global:QUIT) {
		$Global:QUIT = $False
		Write-Host $($lang.ToQuit -f $wait) -ForegroundColor Red
		Start-Sleep -s $wait
		Modules_Import
		exit
	} else {
		Write-Host $($lang.ToMsg -f $wait) -ForegroundColor Red
		Start-Sleep -s $wait
		Mainpage
	}
}