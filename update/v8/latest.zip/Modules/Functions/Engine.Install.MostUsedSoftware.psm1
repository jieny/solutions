﻿<#
	.Install common software user interface
	.安装常用软件用户界面
#>
Function Most_Used_Software
{
	param
	(
		[switch]$Quit,
		[switch]$New
	)
	if ($Quit) { $Global:QUIT = $true }

	$DynamicInstl = "$PSScriptRoot\..\langpacks\$($Global:IsLang)\Instl.ps1"
	$StaticInstl  = "$PSScriptRoot\..\langpacks\en-US\Instl.ps1"

	if (Test-Path $DynamicInstl -PathType Leaf) {
		if ($New) {
			Start-Process "powershell" -ArgumentList "-file ""$DynamicInstl"""
		} else {
			powershell -NoLogo -NonInteractive -file ""$DynamicInstl -Silent""
		}
	} else {
		if (Test-Path $StaticInstl -PathType Leaf) {
			if ($New) {
				Start-Process "powershell" -ArgumentList "-file ""$StaticInstl"""
			} else {
				powershell -NoLogo -NonInteractive -file ""$StaticInstl -Silent""
			}
		} else {
			Clear-Host
			Write-Host "`n   $($lang.InstlNo)$StaticInstl" -ForegroundColor Red
		}
	}
}