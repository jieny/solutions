﻿<#
	.Personalized desktop right click
	.个性化桌面右键
#>
Function PersonaliseDeskMenu
{
	param
	(
		[switch]$Add,
		[switch]$Del,
		[switch]$Hide
	)

	Write-Host "   $($lang.DeskMenu)" -ForegroundColor Green

	if ($Del) { DisableDeskMenu }
	if ($Add) {
		if ($Hide) {
			EnableDeskMenu -Hide
		} else {
			EnableDeskMenu
		}
	}

	Write-host ""
}

<#
	.Delete desktop right click
	.删除桌面右键
#>
Function DisableDeskMenu
{
	Write-Host "   - $($lang.Delete) $($lang.DeskMenu)"
	Remove-Item -Path "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
}

<#
	.Add desktop right click
	.添加桌面右键
#>
Function EnableDeskMenu
{
	param
	(
		[switch]$Hide
	)

	$FlagsHideRight = $False
	if (Test-Path "$PSScriptRoot\..\..\Deploy\DesktopMenuShift" -PathType Leaf) {
		$FlagsHideRight = $True
	}
	if ($Hide) {
		$FlagsHideRight = $True
	}

	Write-Host "   - $($lang.AddTo) $($lang.DeskMenu)"
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel" -Name 'Icon' -Value "$($Global:MainFolder)\icons\MainPanel.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel" -Name "MUIVerb" -Value "$($Global:UniqueID)'s Solutions" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).MainPanel\command" -Name '(default)' -Value "powershell.exe -Command ""Start-Process 'Powershell.exe' -Argument '-File ""$((Convert-Path -Path "$($PSScriptRoot)\..\..\Engine.ps1" -ErrorAction SilentlyContinue))""' -Verb RunAs""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir" -Name 'Icon' -Value "$($Global:MainFolder)\icons\Engine.Gift.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir" -Name "MUIVerb" -Value $($lang.Location) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Dir\command" -Name '(default)' -Value "explorer $($Global:UniqueMainFolder)" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg" -Name 'Icon' -Value "$($Global:MainFolder)\icons\FirstExperience.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg" -Name "MUIVerb" -Value $($lang.FirstExperience) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Reg\command" -Name '(default)' -Value "powershell.exe -Command ""Start-Process 'Powershell.exe' -Argument '-File ""$((Convert-Path -Path "$($PSScriptRoot)\..\..\Engine.ps1" -ErrorAction SilentlyContinue))"" -Functions \""FirstExperience -Quit\""' -Verb RunAs""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update" -Name 'Icon' -Value "$($Global:MainFolder)\icons\update.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update" -Name "MUIVerb" -Value $($lang.Update) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).Update\command" -Name '(default)' -Value "powershell.exe -Command ""Start-Process 'Powershell.exe' -Argument '-File ""$((Convert-Path -Path "$($PSScriptRoot)\..\..\Engine.ps1" -ErrorAction SilentlyContinue))"" -Functions \""Update -Quit\""' -Verb RunAs""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About" -force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About\command" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About" -Name 'Icon' -Value "$($Global:MainFolder)\icons\about.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About" -Name "MUIVerb" -Value $($lang.About) -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\$($Global:UniqueID).About\command" -Name '(default)' -Value "explorer ""$($Global:AuthorURL)/go/os""" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-Item "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name "MUIVerb" -Value "$($Global:UniqueID)'s Solutions" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name 'Icon' -Value "$($Global:MainFolder)\icons\Engine.ico" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name "SeparatorAfter" -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name "Position" -Value 'Top' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	if ($FlagsHideRight) {
		New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name "Extended" -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
	}
	New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\Background\shell\$($Global:UniqueID)" -Name 'SubCommands' -Value "$($Global:UniqueID).MainPanel;$($Global:UniqueID).Dir;|;$($Global:UniqueID).Update;$($Global:UniqueID).Reg;|;$($Global:UniqueID).About;" -PropertyType String -Force -ea SilentlyContinue | Out-Null
}