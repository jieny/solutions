﻿<#
	.Install prerequisite software
	.安装必备软件
#>
$Global:PrerequisiteApp = @(
	("Google Chrome",
	 [Status]::Enabled,
	 [Action]::Install,
	 [Mode]::Queue,
	 $PSScriptRoot,
	 "..\..\..\00\Google Chrome",
	 "",
	 "https://dl.google.com/chrome/install/latest/chrome_installer.exe",
	 "",
	 "",
	 "Chrome*",
	 "/silent /install",
	 "",
	 "Chrome"),
	("Google Chrome Canary",
	 [Status]::Disable,
	 [Action]::Install,
	 [Mode]::Queue,
	 $PSScriptRoot,
	 "..\..\..\00\Google Chrome Canary",
	 "",
	 "https://dl.google.com/chrome/install/latest/chrome_installer.exe",
	 "",
	 "",
	 "Chrome*",
	 "/silent /install",
	 "",
	 "Chrome"),
	("7Zip",
	 [Status]::Enabled,
	 [Action]::Install,
	 [Mode]::Queue,
	 $PSScriptRoot,
	 "..\..\..\00\7Z",
	 "",
	 "https://www.7-zip.org/a/7z2106.exe",
	 "https://www.7-zip.org/a/7z2106-x64.exe",
	 "https://www.7-zip.org/a/7z2106-arm64.exe",
	 "7z*",
	 "/S",
	 "",
	 ""),
	("WinRAR",
	 [Status]::Enabled,
	 [Action]::Install,
	 [Mode]::Queue,
	 $PSScriptRoot,
	 "..\..\..\00\WinRAR",
	 "",
	 $($lang.Winrar),
	 $($lang.WinrarAMD64),
	 "",
	 "winrar*",
	 "/S",
	 "",
	 ""),
	("VisualCppRedist AIO",
	 [Status]::Enabled,
	 [Action]::Install,
	 [Mode]::Queue,
	 $PSScriptRoot,
	 "..\..\..\00\VisualCppRedist",
	 "",
	 "https://github.com/abbodi1406/vcredist/releases/download/v0.60.0/VisualCppRedist_AIO_x86_x64_60.zip",
	 "",
	 "",
	 "VisualCppRedist*",
	 "/y",
	 "",
	 "")
)

Function Prerequisite
{
	param
	(
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title "$($lang.Instl) $($lang.Necessary)"
	Write-Host "   $($lang.Necessary)`n   ---------------------------------------------------"
   
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIPreCanelClick = {
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIPre.Close()
	}
	$GUIPreOKClick = {
		$GUIPre.Hide()
		$GUIPrePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Checked) {
					Install_Process -appname $Global:PrerequisiteApp[$_.Tag][0] -status "Enabled" -act $Global:PrerequisiteApp[$_.Tag][2] -mode $Global:PrerequisiteApp[$_.Tag][3] -todisk $Global:PrerequisiteApp[$_.Tag][4] -structure $Global:PrerequisiteApp[$_.Tag][5] -pwd $Global:PrerequisiteApp[$_.Tag][6] -url $Global:PrerequisiteApp[$_.Tag][7] -urlAMD64 $Global:PrerequisiteApp[$_.Tag][8] -urlarm64 $Global:PrerequisiteApp[$_.Tag][9] -filename $Global:PrerequisiteApp[$_.Tag][10] -param $Global:PrerequisiteApp[$_.Tag][11] -Before $Global:PrerequisiteApp[$_.Tag][12] -After $Global:PrerequisiteApp[$_.Tag][13]
				}
			}
		}
		$GUIPre.Close()
	}
	$GUIPre            = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 550
		Text           = "$($lang.Instl) $($lang.Necessary)"
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUIPrePanel       = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 570
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 1
	}
	$GUIPreOK          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,595"
		Height         = 36
		Width          = 515
		add_Click      = $GUIPreOKClick
		Text           = $lang.OK
	}
	$GUIPreCanel       = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,635"
		Height         = 36
		Width          = 515
		add_Click      = $GUIPreCanelClick
		Text           = $lang.Cancel
	}
	$GUIPre.controls.AddRange((
		$GUIPrePanel,
		$GUIPreOK,
		$GUIPreCanel
	))

	for ($i=0; $i -lt $Global:PrerequisiteApp.Count; $i++) {
		$CheckBox  = New-Object System.Windows.Forms.CheckBox -Property @{
			Height = 28
			Width  = 495
			Text   = $Global:PrerequisiteApp[$i][0]
			Tag    = $i
		}

		if ($Global:PrerequisiteApp[$i][1] -like "Enabled") {
			$CheckBox.Checked = $true
		} else {
			$CheckBox.Checked = $false
		}
		$GUIPrePanel.controls.AddRange($CheckBox)		
	}

	$GUIPreMenuAllSelClick = {
		$GUIPrePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIPreMenuAllClearClick = {
		$GUIPrePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIPreMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIPreMenu.Items.Add($lang.AllSel).add_Click($GUIPreMenuAllSelClick)
	$GUIPreMenu.Items.Add($lang.AllClear).add_Click($GUIPreMenuAllClearClick)
	$GUIPre.ContextMenuStrip = $GUIPreMenu

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIPre.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIPre.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$GUIPre.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$GUIPre.FormBorderStyle = 'Fixed3D'
	$GUIPre.ShowDialog() | Out-Null
}

Enum Status
{
	Enabled
	Disable
}

Enum Mode
{
	Wait
	Fast
	Queue
}

Enum Action
{
	Install
	NoInst
	To
	Unzip
}