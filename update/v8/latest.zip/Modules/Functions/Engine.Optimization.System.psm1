﻿<#
 .Synopsis
  Optimize the system

 .Description
  Optimize the system Feature Modules

 .NOTES
  Author:  Yi
  Website: http://fengyi.tel
#>

<#
	.Optimize the system user interface
	.优化系统用户界面
#>
Function Optimization
{
	param
	(
		[switch]$Force,
		[switch]$Quit
	)
	if ($Quit) { $Global:QUIT = $true }

	Logo -Title "$($lang.Optimize) $($lang.System)"
	Write-Host "   $($lang.Optimize) $($lang.System)`n   ---------------------------------------------------"

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	$GUIOSOptionClick = {
		if ($GUIOSOption.Checked) {
			$GUIOSOptionPanel.Enabled = $True
		} else {
			$GUIOSOptionPanel.Enabled = $False
		}
	}

	$GUINetworkClick = {
		if ($GUINetwork.Checked) {
			$GUINetworkPanel.Enabled = $True
		} else {
			$GUINetworkPanel.Enabled = $False
		}
	}

	$GUIExplorerClick = {
		if ($GUIExplorer.Checked) {
			$GUIExplorerPanel.Enabled = $True
		} else {
			$GUIExplorerPanel.Enabled = $False
		}
	}
	$GUIContextMenuClick = {
		if ($GUIContextMenu.Checked) {
			$GUIContextMenuPanel.Enabled = $True
		} else {
			$GUIContextMenuPanel.Enabled = $False
		}
	}
	$GUIXboxGameClick = {
		if ($GUIXboxGame.Checked) {
			$GUIXboxGamePanel.Enabled = $True
		} else {
			$GUIXboxGamePanel.Enabled = $False
		}
	}

	$GUIStartClick = {
		if ($GUIStart.Checked) {
			$GUIStartPanel.Enabled = $True
		} else {
			$GUIStartPanel.Enabled = $False
		}
	}

	$GUIPersonaliseClick = {
		if ($GUIPersonalise.Checked) {
			$GUIPersonalisePanel.Enabled = $True
		} else {
			$GUIPersonalisePanel.Enabled = $False
		}
	}

	$GUIStartTaskbarAlignmentCenterClick = {
		TaskbarAlignment -Center
	}

	$GUIStartTaskbarAlignmentLeafClick = {
		TaskbarAlignment -Left
	}

	$GUIPrivateClick = {
		if ($GUIPrivate.Checked) {
			$GUIPrivatePanel.Enabled = $True
		} else {
			$GUIPrivatePanel.Enabled = $False
		}
	}
	$GUINotificationClick = {
		if ($GUINotification.Checked) {
			$GUINotificationPanel.Enabled = $True
		} else {
			$GUINotificationPanel.Enabled = $False
		}
	}
	$GUIPagingSizeClick = {
		if ($GUIPagingSize.Checked) {
			$GUIPagingSizePanel.Enabled = $True
		} else {
			$GUIPagingSizePanel.Enabled = $False
		}
	}
	$GUIOtherClick = {
		if ($GUIOther.Checked) {
			$GUIOtherPanel.Enabled = $True
		} else {
			$GUIOtherPanel.Enabled = $False
		}
	}
	$GUIClearClick = {
		if ($GUIClear.Checked) {
			$GUIClearPanel.Enabled = $True
		} else {
			$GUIClearPanel.Enabled = $False
		}
	}
	$GUICanelClick = { 
		Write-Host "   $($lang.UserCancel)" -ForegroundColor Red
		$GUIOS.Close()
	}
	$GUIRestoreClick = {
		$GUIOS.Hide()
		if ($GUIOSOption.Enabled) {
			if ($GUIOSOption.Checked) {
				if ($GUITPMSetup.Checked) { Win11TPMSetup -Restore }
				if ($GUITPMUpdate.Checked) { Win11TPMUpdate -Restore }
				if ($GUIKeepSpace.Checked) { KeepSpace -Enable }
				if ($GUIHibernation.Checked) { Hibernation -Enable }
				if ($GUIPowerSupply.Checked) { PowerSupply -Restore }
				if ($GUIAppRestartScreen.Checked) { AppRestartScreen -Enable }
				if ($GUINumLock.Checked) { Numlock -Disable }
				if ($GUIUAC.Checked)  { UACNever -Enable }
				if ($GUISmartScreenApps.Checked) { SmartScreenApps -Enable }
				if ($GUISmartScreenSafe.Checked) { SmartScreenSafe -Enable }
				if ($GUIEasyAccessKeyboard.Checked) { EasyAccessKeyboard -Enable }
				if ($GUIMaintain.Checked) { Maintain -Enable }
				if ($GUIExperience.Checked) { Experience -Enable }
				if ($GUIDefragmentation.Checked) { Defragmentation -Enable }
				if ($GUICompatibility.Checked) { Compatibility -Enable }
				if ($GUIAnimationEffects.Checked) { AnimationEffects -Restore }
				if ($GUIErrorRecovery.Checked) { ErrorRecovery -Enable }
				if ($GUIDEP.Checked) { DEPPAE -Enable }
				if ($GUIPowerFailure.Checked) { PowerFailure -Enable }
				if ($GUIPwdUnlimited.Checked) { PwdUnlimited -Enable }
				if ($GUIRAM.Checked) { RAM -Enable }
				if ($GUIStorageSense.Checked) { StorageSense -Enable }
				if ($GUIDelivery.Checked) { Delivery -Enable }
				if ($GUIPhotoPreview.Checked) { PhotoPreview -Disable }
				if ($GUIProtected.Checked) { Protected -Enable }
				if ($GUIErrorReporting.Checked) { ErrorReporting -Enable }
				if ($GUIF8BootMenu.Checked) { F8BootMenu -Enable }
				if ($GUISSD.Checked) { SSD -Enable }
				if ($GUIMemoryCompression.Checked) { MemoryCompression -Enable }
				if ($GUIPrelaunch.Checked) { Prelaunch -Enable }
			}
		}

		<#
			.网络优化
		#>
		if ($GUINetwork.Enabled) {
			if ($GUINetwork.Checked) {
				if ($GUIIEProxy.Checked) { IEProxy }
				if ($GUIIEAutoSet.Checked) { AutoDetect -Enable }
				if ($GUINetworkDiscovery.Checked) { NetworkDiscovery -Enable }
				if ($GUINetworkAdaptersPM.Checked) { NetworkAdaptersSavePower -Enable }
				if ($GUIIPv6Component.Checked) { IPv6Component -Enable }
				if ($GUIQOS.Checked) { QOS -Enable }
				if ($GUINetworkTuning.Checked) { NetworkTuning -Enable }
				if ($GUIECN.Checked) { ECN -Enable }
			}
		}

		<#
			.资源管理器
		#>
		if ($GUIExplorer.Enabled) {
			if ($GUIExplorer.Checked) {
				if ($GUISeparateProcess.Checked) { SeparateProcess -Enabled }
				if ($GUIRestartApps.Checked) { RestartApps -Enabled }
				if ($GUICheckBoxes.Checked) { CheckBoxes -Enabled }
				if ($GUIThumbnailCache.Checked) { ThumbnailCache -Enabled }
				if ($GUIToThisPC.Checked) { ExplorerOpenTo -QuickAccess }
				if ($GUIAeroShake.Checked) {
					if ($GUISyncAllUser.Checked) {
						AeroShake -Enable -AllUser
					} else {
						AeroShake -Enable
					}
				}
				if ($GUIFileExtensions.Checked) { FileExtensions -Hide }
				if ($GUISafetyWarnings.Checked) { SafetyWarnings -Enable }
				if ($GUIFileTransfer.Checked) { FileTransferDialog -Simple }
				if ($GUINavShowAll.Checked) { NavShowAll -Disable }
				if ($GUIAutoplay.Checked) { Autoplay -Enable }
				if ($GUIAutorun.Checked) { Autorun -Enable }
				if ($GUIQuickAccessFiles.Checked) { QuickAccessFiles -Show }
				if ($GUIQuickAccessFolders.Checked) { QuickAccessFolders -Show }
				if ($GUIShortcutArrow.Checked) { ShortcutArrow -Enable }
				if ($GUIThisPCDesktop.Checked) { ThisPCDesktop -Enable }
				if ($GUIThisPCDocument.Checked) { ThisPCDocument -Enable }
				if ($GUIThisPCDownload.Checked) { ThisPCDownload -Enable }
				if ($GUIThisPCMusic.Checked) { ThisPCMusic -Enable }
				if ($GUIThisPCPicture.Checked) { ThisPCPicture -Enable }
				if ($GUIThisPCVideo.Checked) { ThisPCVideo -Enable }
				if ($GUIThisPC3D.Checked) { ThisPC3D -Enable }
			}
		}

		<#
			.Right click menu
			.右键菜单
		#>
		if ($GUIContextMenu.Enabled) {
			if ($GUIContextMenu.Checked) {
				if ($GUIClassicModern.Checked) { Win11ContextMenu -Modern }
				if ($GUIOwnership.Checked) { TakeOwnership -Remove }
				if ($GUICopyPath.Checked) { CopyPath -Remove }
				if ($GUIMultipleIncrease.Checked) { MultipleIncrease -Enable }
			}
		}

		<#
			.Personalise
			.个性化
		#>
		if ($GUIPersonalise.Enabled) {
			if ($GUIPersonalise.Checked) {
				if ($GUIPersonaliseDarkApps.Checked) { DarkModeToApps -Light }
				if ($GUIPersonaliseDarkSystem.Checked) { DarkModeToSystem -Light }
				if ($GUIPersonaliseTransparencyEffects.Checked) { TransparencyEffects -Enable }
				if ($GUIPersonaliseSnapAssistFlyout.Checked) { SnapAssistFlyout -Enable }
			}
		}

		<#
			.Start menu and taskbar
			.开始菜单和任务栏
		#>
		if ($GUIStart.Enabled) {
			if ($GUIStart.Checked) {
				if ($GUITaskbarWidgets.Checked) { TaskbarWidgets -Show }
				if ($GUITaskbarWidgetsRemove.Checked) { TaskbarWidgetsRemove -Restore }
				if ($GUITeamsAutostarting.Checked) { TeamsAutostarting -Enable }
				if ($GUITeamsTaskbarChat.Checked) { TeamsTaskbarChat -Show }
				if ($GUIBingSearch.Checked) { BingSearch -Enable }
				if ($GUITaskbarSuggestedContent.Checked) { TaskbarSuggestedContent -Show }
				if ($GUISuggestionsDevice.Checked) { SuggestionsDevice -Enable }
				if ($GUISearchBox.Checked) {
					SearchBox -SearchBox
					RestartExplorer
				}
				if ($GUIMergeTaskbarNever.Checked) { MergeTaskbarNever -Disable }
				if ($GUINotificationAlways.Checked) { NotificationAlways -Disable }
				if ($GUICortana.Checked) {
					Cortana -Enable
					RestartExplorer
				}
				if ($GUITaskView.Checked) { TaskView -Show }
			}
		}

		<#
			.Game Bar
		#>
		if ($GUIXboxGame.Enabled) {
			if ($GUIXboxGame.Checked) {
				if ($GUIXboxGameBar.Checked) { XboxGameBar -Enable }
				if ($GUIXboxGameBarTips.Checked) { XboxGameBarTips -Enable }
				if ($GUIXboxGameMode.Checked) { XboxGameMode -Enable }
				if ($GUIXboxGameDVR.Checked) { XboxGameDVR -Enable }
			}
		}

		<#
			.隐私类
		#>
		if ($GUIPrivate.Enabled) {
			if ($GUIPrivate.Checked) {
				if ($GUIScheduledTasks.Checked) { ScheduledTasks -Restore }
				if ($GUIPrivacyVoiceTyping.Checked) { PrivacyVoiceTyping -Enabled }
				if ($GUIPrivacyContactsSpeech.Checked) { PrivacyContactsSpeech -Enabled }
				if ($GUIPrivacyLanguageOptOut.Checked) { PrivacyLanguageOptOut -Enabled }
				if ($GUIPrivacyAds.Checked) { PrivacyAds -Enabled }
				if ($GUILocatonAware.Checked) { PrivacyLocatonAware -Enabled }
				if ($GUIPrivacySetSync.Checked) { PrivacySetSync -Enabled }
				if ($GUIInkingTyping.Checked) { PrivacyInkingTyping -Enabled }
				if ($GUIShareUnpairedDevices.Checked) { PrivacyShareUnpairedDevices -Enabled }
				if ($GUILocationSensor.Checked) { PrivacyLocationSensor -Enabled }
				if ($GUIBiometrics.Checked) { PrivacyBiometrics -Enabled }
				if ($GUICompatibleTelemetry.Checked) { PrivacyCompatibleTelemetry -Enabled }
				if ($GUIDiagnosticData.Checked) { PrivacyDiagnosticData -Enabled }
				if ($GUITailoredExperiences.Checked) { PrivacyTailoredExperiences -Enabled }
				if ($GUIFeedbackNotifications.Checked) { PrivacyFeedbackNotifications -Enabled }
				if ($GUILocationTracking.Checked) { PrivacyLocationTracking -Enabled }
				if ($GUIExperiencesTelemetry.Checked) { PrivacyExperiencesTelemetry -Enabled }
				if ($GUIPrivacyBackgroundAccess.Checked) { PrivacyBackgroundAccess -Enabled }
				if ($GUITimelineTime.Checked) { TimelineTime -Enable }
				if ($GUICollectActivity.Checked) { CollectActivity -Enable }
			}
		}

		<#
			.系统盘分页大小
		#>
		if ($GUIPagingSize.Enabled) {
			if ($GUIPagingSize.Checked) {
				PagingSize -Disable
			}
		}

		<#
			.通知中心
		#>
		if ($GUINotification.Enabled) {
			if ($GUINotification.Checked) {
				NotificationCenter -Restore
			}
		}

		if ($GUITaskBar.Checked) { ResetTaskBar }
		if ($GUIResetDesk.Checked) { ResetDesktop }

		gpupdate /force | out-null
		Start-Sleep 5
		$Running = Get-Process explorer -ErrorAction SilentlyContinue
		if (-not ($Running)) {
			Start-Process "explorer.exe"
		}
		$GUIOS.Close()
	}
	$GUIOKClick = {
		$GUIOS.Hide()

		if ($GUIOSOption.Enabled) {
			if ($GUIOSOption.Checked) {
				if ($GUITPMSetup.Checked) { Win11TPMSetup -Disable }
				if ($GUITPMUpdate.Checked) { Win11TPMUpdate -Disable }
				if ($GUIKeepSpace.Checked) { KeepSpace -Disable }
				if ($GUIHibernation.Checked) { Hibernation -Disable }
				if ($GUIPowerSupply.Checked) { PowerSupply -Optimize }
				if ($GUIAppRestartScreen.Checked) { AppRestartScreen -Disable }
				if ($GUINumLock.Checked) { Numlock -Enable }
				if ($GUIUAC.Checked) { UACNever -Disable }
				if ($GUISmartScreenApps.Checked) { SmartScreenApps -Disable }
				if ($GUISmartScreenSafe.Checked) { SmartScreenSafe -Disable }
				if ($GUIEasyAccessKeyboard.Checked) { EasyAccessKeyboard -Disable }
				if ($GUIMaintain.Checked) { Maintain -Disable }
				if ($GUIExperience.Checked) { Experience -Disable }
				if ($GUIDefragmentation.Checked) { Defragmentation -Disable }
				if ($GUICompatibility.Checked) { Compatibility -Disable }
				if ($GUIAnimationEffects.Checked) { AnimationEffects -Optimize }
				if ($GUIErrorRecovery.Checked) { ErrorRecovery -Disable }
				if ($GUIDEP.Checked) { DEPPAE -Disable }
				if ($GUIPowerFailure.Checked) { PowerFailure -Disable }
				if ($GUIPwdUnlimited.Checked) { PwdUnlimited -Disable }
				if ($GUIRAM.Checked) { RAM -Disable }
				if ($GUIStorageSense.Checked) { StorageSense -Disable }
				if ($GUIDelivery.Checked) { Delivery -Disable }
				if ($GUIPhotoPreview.Checked) { PhotoPreview -Enable }
				if ($GUIProtected.Checked) { Protected -Disable }
				if ($GUIErrorReporting.Checked) { ErrorReporting -Disable }
				if ($GUIF8BootMenu.Checked) { F8BootMenu -Disable }
				if ($GUISSD.Checked) { SSD -Disable }
				if ($GUIMemoryCompression.Checked) { MemoryCompression -Disable }
				if ($GUIPrelaunch.Checked) { Prelaunch -Disable }
			}
		}

		<#
			.网络优化
		#>
		if ($GUINetwork.Enabled) {
			if ($GUINetwork.Checked) {
				if ($GUIIEProxy.Checked) { IEProxy }
				if ($GUIIEAutoSet.Checked) { AutoDetect -Disable }
				if ($GUINetworkDiscovery.Checked) { NetworkDiscovery -Disable }
				if ($GUINetworkAdaptersPM.Checked) { NetworkAdaptersSavePower -Disable }
				if ($GUIIPv6Component.Checked) { IPv6Component -Disable }
				if ($GUIQOS.Checked) { QOS -Disable }
				if ($GUINetworkTuning.Checked) { NetworkTuning -Disable }
				if ($GUIECN.Checked) { ECN -Disable }
			}
		}

		<#
			.Resource manager
			.资源管理器
		#>
		if ($GUIExplorer.Enabled) {
			if ($GUIExplorer.Checked) {
				if ($GUISeparateProcess.Checked) { SeparateProcess -Disable }
				if ($GUIRestartApps.Checked) { RestartApps -Disable }
				if ($GUICheckBoxes.Checked) { CheckBoxes -Disable }
				if ($GUIThumbnailCache.Checked) { ThumbnailCache -Disable }
				if ($GUIToThisPC.Checked) { ExplorerOpenTo -ThisPC }
				if ($GUIAeroShake.Checked) {
					if ($GUISyncAllUser.Checked) {
						AeroShake -Disable -AllUser
					} else {
						AeroShake -Disable
					}
				}
				if ($GUIFileExtensions.Checked) { FileExtensions -Show }
				if ($GUISafetyWarnings.Checked) { SafetyWarnings -Disable }
				if ($GUIFileTransfer.Checked) { FileTransferDialog -Detailed }
				if ($GUINavShowAll.Checked) { NavShowAll -Enable }
				if ($GUIAutoplay.Checked) { Autoplay -Disable }
				if ($GUIAutorun.Checked) { Autorun -Disable }
				if ($GUIQuickAccessFiles.Checked) { QuickAccessFiles -Hide }
				if ($GUIQuickAccessFolders.Checked) { QuickAccessFolders -Hide }
				if ($GUIShortcutArrow.Checked) { ShortcutArrow -Disable }
				if ($GUIThisPCDesktop.Checked) { ThisPCDesktop -Disable }
				if ($GUIThisPCDocument.Checked) { ThisPCDocument -Disable }
				if ($GUIThisPCDownload.Checked) { ThisPCDownload -Disable }
				if ($GUIThisPCMusic.Checked) { ThisPCMusic -Disable }
				if ($GUIThisPCPicture.Checked) { ThisPCPicture -Disable }
				if ($GUIThisPCVideo.Checked) { ThisPCVideo -Disable }
				if ($GUIThisPC3D.Checked) { ThisPC3D -Disable }
			}
		}

		<#
			.Right click menu
			.右键菜单
		#>
		if ($GUIContextMenu.Enabled) {
			if ($GUIContextMenu.Checked) {
				if ($GUIClassicModern.Checked) { Win11ContextMenu -Classic }
				if ($GUIOwnership.Checked) {
					TakeOwnership -Remove
					TakeOwnership -Add
				}
				if ($GUICopyPath.Checked) {
					CopyPath -Remove
					CopyPath -Add
				}
				if ($GUIMultipleIncrease.Checked) { MultipleIncrease -Disable }
			}
		}

		<#
			.Personalise
			.个性化
		#>
		if ($GUIPersonalise.Enabled) {
			if ($GUIPersonalise.Checked) {
				if ($GUIPersonaliseDarkApps.Checked) { DarkModeToApps -Dark }
				if ($GUIPersonaliseDarkSystem.Checked) { DarkModeToSystem -Dark }
				if ($GUIPersonaliseTransparencyEffects.Checked) { TransparencyEffects -Disable }
				if ($GUIPersonaliseSnapAssistFlyout.Checked) { SnapAssistFlyout -Disable }
			}
		}
	
		<#
			.开始菜单和任务栏
		#>
		if ($GUIStart.Enabled) {
			if ($GUIStart.Checked) {
				if ($GUITaskbarWidgets.Checked) { TaskbarWidgets -Hide }
				if ($GUITaskbarWidgetsRemove.Checked) { TaskbarWidgetsRemove -Remove }
				if ($GUITeamsAutostarting.Checked) { TeamsAutostarting -Disable }
				if ($GUITeamsTaskbarChat.Checked) { TeamsTaskbarChat -Hide }
				if ($GUIBingSearch.Checked) { BingSearch -Disable }
				if ($GUITaskbarSuggestedContent.Checked) { TaskbarSuggestedContent -Hide }
				if ($GUISuggestionsDevice.Checked) { SuggestionsDevice -Disable }
				if ($GUISearchBox.Checked) {
					SearchBox -SearchIcon
					RestartExplorer
				}
				if ($GUIMergeTaskbarNever.Checked) { MergeTaskbarNever -Enable }
				if ($GUINotificationAlways.Checked) { NotificationAlways -Enable }
				if ($GUICortana.Checked) {
					Cortana -Disable
					RestartExplorer
				}
				if ($GUITaskView.Checked) { TaskView -Hide }
			}
		}

		<#
			.Game Bar
		#>
		if ($GUIXboxGameBar.Enabled) {
			if ($GUIXboxGameBar.Checked) {
				if ($GUIXboxGameBar.Checked) { XboxGameBar -Disable }
				if ($GUIXboxGameBarTips.Checked) { XboxGameBarTips -Disable }
				if ($GUIXboxGameMode.Checked) { XboxGameMode -Disable }
				if ($GUIXboxGameDVR.Checked) { XboxGameDVR -Disable }
			}
		}

		<#
			.隐私类
		#>
		if ($GUIPrivate.Enabled) {
			if ($GUIPrivate.Checked) {
				if ($GUIScheduledTasks.Checked) { ScheduledTasks -Disable }
				if ($GUIPrivacyVoiceTyping.Checked) { PrivacyVoiceTyping -Disable }
				if ($GUIPrivacyContactsSpeech.Checked) { PrivacyContactsSpeech -Disable }
				if ($GUIPrivacyLanguageOptOut.Checked) { PrivacyLanguageOptOut -Disable }
				if ($GUIPrivacyAds.Checked) { PrivacyAds -Disable }
				if ($GUILocatonAware.Checked) { PrivacyLocatonAware -Disable }
				if ($GUIPrivacySetSync.Checked) { PrivacySetSync -Disable }
				if ($GUIInkingTyping.Checked) { PrivacyInkingTyping -Disable }
				if ($GUIShareUnpairedDevices.Checked) { PrivacyShareUnpairedDevices -Disable }
				if ($GUILocationSensor.Checked) { PrivacyLocationSensor -Disable }
				if ($GUIBiometrics.Checked) { PrivacyBiometrics -Disable }
				if ($GUICompatibleTelemetry.Checked) { PrivacyCompatibleTelemetry -Disable }
				if ($GUIDiagnosticData.Checked) { PrivacyDiagnosticData -Disable }
				if ($GUITailoredExperiences.Checked) { PrivacyTailoredExperiences -Disable }
				if ($GUIFeedbackNotifications.Checked) { PrivacyFeedbackNotifications -Disable }
				if ($GUILocationTracking.Checked) { PrivacyLocationTracking -Disable }
				if ($GUIExperiencesTelemetry.Checked) { PrivacyExperiencesTelemetry -Disable }
				if ($GUIPrivacyBackgroundAccess.Checked) { PrivacyBackgroundAccess -Disable }
				if ($GUITimelineTime.Checked) { TimelineTime -Disable }
				if ($GUICollectActivity.Checked) { CollectActivity -Disable }
			}
		}

		<#
			.通知中心
		#>
		if ($GUINotification.Enabled) {
			if ($GUINotification.Checked) {
				if ($GUINotificationFull.Checked) {
					NotificationCenter -Restore
					NotificationCenter -Full
				}
				if ($GUINotificationPart.Checked) {
					NotificationCenter -Restore
					NotificationCenter -Part
				}
			}
		}

		<#
			.系统盘分页大小
		#>
		if ($GUIPagingSize.Enabled) {
			if ($GUIPagingSize.Checked) {
				if ($GUIPagingSizeLow.Checked) { PagingSize -Enable -size 8 }
				if ($GUIPagingSizeHigh.Checked) { PagingSize -Enable -size 16 }
			}
		}

		<#
			.其它类
		#>
		if ($GUIOther.Enabled) {
			if ($GUIOther.Checked) {
				if ($GUIRDS.Checked) { RemoteDesktop }
				if ($GUISMB.Checked) { SMBFileShare }
			}
		}

		<#
			.清理类
		#>
		if ($GUIClear.Enabled) {
			if ($GUIClear.Checked) {
				if ($GUISendTo.Checked) { SendTo }
				if ($GUICleanSystemLog.Checked) { CleanSystemLog }
				if ($GUICleanDisk.Checked) {
					Start-Job -ScriptBlock ${function:DiskCleanup} -ErrorAction SilentlyContinue | Out-Null
				}
				if ($GUICleanSxS.Checked) { CleanSxS }
			}
		}

		if ($GUITaskBar.Checked) { ResetTaskBar }
		if ($GUIResetDesk.Checked) { ResetDesktop }

		gpupdate /force | out-null
		Start-Sleep 5
		$Running = Get-Process explorer -ErrorAction SilentlyContinue
		if (-not ($Running)) {
			Start-Process "explorer.exe"
		}
		$GUIOS.Close()
	}
	$GUIOS             = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 1015
		Text           = "$($lang.Optimize) $($lang.System)"
		TopMost        = $False
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$GUILeaf           = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 56
		Width          = 480
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 3
		Location       = '0,0'
	}

	<#
		.优化类
	#>
	$GUIOSOption       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.Optimize)"
		Checked        = $True
		add_click      = $GUIOSOptionClick
		Margin         = "2,6,0,0"
	}
	$GUIOSOptionPanel  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 235
		Width          = 480
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUITPMSetup       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.TPMSetup)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUITPMUpdate      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.TPMUpdate)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIKeepSpace      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Close) $($lang.KeepSpace)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIHibernation    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Close) $($lang.Hibernation)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIPowerSupply    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Setting) $($lang.PowerSupply)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIAppRestartScreen = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.AppRestartScreen)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUINumLock        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Setting) $($lang.NumLock)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIUAC            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Setting) $($lang.UAC)$($lang.UACNever)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUISmartScreenApps = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.SmartScreenApps)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUISmartScreenSafe = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.SmartScreenSafe)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIEasyAccessKeyboard = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.EasyAccessKeyboard)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIMaintain       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Close) $($lang.Maintain)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIExperience     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Close) $($lang.Experience)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIDefragmentation = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.Defragmentation)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUICompatibility  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Close) $($lang.Compatibility)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIAnimationEffects = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Optimize) $($lang.AnimationEffects)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIErrorRecovery  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Close) $($lang.ErrorRecovery)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIDEP            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.DEP) ( $($lang.Restart) )"
		ForeColor      = "#008000"
	}
	$GUIPowerFailure   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Close) $($lang.PowerFailure)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIPwdUnlimited   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Setting) $($lang.PwdUnlimited)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIRAM            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.RAM)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIStorageSense   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.StorageSense)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIDelivery       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.Delivery)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIPhotoPreview   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Enable) $($lang.PhotoPreview)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIProtected      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.Protected)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIErrorReporting = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.ErrorReporting)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIF8BootMenu     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.F8BootMenu)"
		ForeColor      = "#008000"
	}
	$GUISSD            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Optimize) $($lang.OptSSD)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIMemoryCompression = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.MemoryCompression)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIPrelaunch      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.Prelaunch)"
		Checked        = $true
		ForeColor      = "#008000"
	}

	<#
		.Context Menu
		.上下文菜单
	#>
	$GUIContextMenu    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.ContextMenu)"
		Checked        = $True
		add_click      = $GUIContextMenuClick
		Margin         = "2,22,0,0"
	}
	$GUIContextMenuPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 110
		Width          = 480
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIClassicModern  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Enable) $($lang.ClassicMenu)"
		ForeColor      = "#008000"
	}
	$GUIOwnership      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.AddTo) $($lang.TakeOwnership)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUICopyPath       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.AddTo) $($lang.CopyPath)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIMultipleIncrease = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.MultipleIncrease)"
		Checked        = $true
		ForeColor      = "#008000"
	}

	<#
		.网络优化
	#>
	$GUINetwork        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.NetworkOptimization)"
		Checked        = $True
		add_click      = $GUINetworkClick
		Margin         = "2,22,0,0"
	}
	$GUINetworkPanel   = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 235
		Width          = 480
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIIEProxy        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Restore) $($lang.IEProxy)"
	}
	$GUIIEAutoSet      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.IEAutoSet)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUINetworkDiscovery = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.NetworkDiscovery)"
		ForeColor      = "#008000"
	}
	$GUINetworkDiscoveryTips = New-Object System.Windows.Forms.Label -Property @{
		autoSize       = 1
		Text           = $lang.NetworkDiscoveryTips
		Padding        = "15,0,15,8"
	}
	$GUINetworkAdaptersPM = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.NetworkAdaptersPM)"
		ForeColor      = "#008000"
	}
	$GUIIPv6Component  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.IPv6Component)"
		ForeColor      = "#008000"
	}
	$GUIQOS            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.QOS)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUINetworkTuning  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Optimize) $($lang.NetworkTuning)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIECN            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.ECN)"
		Checked        = $true
		ForeColor      = "#008000"
	}


	<#
		.资源管理器
	#>
	$GUIExplorer       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.Explorer)"
		Checked        = $True
		add_click      = $GUIExplorerClick
		Margin         = "2,22,0,0"
	}
	$GUIExplorerPanel  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 235
		Width          = 480
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUISeparateProcess = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Enable) $($lang.SeparateProcess)"
		ForeColor      = "#008000"
	}
	$GUIRestartApps    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Enable) $($lang.RestartApps)"
		ForeColor      = "#008000"
	}
	$GUIRestartAppsTips = New-Object System.Windows.Forms.Label -Property @{
		autoSize       = 1
		Text           = $lang.RestartAppsTips
		Padding        = "15,0,15,8"
	}

	$GUICheckBoxes     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Enable) $($lang.CheckBoxes)"
		ForeColor      = "#008000"
	}
	$GUIThumbnailCache = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.ThumbnailCache)"
		ForeColor      = "#008000"
	}
	$GUIToThisPC       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.ExplorerTo -f $($lang.ExplorerToThisPC))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIAeroShake      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.AeroShake)"
		ForeColor      = "#008000"
	}
	$GUIFileExtensions = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Show) $($lang.FileExtensions)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUISafetyWarnings = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.SafetyWarnings)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIFileTransfer   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Setting) $($lang.FileTransfer)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUINavShowAll     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.NavShowAll)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIAutoplay       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.Autoplay)"
		ForeColor      = "#008000"
	}
	$GUIAutorun        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.Autorun)"
		ForeColor      = "#008000"
	}
	$GUIQuickAccessFiles = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.QuickAccessFiles)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIQuickAccessFolders = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.QuickAccessFolders)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIShortcutArrow  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Delete) $($lang.ShortcutArrow)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIThisPCDesktop  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationDesktop))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIThisPCDocument = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationDocuments))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIThisPCDownload = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationDownloads))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIThisPCMusic    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationMusic))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIThisPCPicture  = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationPictures))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIThisPCVideo    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.ThisPCRemove -f $($lang.LocationVideos))"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIThisPC3D       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.ThisPCRemove -f $($lang.Location3D))"
		Checked        = $true
		ForeColor      = "#008000"
	}

	<#
		.通知中心
	#>
	$GUINotification   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.Notification)"
		ForeColor      = "#008000"
		Checked        = $True
		add_click      = $GUINotificationClick
		Margin         = "2,22,0,0"
	}
	$GUINotificationPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 56
		Width          = 480
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUINotificationFull = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.Close) $($lang.Notification) ( $($lang.Full) )"
	}
	$GUINotificationPart = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.Close) $($lang.Notification) ( $($lang.Part) )"
		Checked        = $true
	}

	<#
		.系统盘分页大小
	#>
	$GUIPagingSize     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.PagingSize) ( $($lang.Restart) )"
		ForeColor      = "#008000"
		Checked        = $True
		add_click      = $GUIPagingSizeClick
		Margin         = "2,22,0,0"
	}
	$GUIPagingSizePanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 56
		Width          = 480
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIPagingSizeLow  = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.Setting) $($lang.PagingSize) (8G)"
		Checked        = $true
	}
	$GUIPagingSizeHigh = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.Setting) $($lang.PagingSize) (16G)"
	}

	<#
		.个性化
	#>
	$GUIPersonalise    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 400
		Text           = $lang.Personalise
		Checked        = $True
		add_click      = $GUIPersonaliseClick
		Margin         = "2,22,0,0"
	}
	$GUIPersonalisePanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 180
		Width          = 410
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIPersonaliseDark = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.DarkMode
	}
	$GUIPersonaliseDarkApps = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 380
		Text           = "$($lang.DarkApps)"
		ForeColor      = "#008000"
		Padding        = "16,0,8,0"
	}
	$GUIPersonaliseDarkSystem = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 380
		Text           = "$($lang.DarkSystem)"
		ForeColor      = "#008000"
		Padding        = "16,0,8,0"
	}
	$GUIPersonaliseTransparencyEffects = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.TransparencyEffects)"
		ForeColor      = "#008000"
	}
	$GUIPersonaliseSnapAssistFlyout = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.SnapAssistFlyout)"
		ForeColor      = "#008000"
	}
	$GUIPersonaliseSnapAssistFlyoutTips = New-Object System.Windows.Forms.Label -Property @{
		autoSize       = 1
		Text           = $lang.SnapAssistFlyoutTips
		Padding        = "15,0,15,8"
	}

	<#
		.开始菜单和任务栏
	#>
	$GUIStart          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 400
		Text           = $lang.Start
		Checked        = $True
		add_click      = $GUIStartClick
		Margin         = "2,22,0,0"
	}
	$GUIStartPanel     = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 180
		Width          = 410
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIStartTaskbarAlignmentPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 85
		Width          = 380
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "0,0,8,0"
		Dock           = 0
	}
	$GUITaskbarAlignment = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.TaskbarAlignment
	}
	$GUIStartTaskbarAlignmentCenter = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.TaskbarAlignmentCentered
		Padding        = "16,0,8,0"
		add_click      = $GUIStartTaskbarAlignmentCenterClick
	}
	$GUIStartTaskbarAlignmentLeaf = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.TaskbarAlignmentLeft
		Padding        = "16,0,8,0"
		add_click      = $GUIStartTaskbarAlignmentLeafClick
	}
	$GUITaskbarWidgets = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Hide) $($lang.TaskbarWidgets)"
		ForeColor      = "#008000"
	}
	$GUITaskbarWidgetsRemove = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Delete) $($lang.TaskbarWidgetsRemove)"
		ForeColor      = "#008000"
	}
	$GUITeamsAutostarting = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.TeamsAutostarting)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUITeamsTaskbarChat = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Hide) $($lang.TeamsTaskbarChat)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIBingSearch     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.BingSearch)"
		ForeColor      = "#008000"
	}
	$GUITaskbarSuggestedContent = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Hide) $($lang.TaskbarSuggestedContent)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUISuggestionsDevice = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.SuggestionsDevice)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUISearchBox      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Setting) $($lang.SearchBox)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIMergeTaskbarNever = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Setting) $($lang.MergeTaskbarNever)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUINotificationAlways = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Setting) $($lang.NotificationAlways)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUICortana        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = $lang.Cortana
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUITaskView       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = $lang.TaskView
		ForeColor      = "#008000"
	}

	<#
		.Gaming
		.游戏
	#>
	$GUIXboxGame       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.Gaming)"
		Checked        = $True
		add_click      = $GUIXboxGameClick
		Margin         = "2,22,0,0"
	}
	$GUIXboxGamePanel  = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 110
		Width          = 480
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIXboxGameBar    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.XboxGameBar)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIXboxGameBarTips = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.XboxGameBarTips)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIXboxGameMode   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.XboxGameMode)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIXboxGameDVR    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.XboxGameDVR)"
		Checked        = $true
		ForeColor      = "#008000"
	}

	<#
		.隐私类
	#>
	$GUIPrivate        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 410
		Text           = "$($lang.FixPrivacy)"
		Checked        = $True
		add_click      = $GUIPrivateClick
		Margin         = "2,22,0,0"
	}
	$GUIPrivatePanel   = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 235
		Width          = 480
		BorderStyle    = 0
		autoSizeMode   = 1
		autoSize       = 1
		autoScroll     = $true
		Padding        = "12,0,8,0"
		Dock           = 0
	}
	$GUIScheduledTasks = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.ScheduledTasks)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIPrivacyVoiceTyping = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyVoiceTyping)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIPrivacyContactsSpeech = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyContactsSpeech)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIPrivacyLanguageOptOut = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyLanguageOptOut)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIPrivacyAds     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyAds)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUILocatonAware   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyLocatonAware)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIPrivacySetSync = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacySetSync)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIInkingTyping   = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyInkingTyping)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIShareUnpairedDevices = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyShareUnpairedDevices)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUILocationSensor = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyLocationSensor)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIBiometrics     = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyBiometrics)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUICompatibleTelemetry = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyCompatibleTelemetry)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIDiagnosticData = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyDiagnosticData)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUITailoredExperiences = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.TailoredExperiences)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIFeedbackNotifications = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyFeedbackNotifications)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUILocationTracking = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyLocationTracking)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIExperiencesTelemetry = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.ExperiencesTelemetry)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUIPrivacyBackgroundAccess = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.PrivacyBackgroundAccess)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUITimelineTime = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.TimelineTime)"
		Checked        = $true
		ForeColor      = "#008000"
	}
	$GUICollectActivity = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = "$($lang.Disable) $($lang.CollectActivity)"
		Checked        = $true
		ForeColor      = "#008000"
	}

	<#
		.其它类
	#>
	$GUIOther          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 460
		Text           = "$($lang.Related)"
		Location       = '530,5'
		Checked        = $True
		add_Click      = $GUIOtherClick
	}
	$GUIOtherPanel     = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 110
		Width          = 460
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "18,0,8,0"
		Dock           = 0
		Location       = '530,30'
	}
	$GUIRDS            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 440
		Text           = $($lang.StRemote)
	}
	$GUISMB            = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 440
		Text           = $($lang.StSMB)
	}
	$GUISMBTips        = New-Object System.Windows.Forms.Label -Property @{
		autoSize       = 1
		Text           = $lang.StSMBTips
		Padding        = "15,0,15,8"
	}

	<#
		.清理类
	#>
	$GUIClear          = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 460
		Text           = "$($lang.Cleanup)"
		Location       = '530,160'
		Checked        = $True
		add_Click      = $GUIClearClick
	}
	$GUIClearPanel     = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 110
		Width          = 460
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "18,0,8,0"
		Dock           = 0
		Location       = '530,185'
	}
	$GUISendTo         = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = $($lang.SendTo)
		Checked        = $true
	}
	$GUICleanSystemLog = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = $($lang.Logs)
		Checked        = $true
	}
	$GUICleanDisk      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = $($lang.DiskCleanup)
		Checked        = $true
	}
	$GUICleanSxS       = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 30
		Width          = 410
		Text           = $($lang.SxS)
	}

	<#
		.可用功能
	#>
	$GUIAdvOption      = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 460
		Text           = $lang.AdvOption
		Location       = '530,320'
	}
	$GUIAdvOptionPanel = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 110
		Width          = 460
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "16,0,8,0"
		Dock           = 0
		Location       = '530,342'
	}
	$GUISyncAllUser    = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 410
		Text           = "$($lang.SyncAllUser)"
		Checked        = $true
	}
	$GUITaskBar        = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 410
		Text           = "$($lang.Reset) $($lang.TaskBar)"
	}
	$GUIResetDesk      = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 28
		Width          = 410
		Text           = $lang.ResetDesk
	}

	$GUITips           = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 458
		Text           = $lang.OptimizationTips
		Location       = '530,530'
	}
	$GUIReset          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "530,555"
		Height         = 36
		Width          = 458
		add_Click      = $GUIRestoreClick
		Text           = $lang.Restore
	}
	$GUIOK             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "530,595"
		Height         = 36
		Width          = 458
		add_Click      = $GUIOKClick
		Text           = $lang.OK
	}
	$GUICanel          = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "530,635"
		Height         = 36
		Width          = 458
		add_Click      = $GUICanelClick
		Text           = $lang.Cancel
	}

	$GUIOS.controls.AddRange((
		$GUILeaf,
		$GUIOther,
		$GUIOtherPanel,
		$GUIClear,
		$GUIClearPanel,
		$GUIAdvOption,
		$GUIAdvOptionPanel,
		$GUITips,
		$GUIReset,
		$GUIOK,
		$GUICanel
	))

	$GUILeaf.controls.AddRange((
		$GUIOSOption,
		$GUIOSOptionPanel,
		$GUINetwork,
		$GUINetworkPanel,
		$GUIExplorer,
		$GUIExplorerPanel,
		$GUIContextMenu,
		$GUIContextMenuPanel,
		$GUINotification,
		$GUINotificationPanel,
		$GUIPagingSize,
		$GUIPagingSizePanel,
		$GUIPersonalise,
		$GUIPersonalisePanel,
		$GUIStart,
		$GUIStartPanel,
		$GUIXboxGame,
		$GUIXboxGamePanel,
		$GUIPrivate,
		$GUIPrivatePanel
	))

	<#
		.通知中心
	#>
	$GUINotificationPanel.controls.AddRange((
		$GUINotificationFull,
		$GUINotificationPart
	))

	$GUIClearPanel.controls.AddRange((
		$GUISendTo,
		$GUICleanSystemLog,
		$GUICleanDisk,
		$GUICleanSxS
	))

	$GUIOtherPanel.controls.AddRange((
		$GUIRDS,
		$GUISMB,
		$GUISMBTips
	))

	$GUINetworkPanel.controls.AddRange((
		$GUIIEProxy,
		$GUIIEAutoSet,
		$GUINetworkDiscovery,
		$GUINetworkDiscoveryTips,
		$GUINetworkAdaptersPM,
		$GUIIPv6Component,
		$GUIQOS,
		$GUINetworkTuning,
		$GUIECN
	))
	
	if (IsWin11) {
		$GUIOSOptionPanel.controls.AddRange((
			$GUITPMSetup,
			$GUITPMUpdate
		))
	}

	$GUIOSOptionPanel.controls.AddRange((
		$GUIKeepSpace,
		$GUIHibernation,
		$GUIPowerSupply,
		$GUIAppRestartScreen,
		$GUINumLock,
		$GUIUAC,
		$GUISmartScreenApps,
		$GUISmartScreenSafe,
		$GUIEasyAccessKeyboard,
		$GUIMaintain,
		$GUIExperience,
		$GUIDefragmentation,
		$GUICompatibility,
		$GUIAnimationEffects,
		$GUIErrorRecovery,
		$GUIDEP,
		$GUIPowerFailure,
		$GUIPwdUnlimited,
		$GUIRAM,
		$GUIStorageSense,
		$GUIDelivery,
		$GUIPhotoPreview,
		$GUIProtected,
		$GUIErrorReporting,
		$GUIF8BootMenu,
		$GUISSD,
		$GUIMemoryCompression,
		$GUIPrelaunch
	))

	$GUIPagingSizePanel.controls.AddRange((
		$GUIPagingSizeLow,
		$GUIPagingSizeHigh
	))

	$GUIExplorerPanel.controls.AddRange((
		$GUISeparateProcess,
		$GUIRestartApps,
		$GUIRestartAppsTips,
		$GUICheckBoxes,
		$GUIThumbnailCache,
		$GUIToThisPC,
		$GUIAeroShake,
		$GUIFileExtensions,
		$GUISafetyWarnings,
		$GUIFileTransfer,
		$GUINavShowAll,
		$GUIAutoplay,
		$GUIAutorun,
		$GUIQuickAccessFiles,
		$GUIQuickAccessFolders,
		$GUIShortcutArrow,
		$GUIThisPCDesktop,
		$GUIThisPCDocument,
		$GUIThisPCDownload,
		$GUIThisPCMusic,
		$GUIThisPCPicture,
		$GUIThisPCVideo,
		$GUIThisPC3D
	))

	$GUIContextMenuPanel.controls.AddRange((
		$GUIClassicModern,
		$GUIOwnership,
		$GUICopyPath,
		$GUIMultipleIncrease
	))

	$GUIPersonalisePanel.controls.AddRange((
		$GUIPersonaliseDark,
		$GUIPersonaliseDarkApps,
		$GUIPersonaliseDarkSystem,
		$GUIPersonaliseTransparencyEffects,
		$GUIPersonaliseSnapAssistFlyout,
		$GUIPersonaliseSnapAssistFlyoutTips
	))

	if (IsWin11) {
		$GUIStartPanel.controls.AddRange((
			$GUIStartTaskbarAlignmentPanel
		))

		$GUIStartTaskbarAlignmentPanel.controls.AddRange((
			$GUITaskbarAlignment,
			$GUIStartTaskbarAlignmentCenter,
			$GUIStartTaskbarAlignmentLeaf
		))

		if (Get-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarAl" -ErrorAction SilentlyContinue) {
			switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarAl" -ErrorAction SilentlyContinue) {
				"0" { $GUIStartTaskbarAlignmentLeaf.Checked = $True }
				"1" { $GUIStartTaskbarAlignmentCenter.Checked = $True }
			}
		} else {
			$GUIStartTaskbarAlignmentCenter.Checked = $True
		}

		$GUIStartPanel.controls.AddRange((
			$GUITaskbarWidgets,
			$GUITaskbarWidgetsRemove
		))
	}

	$GUIStartPanel.controls.AddRange((
		$GUITeamsAutostarting,
		$GUITeamsTaskbarChat,
		$GUIBingSearch,
		$GUITaskbarSuggestedContent,
		$GUISuggestionsDevice,
		$GUISearchBox,
		$GUIMergeTaskbarNever,
		$GUINotificationAlways,
		$GUICortana,
		$GUITaskView
	))
	
	$GUIXboxGamePanel.controls.AddRange((
		$GUIXboxGameBar,
		$GUIXboxGameBarTips,
		$GUIXboxGameMode,
		$GUIXboxGameDVR
	))

	<#
		.添加：隐私类
	#>
	$GUIPrivatePanel.controls.AddRange((
		$GUIScheduledTasks,
		$GUIPrivacyVoiceTyping,
		$GUIPrivacyContactsSpeech,
		$GUIPrivacyLanguageOptOut,
		$GUIPrivacyAds,
		$GUILocatonAware,
		$GUIPrivacySetSync,
		$GUIInkingTyping,
		$GUIShareUnpairedDevices,
		$GUILocationSensor,
		$GUIBiometrics,
		$GUICompatibleTelemetry,
		$GUIDiagnosticData,
		$GUITailoredExperiences,
		$GUIFeedbackNotifications,
		$GUILocationTracking,
		$GUIExperiencesTelemetry,
		$GUIPrivacyBackgroundAccess,
		$GUITimelineTime,
		$GUICollectActivity
	))

	if (IsWin11) {
		$GUIThisPC3D.Checked = $False
		$GUIThisPC3D.Enabled = $False

		$GUITimelineTime.Checked = $False
		$GUITimelineTime.Enabled = $False
		$GUICollectActivity.Checked = $False
		$GUICollectActivity.Enabled = $False
	} else {
		$GUIClassicModern.Checked = $true
		$GUIClassicModern.Enabled = $true

		$GUITimelineTime.Checked = $true
		$GUITimelineTime.Enabled = $true
		$GUICollectActivity.Checked = $true
		$GUICollectActivity.Enabled = $true
	}
	$GUIAdvOptionPanel.controls.AddRange((
		$GUISyncAllUser,
		$GUITaskBar,
		$GUIResetDesk
	))

	<#
		.右键菜单：优化类
	#>
	$GUIMenuAllSelClick = {
		$GUIOSOptionPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIMenuAllClearClick = {
		$GUIOSOptionPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIMenu.Items.Add($lang.AllSel).add_Click($GUIMenuAllSelClick)
	$GUIMenu.Items.Add($lang.AllClear).add_Click($GUIMenuAllClearClick)
	$GUIOSOptionPanel.ContextMenuStrip = $GUIMenu

	<#
		.右键菜单：网络优化
	#>
	$GUINetworkMenuAllSelClick = {
		$GUINetworkPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUINetworkMenuAllClearClick = {
		$GUINetworkPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUINetworkMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUINetworkMenu.Items.Add($lang.AllSel).add_Click($GUINetworkMenuAllSelClick)
	$GUINetworkMenu.Items.Add($lang.AllClear).add_Click($GUINetworkMenuAllClearClick)
	$GUINetworkPanel.ContextMenuStrip = $GUINetworkMenu

	<#
		.右键菜单：文件资源管理器
	#>
	$GUIFileExplorerMenuAllSelClick = {
		$GUIExplorerPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIFileExplorerMenuAllClearClick = {
		$GUIExplorerPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIFileExplorerMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIFileExplorerMenu.Items.Add($lang.AllSel).add_Click($GUIFileExplorerMenuAllSelClick)
	$GUIFileExplorerMenu.Items.Add($lang.AllClear).add_Click($GUIFileExplorerMenuAllClearClick)
	$GUIExplorerPanel.ContextMenuStrip = $GUIFileExplorerMenu

	<#
		.右键菜单：上下文菜单
	#>
	$GUIContextRightMenuAllSelClick = {
		$GUIContextMenuPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIContextRightMenuAllClearClick = {
		$GUIContextMenuPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIContextRightMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIContextRightMenu.Items.Add($lang.AllSel).add_Click($GUIContextRightMenuAllSelClick)
	$GUIContextRightMenu.Items.Add($lang.AllClear).add_Click($GUIContextRightMenuAllClearClick)
	$GUIContextMenuPanel.ContextMenuStrip = $GUIContextRightMenu

	<#
		.右键菜单：个性化
	#>
	$GUIPersonaliseMenuAllSelClick = {
		$GUIPersonalisePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIPersonaliseMenuAllClearClick = {
		$GUIPersonalisePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIPersonaliseMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIPersonaliseMenu.Items.Add($lang.AllSel).add_Click($GUIPersonaliseMenuAllSelClick)
	$GUIPersonaliseMenu.Items.Add($lang.AllClear).add_Click($GUIPersonaliseMenuAllClearClick)
	$GUIPersonalisePanel.ContextMenuStrip = $Personalise

	<#
		.右键菜单：开始菜单和任务栏
	#>
	$GUIStartMenuAllSelClick = {
		$GUIStartPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIStartMenuAllClearClick = {
		$GUIStartPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIStartMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIStartMenu.Items.Add($lang.AllSel).add_Click($GUIStartMenuAllSelClick)
	$GUIStartMenu.Items.Add($lang.AllClear).add_Click($GUIStartMenuAllClearClick)
	$GUIStartPanel.ContextMenuStrip = $GUIStartMenu

	<#
		.右键菜单：游戏
	#>
	$GUIGamingMenuAllSelClick = {
		$GUIXboxGamePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIGamingMenuAllClearClick = {
		$GUIXboxGamePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIGamingMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIGamingMenu.Items.Add($lang.AllSel).add_Click($GUIGamingMenuAllSelClick)
	$GUIGamingMenu.Items.Add($lang.AllClear).add_Click($GUIGamingMenuAllClearClick)
	$GUIXboxGamePanel.ContextMenuStrip = $GUIGamingMenu

	<#
		.右键菜单：隐私设置
	#>
	$GUIPriavteMenuAllSelClick = {
		$GUIPrivatePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIPriavteMenuAllClearClick = {
		$GUIPrivatePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIPriavteMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIPriavteMenu.Items.Add($lang.AllSel).add_Click($GUIPriavteMenuAllSelClick)
	$GUIPriavteMenu.Items.Add($lang.AllClear).add_Click($GUIPriavteMenuAllClearClick)
	$GUIPrivatePanel.ContextMenuStrip = $GUIPriavteMenu

	<#
		.右键菜单：其它
	#>
	$GUIOtherMenuAllSelClick = {
		$GUIOtherPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUIOtherMenuAllClearClick = {
		$GUIOtherPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIOtherMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIOtherMenu.Items.Add($lang.AllSel).add_Click($GUIOtherMenuAllSelClick)
	$GUIOtherMenu.Items.Add($lang.AllClear).add_Click($GUIOtherMenuAllClearClick)
	$GUIOtherPanel.ContextMenuStrip = $GUIOtherMenu

	<#
		.右键菜单：清理
	#>
	$GUICleanMenuAllSelClick = {
		$GUIClearPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $true
				}
			}
		}
	}
	$GUICleanMenuAllClearClick = {
		$GUIClearPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUICleanMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUICleanMenu.Items.Add($lang.AllSel).add_Click($GUICleanMenuAllSelClick)
	$GUICleanMenu.Items.Add($lang.AllClear).add_Click($GUICleanMenuAllClearClick)
	$GUIClearPanel.ContextMenuStrip = $GUICleanMenu

	<#
		.右键菜单：主界面
	#>
	$GUIAllClearClick = {
		$GUIOSOption.Checked = $False
		$GUIOSOptionPanel.Enabled = $False
		$GUIOSOptionPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}

		$GUINetwork.Checked = $False
		$GUINetworkPanel.Enabled = $False
		$GUINetworkPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}

		$GUIExplorer.Checked = $False
		$GUIExplorerPanel.Enabled = $False
		$GUIExplorerPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}

		$GUIContextMenu.Checked = $False
		$GUIContextMenuPanel.Enabled = $False
		$GUIContextMenuPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}

		$GUINotification.Checked = $False
		$GUINotificationPanel.Enabled = $False

		$GUIPagingSize.Checked = $False
		$GUIPagingSizePanel.Enabled = $False

		$GUIPersonalise.Checked = $False
		$GUIPersonalisePanel.Enabled = $False
		$GUIPersonalisePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}

		$GUIStart.Checked = $False
		$GUIStartPanel.Enabled = $False
		$GUIStartPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}

		$GUIXboxGame.Checked = $False
		$GUIXboxGamePanel.Enabled = $False
		$GUIXboxGamePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}

		$GUIPrivate.Checked = $False
		$GUIPrivatePanel.Enabled = $False
		$GUIPrivatePanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}

		$GUIOther.Checked = $False
		$GUIOtherPanel.Enabled = $False
		$GUIOtherPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}

		$GUIClear.Checked = $False
		$GUIClearPanel.Enabled = $False
		$GUIClearPanel.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.CheckBox]) {
				if ($_.Enabled) {
					$_.Checked = $false
				}
			}
		}
	}
	$GUIMainMenu = New-Object System.Windows.Forms.ContextMenuStrip
	$GUIMainMenu.Items.Add($lang.AllClear).add_Click($GUIAllClearClick)
	$GUIOS.ContextMenuStrip = $GUIMainMenu

	$NoSelectPowerSupply = @(8, 9, 10, 11, 14)
	Get-CimInstance -ClassName Win32_SystemEnclosure | ForEach-Object {
		if ($NoSelectPowerSupply -contains $_.SecurityStatus) {
			$GUIHibernation.Checked = $False
			$GUIPowerSupply.Checked = $False
		}
	}

	switch ($Global:IsLang) {
		"zh-CN" {
			$GUIOS.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$GUIOS.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$GUIOS.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$GUIOS.FormBorderStyle = 'Fixed3D'
	$GUIOS.ShowDialog() | Out-Null

	if (-not ($Force)) {
		ToMainpage -wait 2
	}
}

<#
	....................................
	Modules
	....................................
#>

<#
	.Take ownership to the right-click menu
	.Windows 11 上下文菜单传统、现代
#>
Function Win11ContextMenu
{
	param
	(
		[switch]$Classic,
		[switch]$Modern
	)

	if ($Classic) {
		Write-Host "   $($lang.ClassicMenu)"
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32") -ne $true) {
			New-Item "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" -force -ea SilentlyContinue | Out-Null
		}
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32' -Name '(default)' -Value '' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		RefreshIconCache
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Modern) {
		Write-Host "   $($lang.ModernMenu)"
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		RefreshIconCache
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Take ownership to the right-click menu
	.取得所有权到右键菜单
#>
Function TakeOwnership
{
	param
	(
		[switch]$Remove,
		[switch]$Add
	)

	Write-Host "   $($lang.TakeOwnership)"
	if ($Remove) {
		Write-Host "   $($lang.Delete)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Drive\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Add) {
		Write-Host "   $($lang.AddTo)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership" -force -ea SilentlyContinue | Out-Null }
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command") -ne $true) { New-Item "HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\*\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'AppliesTo' -Value "NOT (System.ItemPathDisplay:=\""$($env:SystemDrive)\Users\"" OR System.ItemPathDisplay:=\""$($env:SystemDrive)\ProgramData\"" OR System.ItemPathDisplay:=\""$($env:systemroot)\"" OR System.ItemPathDisplay:=\""$($env:systemroot)\System32\"" OR System.ItemPathDisplay:=\""$($env:SystemDrive)\Program Files\"" OR System.ItemPathDisplay:=\""$($env:SystemDrive)\Program Files (x86)\"")" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" /r && icacls "%1" /grant *S-1-3-4:F /t /c /l /q & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Directory\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" /r && icacls "%1" /grant *S-1-3-4:F /t /c /l /q & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name '(default)' -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name 'NoWorkingDirectory' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership' -Name "Position" -Value 'middle' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command' -Name '(default)' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\dllfile\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value 'cmd.exe /c takeown /f "%1" && icacls "%1" /grant *S-1-3-4:F /c /l & pause' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership' -Name 'HasLUAShield' -Value "" -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership' -Name "MUIVerb" -Value $($lang.TakeOwnership) -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command' -Name '(default)' -Value '"%1" %*' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\exefile\shell\TakeOwnership\command' -Name 'IsolatedCommand' -Value '"%1" %*' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		RefreshIconCache
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Always Show Copy Path Context Menu in Windows 10
	.在 Windows 10 中始终显示复制路径上下文菜单
#>
Function CopyPath
{
	param
	(
		[switch]$Remove,
		[switch]$Add
	)

	Write-Host "   $($lang.CopyPath)"
	if ($Remove) {
		Write-Host "   $($lang.Delete)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Add) {
		Write-Host "   $($lang.AddTo)".PadRight(22) -NoNewline
		if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath") -ne $true) {
			New-Item "HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath" -force -ea SilentlyContinue | Out-Null
		}
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name '(default)' -Value 'Copy &as path' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name 'MUIVerb' -Value '@shell32.dll,-30329' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name 'Icon' -Value 'imageres.dll,-5302' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name 'InvokeCommandOnSelection' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name 'VerbHandler' -Value '{f3d06e7c-1e45-4a26-847e-f9fcdee59be0}' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\Allfilesystemobjects\shell\windows.copyaspath' -Name 'VerbName' -Value 'copyaspath' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Windows 11 TPM Setup Check
	.Windows 11 TPM 安装检查
#>
Function Win11TPMSetup
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	Write-Host "   $($lang.TPMSetup)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\LabConfig" -Name 'BypassCPUCheck' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\LabConfig" -Name 'BypassStorageCheck' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\LabConfig" -Name 'BypassRAMCheck' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\LabConfig" -Name 'BypassTPMCheck' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\LabConfig" -Name 'BypassSecureBootCheck' -Force -ErrorAction SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if((Test-Path -LiteralPath "HKLM:\SYSTEM\Setup\LabConfig") -ne $true) {  New-Item "HKLM:\SYSTEM\Setup\LabConfig" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\LabConfig' -Name 'BypassCPUCheck' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\LabConfig' -Name 'BypassStorageCheck' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\LabConfig' -Name 'BypassRAMCheck' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\LabConfig' -Name 'BypassTPMCheck' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\LabConfig' -Name 'BypassSecureBootCheck' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Windows 11 Bypass the TPM to prevent you from upgrading the system
	.Windows 11 绕过 TPM 阻止您升级系统
#>
Function Win11TPMUpdate
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	Write-Host "   $($lang.TPMUpdate)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SYSTEM\Setup\MoSetup" -Name 'AllowUpgradesWithUnsupportedTPMOrCPU' -Force -ErrorAction SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if((Test-Path -LiteralPath "HKLM:\SYSTEM\Setup\MoSetup") -ne $true) {  New-Item "HKLM:\SYSTEM\Setup\MoSetup" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\Setup\MoSetup' -Name 'AllowUpgradesWithUnsupportedTPMOrCPU' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.The Windows welcome experiences after updates and occasionally when I sign in to highlight what's new and suggested
	.更新后的 Windows 欢迎体验，偶尔在我登录以突出显示新功能和建议时
#>
Function WelcomeExperience
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	Write-Host "   $($lang.UpdateWelcomeExperience)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-310093Enabled -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-310093Enabled -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.First sign-in animation after the upgrade
	.升级后的首次登录动画
#>
Function FirstLogonAnimation
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UpdateFirstLogonAnimation)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name EnableFirstLogonAnimation -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name EnableFirstLogonAnimation -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Keep space
	.保留空间
#>
Function KeepSpace
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.KeepSpace)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		DISM.exe /Online /Set-ReservedStorageState /State:Enabled | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Close)".PadRight(22) -NoNewline
		DISM.exe /Online /Set-ReservedStorageState /State:Disabled | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Hibernation
	.休眠
#>
Function Hibernation
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Hibernation)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Start-Process 'powercfg.exe' -ArgumentList '/h on' -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Close)".PadRight(22) -NoNewline
		Start-Process 'powercfg.exe' -Verb runAs -ArgumentList '/h off' -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Power supply solution optimized after "high performance"
	.电源方案为“高性能”后优化
#>
Function PowerSupply
{
	param
	(
		[switch]$Restore,
		[switch]$Optimize
	)

	Write-Host "   $($lang.PowerSupply)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		powercfg -restoredefaultschemes
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Optimize) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
		powercfg -change -monitor-timeout-ac 0
		powercfg -change -monitor-timeout-dc 0
		powercfg -change -disk-timeout-ac 0
		powercfg -change -disk-timeout-dc 5
		powercfg -change -standby-timeout-ac 0
		powercfg -change -standby-timeout-dc 60
		powercfg -change -hibernate-timeout-ac 0
		powercfg -change -hibernate-timeout-dc 300
		powercfg /SETACVALUEINDEX 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
		powercfg /SETDCVALUEINDEX 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	."This app is preventing shutdown or restart" screen
	."此应用正在阻止关机或重新启动" 屏幕
#>
Function AppRestartScreen
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.AppRestartScreen)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'MenuShowDelay' -Value '400' -PropertyType String -Force -ea SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'WaitToKillAppTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'HungAppTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'AutoEndTasks' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'LowLevelHooksTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name 'WaitToKillServiceTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name 'AutoEndTasks' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name 'LowLevelHooksTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Remove-ItemProperty -Path "Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop" -Name 'WaitToKillServiceTimeout' -Force -ErrorAction SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'MenuShowDelay' -Value '0' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'WaitToKillAppTimeout' -Value '5000' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'HungAppTimeout' -Value '4000' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'LowLevelHooksTimeout' -Value 4096 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'WaitToKillServiceTimeout' -Value 8192 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'LowLevelHooksTimeout' -Value 4096 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'Registry::\HKEY_USERS\.DEFAULT\Control Panel\Desktop' -Name 'WaitToKillServiceTimeout' -Value 8192 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Shortcut small arrow and suffix
	.快捷方式小箭头和后缀
#>
Function ShortcutArrow
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ShortcutArrow)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\IE.AssocFile.URL' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\InternetShortcut' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\lnkfile' -Name 'IsShortcut' -Value "" -PropertyType String -Force -ea SilentlyContinue | out-null
		Remove-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Force -ea SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name link -Force -ErrorAction SilentlyContinue
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Delete)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Value "$($env:systemroot)\system32\imageres.dll,197" -PropertyType String -Force -ea SilentlyContinue | out-null
		Remove-Item -Path "$($env:USERPROFILE)\AppData\Local\iconcache.db" -ErrorAction SilentlyContinue
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'link' -Value ([byte[]](0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.NumLock key will light up automatically after power on
	.NumLock 键开机后自动亮起
#>
Function Numlock
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Numlock)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -Path "Registry::HKEY_USERS\.DEFAULT\Control Panel\Keyboard" -Name InitialKeyboardIndicators -PropertyType String -Value 2147483650 -Force -ErrorAction SilentlyContinue | Out-Null
		Add-Type -AssemblyName System.Windows.Forms
		If (-not ([System.Windows.Forms.Control]::IsKeyLocked('NumLock'))) {
			$wsh = New-Object -ComObject WScript.Shell
			$wsh.SendKeys('{NUMLOCK}')
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -Path "Registry::HKEY_USERS\.DEFAULT\Control Panel\Keyboard" -Name InitialKeyboardIndicators -PropertyType String -Value 2147483648 -Force -ErrorAction SilentlyContinue | Out-Null
		Add-Type -AssemblyName System.Windows.Forms
		If ([System.Windows.Forms.Control]::IsKeyLocked('NumLock')) {
			$wsh = New-Object -ComObject WScript.Shell
			$wsh.SendKeys('{NUMLOCK}')
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.文件资源管理器
#>

<#
	.Each uses a separate process after opening
	.打开后每个使用单独进程
#>
Function SeparateProcess
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ExplorerProcess)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'SeparateProcess' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'SeparateProcess' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Restart apps after signing in
	.登录后重启应用
#>
Function RestartApps
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.RestartApps)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'RestartApps' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'RestartApps' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Item check boxes
	.项目复选框
#>
Function CheckBoxes
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.CheckBoxes)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'AutoCheckSelect' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'AutoCheckSelect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Thumbnail cache
	.缩略图缓存
#>
Function ThumbnailCache
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThumbnailCache)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\Thumbnail Cache" -Name Autorun -PropertyType DWord -Value 3 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\Thumbnail Cache" -Name Autorun -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.Show file name extensions
	.显示文件扩展名
#>
Function ExplorerOpenTo
{
	param
	(
		[switch]$ThisPC,
		[switch]$QuickAccess
	)

	if ($ThisPC) {
		Write-Host "   $($lang.ExplorerTo -f $($lang.ExplorerToThisPC))"
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "LaunchTo" -PropertyType DWord -Value 2 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($QuickAccess) {
		Write-Host "   $($lang.ExplorerTo -f $($lang.ExplorerToQuickAccess))"
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "LaunchTo" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Aero Shake Shake to the lowest function
	.Aero Shake 摇一摇降到最低功能
#>
Function AeroShake
{
	param
	(
		[switch]$AllUser,
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.AeroShake)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name 'DisallowShaking' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "NoWindowMinimizingShortcuts" -ErrorAction SilentlyContinue | Out-Null

		if ($AllUser) {
			Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "NoWindowMinimizingShortcuts" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name 'DisallowShaking' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "NoWindowMinimizingShortcuts" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null

		if ($AllUser) {
			New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "NoWindowMinimizingShortcuts" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Show file name extensions
	.显示文件扩展名
#>
Function FileExtensions
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	Write-Host "   $($lang.FileExtensions)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideFileExt -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name HideFileExt -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.个性化
#>
<#
	.暗黑主题应用到：应用程序
#>
Function DarkModeToApps
{
	param
	(
		[switch]$Dark,
		[switch]$Light
	)

	Write-Host "   $($lang.DarkMode)$($lang.DarkApps)"
	if ($Dark) {
		Write-Host "   $($lang.Dark)"
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Light) {
		Write-Host "   $($lang.Light)"
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.暗黑主题应用到：系统
#>
Function DarkModeToSystem
{
	param
	(
		[switch]$Dark,
		[switch]$Light
	)

	Write-Host "   $($lang.DarkMode)$($lang.DarkSystem)"
	if ($Dark) {
		Write-Host "   $($lang.Dark)"
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Light) {
		Write-Host "   $($lang.Light)"
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.透明效果
#>
Function TransparencyEffects
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.TransparencyEffects)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name EnableTransparency -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name EnableTransparency -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.最大化按钮，显示布局
#>
Function SnapAssistFlyout
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.SnapAssistFlyout)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name EnableSnapAssistFlyout -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name EnableSnapAssistFlyout -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.开始菜单和任务栏
#>
<#
	.Taskbar alignment
	.任务栏对齐
#>
Function TaskbarAlignment
{
	param
	(
		[switch]$Left,
		[switch]$Center
	)

	if ($Left) {
		Write-Host "   $($lang.TaskbarAlignment)$($lang.TaskbarAlignmentLeft)"
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name TaskbarAl -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Center) {
		Write-Host "   $($lang.TaskbarAlignment)$($lang.TaskbarAlignmentCentered)"
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name TaskbarAl -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Taskbar widget icon
	.任务栏小组件图标
#>
Function TaskbarWidgets
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	$MarkHasBeenInstalled = $False
	Get-AppxProvisionedPackage -Online | ForEach-Object {
		if ($_.DisplayName -like "MicrosoftWindows.Client.WebExperience") {
			$MarkHasBeenInstalled = $True
		}
	}

	Write-Host "   $($lang.TaskbarWidgets)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		if ($MarkHasBeenInstalled) {
			New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name TaskbarDa -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		if ($MarkHasBeenInstalled) {
			New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name TaskbarDa -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Taskbar widget icon
	.任务栏小组件图标
#>
Function TaskbarWidgetsRemove
{
	param
	(
		[switch]$Remove,
		[switch]$Restore
	)

	Write-Host "   $($lang.TaskbarWidgetsRemove)"
	if ($Remove) {
		Write-Host "   $($lang.Delete)".PadRight(22) -NoNewline
		Get-AppXProvisionedPackage -Online | Where-Object DisplayName -Like "MicrosoftWindows.Client.WebExperience*" | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction SilentlyContinue | Out-Null
		Get-AppxPackage "MicrosoftWindows.Client.WebExperience*" -ErrorAction SilentlyContinue | Remove-AppxPackage -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Start-Process "ms-windows-store://pdp/?ProductId=9MSSGKG348SP"
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Microsoft Teams autostarting
	.Microsoft Teams 自动启动
#>
Function TeamsAutostarting
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	$MarkHasBeenInstalled = $False
	Get-AppxProvisionedPackage -Online | ForEach-Object {
		if ($_.DisplayName -like "MicrosoftTeams") {
			$MarkHasBeenInstalled = $True
		}
	}

	Write-Host "   $($lang.TeamsAutostarting)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if ($MarkHasBeenInstalled) {
			if (-not (Test-Path -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData\MicrosoftTeams_8wekyb3d8bbwe\TeamsStartupTask"))
			{
				New-Item -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData\MicrosoftTeams_8wekyb3d8bbwe\TeamsStartupTask" -Force -ErrorAction SilentlyContinue | Out-Null
			}
			New-ItemProperty -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData\MicrosoftTeams_8wekyb3d8bbwe\TeamsStartupTask" -Name State -PropertyType DWord -Value 2 -Force -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
		}
	}

	if ($Disable) {
		Write-Host "   $($lang.Close)".PadRight(22) -NoNewline
		if ($MarkHasBeenInstalled) {
			if (-not (Test-Path -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData\MicrosoftTeams_8wekyb3d8bbwe\TeamsStartupTask"))
			{
				New-Item -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData\MicrosoftTeams_8wekyb3d8bbwe\TeamsStartupTask" -Force -ErrorAction SilentlyContinue | Out-Null
			}
			New-ItemProperty -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData\MicrosoftTeams_8wekyb3d8bbwe\TeamsStartupTask" -Name State -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
		}
	}
}

<#
	.Microsoft Chats icons
	.Microsoft Chats 图标
#>
Function TeamsTaskbarChat
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	Write-Host "   $($lang.FileExtensions)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name TaskbarMn -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name TaskbarMn -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Microsoft Chats icons
	.开始菜单中的必应搜索
#>
Function BingSearch
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.BingSearch)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name DisableSearchBoxSuggestions -Force -ErrorAction SilentlyContinue | Out-Null
		RestartExplorer
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if (-not (Test-Path -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer"))
		{
			New-Item -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Force
		}
		New-ItemProperty -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name DisableSearchBoxSuggestions -PropertyType DWord -Value 1 -Force
		RestartExplorer
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Suggested me content in the Settings app
	.在“设置”应用中向我推荐内容
#>
Function TaskbarSuggestedContent
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	$cdm = @(
		"SubscribedContent-314559Enabled"
		"SubscribedContent-338388Enabled"
		"SubscribedContent-338389Enabled"
		"SubscribedContent-338393Enabled"  # tips
		"SubscribedContent-353694Enabled"
		"SubscribedContent-353696Enabled"
		"SubscribedContent-338387Enabled"
		"SubscribedContentEnabled"
		"SystemPaneSuggestionsEnabled"
	)

	Write-Host "   $($lang.TaskbarSuggestedContent)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Force -ErrorAction SilentlyContinue | Out-Null
		foreach ($item in $cdm) {
			New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name $item -Value 1 -PropertyType DWord -Force -ea SilentlyContinue
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Force -ErrorAction SilentlyContinue | Out-Null
		foreach ($item in $cdm) {
			New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name $item -Value 0 -PropertyType DWord -Force -ea SilentlyContinue
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Suggested me content in the Settings app
	.在“设置”应用中向我推荐内容
#>
Function SuggestionsDevice
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.SuggestionsDevice)"
	if ($Enable) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		if((Test-Path -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\UserProfileEngagement") -ne $true) {
			New-Item "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\UserProfileEngagement" -force -ea SilentlyContinue | Out-Null
		}
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\UserProfileEngagement -Name ScoobeSystemSettingEnabled -PropertyType DWord -Value 1 -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		if((Test-Path -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\UserProfileEngagement") -ne $true) {
			New-Item "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\UserProfileEngagement" -force -ea SilentlyContinue | Out-Null
		}
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\UserProfileEngagement -Name ScoobeSystemSettingEnabled -PropertyType DWord -Value 0 -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Search bar: display search icon
	.搜索栏：显示搜索图标
#>
Function SearchBox
{
	param
	(
		[switch]$Hide,
		[switch]$SearchIcon,
		[switch]$SearchBox
	)

	Write-Host "   $($lang.SearchBox)"
	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($SearchIcon) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($SearchBox) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.User Account Control (UAC): Never notify me
	.用户账户控制 (UAC)：从不通知我
#>
Function UACNever
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UAC)"
	if ($Enable) {
		Write-Host "   $($lang.UACNever)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 5 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'PromptOnSecureDesktop' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.File transfer dialog: brief information, detailed information
	.文件传输对话框：简略信息、详细信息
#>
Function FileTransferDialog
{
	param
	(
		[switch]$Detailed,
		[switch]$Simple
	)

	Write-Host "   $($lang.FileTransfer)"
	if ($Detailed) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager" -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager -Name EnthusiastMode -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Simple) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Smart Screen for Microsoft Store apps
	.适用于 Microsoft Store 应用的 Smart Screen
#>
Function SmartScreenApps
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.SmartScreenApps)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Type String -Value "RequireAdmin"
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" -Name "EnableWebContentEvaluation" -ErrorAction SilentlyContinue
	
		Get-ChildItem -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\*edge*" -Name -ErrorAction SilentlyContinue | ForEach-Object {
			if (Test-Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -PathType Container) {
				Remove-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -ErrorAction SilentlyContinue | Out-Null
				Remove-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "PreventOverride" -ErrorAction SilentlyContinue | Out-Null
			}
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "SmartScreenEnabled" -Type String -Value "Off"
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" -Name "EnableWebContentEvaluation" -Type DWord -Value 0
	
		Get-ChildItem -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\*edge*" -Name -ErrorAction SilentlyContinue | ForEach-Object {
			if (Test-Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -PathType Container) {
				Set-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "EnabledV9" -Type DWord -Value 0 | Out-Null
				Set-ItemProperty -Path "HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\$($_)\MicrosoftEdge\PhishingFilter" -Name "PreventOverride" -Type DWord -Value 0 | Out-Null
			}
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Smart Screen for Microsoft Store apps
	.适用于 Microsoft Store 应用的 Smart Screen
#>
Function SmartScreenSafe
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.SmartScreenSafe)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments -Name SaveZoneInformation -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if (-not (Test-Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments))
		{
			New-Item -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments -Force -ErrorAction SilentlyContinue | Out-Null
		}
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments -Name SaveZoneInformation -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Easy access keyboard stuff
	.轻松访问键盘的东西
#>
Function EasyAccessKeyboard
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.EasyAccessKeyboard)"
	if ($Enable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\StickyKeys" "Flags" "450" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\Keyboard Response" "Flags" "126" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\ToggleKeys" "Flags" "62" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\StickyKeys" "Flags" "506" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\Keyboard Response" "Flags" "122" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\ToggleKeys" "Flags" "58" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Automatic maintenance plan
	.自动维护计划
#>
Function Maintain
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Maintain)"
	if ($Enable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" -Name "MaintenanceDisabled" -ErrorAction SilentlyContinue
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance' -Name 'MaintenanceDisabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Customer experience improvement plan
	.客户体验改善计划
#>
Function Experience
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Experience)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows" -Name "CEIPEnable" -ErrorAction SilentlyContinue
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows' -Name 'CEIPEnable' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Common file type safety warnings
	.常见文件类型安全警告
#>
Function SafetyWarnings
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.SafetyWarnings)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations") -ne $true) { New-Item "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'LowRiskFileTypes' -Value '.exe;.reg;.msi;.bat;.cmd;.com;.vbs;.hta;.scr;.pif;.js;' -PropertyType String -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
} 

<#
	.QOS service
	.QOS 服务
#>
Function QOS
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.QOS)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\nvspbind")\nvspbind.exe" -ArgumentList "/e ""*"" ms_pacer" -Wait -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\nvspbind")\nvspbind.exe" -ArgumentList "/d ""*"" ms_pacer" -Wait -WindowStyle Minimized
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Network tuning function
	.网络调优功能
#>
Function NetworkTuning
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.NetworkTuning)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		netsh interface tcp set global autotuninglevel=normal | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		netsh interface tcp set global autotuninglevel=disabled | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.ECN function
	.ECN 功能
#>
Function ECN
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ECN)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		netsh int tcp set global ecn=enabled | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		netsh int tcp set global ecn=disable | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Windows error recovery
	.Windows 错误恢复
#>
Function ErrorRecovery
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ErrorRecovery)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /set {default} bootstatuspolicy DisplayAllFailures | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} bootstatuspolicy ignoreallfailures | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.DEP and PAE
	.DEP 和 PAE
#>
Function DEPPAE
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.DEP)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /deletevalue `{current`} pae 
		bcdedit /set `{current`} nx OptIn
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} nx AlwaysOff
		bcdedit /set `{current`} pae ForceDisable
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Automatic repair function after power failure
	.断电后自动修复功能
#>
Function PowerFailure
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PowerFailure)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} Recoveryenabled Yes | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} Recoveryenabled No | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.The diagnostics tracking scheduled tasks
	.诊断跟踪计划任务
#>
Function ScheduledTasks
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	$tasks = @(
		<#
			.Windows base scheduled tasks
		#>
		# Collects program telemetry information if opted-in to the Microsoft Customer Experience Improvement Program
		"\Microsoft\Windows\Application Experience\ProgramDataUpdater"

		# This task collects and uploads autochk SQM data if opted-in to the Microsoft Customer Experience Improvement Program
		"\Microsoft\Windows\Autochk\Proxy"

		# If the user has consented to participate in the Windows Customer Experience Improvement Program, this job collects and sends usage data to Microsoft
		"\Microsoft\Windows\Customer Experience Improvement Program\Consolidator"

		# The USB CEIP (Customer Experience Improvement Program) task collects Universal Serial Bus related statistics and information about your machine and sends it to the Windows Device Connectivity engineering group at Microsoft
		"\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip"

		# The Windows Disk Diagnostic reports general disk and system information to Microsoft for users participating in the Customer Experience Program
		"\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"

		# This task shows various Map related toasts
		"\Microsoft\Windows\Maps\MapsToastTask"

		# This task checks for updates to maps which you have downloaded for offline use
		"\Microsoft\Windows\Maps\MapsUpdateTask"

		# Initializes Family Safety monitoring and enforcement
		"\Microsoft\Windows\Shell\FamilySafetyMonitor"

		# Synchronizes the latest settings with the Microsoft family features service
		"\Microsoft\Windows\Shell\FamilySafetyRefreshTask"

		# XblGameSave Standby Task
		"\Microsoft\XblGameSave\XblGameSaveTask"
	)

	Write-Host "   $($lang.ScheduledTasks)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		foreach ($task in $tasks) {
			$parts = $task.split('\')
			$name = $parts[-1]
			$path = $parts[0..($parts.length-2)] -join '\'
		
			Enable-ScheduledTask -TaskName "$name" -TaskPath "$path" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Red
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline

		foreach ($task in $tasks) {
			$parts = $task.split('\')
			$name = $parts[-1]
			$path = $parts[0..($parts.length-2)] -join '\'
		
			Disable-ScheduledTask -TaskName "$name" -TaskPath "$path" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Automatic download and installation of Windows updates
	.自动下载和安装 Windows 更新
#>
Function UpdateAutoDownload
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UpdateAutoDownload)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "NoAutoUpdate" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "AUOptions" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "AUOptions" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "ScheduledInstallDay" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "ScheduledInstallTime" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'NoAutoUpdate' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'AUOptions' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'ScheduledInstallDay' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'ScheduledInstallTime' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Disable seeding of updates to other computers via Group Policies
	.通过组策略禁用对其他计算机的更新种子
#>
Function UpdatePolicies
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UpdatePolicies)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" -Name "DODownloadMode" -ErrorAction SilentlyContinue
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" -Name 'DODownloadMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Automatic driver update
	.自动驱动程序更新
#>
Function UpdateAutoDrive
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UpdateAutoDrive)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" -Name 'SearchOrderConfig' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" -Name 'SearchOrderConfig' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Windows Update: 'Updates are available' message
	.Windows 更新：有可用更新消息
#>
Function UpdateAreAvailable
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.UpdateAreAvailable)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Start-Process "takeown" -ArgumentList "/F $env:WinDIR\System32\MusNotification.exe" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotification.exe /remove:d Everyone" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotification.exe /grant Everyone:F" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotification.exe /setowner ""NT SERVICE\TrustedInstaller""" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotification.exe /remove:g Everyone" -WindowStyle Hidden

		Start-Process "takeown" -ArgumentList "/F $env:WinDIR\System32\MusNotificationUx.exe" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotificationUx.exe /remove:d Everyone" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotificationUx.exe /grant Everyone:F" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotificationUx.exe /setowner ""NT SERVICE\TrustedInstaller""" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotificationUx.exe /remove:g Everyone" -WindowStyle Hidden
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Start-Process "takeown" -ArgumentList "/F $env:WinDIR\System32\MusNotification.exe" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotification.exe /deny Everyone:(X)" -WindowStyle Hidden
		Start-Process "takeown" -ArgumentList "/F $env:WinDIR\System32\MusNotificationUx.exe" -WindowStyle Hidden
		Start-Process "icacls" -ArgumentList "$env:WinDIR\System32\MusNotificationUx.exe /deny Everyone:(X)" -WindowStyle Hidden
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.It is forbidden to send voice, ink and typing samples to MS (so Cortana can learn to recognize you)
	.向 MS 发送语音、墨迹和打字样本 ( 因此 Cortana 可以学习识别您 )
#>
Function PrivacyVoiceTyping
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyVoiceTyping)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Personalization\Settings" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Personalization\Settings" "AcceptedPrivacyPolicy" "1" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Personalization\Settings" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Personalization\Settings" "AcceptedPrivacyPolicy" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Send contacts to MS ( so Cortana can compare speech etc samples )
	.向 MS 发送联系人 ( 因此 Cortana 可以比较语音等样本 )
#>
Function PrivacyContactsSpeech
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyContactsSpeech)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore" "HarvestContacts" "1" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore" "HarvestContacts" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.让网站通过访问我的语言列表来提供本地相关内容
	.Let websites provide locally relevant content by accessing my language list
#>
Function PrivacyLanguageOptOut
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyLanguageOptOut)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Control Panel\International\User Profile" -Name "HttpAcceptLanguageOptOut" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Control Panel\International\User Profile" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Control Panel\International\User Profile" "HttpAcceptLanguageOptOut" 0 -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Apps use my advertising ID for experiencess across apps
	.让应用使用我的广告 ID 进行跨应用体验
#>
Function PrivacyAds
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyAds)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo" -Name "Enabled" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo" "Enabled" 0 -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Locaton aware printing (changes default based on connected network)
	.位置感知打印 ( 根据连接的网络更改默认值 )
#>
Function PrivacyLocatonAware
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyLocatonAware)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\Printers\Defaults" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Input\TIPC" -Name "Enabled" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Printers\Defaults" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Printers\Defaults" "NetID" "{00000000-0000-0000-0000-000000000000}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Input\TIPC" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Input\TIPC" "Enabled" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Synchronisation of settings
	.设置同步
#>
Function PrivacySetSync
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	$groups = @(
		"Accessibility"
		"AppSync"
		"BrowserSettings"
		"Credentials"
		"DesktopTheme"
		"Language"
		"PackageState"
		"Personalization"
		"StartLayout"
		"Windows"
	)

	Write-Host "   $($lang.PrivacySetSync)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "BackupPolicy" 0x3c -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "DeviceMetadataUploaded" 0 -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "PriorLogons" 1 -ErrorAction SilentlyContinue | Out-Null
		foreach ($group in $groups) {
			New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\$group" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
			Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\$group" "Enabled" "1" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "BackupPolicy" 0x3c -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "DeviceMetadataUploaded" 0 -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync" "PriorLogons" 1 -ErrorAction SilentlyContinue | Out-Null
		foreach ($group in $groups) {
			New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\$group" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
			Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\$group" "Enabled" "0" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Personalization of inking and typing
	.隐私：墨迹书写和打字个性化
#>
Function PrivacyInkingTyping
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyInkingTyping)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" "RestrictImplicitInkCollection" "0" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" "RestrictImplicitTextCollection" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" "RestrictImplicitInkCollection" "1" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\InputPersonalization" "RestrictImplicitTextCollection" "1" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Share information with unpaired devices
	.隐私：与未配对设备共享信息
#>
Function PrivacyShareUnpairedDevices
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyShareUnpairedDevices)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\LooselyCoupled" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\LooselyCoupled" "Type" "LooselyCoupled" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\LooselyCoupled" "Value" "Deny" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\LooselyCoupled" "InitialAppValue" "Unspecified" -ErrorAction SilentlyContinue | Out-Null
		foreach ($key in (Get-ChildItem "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global")) {
		    if ($key.PSChildName -EQ "LooselyCoupled") {
		        continue
		    }
		    Set-ItemProperty -Path ("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\" + $key.PSChildName) "Type" "InterfaceClass" -ErrorAction SilentlyContinue | Out-Null
		    Set-ItemProperty -Path ("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\" + $key.PSChildName) "Value" "Deny" -ErrorAction SilentlyContinue | Out-Null
		    Set-ItemProperty -Path ("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeviceAccess\Global\" + $key.PSChildName) "InitialAppValue" "Unspecified" -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Windows Hello Biometrics
	.隐私：Windows Hello 生物识别
#>
Function PrivacyBiometrics
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyLocationSensor)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Biometrics" -Name "Enabled" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Policies\Microsoft\Biometrics" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Biometrics" "Enabled" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Compatibility Telemetry
	.隐私：兼容性遥测
#>
Function PrivacyCompatibleTelemetry
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyCompatibleTelemetry)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\CompatTelRunner.exe" -Name "Debugger" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\CompatTelRunner.exe" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\CompatTelRunner.exe" "Debugger" "%windir%\system32\taskkill.exe" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Diagnostic data
	.隐私：诊断数据
#>
Function PrivacyDiagnosticData
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyDiagnosticData)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Get-Service -Name DiagTrack | Set-Service -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
		Get-Service -Name DiagTrack | Start-Service -ErrorAction SilentlyContinue | Out-Null
		Get-NetFirewallRule -Group DiagTrack | Set-NetFirewallRule -Enabled True -Action Allow -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Get-Service -Name DiagTrack | Stop-Service -Force -ErrorAction SilentlyContinue | Out-Null
		Get-Service -Name DiagTrack | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
		Get-NetFirewallRule -Group DiagTrack | Set-NetFirewallRule -Enabled False -Action Block -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Tailored experiences
	.隐私：量身定制的体验
#>
Function PrivacyTailoredExperiences
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.TailoredExperiences)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" "TailoredExperiencesWithDiagnosticDataEnabled" "2" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" "TailoredExperiencesWithDiagnosticDataEnabled" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Feedback notifications
	.隐私：反馈通知
#>
Function PrivacyFeedbackNotifications
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyFeedbackNotifications)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Siuf\Rules" -Name "NumberOfSIUFInPeriod" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Siuf\Rules" -Name "PeriodInNanoSeconds" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Siuf\Rules" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Siuf\Rules" "NumberOfSIUFInPeriod" "0" -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Siuf\Rules" "PeriodInNanoSeconds" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Location tracking
	.隐私：位置跟踪
#>
Function PrivacyLocationTracking
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyLocationTracking)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" "Value" "Allow" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" "Value" "Deny" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Location sensor
	.隐私：位置传感器
#>
Function PrivacyLocationSensor
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyLocationSensor)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-45056BFE4B44}" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-45056BFE4B44}" "SensorPermissionState" "1" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-45056BFE4B44}" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-45056BFE4B44}" "SensorPermissionState" "0" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Connected User Experiences and Telemetry
	.隐私：互联用户体验和遥测
#>
Function PrivacyExperiencesTelemetry
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ExperiencesTelemetry)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Policies\Microsoft\Windows\DataCollection" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Windows\DataCollection" "AllowTelemetry" "3" -ErrorAction SilentlyContinue | Out-Null

		Get-Service -Name DiagTrack | Set-Service -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
		Get-Service -Name DiagTrack | Start-Service -ErrorAction SilentlyContinue | Out-Null
		Get-NetFirewallRule -Group DiagTrack | Set-NetFirewallRule -Enabled True -Action Allow -ErrorAction SilentlyContinue | Out-Null

		Get-Service -Name "dmwappushservice" | Set-Service -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
		Start-Service "dmwappushservice" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\Software\Policies\Microsoft\Windows\DataCollection" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Windows\DataCollection" "AllowTelemetry" "0" -ErrorAction SilentlyContinue | Out-Null

		Get-Service -Name DiagTrack | Stop-Service -Force -ErrorAction SilentlyContinue | Out-Null
		Get-Service -Name DiagTrack | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
		Get-NetFirewallRule -Group DiagTrack | Set-NetFirewallRule -Enabled False -Action Block -ErrorAction SilentlyContinue | Out-Null

		Get-Service -Name "dmwappushservice" | Set-Service -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
		Stop-Service "dmwappushservice" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}



<#
	.Privacy: Background access of default apps
	.隐私：默认应用的后台访问
#>
Function PrivacyBackgroundAccess
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PrivacyBackgroundAccess)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		foreach ($key in (Get-ChildItem "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications")) {
			Remove-ItemProperty -Path ("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications\" + $key.PSChildName) -Name 'Disabled' -Force -ErrorAction SilentlyContinue | out-null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		foreach ($key in (Get-ChildItem "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications")) {
			Set-ItemProperty -Path ("HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications\" + $key.PSChildName) "Disabled" 1 -ErrorAction SilentlyContinue | Out-Null
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Dismiss Microsoft Defender offer in the Windows Security about signing in Microsoft account
	.在 Windows 安全中心关闭 Microsoft Defender 提供的有关登录 Microsoft 帐户的信息
#>
Function DismissMSAccount
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.DefenderLoginAccount)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows Security Health\State" -Name 'AccountProtection_MicrosoftAccount_Disconnected' -Force -ErrorAction SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows Security Health\State" -Name AccountProtection_MicrosoftAccount_Disconnected -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Dismiss Microsoft Defender offer in the Windows Security about turning on the SmartScreen filter for Microsoft Edge
	.在 Windows 安全中心关闭 Microsoft Defender 提供的有关打开 Microsoft Edge 的 SmartScreen 过滤器的信息
#>
Function DismissSmartScreenFilter
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.DefenderLoginAccount)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows Security Health\State" -Name 'AppAndBrowser_EdgeSmartScreenOff' -Force -ErrorAction SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows Security Health\State" -Name AppAndBrowser_EdgeSmartScreenOff -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Privacy: Timeline time
	.隐私：时间轴时间
#>
Function TimelineTime
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.TimelineTime)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Privacy: Collect activity history
	.隐私：收集活动历史记录
#>
Function CollectActivity
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.CollectActivity)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'PublishUserActivities' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'PublishUserActivities' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.IE Setting proxy does not take effect
	.IE 设置代理不生效
#>
Function IEProxy
{
	Write-Host "   $($lang.IEProxy)"
	Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
	"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections [1 7 17]" | Out-File -FilePath "$env:TEMP\ie_proxy.ini" -Encoding ASCII
	Start-Process "regini" -ArgumentList "$env:TEMP\ie_proxy.ini" -WindowStyle Minimized
	Remove-Item -Path "$env:TEMP\ie_proxy.ini" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.IE automatically detects settings
	.IE 自动检测设置
#>
Function AutoDetect
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.IEAutoSet)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoDetect' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoDetect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Network Discovery File and Printers Sharing
	.网络发现文件和打印机共享
#>
Function NetworkDiscovery
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	$FirewallRules = @(
		# File and printer sharing
		"@FirewallAPI.dll,-32752",

		# Network discovery
		"@FirewallAPI.dll,-28502"
	)

	Write-Host "   $($lang.NetworkDiscovery)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if ((Get-CimInstance -ClassName CIM_ComputerSystem).PartOfDomain -eq $false)
		{
			Set-NetFirewallRule -Group $FirewallRules -Profile Private -Enabled True -ErrorAction SilentlyContinue | Out-Null
			Set-NetFirewallRule -Profile Public, Private -Name FPS-SMB-In-TCP -Enabled True -ErrorAction SilentlyContinue | Out-Null
			Set-NetConnectionProfile -NetworkCategory Private
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
		}
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Get-CimInstance -ClassName CIM_ComputerSystem).PartOfDomain -eq $false)
		{
			Set-NetFirewallRule -Group $FirewallRules -Profile Private -Enabled False -ErrorAction SilentlyContinue | Out-Null
			Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
		} else {
			Write-Host "   - $($lang.Inoperable)`n" -ForegroundColor Red
		}
	}
}

<#
	.Network adapters power management
	.网络适配器电源管理
#>
Function NetworkAdaptersSavePower
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	$Adapters = Get-NetAdapter -Physical | Get-NetAdapterPowerManagement | Where-Object -FilterScript { $_.AllowComputerToTurnOffDevice -ne "Unsupported" }

	Write-Host "   $($lang.NetworkAdaptersPM)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		foreach ($item in $Adapters)
		{
			$item.AllowComputerToTurnOffDevice = "Enabled"
			$item | Set-NetAdapterPowerManagement
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		foreach ($item in $Adapters)
		{
			$item.AllowComputerToTurnOffDevice = "Disabled"
			$item | Set-NetAdapterPowerManagement
		}
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Internet Protocol Version 6 (TCP/IPv6) component
	.Internet 协议版本 6 (TCP/IPv6) 组件
#>
Function IPv6Component
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.NetworkAdaptersPM)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Enable-NetAdapterBinding -Name * -ComponentID ms_tcpip6 -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Disable-NetAdapterBinding -Name * -ComponentID ms_tcpip6 -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.Merge taskbar buttons: never
	.合并任务栏按钮：从不
#>
Function MergeTaskbarNever
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.MergeTaskbarNever)"
	if ($Enable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarGlomLevel' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name TaskbarGlomLevel -Force -ErrorAction SilentlyContinue
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.Notification area: always show all icons
	.通知区域：始终显示所有图标
#>
Function NotificationAlways
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.NotificationAlways)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'EnableAutoTray' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name EnableAutoTray -Force -ErrorAction SilentlyContinue
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Open "Show all folders" in the navigation pane
	.在导航窗格中打开“显示所有文件夹”
#>
Function NavShowAll
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.NavShowAll)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'NavPaneExpandToCurrentFolder' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "NavPaneExpandToCurrentFolder" -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Hide the Cortana button on the taskbar
	.在任务栏上隐藏 Cortana 按钮
#>
Function Cortana
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Cortana)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "ShowCortanaButton" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Hide the Task View button on the taskbar
	.在任务栏上隐藏 任务视图 按钮
#>
Function TaskView
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	Write-Host "   $($lang.TaskView)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "ShowTaskViewButton" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "ShowTaskViewButton" -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Hide recently used files in Quick access
	.在快速访问中隐藏最近使用的文件
#>
Function QuickAccessFiles
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	Write-Host "   $($lang.QuickAccessFiles)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowRecent" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowRecent" -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Show frequently used folders in Quick access
	.在快速访问中显示常用文件夹
#>
Function QuickAccessFolders
{
	param
	(
		[switch]$Show,
		[switch]$Hide
	)

	Write-Host "   $($lang.QuickAccessFolders)"
	if ($Show) {
		Write-Host "   $($lang.Show)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowFrequent" -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Hide) {
		Write-Host "   $($lang.Hide)".PadRight(22) -NoNewline
		New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" -Name "ShowFrequent" -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "$env:appdata\Microsoft\Windows\Recent\*.*"
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Memory compression
	.内存压缩
#>
Function MemoryCompression
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.MemoryCompression)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Enable-MMAgent -mc
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Disable-MMAgent -mc
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Pre-fetch pre-launch
	.预取预启动
#>
Function Prelaunch
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Prelaunch)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Enable-MMAgent -ApplicationPreLaunch
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Disable-MMAgent -ApplicationPreLaunch
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.SSD
#>
Function SSD
{
	param
	(
		[switch]$Restore,
		[switch]$Disable
	)

	Write-Host "   $($lang.OptSSD)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		fsutil behavior set DisableLastAccess 2 | Out-Null
		fsutil behavior set EncryptPagingFile 0 | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		fsutil behavior set DisableLastAccess 1 | Out-Null
		fsutil behavior set EncryptPagingFile 0 | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Program Compatibility Assistant
	.程序兼容性助手
#>
Function Compatibility
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Compatibility)"
	if ($Enable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' -Name 'DisablePCA' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Visual animation effect
	.视觉动画效果
#>
Function AnimationEffects 
{
	param
	(
		[switch]$Restore,
		[switch]$Optimize
	)

	Write-Host "   $($lang.AnimationEffects)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-Item -LiteralPath "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM" -force -Recurse -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'EnableAeroPeek' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'AlwaysHibernateThumbnails' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "TurnOffSPIAnimations" -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" -Name "VisualFXSetting" -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewAlphaSelect' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewShadow' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'IconsOnly' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop\WindowMetrics' -Name 'MinAnimate' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'UserPreferencesMask' -Value ([byte[]](0x9e,0x1e,0x07,0x80,0x12,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'DragFullWindows' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'FontSmoothing' -Value '2' -PropertyType String -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Red
	}

	if ($Optimize) {
		Write-Host "   $($lang.Optimize)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM") -ne $true) { New-Item "HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM" -force -ea SilentlyContinue | out-null }
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\DWM' -Name 'DisallowAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'EnableAeroPeek' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\DWM' -Name 'AlwaysHibernateThumbnails' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'TurnOffSPIAnimations' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -Name 'VisualFXSetting' -Value 3 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarAnimations' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewAlphaSelect' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ListviewShadow' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'IconsOnly' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop\WindowMetrics' -Name 'MinAnimate' -Value '0' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'UserPreferencesMask' -Value ([byte[]](0x9e,0x1e,0x07,0x80,0x12,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'DragFullWindows' -Value '1' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name 'FontSmoothing' -Value '2' -PropertyType String -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.Disk Defragmentation Plan
	.磁盘碎片整理计划
#>
Function Defragmentation
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Defragmentation)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Enable-ScheduledTask -TaskPath "\Microsoft\Windows\Defrag\" -TaskName "ScheduledDefrag" | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Disable-ScheduledTask -TaskPath "\Microsoft\Windows\Defrag\" -TaskName "ScheduledDefrag" | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Photo preview
	.照片预览
#>
Function PhotoPreview
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PhotoPreview)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.jpg") -ne $true) { New-Item "HKCU:\Software\Classes\.jpg" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.jpeg") -ne $true) { New-Item "HKCU:\Software\Classes\.jpeg" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.gif") -ne $true) { New-Item "HKCU:\Software\Classes\.gif" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.png") -ne $true) { New-Item "HKCU:\Software\Classes\.png" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.bmp") -ne $true) { New-Item "HKCU:\Software\Classes\.bmp" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.tiff") -ne $true) { New-Item "HKCU:\Software\Classes\.tiff" -force -ea SilentlyContinue }
		if ((Test-Path -LiteralPath "HKCU:\Software\Classes\.ico") -ne $true) { New-Item "HKCU:\Software\Classes\.ico" -force -ea SilentlyContinue }
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.jpg' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.jpeg' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.gif' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.png' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.bmp' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.tiff' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Classes\.ico' -Name '(default)' -Value 'PhotoViewer.FileAssoc.Tiff' -PropertyType String -Force -ea SilentlyContinue | out-null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\Software\Classes\.jpg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.jpeg" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.gif" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.png" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.bmp" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.tiff" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKCU:\Software\Classes\.ico" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Reduce the number of processors using RAM
	.降低 RAM 使用处理器数量
#>
Function RAM
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.RAM)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'SvcHostSplitThresholdInKB' -Value 3670016 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'WaitToKillServiceTimeout' -Value '5000' -PropertyType String -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'NetworkThrottlingIndex' -Value 10 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'SystemResponsiveness' -Value 20 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' -Name 'SearchOrderConfig' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name 'HiberbootEnabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		Remove-ItemProperty -Name "PowerThrottlingOff" -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_Enabled' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_FSEBehaviorMode' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_AutoGameModeDefaultProfile' -Value ([byte[]](0x02,0x00,0x01,0x00,0x00,0x00,0xc4,0x20,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_GameModeRelatedProcesses' -Value ([byte[]](0x01,0x00,0x01,0x00,0x01,0x00,0x67,0x00,0x61,0x00,0x6d,0x00,0x65,0x00,0x70,0x00,0x61,0x00,0x6e,0x00,0x65,0x00,0x6c,0x00,0x2e,0x00,0x65,0x00,0x78,0x00,0x65,0x00,0x00,0x00,0xc9,0x00,0x4e,0x95,0x67,0x77,0xb0,0xeb,0x1e,0x03,0xd8,0xf1,0x1e,0x03,0x1e,0x00,0x00,0x00,0xb0,0xeb,0x1e,0x03,0x1e,0x00,0x00,0x00,0x0f,0x00,0x00,0x00,0x2c,0xea,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_HonorUserFSEBehaviorMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_DXGIHonorFSEWindowsCompatible' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_EFSEFeatureFlags' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name 'HibernateEnabledDefault' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\943c8cb6-6f93-4227-ad87-e9a3feec08d1' -Name 'Attributes' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'SvcHostSplitThresholdInKB' -Value 67108864 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name 'WaitToKillServiceTimeout' -Value '2000' -PropertyType String -Force -ea SilentlyContinue | out-null
		if((Test-Path -LiteralPath "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile") -ne $true) { New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" -force -ea SilentlyContinue }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'NetworkThrottlingIndex' -Value -1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name 'SystemResponsiveness' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' -Name 'SearchOrderConfig' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name 'HiberbootEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		if((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling") -ne $true) {  New-Item "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' -Name 'PowerThrottlingOff' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		if((Test-Path -LiteralPath "HKCU:\System\GameConfigStore") -ne $true) {  New-Item "HKCU:\System\GameConfigStore" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_Enabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_FSEBehaviorMode' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_AutoGameModeDefaultProfile' -Value ([byte[]](0x01,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'Win32_GameModeRelatedProcesses' -Value ([byte[]](0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00)) -PropertyType Binary -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_HonorUserFSEBehaviorMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_DXGIHonorFSEWindowsCompatible' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\System\GameConfigStore' -Name 'GameDVR_EFSEFeatureFlags' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name 'HibernateEnabledDefault' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\943c8cb6-6f93-4227-ad87-e9a3feec08d1' -Name 'Attributes' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e' -Name 'DCSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -Name 'ACSettingIndex' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Storage Sense
	.存储感知
#>
Function StorageSense
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.StorageSense)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if (-not (Test-Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy))
		{
			New-Item -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		}
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -Name 01 -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if (-not (Test-Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy))
		{
			New-Item -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		}
		New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -Name 01 -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Delivery Optimization
	.传递优化
#>
Function Delivery
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Delivery)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-ItemProperty -Path Registry::HKEY_USERS\S-1-5-20\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings -Name DownloadMode -PropertyType DWord -Value 1 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -Path Registry::HKEY_USERS\S-1-5-20\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings -Name DownloadMode -PropertyType DWord -Value 0 -Force -ErrorAction SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Maximum password usage time is unlimited
	.密码最长使用时间为无限
#>
Function PwdUnlimited
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.PwdUnlimited)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		net accounts /maxpwage:42 | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		net accounts /maxpwage:UNLIMITED | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Gamebar
#>
Function XboxGameBar
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.XboxGameBar)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if (-not (Test-Path HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR))
		{
			New-Item -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		}
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name AppCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name AudioCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name CursorCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name MicrophoneCaptureEnabled -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if (-not (Test-Path HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR))
		{
			New-Item -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		}
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AppCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AudioCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'CursorCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'MicrophoneCaptureEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Gamebar Tips
#>
Function XboxGameBarTips
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.XboxGameBarTips)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		if (-not (Test-Path HKCU:\SOFTWARE\Microsoft\GameBar))
		{
			New-Item -Path HKCU:\SOFTWARE\Microsoft\GameBar -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		}
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\GameBar' -Name 'ShowStartupPanel' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if (-not (Test-Path HKCU:\SOFTWARE\Microsoft\GameBar))
		{
			New-Item -Path HKCU:\SOFTWARE\Microsoft\GameBar -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		}
		New-ItemProperty -LiteralPath 'HKCU:\SOFTWARE\Microsoft\GameBar' -Name 'ShowStartupPanel' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Game Mode
	.Game Mode
#>
Function XboxGameMode
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.XboxGameMode)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name CursorCaptureEnabled -Force -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name MicrophoneCaptureEnabled -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\GameBar' -Name 'AutoGameModeEnabled' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\GameBar' -Name 'AllowAutoGameMode' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Game DVR
	.游戏 DVR
#>
Function XboxGameDVR
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.XboxGameDVR)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Name AllowgameDVR -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Name 'AllowgameDVR' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	."Windows protects your PC" dialog
	."Windows 保护了您的 PC" 对话框
#>
Function Protected
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Protected)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments") -ne $true) { New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Add 15 file selection limit to hide context menu items
	.增加 15 个文件选择限制以隐藏上下文菜单项
#>
Function MultipleIncrease
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.MultipleIncrease)"
	if ($Enable) {
		Write-Host "   $($lang.Setting)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer" -Name MultipleInvokePromptMinimum -Force -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'MultipleInvokePromptMinimum' -Value 999 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Autoplay
	.自动播放
#>
Function Autoplay
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Autoplay)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -Name "DisableAutoplay" -Type DWord -Value 0
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -Name "DisableAutoplay" -Type DWord -Value 1
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Run all drives automatically
	.自动运行所有驱动器
#>
Function Autorun
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.Autorun)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun" -ErrorAction SilentlyContinue
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		If (-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer")) {
			New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" | Out-Null
		}
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoDriveTypeAutoRun" -Type DWord -Value 255
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Error report
	.错误报告
#>
Function ErrorReporting
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ErrorReporting)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "Disabled" -ErrorAction SilentlyContinue

		Set-Service -Name "WerSvc" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
		Start-Service "WerSvc" -ErrorAction SilentlyContinue | Out-Null

		Enable-ScheduledTask -TaskName "QueueReporting" -TaskPath "\Microsoft\Windows\Windows Error Reporting" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "Disabled" -Type DWord -Value 1

		Set-Service -Name "WerSvc" -StartupType Disabled -ErrorAction SilentlyContinue | Out-Null
		Stop-Service "WerSvc" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

		Disable-ScheduledTask -TaskName "QueueReporting" -TaskPath "\Microsoft\Windows\Windows Error Reporting" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.F8 boot menu option
	.F8 启动菜单选项
#>
Function F8BootMenu
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.F8BootMenu)"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} bootmenupolicy Legacy | Out-Null
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		bcdedit /set `{current`} bootmenupolicy Standard | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Sent to
	.发送到
#>
Function SendTo
{
	Write-Host "   $($lang.SendTo)"
	Write-Host "   $($lang.Clean)".PadRight(22) -NoNewline
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\Mail Recipient.MAPIMail" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\邮件收件人.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\Fax Recipient.lnk" -ErrorAction SilentlyContinue
	Remove-Item -Path "$env:APPDATA\Microsoft\Windows\SendTo\传真收件人.lnk" -ErrorAction SilentlyContinue
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.System logs
	.系统日志
#>
Function CleanSystemLog
{
	Write-Host "   $($lang.Logs)"
	Write-Host "   $($lang.Clean)".PadRight(22) -NoNewline
	Get-EventLog -LogName * | ForEach-Object { Clear-EventLog $_.Log }
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Disk clean-up
	.磁盘清理
#>
Function DiskCleanup
{
	$SageSet = "StateFlags0099"
	$Base = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\"
	$Locations= @(
		"Active Setup Temp Folders"
		"BranchCache"
		"Downloaded Program Files"
		"GameNewsFiles"
		"GameStatisticsFiles"
		"GameUpdateFiles"
		"Internet Cache Files"
		"Memory Dump Files"
		"Offline Pages Files"
		"Old ChkDsk Files"
		"D3D Shader Cache"
		"Delivery Optimization Files"
		"Diagnostic Data Viewer database files"
#		"Previous Installations"
#		"Recycle Bin"
		"Service Pack Cleanup"
		"Setup Log Files"
		"System error memory dump files"
		"System error minidump files"
		"Temporary Files"
		"Temporary Setup Files"
		"Temporary Sync Files"
		"Thumbnail Cache"
		"Update Cleanup"
		"Upgrade Discarded Files"
		"User file versions"
		"Windows Defender"
		"Windows Error Reporting Archive Files"
		"Windows Error Reporting Queue Files"
		"Windows Error Reporting System Archive Files"
		"Windows Error Reporting System Queue Files"
		"Windows ESD installation files"
		"Windows Upgrade Log Files"
	)

	Foreach ($item in $Locations) {
	    Set-ItemProperty -Path $($Base+$item) -Name $SageSet -Type DWORD -Value 2 -ea silentlycontinue | Out-Null
	}

	<#
		.Do the clean-up. Have to convert the SageSet number
		.进行清理。 必须转换 SageSet 编号
	#>
	$Args = "/sagerun:$([string]([int]$SageSet.Substring($SageSet.Length-4)))"
	Start-Process -Wait "$env:SystemRoot\System32\cleanmgr.exe" -ArgumentList $Args

	<#
		.Remove the Stateflags
		.删除状态标志
	#>
	Foreach ($item in $Locations)
	{
		Remove-ItemProperty -Path $($Base+$item) -Name $SageSet -Force -ea silentlycontinue | Out-Null
	}
}

<#
	.WinSxS slimming
	.WinSxS 瘦身
#>
Function CleanSxS
{
	Write-Host "   $($lang.SxS)"
	Write-Host "   $($lang.Clean)".PadRight(22) -NoNewline

	# 清理组件
	Dism.exe /online /Cleanup-Image /StartComponentCleanup

	# 重置替代组件的基础
	Dism.exe /Online /Cleanup-Image /StartComponentCleanup /ResetBase
	
	# 删除备份文件
	Dism.exe /online /Cleanup-Image /SPSuperseded
	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Notification Center
	.通知中心
#>
Function NotificationCenter
{
	param
	(
		[switch]$Restore,
		[switch]$Full,
		[switch]$Part
	)

	$Notifications = @(
#		"windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel" # Settings
		"microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowslive.calendar"    # Calendar
		"microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowslive.mail"        # Mail
		"Microsoft.MicrosoftEdge_8wekyb3d8bbwe!MicrosoftEdge"                                 # Edge
		"Microsoft.Windows.Cortana_cw5n1h2txyewy!CortanaUI"                                   # Cortana
		"Windows.SystemToast.AudioTroubleshooter"                                             # Audio
		"Windows.SystemToast.Suggested"                                                       # Suggested
		"Microsoft.WindowsStore_8wekyb3d8bbwe!App"                                            # Store
		"Windows.SystemToast.SecurityAndMaintenance"                                          # Security and Maintenance
		"Windows.SystemToast.WiFiNetworkManager"                                              # Wireless
		"Windows.SystemToast.HelloFace"                                                       # Windows Hello
		"Windows.SystemToast.RasToastNotifier"                                                # VPN
		"Windows.System.Continuum"                                                            # Tablet
		"Microsoft.BingNews_8wekyb3d8bbwe!AppexNews"                                          # News
		"Windows.SystemToast.BdeUnlock"                                                       # Bitlocker
		"Windows.SystemToast.BackgroundAccess"                                                # Battery Saver
		"Windows.Defender.SecurityCenter"                                                     # Security Center
		"Microsoft.Windows.Photos_8wekyb3d8bbwe!App"                                          # Photos
		"Microsoft.SkyDrive.Desktop"                                                          # OneDrive
#		"Windows.SystemToast.AutoPlay"                                                        # Autoplay
	)

	Write-Host "   $($lang.Notification)"
	if ($Restore) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		Remove-ItemProperty -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\TrayNotify" -Name "PastIconsStream" -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\TrayNotify" -Name "IconStreams" -ErrorAction SilentlyContinue
		
		Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" -Name "ToastEnabled" -ErrorAction SilentlyContinue
		Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -Name "DisableEnhancedNotifications" -ErrorAction SilentlyContinue
		Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
		
		foreach ($Name in $Notifications) {
			New-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -Name Enabled -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		}
	
		netsh firewall set notifications mode=enable profile=all | Out-Null
		netsh firewall set opmode exceptions=enable | Out-Null
	}

	if ($Full) {
		Write-Host "   $($lang.Full)".PadRight(22) -NoNewline
		If (-not (Test-Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer")) {
			New-Item -Path "HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer" | Out-Null
		}
		Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" -Name "ToastEnabled" -Type DWord -Value 0
	}

	if ($Part) {
		Write-Host "   $($lang.Part)".PadRight(22) -NoNewline
		if ((Test-Path -LiteralPath "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications") -ne $true) { New-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" -force -ea SilentlyContinue | Out-Null }
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications' -Name 'DisableEnhancedNotifications' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

		New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Force -ErrorAction SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableSoftLanding' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null

		foreach ($Name in $Notifications)
		{
			if ((Test-Path -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name") -ne $true) {
				New-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -force -ea SilentlyContinue | Out-Null
			}

			New-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$Name" -Name Enabled -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		}

		# 关闭 防火墙通知
		New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
		New-ItemProperty -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile" -Name DisableNotifications -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | Out-Null
	}

	RestartExplorer

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.System disk paging size
	.系统盘分页大小
#>
Function PagingSize
{
	param
	(
		[switch]$Enable,
		[switch]$Disable,
		[string]$size
	)

	Write-Host "   $($lang.PagingSize)"
	if ($Enable) {
		Write-Host "   $($lang.Setting) $($size)G".PadRight(22) -NoNewline
		switch ($size)
		{
			8 {
				New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("$($env:SystemDrive)\pagefile.sys 8192 8192") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
			}
			16 {
				New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("$($env:SystemDrive)\pagefile.sys 16384 16384") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
			}
		}
	}

	if ($Disable) {
		Write-Host "   $($lang.Restore)".PadRight(22) -NoNewline
		New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value @("?:\pagefile.sys") -PropertyType MultiString -Force -ea SilentlyContinue | Out-Null
	}

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Enable 3389 remote desktop
	.启用 3389 远程桌面
#>
Function RemoteDesktop {
	Write-Host "   $($lang.StRemote)"
	Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 0 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\TermService") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Services\TermService" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services\TermService' -Name 'Start' -Value 2 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\MpsSvc") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Services\MpsSvc" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services\MpsSvc' -Name 'Start' -Value 4 -PropertyType DWord -Force -ea SilentlyContinue | out-null
	Stop-Service "MpsSvc" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	netsh advfirewall firewall add rule name="Open Port 3389" dir=in action=allow protocol=TCP localport=3389 | Out-Null
	Start-Service "TermService" -ErrorAction SilentlyContinue | Out-Null

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}


<#
	.Turn on SMB file sharing
	.打开 SMB 文件共享
#>
Function SMBFileShare
{
	Write-Host "   $($lang.StSMB)"
	Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
	<#
		.Add 'firewall rules'
		.添加 '防火墙规则'
	#>
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 137" dir=in action=allow protocol=UDP localport=137 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 137" dir=out action=allow protocol=UDP localport=137 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 138" dir=in action=allow protocol=UDP localport=138 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS UDP Port 138" dir=out action=allow protocol=UDP localport=138 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 139" dir=in action=allow protocol=TCP localport=139 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 139" dir=out action=allow protocol=TCP localport=139 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 445" dir=in action=allow protocol=TCP localport=445 | Out-Null
	netsh advfirewall firewall add rule name="NetBIOS TCP Port 445" dir=out action=allow protocol=TCP localport=445 | Out-Null

	<#
		.Enable 'Guest User'
		.启用 'Guest 用户'
	#>
	Net User Guest /Active:yes | Out-Null

	<#
		.Set the group policy 'Deny guest users in this computer from accessing the network'
		.设置组策略 '拒绝从网络访问此计算机中的 Guest 用户'
	#>
	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'forceguest' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	if ((Test-Path -LiteralPath "HKLM:\SYSTEM\CurrentControlSet001\Control\Lsa") -ne $true) { New-Item "HKLM:\SYSTEM\CurrentControlSet001\Control\Lsa" -force -ea SilentlyContinue | out-null }
	New-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet001\Control\Lsa' -Name 'forceguest' -Value 1 -PropertyType DWord -Force -ea SilentlyContinue | out-null

	<#
		.Group Policy 'Guests Only-Authenticate local users as guests'
		.组策略 '仅来宾 - 对本地用户进行身份验证，其身份为来宾'
	#>
	Remove-Item -Path "$($env:TEMP)\share.inf" -ErrorAction SilentlyContinue
@"
[Version] 
signature="`$CHICAGO$" 
Revision=1 

[Privilege Rights] 
SeDenyNetworkLogonRight = 
"@ | Out-File -FilePath "$($env:TEMP)\share.inf" -Encoding Ascii
	secedit /configure /db "$($env:TEMP)\share.sdb" /cfg "$($env:TEMP)\share.inf"
	Remove-Item -Path "$($env:TEMP)\share.inf" -ErrorAction SilentlyContinue
	Remove-Item -Path "$($env:TEMP)\share.sdb" -ErrorAction SilentlyContinue

	<#
		.Disable the 'Psec Policy Agent (IP security policy) service'
		.禁用 'Psec Policy Agent（IP安全策略）服务'
	#>
	Set-Service -Name "PolicyAgent" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
	Stop-Service "PolicyAgent" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	<#
		.Disable the 'Server (Shared Service)'
		.禁用 'Server（共享服务）'
	#>
	Set-Service -Name "ShareAccess" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
	Stop-Service "ShareAccess" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	<#
		.Enable 'Computer Browser (browsing service)'
		.启用 'Computer Browser（浏览服务）'
	#>
	Set-Service -Name "Browser" -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
	Start-Service "Browser" -ErrorAction SilentlyContinue | Out-Null

	<#
		.Disable the 'MpsSvc Service'
		.禁用 'MpsSvc 服务'
	#>
	Set-Service -Name "MpsSvc" -StartupType Manual -ErrorAction SilentlyContinue | Out-Null
	Stop-Service "MpsSvc" -Force -NoWait -ErrorAction SilentlyContinue | Out-Null

	<#
		.Enable 'LanmanServer service'
		.启用 'LanmanServer 服务'
	#>
	Set-Service -Name "LanmanServer" -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
	Start-Service "LanmanServer" -ErrorAction SilentlyContinue | Out-Null
	gpupdate /force | out-null

	Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
}

<#
	.Remove Desktop from This PC
	.从这台电脑上删除桌面
#>
Function ThisPCDesktop
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationDesktop))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
        Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Remove Documents from This PC
	.从这台电脑上删除文档
#>
Function ThisPCDocument
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationDocuments))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A8CDFF1C-4878-43be-B5FD-F8091C1C60D0}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A8CDFF1C-4878-43be-B5FD-F8091C1C60D0}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A8CDFF1C-4878-43be-B5FD-F8091C1C60D0}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A8CDFF1C-4878-43be-B5FD-F8091C1C60D0}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{d3162b92-9365-467a-956b-92703aca08af}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.Remove Downloads from This PC
	.从这台 PC 中删除下载
#>
Function ThisPCDownload
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationDownloads))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{374DE290-123F-4565-9164-39C4925E467B}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{374DE290-123F-4565-9164-39C4925E467B}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{374DE290-123F-4565-9164-39C4925E467B}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{374DE290-123F-4565-9164-39C4925E467B}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Remove Music from This PC
	.从这台电脑中删除音乐
#>
Function ThisPCMusic
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationMusic))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{1CF1260C-4DD0-4ebb-811F-33C572699FDE}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{1CF1260C-4DD0-4ebb-811F-33C572699FDE}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{1CF1260C-4DD0-4ebb-811F-33C572699FDE}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{1CF1260C-4DD0-4ebb-811F-33C572699FDE}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Remove Pictures from This PC
	.从这台电脑中删除图片
#>
Function ThisPCPicture
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationPictures))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3ADD1653-EB32-4cb0-BBD7-DFA0ABB5ACCA}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3ADD1653-EB32-4cb0-BBD7-DFA0ABB5ACCA}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3ADD1653-EB32-4cb0-BBD7-DFA0ABB5ACCA}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3ADD1653-EB32-4cb0-BBD7-DFA0ABB5ACCA}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Remove Videos from This PC
	.从这台 PC 中删除视频
#>
Function ThisPCVideo
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.LocationVideos))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A0953C92-50DC-43bf-BE83-3742FED03C9C}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A0953C92-50DC-43bf-BE83-3742FED03C9C}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A0953C92-50DC-43bf-BE83-3742FED03C9C}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{A0953C92-50DC-43bf-BE83-3742FED03C9C}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}

<#
	.Remove Videos from This PC
	.从这台 PC 中删除视频
#>
Function ThisPC3D
{
	param
	(
		[switch]$Enable,
		[switch]$Disable
	)

	Write-Host "   $($lang.ThisPCRemove -f $($lang.Location3D))"
	if ($Enable) {
		Write-Host "   $($lang.Enable)".PadRight(22) -NoNewline
		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}" -ErrorAction SilentlyContinue | Out-Null
		New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}

	if ($Disable) {
		Write-Host "   $($lang.Disable)".PadRight(22) -NoNewline
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}" -ErrorAction SilentlyContinue | Out-Null
		Remove-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}" -ErrorAction SilentlyContinue | Out-Null
		Write-Host "   - $($lang.Done)`n" -ForegroundColor Green
	}
}


<#
	.All icons in the taskbar
	.任务栏所有图标
#>
Function ResetTaskBar
{
	Write-Host "   $($lang.Reset) $($lang.TaskBar)" -ForegroundColor Green
	Write-Host "   - $($lang.Delete) $($lang.TaskBar)"
	Remove-Item -Path "$env:AppData\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\*.*" -ErrorAction SilentlyContinue | Out-Null
	Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	if (Test-Path "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\syspin")\syspin.exe" -PathType Leaf) {
		Start-Process -FilePath "$(GetArchitecturePacker -Path "$PSScriptRoot\..\..\AIO\syspin")\syspin.exe" -ArgumentList """$($env:systemroot)\explorer.exe"" ""5386""" -Wait -WindowStyle Hidden
	}
	RestartExplorer

	Write-Host "   - $($lang.ResetExplorer)`n"
}


<#
	.Rearrange the desktop icons by name
	.重新按名称排列桌面图标
#>
Function ResetDesktop
{
	$ResetDesktopReg = @(
		'HKCU:\Software\Microsoft\Windows\Shell\BagMRU'
		'HKCU:\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Microsoft\Windows\ShellNoRoam\Bags'
		'HKCU:\Software\Microsoft\Windows\ShellNoRoam\BagMRU'
		'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
		'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\Bags'
		'HKCU:\Software\Classes\Wow6432Node\Local Settings\Software\Microsoft\Windows\Shell\BagMRU'
	)

	Write-Host "   $($lang.ResetDesk)" -ForegroundColor Green
	Write-Host "   - $($lang.ResetFolder)"
	foreach ($item in $ResetDesktopReg) {
		Remove-Item -Path $item -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
	}

	RestartExplorer

	Write-Host "   - $($lang.ResetExplorer)`n"
	RefreshIconCache
}


<#
	.Refresh icon cache
	.刷新图标缓存
#>
Function RefreshIconCache
{
	$code = @'
	private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
	private const int WM_SETTINGCHANGE = 0x1a;
	private const int SMTO_ABORTIFHUNG = 0x0002;

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);

[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
private static extern IntPtr SendMessageTimeout ( IntPtr hWnd, int Msg, IntPtr wParam, string lParam, uint fuFlags, uint uTimeout, IntPtr lpdwResult );

[System.Runtime.InteropServices.DllImport("Shell32.dll")] 
private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

public static void Refresh() {
	SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);
	SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);
}
'@

	Add-Type -MemberDefinition $code -Namespace MyWinAPI -Name Explorer
	[MyWinAPI.Explorer]::Refresh()
}

Export-ModuleMember -Function * -Alias *