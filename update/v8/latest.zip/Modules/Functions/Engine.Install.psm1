﻿<#
	.初始化自动选择磁盘最低大小：1GB
	.The minimum size of the disk is automatically selected during initialization: 1GB
#>
$Global:DiskMinSize = 1

<#
	.等待队列
	.Waiting queue
#>
$Global:AppQueue = @()

<#
	.Start processing all software installation requests
	.处理安装请求

	
#>
Function Install_Process
{
	param
	(
		$appname,
		$status,
		$act,
		$mode,
		$todisk,
		$structure,
		$pwd,
		$url,
		$urlAMD64,
		$urlarm64,
		$filename,
		$param,
		$Before,
		$After
	)

	Get_Architecture
	Setting_Init_Disk_Free
	Setting_Init_Disk_Available
	Install_Init_Disk_To

	Switch ($status)
	{
		Enabled
		{
			Write-Host "   $($lang.Instl) - $($appname)" -ForegroundColor Green
		}
		Disable
		{
			Write-Host "   $($lang.InstlSkip) - $($appname)" -ForegroundColor Red
			return
		}
	}

	switch ($Global:InstlArchitecture) {
		"arm64" {
			if (([string]::IsNullOrEmpty($urlarm64))) {
				if ([string]::IsNullOrEmpty($urlAMD64)) {
					if ([string]::IsNullOrEmpty($url)) {
						$FilenameTo = $urlAMD64
					} else {
						$url = $url
						$FilenameTo = $url
					}
				} else {
					$url = $urlAMD64
					$FilenameTo = $urlAMD64
				}
			} else {
				$url = $urlarm64
				$FilenameTo = $urlarm64
			}
		}
		"AMD64" {
			if ($Global:InstlArchitecture -eq "AMD64") {
				if (([string]::IsNullOrEmpty($urlAMD64))) {
					if ([string]::IsNullOrEmpty($url)) {
						$FilenameTo = $urlAMD64
					} else {
						$url = $url
						$FilenameTo = $url
					}
				} else {
					$url = $urlAMD64
					$FilenameTo = $urlAMD64
				}
			}
		}
		Default {
			if ($Global:InstlArchitecture -eq "x86") {
				if (([string]::IsNullOrEmpty($url))) {
					$FilenameTo = $urlAMD64
				} else {
					$url = $url
					$FilenameTo = $url
				}
			}
		}
	}

	$SaveToName = [IO.Path]::GetFileName($FilenameTo)
	$packer = [IO.Path]::GetFileNameWithoutExtension($FilenameTo)
	$types =  [IO.Path]::GetExtension($FilenameTo).Replace(".", "")

	Switch ($todisk)
	{
		auto
		{
			Get-PSDrive -PSProvider FileSystem | ForEach-Object {
				$TempRootPath = $_.Root
				$tempoutputfoldoer = Join-Path -Path $($TempRootPath) -ChildPath "$($structure)"
				Get-ChildItem -Path "$($tempoutputfoldoer)\$((Get-Culture).Name)" -Filter "*$($filename)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($TempRootPath)" -ChildPath "$($structure)\$((Get-Culture).Name)"
					$OutAny = $($_.fullname)
					break
				}
				Get-ChildItem -Path "$($tempoutputfoldoer)\en-US" -Filter "*$($filename)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($TempRootPath)" -ChildPath "$($structure)\en-US"
					$OutAny = $($_.fullname)
					break
				}
				Get-ChildItem -Path $tempoutputfoldoer -Filter "*$($filename)*$((Get-Culture).Name)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($TempRootPath)" -ChildPath "$($structure)"
					$OutAny = $($_.fullname)
					break
				}
				Get-ChildItem -Path $tempoutputfoldoer -Filter "*$($filename)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($TempRootPath)" -ChildPath "$($structure)"
					$OutAny = $($_.fullname)
					break
				}
				Get-ChildItem -Path $tempoutputfoldoer -Filter "*$($packer)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
					$OutTo = Join-Path -Path "$($TempRootPath)" -ChildPath "$($structure)"
					$OutAny = $($_.fullname)
					break
				}
				$OutTo = Join-Path -Path $Global:FreeDiskTo -ChildPath "$($structure)"
				$OutAny = Join-Path -Path $Global:FreeDiskTo -ChildPath "$($structure)\$SaveToName"
			}
		}
		default
		{
			$OutTo = Join-Path -Path $($todisk) -ChildPath "$($structure)"
			$OutAny = Join-Path -Path $($todisk) -ChildPath "$($structure)\$SaveToName"
			Get-ChildItem -Path "$($OutTo)\$((Get-Culture).Name)" -Filter "*$($filename)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutTo = Join-Path -Path "$($todisk)" -ChildPath "$($structure)\$((Get-Culture).Name)"
				$OutAny = $($_.fullname)
				break
			}
			Get-ChildItem -Path "$($OutTo)\en-US" -Filter "*$($filename)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutTo = Join-Path -Path "$($todisk)" -ChildPath "$($structure)\en-US"
				$OutAny = $($_.fullname)
				break
			}
			Get-ChildItem -Path $OutTo -Filter "*$($filename)*$((Get-Culture).Name)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutAny = $($_.fullname)
				break
			}
			Get-ChildItem -Path $OutTo -Filter "*$($filename)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutAny = $($_.fullname)
				break
			}
			Get-ChildItem -Path $OutTo -Filter "*$($packer)*" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
				$OutAny = $($_.fullname)
				break
			}
		}
	}

	if ($Before -eq "dfControl") {
		Add-MpPreference -ExclusionPath (Convert-Path -Path $OutTo -ErrorAction SilentlyContinue) -ErrorAction SilentlyContinue | Out-Null
	}

	if ($Before -eq "HEU") {
		Add-MpPreference -ExclusionPath "$($env:systemroot)\System32\SECOPatcher.dll" -ErrorAction SilentlyContinue | Out-Null
	}

	Switch ($types)
	{
		zip
		{
			Switch ($act)
			{
				Install
				{
					Get-ChildItem -Path $OutTo -Filter "*$($filename)*$((Get-Culture).Name)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)`n     $($_.fullname)"
						Open_Apps -filename $($_.fullname) -param $param -mode $mode -Before $Before -After $After
						break
					}
					Get-ChildItem -Path $OutTo -Filter "*$($filename)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)`n     $($_.fullname)"
						Open_Apps -filename $($_.fullname) -param $param -mode $mode -Before $Before -After $After
						break
					}
					Get-ChildItem -Path $OutTo -Filter "*$($packer)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "    - $($lang.LocallyExist)`n     $($_.fullname)"
						Open_Apps -filename $($_.fullname) -param $param -mode $mode -Before $Before -After $After
						break
					}
					if (Test-Path $OutAny -PathType leaf) {
						Write-Host "   - $($lang.ExistingPacker)"
					} else {
						Write-Host "    * $($lang.StartDown)"
						if ([string]::IsNullOrEmpty($url)) {
							Write-Host "    - $($lang.DownloadLinkError)" -ForegroundColor Red
						} else {
							if (Test_URI $url) {
								Write-Host "      > $($lang.ConnectTo)`n        $url`n      + $($lang.SaveTo)`n        $OutAny"
								Check_Folder -chkpath $OutTo
								Invoke-WebRequest -Uri $url -OutFile "$($OutAny)" -ErrorAction SilentlyContinue | Out-Null
							} else {
								Write-Host "      - $($lang.NotAvailable)" -ForegroundColor Red
							}
						}
					}
					if (Test-Path $OutAny -PathType leaf) {
						Write-Host "   - $($lang.Unpacking)".PadRight(28) -NoNewline
						Archive -Password $pwd -filename $OutAny -to $OutTo
						Remove-Item -path $OutAny -force -ErrorAction SilentlyContinue
					} else {
						Write-Host "   - $($lang.ErrorDown)`n" -ForegroundColor Red
					}
					Get-ChildItem -Path $OutTo -Filter "*$($filename)*$((Get-Culture).Name)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)`n     $($_.fullname)"
						Open_Apps -filename $($_.fullname) -param $param -mode $mode -Before $Before -After $After
						break
					}
					Get-ChildItem -Path $OutTo -Filter "*$($filename)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)`n     $($_.fullname)"
						Open_Apps -filename $($_.fullname) -param $param -mode $mode -Before $Before -After $After
						break
					}
					Get-ChildItem -Path $OutTo -Filter "*$($packer)*.exe" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
						Write-Host "   - $($lang.LocallyExist)`n     $($_.fullname)"
						Open_Apps -filename $($_.fullname) -param $param -mode $mode -Before $Before -After $After
						break
					}
				}
				NoInst
				{
					if (Test-Path $OutAny -PathType leaf) {
						Write-Host "   - $($lang.BeenInstl)`n"
					} else {
						Write-Host "    * $($lang.StartDown)"
						if ([string]::IsNullOrEmpty($url)) {
							Write-Host "      - $($lang.DownloadLinkError)" -ForegroundColor Red
						} else {
							if (Test_URI $url) {
								Write-Host "      > $($lang.ConnectTo)`n        $url`n      + $($lang.SaveTo)`n        $OutAny"
								Check_Folder -chkpath $OutTo
								Invoke-WebRequest -Uri $url -OutFile "$($OutAny)" -ErrorAction SilentlyContinue | Out-Null
							} else {
								Write-Host "      - $($lang.NotAvailable)`n" -ForegroundColor Red
							}
						}
					}
				}
				To
				{
					$newoutputfoldoer = "$($OutTo)\$($packer)"
					if (Test-Path $newoutputfoldoer -PathType Container) {
						Write-Host "   - $($lang.BeenInstl)`n"
						break
					}
					if (Test-Path $OutAny -PathType leaf) {
						Write-Host "   - $($lang.ExistingInstlPacker)"
					} else {
						Write-Host "    * $($lang.StartDown)"
						if ([string]::IsNullOrEmpty($url)) {
							Write-Host "      - $($lang.DownloadLinkError)" -ForegroundColor Red
						} else {
							Write-Host "      > $($lang.ConnectTo)`n        $url`n      + $($lang.SaveTo)`n        $OutAny"
							Invoke-WebRequest -Uri $url -OutFile $OutAny -ErrorAction SilentlyContinue | Out-Null
						}
					}
					if (Test-Path $OutAny -PathType leaf) {
						Write-Host "   - $($lang.UnzipOnly)".PadRight(28) -NoNewline
						Archive -Password $pwd -filename $OutAny -to $newoutputfoldoer
						Remove-Item -path $OutAny -force -ErrorAction SilentlyContinue
					} else {
						Write-Host "   - $($lang.ErrorDown)`n" -ForegroundColor Red
					}
				}
				Unzip
				{
					if (Test-Path $OutAny -PathType leaf) {
						Write-Host "   - $($lang.ExistingPacker)"
					} else {
						Write-Host "    * $($lang.StartDown)"
						if ([string]::IsNullOrEmpty($url)) {
							Write-Host "      - $($lang.DownloadLinkError)" -ForegroundColor Red
						} else {
							if (Test_URI $url) {
								Write-Host "      > $($lang.ConnectTo)`n        $url`n      + $($lang.SaveTo)`n        $OutAny"
								Check_Folder -chkpath $OutTo
								Invoke-WebRequest -Uri $url -OutFile $OutAny -ErrorAction SilentlyContinue | Out-Null
							} else {
								Write-Host "      - $($lang.NotAvailable)`n" -ForegroundColor Red
							}
						}
					}
					if (Test-Path $OutAny -PathType leaf) {
						Write-Host "   - $($lang.UnzipOnly)".PadRight(28) -NoNewline
						Archive -Password $pwd -filename $OutAny -to $OutTo
						Remove-Item -path $OutAny -force -ErrorAction SilentlyContinue
					} else {
						Write-Host "   - $($lang.ErrorDown)`n" -ForegroundColor Red
					}
				}
			}
		}
		default
		{
			if (Test-Path $OutAny -PathType Leaf) {
				Open_Apps -filename $OutAny -param $param -mode $mode -Before $Before -After $After
			} else {
				Write-Host "    * $($lang.StartDown)"
				if ([string]::IsNullOrEmpty($url)) {
					Write-Host "      - $($lang.DownloadLinkError)`n" -ForegroundColor Red
				} else {
					Write-Host "      > $($lang.ConnectTo)`n        $url"
					if (Test_URI $url) {
						Write-Host "      + $($lang.SaveTo)`n        $OutAny"
						Check_Folder -chkpath $OutTo
						Invoke-WebRequest -Uri $url -OutFile $OutAny -ErrorAction SilentlyContinue | Out-Null
						Open_Apps -filename $OutAny -param $param -mode $mode -Before $Before -After $After
					} else {
						Write-Host "      - $($lang.NotAvailable)`n" -ForegroundColor Red
					}
				}
			}
		}
	}
}


<#
	.Set interface
	.设置界面
#>
Function Setting_UI
{
	Get_Architecture
	Setting_Init_Disk_Free
	Setting_Init_Disk_Available
	Install_Init_Disk_To

	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	[System.Windows.Forms.Application]::EnableVisualStyles()

	Function Setting_Init_Disk_To
	{
		$GetDiskTo = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskTo"

		$FormSelectDiSKPane1.controls.Clear()
		Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object {
			if (Test_Available_Disk -Path $_.Root) {
				$RadioButton  = New-Object System.Windows.Forms.RadioButton -Property @{
					Height    = 22
					Width     = 430
					Text      = $_.Root
					Tag       = $_.Description
				}

				if ($_.Root -eq $GetDiskTo) {
					$RadioButton.Checked = $True
				}

				if ($FormSelectDiSKLowSize.Checked) {
					if (-not (Verify_Available_Size -Disk $_.Root -Size $SelectLowSize.Text)) {
						$RadioButton.Enabled = $False
					}
				}
				$FormSelectDiSKPane1.controls.AddRange($RadioButton)
			}
		}
	}
	$GetDiskAvailable_Click = {
		if ($FormSelectDiSKLowSize.Checked) {
			$SelectLowSize.Enabled = $True
			Setting_Set_Disk_Available -Status "True"
		} else {
			$SelectLowSize.Enabled = $False
			Setting_Set_Disk_Available -Status "False"
		}
		Setting_Init_Disk_To
	}
	$SelectLowSizeClick = {
		Setting_Set_Disk_Free -Size $SelectLowSize.Text
		Setting_Init_Disk_To
	}
	$Canel_Click = {
		$FormSelectDiSK.Close()
	}
	$OK_ArchitectureARM64_Click = {
		$SoftwareTipsErrorMsg.Text = $lang.SelectArm64
	}
	$OK_ArchitectureAMD64_Click = {
		$SoftwareTipsErrorMsg.Text = $lang.SelectAMD64
	}
	$OK_ArchitectureX86_Click = {
		$SoftwareTipsErrorMsg.Text = $lang.Selectx86
	}
	$OK_Click = {
		if ($ArchitectureARM64.Checked) { Set_Architecture -Type "ARM64" }
		if ($ArchitectureAMD64.Checked) { Set_Architecture -Type "AMD64" }
		if ($ArchitectureX86.Checked) { Set_Architecture -Type "x86" }

		$FormSelectDiSKPane1.Controls | ForEach-Object {
			if ($_ -is [System.Windows.Forms.RadioButton]) {
				if ($_.Enabled) {
					if ($_.Checked) {
						$FormSelectDiSK.Hide()
						SetNewFreeDiskTo -Disk $_.Text
						$FormSelectDiSK.Close()
					}
				}
			}
		}
		$ErrorMsg.Text = "$($lang.SelectFromError -f $($lang.SelectNoDisk))"
	}
	$FormSelectDiSK    = New-Object system.Windows.Forms.Form -Property @{
		autoScaleMode  = 2
		Height         = 720
		Width          = 550
		Text           = $lang.Setting
		MaximizeBox    = $False
		StartPosition  = "CenterScreen"
		MinimizeBox    = $false
		BackColor      = "#ffffff"
	}
	$ArchitectureTitle = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 490
		Text           = $lang.PreferredDownload
		Location       = '10,10'
	}
	$GroupArchitecture = New-Object system.Windows.Forms.Panel -Property @{
		BorderStyle    = 0
		Height         = 28
		Width          = 505
		autoSizeMode   = 1
		Padding        = 8
		Location       = '10,35'
	}
	$ArchitectureARM64 = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 60
		Text           = "arm64"
		Location       = '10,0'
		add_Click      = $OK_ArchitectureARM64_Click
	}
	$ArchitectureAMD64 = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 60
		Text           = "x64"
		Location       = '80,0'
		add_Click      = $OK_ArchitectureAMD64_Click
	}
	$ArchitectureX86    = New-Object System.Windows.Forms.RadioButton -Property @{
		Height         = 22
		Width          = 60
		Text           = "x86"
		Location       = '140,0'
		add_Click      = $OK_ArchitectureX86_Click
	}
	$SoftwareTips      = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 40
		Width          = 491
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $False
		Padding        = "8,0,8,0"
		Dock           = 0
		Location       = '24,65'
	}
	$SoftwareTipsErrorMsg = New-Object system.Windows.Forms.Label -Property @{
		AutoSize       = 1
		Text           = ""
	}
	$FormSelectDiSKSize = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 395
		Text           = $lang.SelectAutoAvailable
		Location       = '10,115'
	}
	$FormSelectDiSKLowSize = New-Object System.Windows.Forms.CheckBox -Property @{
		Height         = 22
		Width          = 400
		Text           = $lang.SelectCheckAvailable
		Location       = '26,140'
		add_Click      = $GetDiskAvailable_Click
	}
	$SelectLowSize     = New-Object System.Windows.Forms.NumericUpDown -Property @{
		Height         = 22
		Width          = 60
		Location       = "45,165"
		Value          = 1
		Minimum        = 1
		Maximum        = 999999
		TextAlign      = 1
		add_Click      = $SelectLowSizeClick
	}
	$SelectLowUnit     = New-Object System.Windows.Forms.Label -Property @{
		Height         = 22
		Width          = 80
		Text           = "GB"
		Location       = "115,168"
	}
	$FormSelectDiSKTitle = New-Object system.Windows.Forms.LinkLabel -Property @{
		Height         = 22
		Width          = 380
		Text           = $lang.ChangeInstallDisk
		Location       = '24,205'
		LinkColor      = "GREEN"
		ActiveLinkColor = "RED"
		LinkBehavior   = "NeverUnderline"
		add_Click      = { Setting_Init_Disk_To }
	}
	$FormSelectDiSKPane1 = New-Object system.Windows.Forms.FlowLayoutPanel -Property @{
		Height         = 320
		Width          = 490
		BorderStyle    = 0
		autoSizeMode   = 0
		autoScroll     = $true
		Padding        = "8,0,8,0"
		Dock           = 0
		Location       = '24,228'
	}
	$ErrorMsg          = New-Object system.Windows.Forms.Label -Property @{
		Location       = "8,570"
		Height         = 22
		Width          = 408
		Text           = ""
	}
	$Start             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,595"
		Height         = 36
		Width          = 515
		add_Click      = $OK_Click
		Text           = $lang.OK
	}
	$Canel             = New-Object system.Windows.Forms.Button -Property @{
		UseVisualStyleBackColor = $True
		Location       = "8,635"
		Height         = 36
		Width          = 515
		add_Click      = $Canel_Click
		Text           = $lang.Cancel
	}
	$FormSelectDiSK.controls.AddRange((
		$ArchitectureTitle,
		$GroupArchitecture,
		$SoftwareTips,
		$FormSelectDiSKSize,
		$FormSelectDiSKLowSize,
		$SelectLowSize,
		$SelectLowUnit,
		$FormSelectDiSKTitle,
		$FormSelectDiSKPane1,
		$ErrorMsg,
		$Start,
		$Canel
	))
	$SoftwareTips.controls.AddRange((
		$SoftwareTipsErrorMsg
	))
	$GroupArchitecture.controls.AddRange((
		$ArchitectureARM64,
		$ArchitectureAMD64,
		$ArchitectureX86
	))

	switch ($Global:InstlArchitecture) {
		"ARM64" {
			$ArchitectureARM64.Checked = $True
		}
		"AMD64" {
			if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") {
				$ArchitectureARM64.Enabled = $True
			} else {
				$ArchitectureARM64.Enabled = $False
			}

			$ArchitectureAMD64.Checked = $True
		}
		Default {
			if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") {
				$ArchitectureARM64.Enabled = $True
			} else {
				$ArchitectureARM64.Enabled = $False
			}
			
			if ($env:PROCESSOR_ARCHITECTURE -eq "AMD64") {
				$ArchitectureAMD64.Enabled = $True
			} else {
				$ArchitectureAMD64.Enabled = $False
			}

			$ArchitectureX86.Checked = $True
		}
	}

	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskMinSize" -ErrorAction SilentlyContinue) {
		$GetDiskMinSize = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskMinSize"
		$SelectLowSize.Text = $GetDiskMinSize
	} else {
		Setting_Set_Disk_Free -Size $Global:DiskMinSize
	}

	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskStatus" -ErrorAction SilentlyContinue) {
		switch (Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskStatus" -ErrorAction SilentlyContinue) {
			"True" {
				$FormSelectDiSKLowSize.Checked = $True
				$SelectLowSize.Enabled = $True
			}
			"False" {
				$FormSelectDiSKLowSize.Checked = $False
				$SelectLowSize.Enabled = $False
			}
		}
	} else {
		$FormSelectDiSKLowSize.Checked = $True
		$SelectLowSize.Enabled = $True
	}

	Setting_Init_Disk_To

	switch ($Global:IsLang) {
		"zh-CN" {
			$FormSelectDiSK.Font = New-Object System.Drawing.Font("Microsoft YaHei", 9, [System.Drawing.FontStyle]::Regular)
		}
		Default {
			$FormSelectDiSK.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Regular)
		}
	}

	if (Test-Path -Path "$($PSScriptRoot)\..\..\icons\Engine.ico" -PathType Leaf) {
		$FormSelectDiSK.icon = New-Object system.drawing.icon("$($PSScriptRoot)\..\..\icons\Engine.ico")
	}

	$FormSelectDiSK.FormBorderStyle = 'Fixed3D'
	$FormSelectDiSK.ShowDialog() | Out-Null
}

<#
	.系统结构
	.System structure
#>
Function Get_Architecture
{
	<#
		.从注册表获取：用户指定系统架构
		.Obtain from the registry: user-specified system architecture
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "Architecture" -ErrorAction SilentlyContinue) {
		$Global:InstlArchitecture = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "Architecture"
		return
	}

	<#
		.初始化：系统架构
		.Initialization: system architecture
	#>
	Set_Architecture -Type $env:PROCESSOR_ARCHITECTURE
}

<#
	.设置系统架构
	.Set up the system architecture
#>
Function Set_Architecture
{
	param
	(
		[string]$Type
	)

	$FullPath = "HKCU:\SOFTWARE\$($Global:UniqueID)\Install"

	if (-not (Test-Path $FullPath)) {
		New-Item -Path $FullPath -Force -ErrorAction SilentlyContinue | Out-Null
	}
	New-ItemProperty -LiteralPath $FullPath -Name "Architecture" -Value $Type -PropertyType String -Force -ea SilentlyContinue | Out-Null

	$Global:InstlArchitecture = $Type
}

<#
	.自动选择磁盘
	.Automatically select disk
#>
Function Install_Init_Disk_To
{
	<#
		.从注册表里获取：选择的磁盘并判断，如果是强行设置磁盘，跳过检查剩余磁盘空间了，继续
		.Obtain from the registry: select the disk and judge, if the disk is forcibly set, skip checking the remaining disk space, continue
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskTo" -ErrorAction SilentlyContinue) {
		$GetDiskTo = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskTo"
		if (Test_Available_Disk -Path $GetDiskTo) {
			$Global:FreeDiskTo = $GetDiskTo
			return
		}
	}

	<#
		.搜索磁盘条件，排除系统盘
		.Search disk conditions, exclude system disks
	#>
	$drives = Get-PSDrive -PSProvider FileSystem | Where-Object { -not ((Join_MainFolder -Path $env:SystemDrive) -eq $_.Root) } | Select-Object -ExpandProperty 'Root'

	<#
		.从注册表里获取是否检查磁盘可用空间
		.Get from the registry whether to check the disk free space
	#>
	$GetDiskStatus = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskStatus"

	<#
		.从注册表里获取选择的磁盘
		Get the selected disk from the registry
	#>
	$GetDiskMinSize = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskMinSize"

	<#
		.搜索磁盘条件，排除系统盘
		.Search disk conditions, exclude system disks
	#>
	$FlagsSearchNewDisk = $False
	foreach ($item in $drives) {
		if (Test_Available_Disk -Path $item) {
			$FlagsSearchNewDisk = $True

			if (Verify_Available_Size -Disk $item -Size $GetDiskMinSize) {
				SetNewFreeDiskTo -Disk $item
				return
			}
		}
	}

	<#
		.未找到可用磁盘，初始化：当前系统盘
		.No available disk found, initialization: current system disk
	#>
	if (-not ($FlagsSearchNewDisk)) {
		SetNewFreeDiskTo -Disk (Join_MainFolder -Path $env:SystemDrive)
	}
}

Function SetNewFreeDiskTo
{
	param
	(
		[string]$Disk
	)

	$FullPath = "HKCU:\SOFTWARE\$($Global:UniqueID)\Install"

	if (-not (Test-Path $FullPath)) {
		New-Item -Path $FullPath -Force -ErrorAction SilentlyContinue | Out-Null
	}
	New-ItemProperty -LiteralPath $FullPath -Name "DiskTo" -Value $Disk -PropertyType String -Force -ea SilentlyContinue | Out-Null

	$Global:FreeDiskTo = $Disk
}

Function Setting_Init_Disk_Free
{
	<#
		.从注册表里获取选择的磁盘并判断，如果是强行设置磁盘，跳过检查剩余磁盘空间了，继续
		.Obtain the selected disk from the registry and judge. If the disk is forcibly set, skip checking the remaining disk space and continue
	#>
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskMinSize" -ErrorAction SilentlyContinue) {
		$GetDiskMinSize = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskMinSize"

		if ([string]::IsNullOrEmpty($GetDiskMinSize)) {
			Setting_Set_Disk_Free -Size $Global:DiskMinSize
		}

		if (-not ($GetDiskMinSize -ge $Global:DiskMinSize)) {
			Setting_Set_Disk_Free -Size $Global:DiskMinSize
		}
	} else {
		Setting_Set_Disk_Free -Size $Global:DiskMinSize
	}
}

Function Setting_Set_Disk_Free
{
	param
	(
		[string]$Size
	)

	$FullPath = "HKCU:\SOFTWARE\$($Global:UniqueID)\Install"

	if (-not (Test-Path $FullPath)) {
		New-Item -Path $FullPath -Force -ErrorAction SilentlyContinue | Out-Null
	}
	New-ItemProperty -LiteralPath $FullPath -Name "DiskMinSize" -Value $Size -PropertyType String -Force -ea SilentlyContinue | Out-Null
}

<#
	.Get from the registry whether to check the disk free space
	.从注册表里获取是否检查磁盘可用空间
#>
Function Setting_Init_Disk_Available
{
	if (Get-ItemProperty -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskStatus" -ErrorAction SilentlyContinue) {
		$GetDiskStatus = Get-ItemPropertyValue -Path "HKCU:\SOFTWARE\$($Global:UniqueID)\Install" -Name "DiskStatus"

		if ([string]::IsNullOrEmpty($GetDiskStatus)) {
			Setting_Set_Disk_Available -Status "True"
		} else {
			$Global:FreeDiskStatus = $GetDiskStatus
		}
	} else {
		Setting_Set_Disk_Available -Status "True"
	}
}

<#
	.Set free disk
	.设置可用磁盘
#>
Function Setting_Set_Disk_Available
{
	param
	(
		[string]$Status
	)

	$FullPath = "HKCU:\SOFTWARE\$($Global:UniqueID)\Install"

	if (-not (Test-Path $FullPath)) {
		New-Item -Path $FullPath -Force -ErrorAction SilentlyContinue | Out-Null
	}
	New-ItemProperty -LiteralPath $FullPath -Name "DiskStatus" -Value $Status -PropertyType String -Force -ea SilentlyContinue | Out-Null

	$Global:FreeDiskStatus = $Status
}

<#
	.验证可用磁盘大小
	.Verify the available disk size
#>
Function Verify_Available_Size
{
	param
	(
		[string]$Disk,
		[int]$Size
	)

	$TempCheckVerify = $false

	Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | Where-Object { ((Join_MainFolder -Path $Disk) -eq $_.Root) } | ForEach-Object {
		if ($_.Free -gt (Convert_Size -From GB -To Bytes $Size)) {
			$TempCheckVerify = $True
		} else {
			$TempCheckVerify = $false
		}
	}

	return $TempCheckVerify
}

<#
	.Convert disk space size
	.转换磁盘空间大小
#>
Function Convert_Size
{
	param
	(
		[validateset("Bytes","KB","MB","GB","TB")]
		[string]$From,
		[validateset("Bytes","KB","MB","GB","TB")]
		[string]$To,
		[Parameter(Mandatory=$true)]
		[double]$Value,
		[int]$Precision = 4
	)
	switch($From) {
		"Bytes" { $value = $Value }
		"KB" { $value = $Value * 1024 }
		"MB" { $value = $Value * 1024 * 1024 }
		"GB" { $value = $Value * 1024 * 1024 * 1024 }
		"TB" { $value = $Value * 1024 * 1024 * 1024 * 1024 }
	}
	switch ($To) {
		"Bytes" { return $value }
		"KB" { $Value = $Value/1KB }
		"MB" { $Value = $Value/1MB }
		"GB" { $Value = $Value/1GB }
		"TB" { $Value = $Value/1TB }
	}

	return [Math]::Round($value,$Precision,[MidPointRounding]::AwayFromZero)
}

<#
	.Create a temporary file to determine whether the disk is readable or not
	.创建临时文件，判断磁盘是否可读用
#>
Function Test_Available_Disk
{
	param
	(
		[string]$Path
	)

	try {
		New-Item -Path $Path -ItemType Directory -ErrorAction SilentlyContinue | Out-Null

		$RandomGuid = [guid]::NewGuid()
		$test_tmp_filename = "writetest-$($RandomGuid)"
		$test_filename = Join-Path -Path "$($Path)" -ChildPath "$($test_tmp_filename)" -ErrorAction SilentlyContinue

		[io.file]::OpenWrite($test_filename).close()

		if (Test-Path $test_filename -PathType Leaf)
		{
			Remove-Item $test_filename -ErrorAction SilentlyContinue
			return $true
		}
		$false
	} catch {
		return $false
	}
}

<#
	.Join URL
	.加入网址
#>
Function Join_Url
{
	param
	(
		[parameter(Mandatory = $True, HelpMessage = "Base Path")]
		[ValidateNotNullOrEmpty()]
		[string]$Path,
		[parameter(Mandatory = $True, HelpMessage = "Child Path or Item Name")]
		[ValidateNotNullOrEmpty()]
		[string]$ChildPath
	)
	if ($Path.EndsWith('/')) {
		return "$Path" + "$ChildPath"
	} else {
		return "$Path/$ChildPath"
	}
}

<#
	.Test if the URL address is available
	.测试 URL 地址是否可用
#>
Function Test_URI
{
	Param
	(
		[Parameter(Position=0,Mandatory,HelpMessage="HTTP or HTTPS")]
		[ValidatePattern( "^(http|https)://" )]
		[Alias("url")]
		[string]$URI,
		[Parameter(ParameterSetName="Detail")]
		[Switch]$Detail,
		[ValidateScript({$_ -ge 0})]
		[int]$Timeout = 30
	)
	Process
	{
		Try
		{
			$paramHash = @{
				UseBasicParsing = $True
				DisableKeepAlive = $True
				Uri = $uri
				Method = 'Head'
				ErrorAction = 'stop'
				TimeoutSec = $Timeout
			}
			$test = Invoke-WebRequest @paramHash
			if ($Detail) {
				$test.BaseResponse | Select-Object ResponseURI,ContentLength,ContentType,LastModified, @{Name="Status";Expression={$Test.StatusCode}}
			} else {
				if ($test.statuscode -ne 200) { $False } else { $True }
			}
		} Catch {
			write-verbose -message $_.exception
			if ($Detail) {
				$objProp = [ordered]@{
					ResponseURI = $uri
					ContentLength = $null
					ContentType = $null
					LastModified = $null
					Status = 404
				}
				New-Object -TypeName psobject -Property $objProp
			} else { $False }
		}
	}
}

<#
	.Wait for the queue to complete
	.等待队列完成
#>
Function Wait_Process_End
{
	Write-Host "`n   $($lang.WaitQueue)"
	for ($i=0; $i -lt $Global:AppQueue.Count; $i++) {
		Write-Host "    * PID: $($Global:AppQueue[$i]['ID'])".PadRight(16) -NoNewline
		if ((Get-Process -ID $($Global:AppQueue[$i]['ID']) -ErrorAction SilentlyContinue).Path -eq $Global:AppQueue[$i]['PATH']) {
			Wait-Process -id $($Global:AppQueue[$i]['ID']) -ErrorAction SilentlyContinue
		}
		Write-Host "    $($lang.Done)" -ForegroundColor Green
	}
	$Global:AppQueue = @()
}

<#
	.Run any application
	.运行任意应用程序
#>
Function Open_Apps
{
	param
	(
		$filename,
		$param,
		$mode,
		$Before,
		$After
	)

	if (Test-Path $filename -PathType Leaf) {
		Switch ($mode)
		{
			Fast
			{
				Write-Host "   - $($lang.QucikRun)"
				if (([string]::IsNullOrEmpty($param))) {
					Write-Host "     $filename`n"
					Start-Process -FilePath $filename
				} else {
					Write-Host "   - $($lang.Parameter)`n     $param`n"
					Start-Process -FilePath $filename -ArgumentList $param
				}
			}
			Wait
			{
				Write-Host "   - $($lang.WaitDone)`n     $filename"
				if (([string]::IsNullOrEmpty($param))) {
					Start-Process -FilePath $filename -Wait
				} else {
					Write-Host "   - $($lang.Parameter)`n     $param`n"
					Start-Process -FilePath $filename -ArgumentList $param -Wait
				}
			}
			Queue
			{
				Write-Host "   - $($lang.QucikRun)`n     $filename"
				if (([string]::IsNullOrEmpty($param))) {
					$AppRunQueue = Start-Process -FilePath $filename -passthru
					$Global:AppQueue += @{
						ID="$($AppRunQueue.Id)";
						PATH="$($filename)"
					}
					Write-Host "   - $($lang.AddQueue)$($AppRunQueue.Id)`n"
				} else {
					$AppRunQueue = Start-Process -FilePath $filename -ArgumentList $param -passthru
					$Global:AppQueue += @{
						ID="$($AppRunQueue.Id)";
						PATH="$($filename)"
					}
					Write-Host "   - $($lang.Parameter)`n     $param`n   - $($lang.AddQueue)$($AppRunQueue.Id)`n"
				}
			}
		}
	} else {
		Write-Host "   - $($lang.InstlNo)$filename`n" -ForegroundColor Red
	}

	switch ($After)
	{
		"Chrome"
		{
#			stop-service "GoogleChromeElevationService" -force -NoWait -ErrorAction SilentlyContinue | Out-Null
#			stop-service "gupdate" -force -NoWait -ErrorAction SilentlyContinue | Out-Null
#			stop-service "gupdatem" -force -NoWait -ErrorAction SilentlyContinue | Out-Null
#			set-service "GoogleChromeElevationService" -startuptype disabled -ErrorAction SilentlyContinue | Out-Null
#			set-service "gupdate" -startuptype disabled -ErrorAction SilentlyContinue | Out-Null
#			set-service "gupdatem" -startuptype disabled -ErrorAction SilentlyContinue | Out-Null
#			Disable-ScheduledTask -TaskPath "\" -TaskName "GoogleUpdateTaskMachineCore" -ErrorAction SilentlyContinue | Out-Null
#			Disable-ScheduledTask -TaskPath "\" -TaskName "GoogleUpdateTaskMachineUA" -ErrorAction SilentlyContinue | Out-Null
		}
	}
}